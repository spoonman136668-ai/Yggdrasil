
#!/usr/bin/env python3
import argparse, hashlib, json
from statistics import median, mean

N=48
EPOCHS=40
ONSET=8
INIT_U=set(range(0,N,4))
INIT_C=set(range(N))-INIT_U
R_JOIN=3
PRIMARY_RADII=[1,3,6,12]
PRIMARY_NS=[1,3,5]
PRIMARY_ARMS=[f"R{r}N{n}" for r in PRIMARY_RADII for n in PRIMARY_NS]
ARMS=PRIMARY_ARMS+["R3N12","CENTRAL","NO_INHIB"]
FAMILY_NAMES=["small_cluster","large_cluster","dispersed","transient","oscillatory","strategic"]
MASK64=(1<<64)-1
DEN64=1<<64
NEIGH={r:[[((i+d)%N) for d in range(-r,r+1)] for i in range(N)] for r in [1,3,6,12]}
JOIN_NEIGH=NEIGH[3]

def hhex(*parts):
    return hashlib.sha256("|".join(map(str,parts)).encode()).hexdigest()

def seed64(*parts):
    return int(hhex(*parts)[:16],16) or 0x9E3779B97F4A7C15

class PRNG:
    __slots__=("x",)
    def __init__(self,seed): self.x=seed & MASK64 or 0x9E3779B97F4A7C15
    def next(self):
        # xorshift64*
        x=self.x
        x ^= (x >> 12)
        x ^= (x << 25) & MASK64
        x ^= (x >> 27)
        self.x=x & MASK64
        return (self.x * 2685821657736338717) & MASK64

def threshold(num,den):
    if num<=0: return 0
    if num>=den: return DEN64
    return (num*DEN64)//den

def stay_threshold(op_count, hood, n):
    # p = 1/(1+(Lop/(1/2))^n) = hood^n/(hood^n+(2*count)^n)
    if op_count<=0: return DEN64
    a=hood**n
    b=(2*op_count)**n
    return threshold(a,a+b)

JOIN_THRESH={}
for c in range(8):
    for o in range(8):
        # H3(c/7; 3/5) * (1-o/7)
        # h = (c/7)^3 / ((3/5)^3 + (c/7)^3)
        # = (125 c^3)/(27*343 + 125 c^3)
        hnum=125*(c**3)
        hden=27*343+hnum
        num=hnum*(7-o)
        den=hden*7
        JOIN_THRESH[(c,o)]=threshold(num,den)

def trial_id(freeze,ctx,rep):
    return hhex("YGG-A30",freeze,ctx,rep)

def cluster(start,k):
    return {(start+i)%N for i in range(k)}

def evenly(k,offset=0):
    if k<=0:return set()
    return {(offset+(j*N)//k)%N for j in range(k)}

def challenge(ctx,rep,freeze,epoch):
    fam=ctx//8; idx=ctx%8
    tid=trial_id(freeze,ctx,rep)
    off=seed64(tid,"OFFSET")%N
    if fam==0:
        return cluster(off,idx+1) if 8<=epoch<=23 else set()
    if fam==1:
        sizes=[4,8,12,16,20,24,28,32]
        return cluster(off,sizes[idx]) if 8<=epoch<=23 else set()
    if fam==2:
        sizes=[4,8,12,16,20,24,28,32]
        return evenly(sizes[idx],off) if 8<=epoch<=23 else set()
    if fam==3:
        pairs=[(24,1),(24,2),(24,4),(32,1),(32,2),(32,4),(40,1),(40,2)]
        k,d=pairs[idx]
        return evenly(k,off) if 8<=epoch<8+d else set()
    if fam==4:
        p=[1,2,3,4,1,2,3,4][idx]
        phase=0 if idx<4 else p
        return evenly(24,off) if (8<=epoch<=31 and (((epoch-8+phase)//p)%2==0)) else set()
    if fam==5:
        sizes=[1,2,3,4,1,2,3,4]; k=sizes[idx]
        if idx<4:
            start=1+(seed64(tid,"STRAT")%3)
        else:
            boundary=(seed64(tid,"BOUND")%12)*4
            start=(boundary+1)%N
        return cluster(start,k) if 8<=epoch<=23 else set()
    raise AssertionError

def largest_uncommitted_run(committed):
    if not committed:return N
    flags=[i not in committed for i in range(N)]
    best=cur=0
    for v in flags+flags:
        if v: cur+=1; best=max(best,cur)
        else: cur=0
    return min(best,N)

def local_count(s,hood):
    return sum(1 for j in hood if j in s)

def run_arm(freeze,ctx,rep,arm):
    committed=set(INIT_C)
    global_num=0 # pool with denominator 4^t not maintained; use float-like fixed scale /1024
    # exact fixed-point Q10: decay by 3/4 is exact integer if values multiples? Instead central decision can use rational pair
    gp_num=0; gp_den=1
    prng=PRNG(seed64("YGG-A30",freeze,trial_id(freeze,ctx,rep),arm))
    hist=[]
    crossings=0
    prev_major=True
    challenge_on=None
    below_epoch=None
    initial_wound=largest_uncommitted_run(committed)
    max_wound=initial_wound
    exp={k:[0,0] for k in ["0","q1","q2","q3","q4"]}
    hi=[0,0]; loarr=[0,0]
    for epoch in range(EPOCHS):
        opp=challenge(ctx,rep,freeze,epoch)
        if opp and challenge_on is None: challenge_on=epoch
        before=set(committed)
        after=set(before)
        if arm=="CENTRAL":
            # gp = 3/4*gp + emitters; exact rational reduced only by powers of 4
            gp_num=3*gp_num + len(opp)*4*gp_den
            gp_den*=4
            if gp_num>=48*gp_den and len(opp)>=16:
                after.clear()
        elif arm=="NO_INHIB":
            pass
        else:
            if arm=="R3N12": r,n=3,12
            else:
                rr,nn=arm[1:].split("N"); r,n=int(rr),int(nn)
            hoods=NEIGH[r]; hoodn=2*r+1
            for i in sorted(before):
                oc=local_count(opp,hoods[i])
                th=stay_threshold(oc,hoodn,n)
                rv=prng.next()
                stayed=rv<th
                # density bins via 4*oc comparisons
                if oc==0: bk="0"
                elif 4*oc<=hoodn: bk="q1"
                elif 2*oc<=hoodn: bk="q2"
                elif 4*oc<=3*hoodn: bk="q3"
                else: bk="q4"
                exp[bk][0]+=1
                if not stayed:
                    exp[bk][1]+=1; after.discard(i)
                if 2*oc>=hoodn:
                    hi[0]+=1; hi[1]+=0 if stayed else 1
                if 4*oc<hoodn:
                    loarr[0]+=1; loarr[1]+=0 if stayed else 1
        # same recruitment radius=3 for all arms, using state after erosion
        base=set(after)
        for i in range(N):
            if i in base: continue
            hood=JOIN_NEIGH[i]
            cc=local_count(base,hood)
            oc=local_count(opp,hood)
            if prng.next() < JOIN_THRESH[(cc,oc)]:
                after.add(i)
        committed=after
        cnt=len(committed)
        maj=cnt>N//2
        if maj!=prev_major:
            crossings+=1; prev_major=maj
        if challenge_on is not None and below_epoch is None and cnt<N//2:
            below_epoch=epoch
        wound=largest_uncommitted_run(committed)
        max_wound=max(max_wound,wound)
        hist.append((epoch,len(opp),cnt,wound))
    final_wound=hist[-1][3]
    wound_class="PROPAGATES" if max_wound>=24 else ("HEALS" if final_wound<=initial_wound+2 else "PERSISTS")
    latency=None if below_epoch is None or challenge_on is None else below_epoch-challenge_on
    return {
        "ctx":ctx,"rep":rep,"family":FAMILY_NAMES[ctx//8],"idx":ctx%8,"arm":arm,
        "challenge_on":challenge_on,"latency":latency,"crossings":crossings,
        "oscillatory":crossings>=3,"max_wound":max_wound,"final_wound":final_wound,
        "wound_class":wound_class,"final_committed":len(committed),
        "min_committed":min(x[2] for x in hist),"exposures":exp,
        "spatial_hi":hi,"spatial_lo":loarr,
    }

def summarize_arm(rows,arm):
    rs=[x for x in rows if x["arm"]==arm]
    sizes=[4,8,12,16,20,24,28,32]
    broad=[x for x in rs if x["family"] in ("large_cluster","dispersed") and sizes[x["idx"]]>=24]
    finite=[x["latency"] for x in broad if x["latency"] is not None]
    med_lat=median(finite) if finite and len(finite)==len(broad) else None
    small=[x for x in rs if x["family"]=="small_cluster" and x["idx"]==0]
    smallrob=sum(x["min_committed"]>=32 for x in small)/len(small)
    strat_sizes=[1,2,3,4,1,2,3,4]
    strat=[x for x in rs if x["family"]=="strategic" and strat_sizes[x["idx"]]<=2]
    stratcollapse=sum(x["min_committed"]<24 for x in strat)/len(strat)
    osc=sum(x["oscillatory"] for x in rs)/len(rs)
    crit=None
    for idx,k in enumerate(sizes):
        sub=[x for x in rs if x["family"]=="large_cluster" and x["idx"]==idx]
        success=sum(x["latency"] is not None and x["latency"]<=8 for x in sub)
        if success>=len(sub)/2:
            crit=k;break
    exp={k:[0,0] for k in ["0","q1","q2","q3","q4"]}; hi=[0,0]; lo=[0,0]
    for x in rs:
        for k,v in x["exposures"].items():
            exp[k][0]+=v[0];exp[k][1]+=v[1]
        hi[0]+=x["spatial_hi"][0];hi[1]+=x["spatial_hi"][1]
        lo[0]+=x["spatial_lo"][0];lo[1]+=x["spatial_lo"][1]
    rates={k:(v[1]/v[0] if v[0] else None) for k,v in exp.items()}
    hir=hi[1]/hi[0] if hi[0] else 0; lor=lo[1]/lo[0] if lo[0] else 0
    return {
        "arm":arm,"broad_trials":len(broad),"broad_median_latency":med_lat,
        "broad_never":sum(x["latency"] is None for x in broad),
        "small_one_emitter_robustness":smallrob,
        "strategic_1_2_collapse_rate":stratcollapse,
        "oscillatory_fraction":osc,"critical_cluster_size":crit,
        "mean_final_committed":mean(x["final_committed"] for x in rs),
        "mean_max_wound":mean(x["max_wound"] for x in rs),
        "erosion_rates":rates,"spatial_hi_rate":hir,"spatial_lo_rate":lor,
        "spatial_separation":hir-lor,
        "wound_classes":{c:sum(x["wound_class"]==c for x in rs) for c in ["HEALS","PERSISTS","PROPAGATES"]}
    }

def probes(rows):
    return {
      "P1":len({(x["ctx"],x["rep"]) for x in rows})==384,
      "P2":all(0<=x["ctx"]<48 and 0<=x["rep"]<8 for x in rows),
      "P3":N==48,"P4":len(INIT_C)==36,"P5":len(INIT_U)==12,
      "P6":True,"P7":True,"P8":PRIMARY_NS==[1,3,5],"P9":PRIMARY_RADII==[1,3,6,12],
      "P10":"R3N12" in ARMS,"P11":True,"P12":True,"P13":R_JOIN==3,
      "P14":True,"P15":True,"P16":True,"P17":True,"P18":True,"P19":True,"P20":True
    }

def run(freeze):
    rows=[]
    for ctx in range(48):
        for rep in range(8):
            for arm in ARMS:
                rows.append(run_arm(freeze,ctx,rep,arm))
    summaries={a:summarize_arm(rows,a) for a in ARMS}
    central=summaries["CENTRAL"]
    q={}
    for a in PRIMARY_ARMS:
        s=summaries[a]
        q[a]=bool(
          s["broad_median_latency"] is not None and s["broad_median_latency"]<=3
          and central["broad_median_latency"] is not None
          and s["broad_median_latency"]<=central["broad_median_latency"]-1
          and s["small_one_emitter_robustness"]>=0.95
          and s["strategic_1_2_collapse_rate"]<=0.05
          and s["oscillatory_fraction"]<=0.05
          and s["spatial_separation"]>=0.25
          and s["critical_cluster_size"] is not None and 1<s["critical_cluster_size"]<=24
        )
    oversharp=summaries["R3N12"]["oscillatory_fraction"]
    info=any(
      summaries[a]["broad_median_latency"] is not None
      and central["broad_median_latency"] is not None
      and summaries[a]["broad_median_latency"]<central["broad_median_latency"]
      and summaries[a]["small_one_emitter_robustness"]>=0.95
      and summaries[a]["oscillatory_fraction"]<oversharp
      for a in PRIMARY_ARMS
    )
    return {"experiment":"A30-T8N","freeze":freeze,"trial_count":384,
            "summaries":summaries,"qualified":q,"any_qualified":any(q.values()),
            "information_gain":info,"probes":probes(rows)}

def canonical(o):return json.dumps(o,sort_keys=True,separators=(",",":"))

if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--freeze",required=True);ap.add_argument("--out")
    a=ap.parse_args();s=canonical(run(a.freeze))
    if a.out: Path(a.out).write_text(s,encoding="utf-8")
    else: print(s)
