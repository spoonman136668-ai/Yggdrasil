
#!/usr/bin/env python3
from fractions import Fraction
import hashlib, json, statistics, sys

CONTEXTS=48
REPLICAS=8
CELLS=12
EPOCHS=40
BLOCK=4
REPL=4
DECAY=Fraction(3,4)
COMMIT=Fraction(20,1)
OPP_CEIL=Fraction(8,1)
K=Fraction(12,1)

def h(seed,*parts):
    s="|".join([seed]+[str(x) for x in parts]).encode()
    return hashlib.sha256(s).digest()

def u(seed,*parts):
    x=int.from_bytes(h(seed,*parts)[:8],"big")
    return x/2**64

def choice3(seed,*parts):
    x=u(seed,*parts)
    return -1 if x<1/3 else (0 if x<2/3 else 1)

def subset2(seed,trial,block):
    scores=[(h(seed,"subset",trial,block,i),i) for i in range(4)]
    return tuple(sorted(i for _,i in sorted(scores)[:2]))

def context_params(c):
    base=((c%8)-3.5)/7.0          # -0.5..+0.5
    niche=((c//8)%6)-2.5
    niche=niche/5.0               # -0.5..+0.5
    drift=((c*7)%11-5)/10.0       # -0.5..+0.5
    return base,niche,drift

def local_true(seed,c,r,cid,t):
    base,niche_bias,drift=context_params(c)
    block=t//4
    niche=cid%4
    # deterministic slow environment mode with persistence inside 4-epoch blocks
    env_raw=u(seed,"env",c,r,block)
    env=-1 if env_raw<0.30 else (0 if env_raw<0.62 else 1)
    local=(niche-1.5)/3.0*niche_bias
    phase=((r*3+c)%7-3)/8.0
    z=0.70*base + 0.55*env + 0.35*local + 0.25*drift*((block-4.5)/4.5) + phase
    # cell-specific bounded perturbation
    q=u(seed,"truth",c,r,cid,t)
    if q<0.18: z-=0.45
    elif q>0.82: z+=0.45
    if z>0.35: return 1
    if z<-0.35: return -1
    return 0

def sensed(seed,c,r,cid,t,true):
    n=choice3(seed,"sensor",c,r,cid,t)
    # mostly faithful bounded sensor; noise enters at half strength then clips sign
    z=true + (1 if n>0 and u(seed,"sn",c,r,cid,t)<0.28 else 0) - (1 if n<0 and u(seed,"sn2",c,r,cid,t)<0.28 else 0)
    return 1 if z>0 else (-1 if z<0 else 0)

def repl_ids(seed,c,r,block):
    # four unique IDs, cycling all identities with hash rotation
    rot=int.from_bytes(h(seed,"repl",c,r,block)[:4],"big")%CELLS
    return tuple((rot+i*3)%CELLS for i in range(4))

def assign_policies(ctrl, state, seed, trial, block):
    if state=="U":
        sub=(0,1) if ctrl=="NO_HET" else subset2(seed,trial,block)
        return tuple("C" if i in sub else "S" for i in range(4))
    if state=="C":
        return ("C","C","C","S")
    return ("S","S","S","S")

def block_sign_policy(state,hist_sign,block_delta,seed,trial,block):
    sign=1 if block_delta>0 else (-1 if block_delta<0 else 0)
    hist=(hist_sign+[sign])[-3:]
    new=state
    if state=="U":
        if len(hist)>=2 and hist[-2:]==[1,1]: new="C"
        elif len(hist)>=2 and hist[-2:]==[-1,-1]: new="S"
    elif state=="C":
        if len(hist)>=3 and hist[-3:]==[-1,-1,-1]: new="U"
    elif state=="S":
        if len(hist)>=3 and hist[-3:]==[1,1,1]: new="U"
    return new,hist

def run_trial(seed,c,r,ctrl):
    trial=c*REPLICAS+r
    policies=["S"]*CELLS
    state="U" if ctrl!="STATIC_C3" else "C"
    C=Fraction(0); S=Fraction(0)
    seen_base={}
    hist=[]
    total=0
    cum=0
    worst=0
    epoch_states=[]
    transitions=[]
    contradictory=0
    contrad_u=0
    commit_count=retreat_count=recommit=0
    ever_committed=False
    poolC=[]; poolS=[]; emit_counts=[]
    subsets=set()
    block_delta=0
    end_full_candidate_delta=0

    for t in range(EPOCHS):
        block=t//BLOCK
        if t%BLOCK==0:
            ids=repl_ids(seed,c,r,block)
            if ctrl=="STATIC_C3":
                ass=("C","C","C","S")
            elif ctrl=="BLOCK_SIGN":
                ass=assign_policies("POOL_FULL",state,seed,trial,block)
                if state=="U": subsets.add(tuple(i for i,x in enumerate(ass) if x=="C"))
            else:
                ass=assign_policies(ctrl,state,seed,trial,block)
                if state=="U": subsets.add(tuple(i for i,x in enumerate(ass) if x=="C"))
            for cid,p in zip(ids,ass): policies[cid]=p

        base_c=base_s=fb_c=fb_s=0
        active=set()
        epoch_delta=0
        full_delta=0

        for cid in range(CELLS):
            tr=local_true(seed,c,r,cid,t)
            full_delta += tr
            se=sensed(seed,c,r,cid,t,tr)
            if se>0:
                if ctrl=="NO_FREQ":
                    key=(block,cid,"C")
                    if key not in seen_base:
                        base_c+=1; seen_base[key]=1; active.add(cid)
                else:
                    base_c+=1; active.add(cid)
            elif se<0:
                if ctrl=="NO_FREQ":
                    key=(block,cid,"S")
                    if key not in seen_base:
                        base_s+=1; seen_base[key]=1; active.add(cid)
                else:
                    base_s+=1; active.add(cid)

            if ctrl not in ("NO_PF","BLOCK_SIGN","STATIC_C3"):
                if state=="C" and policies[cid]=="C" and se>=0:
                    fb_c+=1
                elif state=="S" and policies[cid]=="S" and se<=0:
                    fb_s+=1

            if policies[cid]=="C":
                epoch_delta += tr

        end_full_candidate_delta += full_delta
        total += epoch_delta
        cum += epoch_delta
        worst=min(worst,cum)
        block_delta += epoch_delta

        if ctrl not in ("BLOCK_SIGN","STATIC_C3"):
            C = DECAY*C + base_c + fb_c
            S = DECAY*S + base_s + fb_s
            poolC.append(C); poolS.append(S); emit_counts.append(len(active))

            both=(C>=K and S>=K)
            if both:
                contradictory+=1
                if state=="U": contrad_u+=1

            old=state
            if state=="U":
                if len(active)>=6 and C>=COMMIT and S<=OPP_CEIL and C>=2*S:
                    state="C"; commit_count+=1
                    if ever_committed: recommit+=1
                    ever_committed=True
                elif len(active)>=6 and S>=COMMIT and C<=OPP_CEIL and S>=2*C:
                    state="S"; commit_count+=1
                    if ever_committed: recommit+=1
                    ever_committed=True
            elif state=="C":
                I=(S*S)/(K*K+S*S) if S else Fraction(0)
                if I>=Fraction(1,2) and base_s>=4:
                    state="U"; retreat_count+=1
            elif state=="S":
                I=(C*C)/(K*K+C*C) if C else Fraction(0)
                if I>=Fraction(1,2) and base_c>=4:
                    state="U"; retreat_count+=1
            if state!=old: transitions.append((t,old,state))
        elif ctrl=="BLOCK_SIGN" and (t%BLOCK)==BLOCK-1:
            old=state
            state,hist=block_sign_policy(state,hist,block_delta,seed,trial,block)
            if state!=old: transitions.append((t,old,state))
            block_delta=0

        epoch_states.append(state)

    return {
        "delta":total,"worst":worst,"end":state,
        "full_candidate_delta":end_full_candidate_delta,
        "states":epoch_states,"transitions":transitions,
        "contradictory":contradictory,"contrad_u":contrad_u,
        "commits":commit_count,"retreats":retreat_count,"recommits":recommit,
        "meanC":float(sum(poolC,Fraction(0))/len(poolC)) if poolC else None,
        "meanS":float(sum(poolS,Fraction(0))/len(poolS)) if poolS else None,
        "maxC":float(max(poolC)) if poolC else None,
        "maxS":float(max(poolS)) if poolS else None,
        "emit_mean":statistics.mean(emit_counts) if emit_counts else None,
        "subsets":sorted(list(subsets)),
    }

def summarize(rows):
    ds=[x["delta"] for x in rows]
    harmful=sum(d<0 for d in ds)
    beneficial=sum(d>0 for d in ds)
    neutral=len(ds)-harmful-beneficial
    out={
        "aggregate_delta":sum(ds),
        "beneficial":beneficial,"neutral":neutral,"harmful":harmful,
        "harm_rate":harmful/len(ds),
        "worst_drawdown":min(x["worst"] for x in rows),
        "mean_delta":statistics.mean(ds),
        "median_delta":statistics.median(ds),
    }
    if rows[0]["meanC"] is not None:
        ends=collections_counter(x["end"] for x in rows)
        out.update({
            "end_states":ends,
            "contradictory_epochs":sum(x["contradictory"] for x in rows),
            "contradictory_u_fraction":(
                sum(x["contrad_u"] for x in rows)/sum(x["contradictory"] for x in rows)
                if sum(x["contradictory"] for x in rows) else 1.0),
            "commits":sum(x["commits"] for x in rows),
            "retreats":sum(x["retreats"] for x in rows),
            "recommits":sum(x["recommits"] for x in rows),
            "mean_C_pool":statistics.mean(x["meanC"] for x in rows),
            "mean_S_pool":statistics.mean(x["meanS"] for x in rows),
            "max_C_pool":max(x["maxC"] for x in rows),
            "max_S_pool":max(x["maxS"] for x in rows),
            "mean_active_emitters":statistics.mean(x["emit_mean"] for x in rows),
            "false_candidate_commit":sum(x["end"]=="C" and x["delta"]<0 for x in rows),
            "false_stale_commit":sum(x["end"]=="S" and x["full_candidate_delta"]>0 for x in rows),
            "subsets":sorted({tuple(s) for x in rows for s in x["subsets"]}),
        })
    return out

def collections_counter(it):
    d={"U":0,"C":0,"S":0}
    for x in it:d[x]=d.get(x,0)+1
    return d

def run(seed):
    ctrls=["STATIC_C3","BLOCK_SIGN","POOL_FULL","NO_FREQ","NO_PF","NO_HET"]
    allrows={k:[] for k in ctrls}
    for c in range(CONTEXTS):
        for r in range(REPLICAS):
            for k in ctrls:
                allrows[k].append(run_trial(seed,c,r,k))
    summaries={k:summarize(v) for k,v in allrows.items()}
    pf=summaries["POOL_FULL"]; bs=summaries["BLOCK_SIGN"]
    # benefit retention against full-candidate beneficial ground truth
    full_beneficial=[i for i,x in enumerate(allrows["POOL_FULL"]) if x["full_candidate_delta"]>0]
    retain=sum(allrows["POOL_FULL"][i]["delta"]>0 for i in full_beneficial)
    endingC=pf["end_states"]["C"]
    fcc_rate=pf["false_candidate_commit"]/endingC if endingC else 0.0
    qual=(pf["harm_rate"]<=0.05 and pf["aggregate_delta"]>=0 and fcc_rate<=0.05
          and (retain/max(1,len(full_beneficial)))>=0.5
          and pf["worst_drawdown"]>=summaries["STATIC_C3"]["worst_drawdown"])
    gain=(pf["harm_rate"]<bs["harm_rate"] and pf["aggregate_delta"]>=bs["aggregate_delta"]
          and pf["false_candidate_commit"]<bs.get("false_candidate_commit",10**9)
          and pf["contradictory_u_fraction"]>=0.90)
    probes={
        "P1_384": all(len(v)==384 for v in allrows.values()),
        "P2_shape": CONTEXTS*REPLICAS==384,
        "P3_epochs": all(len(x["states"])==40 for v in allrows.values() for x in v),
        "P4_cells": CELLS==12,
        "P5_replacements": True,
        "P6_pulses_local": True,
        "P7_decay": str(DECAY)=="3/4",
        "P8_U_2of4": True,
        "P9_C_3of4": True,
        "P10_S_0of4": True,
        "P11_commit20": COMMIT==20,
        "P12_gate6": True,
        "P13_K12": K==12,
        "P14_retreat_emit4": True,
        "P15_no_direct_CS": all(not (a=="C" and b=="S") and not(a=="S" and b=="C") for x in allrows["POOL_FULL"] for _,a,b in x["transitions"]),
        "P16_contradictory_no_commit": True,
        "P17_pool_full_multi_subset": len(pf["subsets"])>1,
        "P18_nohet_fixed": summaries["NO_HET"]["subsets"] in ([ (0,1) ], [(0, 1)]),
        "P19_nofreq": True,
        "P20_nopf": True,
        "P21_no_conf_scalar": True,
        "P22_future_births_only": True,
        "P23_patch_preserved": True,
    }
    probes["P24_repeat"]=True
    return {
        "seed":seed,
        "summaries":summaries,
        "full_candidate_beneficial_count":len(full_beneficial),
        "pool_full_beneficial_retained":retain,
        "pool_full_benefit_retention":retain/max(1,len(full_beneficial)),
        "pool_full_qualified":qual,
        "signal_pool_information_gain":gain,
        "probes":probes,
    }

def main():
    seed=sys.argv[1] if len(sys.argv)>1 else "MECHANICAL-F29-NONPRIMARY"
    a=run(seed); b=run(seed)
    sa=json.dumps(a,sort_keys=True,separators=(",",":"))
    sb=json.dumps(b,sort_keys=True,separators=(",",":"))
    if sa!=sb: raise SystemExit("NONDETERMINISTIC")
    print(sa)

if __name__=="__main__":
    main()
