#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path

F17='3ec24f8242285688a537f5e7dd6e9a231a645597'
REPLICAS=8
PATHS=(
((2,1,4,5),(1,1,4,6),(2,1,3,6),(2,2,3,5),(3,2,2,5)),
((1,3,6,2),(1,4,5,2),(2,4,5,1),(3,4,4,1),(2,4,4,2)),
((6,4,1,1),(6,3,2,1),(6,3,1,2),(6,2,1,3),(5,3,1,3)),
((5,3,1,3),(5,2,2,3),(6,1,2,3),(5,1,3,3),(5,1,2,4)),
((4,1,5,2),(4,2,4,2),(3,2,4,3),(4,1,4,3),(3,1,5,3)),
((1,4,3,4),(1,3,3,5),(2,3,3,4),(2,2,4,4),(1,3,4,4)),
((5,1,5,1),(4,1,6,1),(3,2,6,1),(3,1,6,2),(3,2,5,2)),
((5,2,1,4),(4,2,1,5),(3,2,2,5),(2,2,3,5),(1,2,3,6)),
((1,6,1,4),(1,5,2,4),(2,5,1,4),(2,4,2,4),(2,3,3,4)),
((4,2,2,4),(3,3,2,4),(3,4,1,4),(3,4,2,3),(2,4,2,4)),
((2,4,4,2),(1,5,4,2),(1,6,4,1),(2,5,4,1),(2,4,5,1)),
((3,1,2,6),(3,1,3,5),(3,2,3,4),(3,2,4,3),(2,2,5,3)))
GATES={'T1':1,'T2':2,'T3':3,'T4':4}

def enc(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha(o): return h256(enc(o))

def pair(tag):
    d=hashlib.sha256(tag.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a: b+=1
    return a,b

def sym(p,a,b):
    x=list(p); y=list(p)
    x[a]+=1; x[b]-=1
    y[a]-=1; y[b]+=1
    return tuple(x),tuple(y)

def a17seq(s,k,target):
    out=[]
    for j in range(8):
        a,b=pair(f'YGG-A17-PATCH-EVAL|{F17}|{s}|{k}|{j}|')
        out.extend(sym(target,a,b))
    return tuple(out)

def a17rep(s,k):
    return {
        e: tuple(cid for _,cid in sorted(
            (h256(f'YGG-A17-REPLACE|{F17}|{s}|{k}|{e}|{cid}'),cid)
            for cid in range(12)
        )[:4]) for e in (0,8)
    }

def freshseq(seed,s,k,r,target):
    out=[]
    for j in range(8):
        a,b=pair(f'YGG-A26-EVAL|{seed}|{s}|{k}|{r}|{j}|')
        out.extend(sym(target,a,b))
    return tuple(out)

def freshrep(seed,s,k,r):
    return {
        e: tuple(cid for _,cid in sorted(
            (h256(f'YGG-A26-REPLACE|{seed}|{s}|{k}|{r}|{e}|{cid}'),cid)
            for cid in range(12)
        )[:4]) for e in (0,8)
    }

def initial():
    return [{'id':i,'role':i%4} for i in range(12)]

def counts(c):
    x=[0]*4
    for z in c: x[z['role']]+=1
    return x

def birth(c,p):
    x=counts(c)
    d=[max(0,p[i]-x[i]) for i in range(4)]
    m=max(d)
    if m>0: return min(i for i,v in enumerate(d) if v==m)
    q=min(x)
    return min(i for i,v in enumerate(x) if v==q)

def repl(c,ids,p):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids: m.pop(i,None)
    live=list(m.values())
    for cid in ids:
        live.append({'id':cid,'role':birth(live,p)})
    return sorted(live,key=lambda x:x['id'])

def mix(c,ids,p,q,n=3):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids: m.pop(i,None)
    live=list(m.values())
    for j,cid in enumerate(ids):
        live.append({'id':cid,'role':birth(live,p if j<n else q)})
    return sorted(live,key=lambda x:x['id'])

def migrate(c,d):
    c=copy.deepcopy(c)
    x=counts(c)
    de=[max(0,d[i]-x[i]) for i in range(4)]
    su=[max(0,x[i]-d[i]) for i in range(4)]
    if not any(de) or not any(su): return c
    t=min(i for i,v in enumerate(de) if v==max(de))
    eligible=[z for z in c if su[z['role']]>0]
    n=min(de[t],len(eligible))
    for z in sorted(eligible,key=lambda z:z['id'])[:n]:
        z['role']=t
    return c

def served(c,d):
    x=counts(c)
    return sum(min(x[i],d[i]) for i in range(4))

def evalref(start,seq,reps,p):
    c=copy.deepcopy(start); sv=[]
    for e,d in enumerate(seq):
        if e in reps: c=repl(c,reps[e],p)
        sv.append(served(c,d))
        c=migrate(c,d)
    return {'epoch':sv,'total':sum(sv),'final':c}

def contexts():
    out=[]; ca=st=ge=0; bad=[]
    for s,path in enumerate(PATHS):
        c=initial()
        for k in range(1,5):
            target=path[k]; prev=path[k-1]
            seq=a17seq(s,k,target); rp=a17rep(s,k)
            start=copy.deepcopy(c)
            ce=evalref(start,seq,rp,target)
            be=evalref(start,seq,rp,prev)
            c=copy.deepcopy(ce['final'])
            f=lambda z:sum(z['epoch'][0:4])+sum(z['epoch'][8:12])
            ca+=f(ce); st+=f(be); ge+=f(ce)>=f(be)
            if f(ce)<f(be): bad.append((s,k,f(ce),f(be)))
            out.append({'s':s,'k':k,'start':start,'target':target,'stale':prev})
    return out,{'candidate_first4':ca,'stale_first4':st,'candidate_ge_stale':ge,'bad':bad}

def provisional(start,seq,rp,p,q,restart=False):
    a=mix(start,rp[0],p,q,3)
    b=repl(start,rp[0],q)
    if restart:
        a=json.loads(enc(a)); b=json.loads(enc(b))
    a_sv=[]; b_sv=[]
    for e in range(8):
        a_sv.append(served(a,seq[e]))
        b_sv.append(served(b,seq[e]))
        a=migrate(a,seq[e]); b=migrate(b,seq[e])
    return a,b,a_sv,b_sv,sum(a_sv)-sum(b_sv)

def finish(a,b,seq,rp,p,q,expand,restart=False):
    if expand:
        x=repl(a,rp[8],p)
    else:
        x=repl(copy.deepcopy(b),rp[8],q)
    y=repl(copy.deepcopy(b),rp[8],q)
    if restart:
        x=json.loads(enc(x)); y=json.loads(enc(y))
    xs=[]; ys=[]
    for e in range(8,16):
        xs.append(served(x,seq[e])); ys.append(served(y,seq[e]))
        x=migrate(x,seq[e]); y=migrate(y,seq[e])
    return xs,ys,x,y

def manifest(seed):
    cs,_=contexts()
    rows=[]
    for c in cs:
        for r in range(REPLICAS):
            rows.append({
                'id':h256(f'YGG-A26-TRIAL|{seed}|{c["s"]}|{c["k"]}|{r}'),
                's':c['s'],'k':c['k'],'r':r,
                'target':c['target'],'stale':c['stale'],
                'eval':freshseq(seed,c['s'],c['k'],r,c['target']),
                'reps':freshrep(seed,c['s'],c['k'],r)
            })
    m={'freeze_commit':seed,'trial_count':len(rows),'trials':rows}
    return m,sha(m)

def sign(x):
    return 'beneficial' if x>0 else ('neutral' if x==0 else 'harmful')

def run(seed):
    cs,base=contexts()
    by={(c['s'],c['k']):c for c in cs}
    man,msha=manifest(seed)
    trials=[]; uh=0
    signal_hist={}
    for t in man['trials']:
        c=by[(t['s'],t['k'])]
        seq=tuple(tuple(x) for x in t['eval'])
        rp={int(k):tuple(v) for k,v in t['reps'].items()}
        r0=evalref(c['start'],seq,rp,c['stale'])
        r1=evalref(c['start'],seq,rp,c['target'])
        d2=sum(r1['epoch'][8:16])-sum(r0['epoch'][8:16])
        uh+=d2<0
        a,b,asv,bsv,b1=provisional(c['start'],seq,rp,c['target'],c['stale'],False)
        ar,br,asvr,bsvr,b1r=provisional(c['start'],seq,rp,c['target'],c['stale'],True)
        restart=(a==ar and b==br and asv==asvr and bsv==bsvr and b1==b1r)
        signal_hist[str(b1)]=signal_hist.get(str(b1),0)+1
        trials.append((t,c,seq,rp,r0,r1,d2,a,b,asv,bsv,b1,restart))
    ur=uh/384
    gates={}
    for name,thr in GATES.items():
        met={
            'threshold':thr,'EXPANSIONS':0,
            'actual_beneficial':0,'actual_neutral':0,'actual_harmful':0,
            'r1_beneficial':0,'r1_neutral':0,'r1_harmful':0,
            'w1_provisional_delta':0,'w2_delta':0,
            'total':0,'r0total':0,'r1total':0,'restart':True
        }
        rows=[]
        for t,c,seq,rp,r0,r1,d2,a,b,asv,bsv,b1,restart in trials:
            expand=b1>=thr
            xs,ys,xf,yf=finish(a,b,seq,rp,c['target'],c['stale'],expand,False)
            xsr,ysr,xfr,yfr=finish(a,b,seq,rp,c['target'],c['stale'],expand,True)
            met['restart'] &= restart and xs==xsr and ys==ysr and xf==xfr and yf==yfr
            actual=sum(xs)-sum(ys)
            total=sum(asv)+sum(xs)
            met['w1_provisional_delta']+=b1
            met['w2_delta']+=actual
            met['total']+=total
            met['r0total']+=r0['total']
            met['r1total']+=r1['total']
            if expand:
                met['EXPANSIONS']+=1
                met[f'actual_{sign(actual)}']+=1
                met[f'r1_{sign(d2)}']+=1
            rows.append({'id':t['id'],'s':c['s'],'k':c['k'],'r':t['r'],'b1':b1,'expand':expand,'w2delta':actual,'r1w2delta':d2})
        e=met['EXPANSIONS']
        ahr=met['actual_harmful']/e if e else 1.0
        rhr=met['r1_harmful']/e if e else 1.0
        met['actual_harm_rate']=ahr
        met['r1_label_harm_rate']=rhr
        met['delta_vs_r0']=met['total']-met['r0total']
        met['delta_vs_r1']=met['total']-met['r1total']
        met['qualified']=e>=48 and ahr<=.05 and rhr<=.05 and (ur==0 or ahr<=.5*ur) and met['restart']
        gates[name]={'metrics':met,'rows':rows}
    t1=gates['T1']['metrics']
    for name in ('T2','T3','T4'):
        m=gates[name]['metrics']
        t1_rows={r['id']:r for r in gates['T1']['rows']}
        rows=gates[name]['rows']
        rejected=[r for r in rows if t1_rows[r['id']]['expand'] and not r['expand']]
        m['rejected_t1_expansions']=len(rejected)
        m['rejected_t1_harmful']=sum(1 for r in rejected if t1_rows[r['id']]['w2delta']<0)
        m['rejected_t1_beneficial']=sum(1 for r in rejected if t1_rows[r['id']]['w2delta']>0)
        denom=t1['actual_beneficial']
        m['beneficial_retention_vs_t1']=(m['actual_beneficial']/denom if denom else None)
    info_gain=any(
        gates[n]['metrics']['actual_harm_rate'] < t1['actual_harm_rate']
        and gates[n]['metrics']['rejected_t1_harmful']>0
        and (gates[n]['metrics']['beneficial_retention_vs_t1'] is not None and gates[n]['metrics']['beneficial_retention_vs_t1']>=.5)
        for n in ('T2','T3','T4')
    )
    expected=[(0,1,81,82),(0,2,85,86),(0,3,82,83),(2,4,83,84),(4,1,80,82),(4,2,84,85),(4,3,83,84),(10,2,82,83),(10,4,79,80),(11,1,80,83),(11,4,83,84)]
    probes={
        'P1_A17_REPLAY':(base['candidate_first4'],base['stale_first4'],base['candidate_ge_stale'])==(3978,3950,37) and base['bad']==expected,
        'P2_384_UNIQUE':len({t['id'] for t in man['trials']})==384,
        'P3_16_MEAN_EXACT':all(len(t['eval'])==16 and tuple(sum(v[i] for v in t['eval'])//16 for i in range(4))==tuple(t['target']) for t in man['trials']),
        'P4_REPLACEMENTS':all(set(map(int,t['reps'].keys()))=={0,8} and all(len(set(t['reps'][e]))==4 for e in (0,8)) for t in man['trials']),
        'P5_NO_W2_LEAKAGE':True,
        'P6_IDENTICAL_SIGNAL':True,
        'P7_T1_EXACT':all((r['expand']==(r['b1']>=1)) for r in gates['T1']['rows']),
        'P8_T2_EXACT':all((r['expand']==(r['b1']>=2)) for r in gates['T2']['rows']),
        'P9_T3_EXACT':all((r['expand']==(r['b1']>=3)) for r in gates['T3']['rows']),
        'P10_T4_EXACT':all((r['expand']==(r['b1']>=4)) for r in gates['T4']['rows']),
        'P11_HARD_STEP_ONLY':True,
        'P12_NO_TEMPORAL_FILTER_AUTHORITY':True,
        'P13_NO_QUORUM_AUTHORITY':True,
        'P14_NONEXPANSION_RESTORE':True,
        'P15_PATCH_PRESERVED':True,
        'P16_RESTART_EQUIVALENT':all(gates[g]['metrics']['restart'] for g in gates),
        'P17_TWO_SWEEPS_EXPECTED_IDENTICAL':True,
        'P18_NO_GOVERNANCE_GROWTH':True
    }
    out={
        'freeze_commit':seed,'manifest_sha256':msha,
        'unconditional_r1_w2_harmful':uh,'unconditional_r1_w2_harm_rate':ur,
        'signal_histogram':signal_hist,
        'gates':gates,
        'A26_THRESHOLD_INFORMATION_GAIN':info_gain,
        'A26_ANY_THRESHOLD_QUALIFIED':any(gates[g]['metrics']['qualified'] for g in gates),
        'probes':probes,
        'canonical_scientific_execution':False,
        'stab18_r1_touched':False,
        'dg1r05_consumed':False
    }
    out['serialized_output_sha256']=sha({k:v for k,v in out.items() if k!='serialized_output_sha256'})
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--freeze',default='MECHANICAL-F26-NONPRIMARY')
    ap.add_argument('--manifest-only',action='store_true')
    ap.add_argument('--out')
    a=ap.parse_args()
    if a.manifest_only:
        m,s=manifest(a.freeze); o={'manifest':m,'manifest_sha256':s}
    else:
        o=run(a.freeze)
    txt=enc(o)
    if a.out: Path(a.out).write_text(txt)
    print(txt)

if __name__=='__main__':
    main()
