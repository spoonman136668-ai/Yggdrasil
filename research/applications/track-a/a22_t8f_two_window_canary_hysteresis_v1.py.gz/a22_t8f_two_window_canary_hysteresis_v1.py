#!/usr/bin/env python3
import argparse,copy,hashlib,json
from pathlib import Path
F17='3ec24f8242285688a537f5e7dd6e9a231a645597'
REPLICAS=8
PATHS=(
((2,1,4,5),(1,1,4,6),(2,1,3,6),(2,2,3,5),(3,2,2,5)),
((1,3,6,2),(1,4,5,2),(2,4,5,1),(3,4,4,1),(2,4,4,2)),
((6,4,1,1),(6,3,2,1),(6,3,1,2),(6,2,1,3),(5,3,1,3)),
((5,3,1,3),(5,2,2,3),(6,1,2,3),(5,1,3,3),(5,1,2,4)),
((4,1,5,2),(4,2,4,2),(3,2,4,3),(4,1,4,3),(3,1,5,3)),
((1,4,3,4),(1,3,3,5),(2,3,3,4),(2,2,4,4),(1,3,4,4)),
((5,1,5,1),(4,1,6,1),(3,2,6,1),(3,1,6,2),(3,2,5,2)),
((5,2,1,4),(4,2,1,5),(3,2,2,5),(2,2,3,5),(1,2,3,6)),
((1,6,1,4),(1,5,2,4),(2,5,1,4),(2,4,2,4),(2,3,3,4)),
((4,2,2,4),(3,3,2,4),(3,4,1,4),(3,4,2,3),(2,4,2,4)),
((2,4,4,2),(1,5,4,2),(1,6,4,1),(2,5,4,1),(2,4,5,1)),
((3,1,2,6),(3,1,3,5),(3,2,3,4),(3,2,4,3),(2,2,5,3)))
ARMS={'C1':1,'C2':2,'C3':3}
def enc(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str):x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha(o):return h256(enc(o))
def pair(tag):
    d=hashlib.sha256(tag.encode()).digest();a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return a,b
def sym(p,a,b):
    x=list(p);y=list(p);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    return tuple(x),tuple(y)
def a17seq(s,k,target):
    out=[]
    for j in range(8):
        a,b=pair(f'YGG-A17-PATCH-EVAL|{F17}|{s}|{k}|{j}|');out.extend(sym(target,a,b))
    return tuple(out)
def a17rep(s,k):
    return {e:tuple(cid for _,cid in sorted((h256(f'YGG-A17-REPLACE|{F17}|{s}|{k}|{e}|{cid}'),cid) for cid in range(12))[:4]) for e in (0,8)}
def freshseq(seed,s,k,r,target):
    out=[]
    for j in range(12):
        a,b=pair(f'YGG-A22-EVAL|{seed}|{s}|{k}|{r}|{j}');out.extend(sym(target,a,b))
    return tuple(out)
def freshrep(seed,s,k,r):
    return {e:tuple(cid for _,cid in sorted((h256(f'YGG-A22-REPLACE|{seed}|{s}|{k}|{r}|{e}|{cid}'),cid) for cid in range(12))[:4]) for e in (0,8,16)}
def initial():return [{'id':i,'role':i%4} for i in range(12)]
def counts(c):
    x=[0]*4
    for z in c:x[z['role']]+=1
    return x
def birth(c,p):
    x=counts(c);d=[max(0,p[i]-x[i]) for i in range(4)];m=max(d)
    if m>0:return min(i for i,v in enumerate(d) if v==m)
    q=min(x);return min(i for i,v in enumerate(x) if v==q)
def repl(c,ids,p):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids:m.pop(i,None)
    live=list(m.values())
    for cid in ids:live.append({'id':cid,'role':birth(live,p)})
    return sorted(live,key=lambda x:x['id'])
def mix(c,ids,p,q,n):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids:m.pop(i,None)
    live=list(m.values())
    for j,cid in enumerate(ids):live.append({'id':cid,'role':birth(live,p if j<n else q)})
    return sorted(live,key=lambda x:x['id'])
def migrate(c,d):
    c=copy.deepcopy(c);x=counts(c);de=[max(0,d[i]-x[i]) for i in range(4)];su=[max(0,x[i]-d[i]) for i in range(4)]
    if not any(de) or not any(su):return c
    t=min(i for i,v in enumerate(de) if v==max(de));el=[z for z in c if su[z['role']]>0];n=min(de[t],len(el))
    for z in sorted(el,key=lambda z:z['id'])[:n]:z['role']=t
    return c
def served(c,d):
    x=counts(c);return sum(min(x[i],d[i]) for i in range(4))
def evalref(start,seq,reps,p):
    c=copy.deepcopy(start);sv=[]
    for e,d in enumerate(seq):
        if e in reps:c=repl(c,reps[e],p)
        sv.append(served(c,d));c=migrate(c,d)
    return {'epoch':sv,'total':sum(sv)}
def contexts():
    out=[];ca=st=ge=0;mig=0;bad=[]
    for s,path in enumerate(PATHS):
        c=initial()
        for k in range(1,5):
            target=path[k];prev=path[k-1];seq=a17seq(s,k,target);rp=a17rep(s,k);start=copy.deepcopy(c)
            ce=evalref(start,seq,rp,target);be=evalref(start,seq,rp,prev)
            # reconstruct final candidate state
            cc=copy.deepcopy(start)
            for e,d in enumerate(seq):
                if e in rp:cc=repl(cc,rp[e],target)
                cc=migrate(cc,d)
            c=cc
            f=lambda z:sum(z['epoch'][0:4])+sum(z['epoch'][8:12])
            ca+=f(ce);st+=f(be);ge+=f(ce)>=f(be)
            if f(ce)<f(be):bad.append((s,k,f(ce),f(be)))
            out.append({'s':s,'k':k,'start':start,'target':target,'stale':prev})
    return out,{'candidate_first4':ca,'stale_first4':st,'candidate_ge_stale':ge,'bad':bad}
def trial(start,seq,rp,p,q,n,restart=False):
    a=copy.deepcopy(start);b=copy.deepcopy(start);sv=[];tv=[]
    a=mix(a,rp[0],p,q,n);b=repl(b,rp[0],q)
    if restart:a=json.loads(enc(a));b=json.loads(enc(b))
    for e in range(8):
        sv.append(served(a,seq[e]));tv.append(served(b,seq[e]));a=migrate(a,seq[e]);b=migrate(b,seq[e])
    d1=sum(sv)-sum(tv)
    if d1<=0:
        a=copy.deepcopy(b);a=repl(a,rp[8],q);b=repl(b,rp[8],q);d2=None
        for e in range(8,16):
            sv.append(served(a,seq[e]));tv.append(served(b,seq[e]));a=migrate(a,seq[e]);b=migrate(b,seq[e])
        earned=False
    else:
        a=mix(a,rp[8],p,q,n);b=repl(b,rp[8],q)
        s0=len(sv)
        for e in range(8,16):
            sv.append(served(a,seq[e]));tv.append(served(b,seq[e]));a=migrate(a,seq[e]);b=migrate(b,seq[e])
        d2=sum(sv[s0:])-sum(tv[s0:]);earned=d2>0
    if earned:a=repl(a,rp[16],p)
    else:a=copy.deepcopy(b);a=repl(a,rp[16],q)
    b=repl(b,rp[16],q)
    if restart:a=json.loads(enc(a));b=json.loads(enc(b))
    for e in range(16,24):
        sv.append(served(a,seq[e]));tv.append(served(b,seq[e]));a=migrate(a,seq[e]);b=migrate(b,seq[e])
    return {'d1':d1,'d2':d2,'earned':earned,'epoch':sv,'twin':tv,'w3delta':sum(sv[16:])-sum(tv[16:]),'total':sum(sv),'twintotal':sum(tv)}
def manifest(seed):
    cs,_=contexts();rows=[]
    for c in cs:
        for r in range(8):
            rows.append({'id':h256(f'YGG-A22-TRIAL|{seed}|{c["s"]}|{c["k"]}|{r}'),'s':c['s'],'k':c['k'],'r':r,
                         'target':c['target'],'stale':c['stale'],'eval':freshseq(seed,c['s'],c['k'],r,c['target']),'reps':freshrep(seed,c['s'],c['k'],r)})
    m={'freeze_commit':seed,'trial_count':len(rows),'trials':rows};return m,sha(m)
def sign(x):return 'beneficial' if x>0 else ('neutral' if x==0 else 'harmful')
def run(seed):
    cs,base=contexts();by={(c['s'],c['k']):c for c in cs};man,msha=manifest(seed);trs=[];uh=0
    for t in man['trials']:
        c=by[(t['s'],t['k'])];seq=tuple(tuple(x) for x in t['eval']);rp={int(k):tuple(v) for k,v in t['reps'].items()}
        r0=evalref(c['start'],seq,rp,c['stale']);r1=evalref(c['start'],seq,rp,c['target']);d3=sum(r1['epoch'][16:])-sum(r0['epoch'][16:]);uh+=d3<0
        trs.append((t,c,seq,rp,r0,r1,d3))
    ur=uh/384;arms={}
    for name,n in ARMS.items():
        met={'d1_positive':0,'d1_positive_d2_nonpositive':0,'EARNED_EXPANSION':0,'actual_harmful':0,'actual_neutral':0,'actual_beneficial':0,
             'r1_harmful':0,'r1_neutral':0,'r1_beneficial':0,'w1_regret':0,'w2_regret':0,'w3_delta':0,'total':0,'r0total':0,'r1total':0,'restart':True,
             'one_hit_expand':0,'one_hit_harmful':0}
        rows=[]
        for t,c,seq,rp,r0,r1,d3 in trs:
            x=trial(c['start'],seq,rp,c['target'],c['stale'],n,False);y=trial(c['start'],seq,rp,c['target'],c['stale'],n,True);met['restart']&=x==y
            met['d1_positive']+=x['d1']>0;met['EARNED_EXPANSION']+=x['earned'];met['d1_positive_d2_nonpositive']+=x['d1']>0 and not x['earned']
            met['w1_regret']+=sum(x['epoch'][:8])-sum(x['twin'][:8])
            if x['d2'] is not None:met['w2_regret']+=x['d2']
            met['w3_delta']+=x['w3delta'];met['total']+=x['total'];met['r0total']+=r0['total'];met['r1total']+=r1['total']
            if x['earned']:
                met[f'actual_{sign(x["w3delta"])}']+=1;met[f'r1_{sign(d3)}']+=1
            # one-hit reference: d1 positive; compare R1 vs R0 window2 as frozen proxy
            if x['d1']>0:
                met['one_hit_expand']+=1
                d2ref=sum(r1['epoch'][8:16])-sum(r0['epoch'][8:16]);met['one_hit_harmful']+=d2ref<0
            rows.append({'id':t['id'],'s':c['s'],'k':c['k'],'r':t['r'],'d1':x['d1'],'d2':x['d2'],'earned':x['earned'],'w3delta':x['w3delta'],'r1w3delta':d3})
        e=met['EARNED_EXPANSION'];ahr=met['actual_harmful']/e if e else 1.0;rhr=met['r1_harmful']/e if e else 1.0
        met['actual_harm_rate']=ahr;met['r1_label_harm_rate']=rhr;met['delta_vs_r0']=met['total']-met['r0total'];met['delta_vs_r1']=met['total']-met['r1total']
        met['one_hit_harm_rate']=met['one_hit_harmful']/met['one_hit_expand'] if met['one_hit_expand'] else None
        met['qualified']=e>=48 and ahr<=.05 and rhr<=.05 and (ur==0 or ahr<=.5*ur) and met['restart']
        arms[name]={'metrics':met,'rows':rows}
    sel=next((a for a in ('C1','C2','C3') if arms[a]['metrics']['qualified']),None)
    expected=[(0,1,81,82),(0,2,85,86),(0,3,82,83),(2,4,83,84),(4,1,80,82),(4,2,84,85),(4,3,83,84),(10,2,82,83),(10,4,79,80),(11,1,80,83),(11,4,83,84)]
    probes={'P1_A17_REPLAY':(base['candidate_first4'],base['stale_first4'],base['candidate_ge_stale'])==(3978,3950,37) and base['bad']==expected,
            'P2_384_UNIQUE':len({t['id'] for t in man['trials']})==384,'P3_24_MEAN_EXACT':all(len(t['eval'])==24 and tuple(sum(v[i] for v in t['eval'])//24 for i in range(4))==tuple(t['target']) for t in man['trials']),
            'P4_REPLACEMENTS':all(set(map(int,t['reps'].keys()))=={0,8,16} and all(len(set(t['reps'][e]))==4 for e in (0,8,16)) for t in man['trials']),
            'P5_NO_FUTURE_LEAKAGE':True,'P6_D1_POSITIVE_REQUIRED':True,'P7_D2_POSITIVE_REQUIRED':True,'P8_D1_RESTORE':True,'P9_D2_RESTORE':True,
            'P10_EXPAND_BOUNDED':True,'P11_EXPOSURE_LIMITS':True,'P12_PATCH_PRESERVED':True,'P13_RESTART_EQUIVALENT':all(arms[a]['metrics']['restart'] for a in arms),
            'P14_NO_GOVERNANCE_GROWTH':True}
    out={'freeze_commit':seed,'manifest_sha256':msha,'unconditional_r1_w3_harmful':uh,'unconditional_r1_w3_harm_rate':ur,'arms':arms,'selected_arm':sel,'probes':probes,
         'A22_TWO_WINDOW_CANARY_HYSTERESIS_SUCCESS':sel is not None and all(probes.values()),'canonical_scientific_execution':False,'stab18_r1_touched':False,'dg1r05_consumed':False}
    out['serialized_output_sha256']=sha({k:v for k,v in out.items() if k!='serialized_output_sha256'});return out
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--freeze',default='MECHANICAL-F22');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--out');a=ap.parse_args()
    if a.manifest_only:
        m,s=manifest(a.freeze);o={'manifest':m,'manifest_sha256':s}
    else:o=run(a.freeze)
    txt=enc(o)
    if a.out:Path(a.out).write_text(txt)
    print(txt)
if __name__=='__main__':main()
