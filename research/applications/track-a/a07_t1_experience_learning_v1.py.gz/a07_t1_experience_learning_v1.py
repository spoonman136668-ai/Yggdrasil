#!/usr/bin/env python3
import argparse, copy, gzip, hashlib, json
from pathlib import Path

import a06_online_program_inheritance_v1 as A06

A06_SOURCE_SHA256="eb7a83320983168fe63d46852ee5d84bebf4c4cf80674ab2a885502e3bfb5a73"
A06_FREEZE="890046dba7004bdceebb8b49f2516779dc7b08ee"
A06_MANIFEST_SHA256="2146c42b61663afede16745123af96bb760a3f886793e9e2d741522c546c2404"
SCENARIOS=12
EPOCHS=384
TRAIN_INPUTS=(0,1,2,3,4,5,6,8,9,10,12)
HOLDOUT_INPUTS=(7,11,13,14,15)
LEARNER_ROOTS={"A":1<<42,"B":1<<43}


def enc(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def h256(b): return hashlib.sha256(b).hexdigest()


def verify_dependencies():
    gz=Path(A06.__file__).with_suffix('.py.gz')
    src=gzip.decompress(gz.read_bytes())
    sha=h256(src)
    if sha!=A06_SOURCE_SHA256: raise AssertionError((sha,A06_SOURCE_SHA256))
    m,msha=A06.update_manifest(A06_FREEZE)
    if msha!=A06_MANIFEST_SHA256: raise AssertionError((msha,A06_MANIFEST_SHA256))
    return {"a06_source_sha256":sha,"a06_source_bytes":len(src),"a06_manifest_sha256":msha}


def bits4(x): return tuple((x>>i)&1 for i in range(4))


def qfeatures(x):
    x0,x1,x2,x3=bits4(x)
    return (1,x0,x1,x2,x3,x0*x1,x0*x2,x0*x3,x1*x2,x1*x3,x2*x3)


def qeval_mask(mask,x):
    y=0
    for i,v in enumerate(qfeatures(x)): y^=((mask>>i)&1)&v
    return y


def truth_from_mask(mask):
    return sum(qeval_mask(mask,x)<<x for x in range(16))


QUADRATIC_CATALOG=tuple((m,truth_from_mask(m)) for m in range(1<<11)
                        if any((m>>i)&1 for i in range(5,11)) and sum(qeval_mask(m,x) for x in range(16))==8)


def gf2_rank(rows):
    a=[list(r) for r in rows]; rank=0
    if not a: return 0
    n=len(a[0])
    for c in range(n):
        pivot=next((i for i in range(rank,len(a)) if a[i][c]),None)
        if pivot is None: continue
        a[rank],a[pivot]=a[pivot],a[rank]
        for i in range(len(a)):
            if i!=rank and a[i][c]: a[i]=[x^y for x,y in zip(a[i],a[rank])]
        rank+=1
    return rank


def gf2_solve(examples):
    if len(examples)<11: return None
    a=[list(qfeatures(idx))+[label] for idx,label in examples]
    row=0; pivots=[]
    for c in range(11):
        pivot=next((i for i in range(row,len(a)) if a[i][c]),None)
        if pivot is None: continue
        a[row],a[pivot]=a[pivot],a[row]
        for i in range(len(a)):
            if i!=row and a[i][c]: a[i]=[x^y for x,y in zip(a[i],a[row])]
        pivots.append(c); row+=1
    if row<11: return None
    coeff=[0]*11
    for r,c in enumerate(pivots): coeff[c]=a[r][11]
    mask=sum(v<<i for i,v in enumerate(coeff))
    return {"coefficient_mask":mask,"truth_table":truth_from_mask(mask)}


def learner_rank(examples): return gf2_rank([qfeatures(idx) for idx,_ in examples])


def derive_target(freeze_commit,scenario,current_truth):
    counter=0
    while True:
        suffix=f"|{counter}" if counter else ""
        d=hashlib.sha256(f"YGG-A07-TARGET|{freeze_commit}|{scenario}{suffix}".encode()).digest()
        mask,truth=QUADRATIC_CATALOG[int.from_bytes(d[:8],'big')%len(QUADRATIC_CATALOG)]
        if truth!=current_truth: return mask,truth,counter
        counter+=1


def learner_order(freeze_commit,scenario,learner):
    return tuple(sorted(TRAIN_INPUTS,key=lambda i:hashlib.sha256(
        f"YGG-A07-ORDER|{freeze_commit}|{scenario}|{learner}|{i}".encode()).digest()))


def target_manifest(freeze_commit):
    initial,initial_sha=A06.A05.task_program_manifest(A06.A05_FREEZE)
    env,env_sha=A06.A05.A03.schedule_manifest(A06.A03_ENV_FREEZE)
    scenarios=[]
    for s in range(SCENARIOS):
        init=A06.A05.programs_for_scenario(initial,s)
        point=A06.select_update_point(env['schedules'][s])
        role=point['target_role']
        mask,truth,counter=derive_target(freeze_commit,s,init[role])
        scenarios.append({
            "scenario":s,"target_role":role,"transition_start":point['transition_start'],
            "commit_epoch":point['update_epoch'],"training_start":point['update_epoch']-11,
            "target_coefficient_mask":mask,"target_truth_table":truth,
            "target_truth_table_hex":f"0x{truth:04x}","derivation_counter":counter,
            "learner_A_order":learner_order(freeze_commit,s,'A'),
            "learner_B_order":learner_order(freeze_commit,s,'B'),
        })
    m={"freeze_commit":freeze_commit,"train_inputs":TRAIN_INPUTS,"holdout_inputs":HOLDOUT_INPUTS,
       "learner_roots":LEARNER_ROOTS,"scenarios":scenarios}
    return m,h256(enc(m).encode())


class LearningOrganism(A06.ProgramOrganism):
    def __init__(self,scenario,allow_migration=True,schedule=None,seed_hex=None,initial_programs=None,training_spec=None,evaluator_target=None):
        public_spec={k:training_spec[k] for k in ('target_role','commit_epoch','transition_start')}
        public_spec['update_epoch']=training_spec['commit_epoch']
        super().__init__(scenario,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=public_spec)
        self.training_spec=copy.deepcopy(public_spec)
        self.learner_examples={"A":[],"B":[]}
        self.learner_candidates={"A":None,"B":None}
        self.learning_metrics={
            "training_examples_A":0,"training_examples_B":0,"learner_agreements":0,
            "learned_program_commits":0,"incomplete_candidate_attempts":0,
        }
        # Evaluator-only scoring reference; excluded from snapshots and never read by learning/authority logic.
        self._evaluator_target=evaluator_target

    def observe_training(self,learner,input_index,label):
        if learner not in ('A','B'): raise KeyError(learner)
        if input_index not in TRAIN_INPUTS: raise AssertionError('held-out input leaked into learner')
        self.learner_examples[learner].append((int(input_index),int(label)))
        self.learning_metrics[f"training_examples_{learner}"]+=1

    def _learner_candidate(self,learner):
        return gf2_solve(self.learner_examples[learner])

    def _process_program_update(self,epoch):
        if epoch!=self.training_spec['commit_epoch']: return
        ca=self._learner_candidate('A'); cb=self._learner_candidate('B')
        self.learner_candidates={"A":copy.deepcopy(ca),"B":copy.deepcopy(cb)}
        if ca is None or cb is None:
            self.learning_metrics['incomplete_candidate_attempts']+=1
            self.program_metrics['program_update_abstentions']+=1
            return
        if ca['truth_table']!=cb['truth_table']:
            self.program_metrics['program_update_abstentions']+=1
            return
        self.learning_metrics['learner_agreements']+=1
        role=self.training_spec['target_role']; cur=self.program_authority[role]
        proposal=A06.program_record(self.scenario,role,cur['version']+1,ca['truth_table'],cur['program_digest'],epoch)
        attest=({"root":LEARNER_ROOTS['A'],"digest":proposal['program_digest']},
                {"root":LEARNER_ROOTS['B'],"digest":proposal['program_digest']})
        if self._commit_program_update(proposal,attest): self.learning_metrics['learned_program_commits']+=1

    def _build_requests(self,epoch):
        demand=A06.A05.A03.schedule_demand(self.heldout_schedule,epoch)
        reqs=[]; idx=0; remaining=list(demand)
        committed=self.program_metrics['program_updates_committed']>0
        target_role=self.training_spec['target_role']
        while sum(remaining):
            for role in range(4):
                if remaining[role]:
                    bits=A06.A05.A03.heldout_payload_bits(self.heldout_seed,epoch,idx,role)
                    if role==target_role and committed:
                        expected=A06.A05.program_eval(self._evaluator_target,bits)
                    else:
                        expected=A06.A05.program_eval(self.initial_programs[role],bits)
                    reqs.append({"index":idx,"role":role,"bits":bits,"expected":expected})
                    remaining[role]-=1; idx+=1
        assert len(reqs)==12
        return reqs

    def heldout_snapshot(self,next_epoch):
        s=super().heldout_snapshot(next_epoch)
        s['learning_layer']={
            "training_spec":self.training_spec,
            "learner_examples":self.learner_examples,
            "learner_candidates":self.learner_candidates,
            "learning_metrics":self.learning_metrics,
        }
        return s

    @classmethod
    def heldout_restore_with_evaluator(cls,snap,evaluator_target):
        schedule=snap['heldout_schedule']; seed=snap['heldout_seed']; scenario=snap['base']['scenario']
        p=snap['program_layer']; l=snap['learning_layer']
        base=A06.ProgramOrganism.heldout_restore(snap)
        o=cls(scenario,snap['base']['allow_migration'],schedule=schedule,seed_hex=seed,
              initial_programs=tuple(p['initial_programs']),training_spec=l['training_spec'],evaluator_target=evaluator_target)
        o.__dict__.update(base.__dict__)
        o.training_spec=copy.deepcopy(l['training_spec'])
        o.learner_examples={k:[tuple(x) for x in v] for k,v in l['learner_examples'].items()}
        o.learner_candidates=copy.deepcopy(l['learner_candidates'])
        o.learning_metrics=copy.deepcopy(l['learning_metrics'])
        o._evaluator_target=evaluator_target
        return o


def deliver_training(o,epoch,spec):
    start=spec['training_start']; end=spec['commit_epoch']-1
    if not (start<=epoch<=end): return
    pos=epoch-start
    for learner,key in (('A','learner_A_order'),('B','learner_B_order')):
        idx=spec[key][pos]
        label=qeval_mask(spec['target_coefficient_mask'],idx)
        o.observe_training(learner,idx,label)


def run_scenario(index,schedule,seed_hex,initial_programs,spec,allow_migration=True,restart=True):
    original=A06.A05.A03.patch_environment(schedule)
    try:
        o=LearningOrganism(index,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,
                           training_spec=spec,evaluator_target=spec['target_truth_table'])
        ra=schedule['restart_after']
        if restart:
            for e in range(ra+1):
                deliver_training(o,e,spec); o.step(e)
            raw=enc(o.heldout_snapshot(ra+1)); o=LearningOrganism.heldout_restore_with_evaluator(json.loads(raw),spec['target_truth_table'])
            for e in range(ra+1,EPOCHS):
                deliver_training(o,e,spec); o.step(e)
        else:
            for e in range(EPOCHS):
                deliver_training(o,e,spec); o.step(e)
        A06.A05.A03.finalize_reallocation(o)
        return o
    finally:
        A06.A05.A03.restore_environment(original)


def authoritative_equal(a,b):
    return A06.authoritative_equal(a,b) and a.learner_examples==b.learner_examples and a.learner_candidates==b.learner_candidates


def output_equal(a,b):
    return A06.output_equal(a,b) and a.learning_metrics==b.learning_metrics


def learner_eval(candidate,target_mask):
    if candidate is None: return None
    train_error=sum(qeval_mask(candidate['coefficient_mask'],i)!=qeval_mask(target_mask,i) for i in TRAIN_INPUTS)
    holdout_error=sum(qeval_mask(candidate['coefficient_mask'],i)!=qeval_mask(target_mask,i) for i in HOLDOUT_INPUTS)
    return {"rank":11,"candidate_coefficient_mask":candidate['coefficient_mask'],"candidate_truth_table":candidate['truth_table'],
            "training_error":train_error,"holdout_error":holdout_error}


def scenario_summary(index,schedule,seed_hex,initial_programs,spec):
    cand=run_scenario(index,schedule,seed_hex,initial_programs,spec,True,True)
    shadow=run_scenario(index,schedule,seed_hex,initial_programs,spec,True,False)
    cm=A06.A05.A03.A02.scenario_metrics(cand)
    la=learner_eval(cand.learner_candidates['A'],spec['target_coefficient_mask'])
    lb=learner_eval(cand.learner_candidates['B'],spec['target_coefficient_mask'])
    return {
        "scenario":index,"seed":seed_hex,"target_role":spec['target_role'],"training_start":spec['training_start'],"commit_epoch":spec['commit_epoch'],
        "target_coefficient_mask":spec['target_coefficient_mask'],"target_truth_table":spec['target_truth_table'],
        "learner_A":la,"learner_B":lb,"learner_A_order":spec['learner_A_order'],"learner_B_order":spec['learner_B_order'],
        "candidate_agreement":cand.learner_candidates['A'] is not None and cand.learner_candidates['B'] is not None and cand.learner_candidates['A']['truth_table']==cand.learner_candidates['B']['truth_table'],
        "candidate":cm,"program_metrics":copy.deepcopy(cand.program_metrics),"learning_metrics":copy.deepcopy(cand.learning_metrics),
        "restart_authoritative_state_equivalence":authoritative_equal(cand,shadow),"restart_output_equivalence":output_equal(cand,shadow),
        "dynamic_remerge_count":cand.heldout_remerge_count,"final_provisional_count":len(cand.provisional),
        "_outputs":list(cand.outputs),
    }


def plasticity_probes(spec):
    target=spec['target_coefficient_mask']
    # P1 incomplete experience.
    ex=[(i,qeval_mask(target,i)) for i in TRAIN_INPUTS[:10]]
    p1=gf2_solve(ex) is None and learner_rank(ex)<11
    # P2 learner disagreement from one flipped B label.
    ea=[(i,qeval_mask(target,i)) for i in TRAIN_INPUTS]
    eb=list(ea); i,l=eb[0]; eb[0]=(i,1-l)
    ca=gf2_solve(ea); cb=gf2_solve(eb)
    p2=ca is not None and cb is not None and ca['truth_table']!=cb['truth_table']
    # P3 one learner cannot form two-root quorum.
    fake_digest='1'*64
    p3=not A06.source_quorum(({"root":LEARNER_ROOTS['A'],"digest":fake_digest},),fake_digest)
    # P4 architecture train/holdout separation.
    p4=set(TRAIN_INPUTS).isdisjoint(HOLDOUT_INPUTS)
    # P5 lookup-only learner cannot answer unseen keys.
    lookup={i:qeval_mask(target,i) for i in TRAIN_INPUTS}
    p5=all(i not in lookup for i in HOLDOUT_INPUTS)
    # P6 hereditary paths reuse A06 probe against learned target.
    initial,_=A06.A05.task_program_manifest(A06.A05_FREEZE)
    env,_=A06.A05.A03.schedule_manifest(A06.A03_ENV_FREEZE)
    init=A06.A05.programs_for_scenario(initial,spec['scenario'])
    a06spec={"target_role":spec['target_role'],"update_epoch":spec['commit_epoch'],"transition_start":spec['transition_start'],"new_truth_table":spec['target_truth_table']}
    h=A06.probe_suite(env['schedules'][spec['scenario']],env['seeds'][spec['scenario']],init,a06spec)
    p6=all(h.values())
    return {"INCOMPLETE_EXPERIENCE_ABSTAINS":p1,"LEARNER_DISAGREEMENT_BLOCKS":p2,"SINGLE_LEARNER_BLOCKS":p3,
            "HELDOUT_NOT_OBSERVED":p4,"MEMORIZATION_ONLY_ABSTAINS":p5,"HEREDITARY_PROPAGATION":p6}


def negative_controls(schedule,seed_hex,initial_programs,spec):
    target=spec['target_coefficient_mask']
    digest='2'*64
    n1=not A06.source_quorum(({"root":LEARNER_ROOTS['A'],"digest":digest},),digest)
    n2=not A06.source_quorum(({"root":LEARNER_ROOTS['A'],"digest":digest},{"root":LEARNER_ROOTS['A'],"digest":digest}),digest)
    a06spec={"target_role":spec['target_role'],"update_epoch":spec['commit_epoch'],"transition_start":spec['transition_start'],"new_truth_table":spec['target_truth_table']}
    inherited=A06.negative_controls(schedule,seed_hex,initial_programs,a06spec)
    n3=inherited['STALE_PARENT_FAIL_CLOSED']
    n4=inherited['GOVERNANCE_UNAVAILABLE_FAIL_CLOSED']
    # Poison one learner: auto-authorizing its candidate would install a wrong target.
    ex=[(i,qeval_mask(target,i)) for i in TRAIN_INPUTS]; i,l=ex[0]; ex[0]=(i,1-l)
    wrong=gf2_solve(ex); n5=wrong is not None and wrong['truth_table']!=spec['target_truth_table']
    # Poison both identically: they agree on the same wrong candidate -- explicit boundary.
    ex2=[(i,qeval_mask(target,i)) for i in TRAIN_INPUTS]; i,l=ex2[0]; ex2[0]=(i,1-l)
    wa=gf2_solve(ex2); wb=gf2_solve(list(ex2))
    n6=wa is not None and wb is not None and wa['truth_table']==wb['truth_table'] and wa['truth_table']!=spec['target_truth_table']
    return {"ONE_LEARNER_ROOT_FAILS_CLOSED":n1,"SAME_ROOT_FANOUT_FAILS_CLOSED":n2,"STALE_PARENT_FAILS_CLOSED":n3,
            "GOVERNANCE_UNAVAILABLE_FAILS_CLOSED":n4,"AUTO_AUTHORIZE_POISONED_LEARNER_FALSE_AUTHORITY_REACHABLE":n5,
            "CORRELATED_TRAINING_POISON_BOUNDARY":n6}


def run_primary(freeze_commit):
    deps=verify_dependencies()
    initial,initial_sha=A06.A05.task_program_manifest(A06.A05_FREEZE)
    env,env_sha=A06.A05.A03.schedule_manifest(A06.A03_ENV_FREEZE)
    manifest,msha=target_manifest(freeze_commit)
    summaries=[]; outputs=[]
    for s in range(SCENARIOS):
        init=A06.A05.programs_for_scenario(initial,s); spec=manifest['scenarios'][s]
        x=scenario_summary(s,env['schedules'][s],env['seeds'][s],init,spec); outputs.extend(x.pop('_outputs')); summaries.append(x)
    total=sum(x['candidate']['total_requests'] for x in summaries); served=sum(x['candidate']['served_requests'] for x in summaries)
    correct=sum(x['candidate']['correct_served_requests'] for x in summaries); incorrect=sum(x['candidate']['incorrect_served_requests'] for x in summaries)
    exactA=sum(x['learner_A']['candidate_truth_table']==x['target_truth_table'] for x in summaries)
    exactB=sum(x['learner_B']['candidate_truth_table']==x['target_truth_table'] for x in summaries)
    agree=sum(x['candidate_agreement'] for x in summaries)
    holdout_correct=sum(5-x['learner_A']['holdout_error'] for x in summaries)+sum(5-x['learner_B']['holdout_error'] for x in summaries)
    commits=sum(x['program_metrics']['program_updates_committed'] for x in summaries)
    stale_served=sum(x['program_metrics']['stale_program_served_requests'] for x in summaries)
    migrations=sum(x['program_metrics']['migration_program_inheritances'] for x in summaries)
    restarts=sum(not (x['restart_authoritative_state_equivalence'] and x['restart_output_equivalence']) for x in summaries)
    safety_keys=('stale_vote_attempts_accepted','authority_violations','causal_regressions','duplicate_effective_provenance','split_brain_final_states','resource_budget_violations')
    safety={k:sum(x['candidate'][k] for x in summaries) for k in safety_keys}
    probes=[plasticity_probes(spec) for spec in manifest['scenarios']]
    controls=[]
    for i,spec in enumerate(manifest['scenarios']):
        init=A06.A05.programs_for_scenario(initial,i)
        controls.append(negative_controls(env['schedules'][i],env['seeds'][i],init,spec))
    all_probes=all(all(v for v in p.values()) for p in probes)
    controls_required=all(all(c[k] for k in ('ONE_LEARNER_ROOT_FAILS_CLOSED','SAME_ROOT_FANOUT_FAILS_CLOSED','STALE_PARENT_FAILS_CLOSED','GOVERNANCE_UNAVAILABLE_FAILS_CLOSED','AUTO_AUTHORIZE_POISONED_LEARNER_FALSE_AUTHORITY_REACHABLE')) for c in controls)
    boundary=all(c['CORRELATED_TRAINING_POISON_BOUNDARY'] for c in controls)
    signals={
        "LEARNER_A_EXACT_12_OF_12":exactA==12,"LEARNER_B_EXACT_12_OF_12":exactB==12,"LEARNER_PAIRS_AGREE_12_OF_12":agree==12,
        "HELDOUT_120_OF_120":holdout_correct==120,"PROGRAM_COMMITS_12_OF_12":commits==12,
        "TASK_ACCURACY_ONE":incorrect==0 and correct==served,"ZERO_INCORRECT_SERVED":incorrect==0,"ZERO_STALE_PROGRAM_SERVED":stale_served==0,
        "MIGRATION_INHERITANCE_EXERCISED":migrations>=1,"PLASTICITY_HEREDITY_PROBES_PASS":all_probes,"NEGATIVE_CONTROLS_PASS":controls_required,
        "ALL_RESTARTS_EQUIVALENT":restarts==0,"ZERO_EXISTING_SAFETY_VIOLATIONS":all(v==0 for v in safety.values()),
        "PARTITION_REMERGE_COMPLETE":all(x['dynamic_remerge_count']==1 and x['final_provisional_count']==0 for x in summaries),
    }
    signals['A07_T1_EXPERIENCE_DEPENDENT_HEREDITARY_LEARNING_SUCCESS']=all(signals.values())
    return {"schema":"yggdrasil.training-t1.a07-experience-hereditary-learning.v1","freeze_commit":freeze_commit,
            "target_manifest_sha256":msha,"target_manifest":manifest,"dependencies":deps,"scenarios":summaries,
            "aggregate":{"total_requests":total,"candidate_served":served,"candidate_correct":correct,"candidate_incorrect":incorrect,
                         "learner_A_exact":exactA,"learner_B_exact":exactB,"learner_pairs_agree":agree,"heldout_predictions_correct":holdout_correct,
                         "program_commits":commits,"migration_program_inheritances":migrations,"stale_program_served_requests":stale_served,
                         "restart_mismatches":restarts,"safety_totals":safety},
            "task_output_sha256":h256(enc(outputs).encode()),"plasticity_probes":probes,"negative_controls":controls,
            "correlated_training_poison_boundary":boundary,"signals":signals,
            "canonical_scientific_execution":False,"stab18_r1_touched":False}


def validate():
    deps=verify_dependencies()
    assert len(QUADRATIC_CATALOG)==840
    assert gf2_rank([qfeatures(i) for i in TRAIN_INPUTS])==11
    assert set(TRAIN_INPUTS).isdisjoint(HOLDOUT_INPUTS) and set(TRAIN_INPUTS)|set(HOLDOUT_INPUTS)==set(range(16))
    m,msha=target_manifest('MECHANICAL-NONPRIMARY-FREEZE')
    assert len(m['scenarios'])==12
    for s in m['scenarios']:
        assert s['training_start']==s['commit_epoch']-11 and s['training_start']>=0
        assert len(s['learner_A_order'])==11 and len(s['learner_B_order'])==11
        assert set(s['learner_A_order'])==set(TRAIN_INPUTS) and set(s['learner_B_order'])==set(TRAIN_INPUTS)
        ex=[(i,qeval_mask(s['target_coefficient_mask'],i)) for i in TRAIN_INPUTS]
        sol=gf2_solve(ex); assert sol and sol['truth_table']==s['target_truth_table']
    return {"dependencies":deps,"quadratic_catalog_size":len(QUADRATIC_CATALOG),"train_inputs":TRAIN_INPUTS,"holdout_inputs":HOLDOUT_INPUTS,
            "train_feature_rank":11,"learner_roots":LEARNER_ROOTS,"mechanical_target_manifest_sha256":msha,
            "mechanical_primary_target_derivation":False,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--freeze-commit'); ap.add_argument('--manifest-only',action='store_true'); ap.add_argument('--mechanical-only',action='store_true'); ap.add_argument('--out')
    args=ap.parse_args()
    if args.mechanical_only: print(enc({"mechanical_valid":True,"mechanical":validate()})); return
    if not args.freeze_commit: raise SystemExit('--freeze-commit required')
    if args.manifest_only:
        m,sha=target_manifest(args.freeze_commit); print(enc({"freeze_commit":args.freeze_commit,"target_manifest_sha256":sha,"target_manifest":m})); return
    if not args.out: raise SystemExit('--out required')
    obj=run_primary(args.freeze_commit); raw=(enc(obj)+'\n').encode(); Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":h256(raw),"target_manifest_sha256":obj['target_manifest_sha256'],"aggregate":obj['aggregate'],"signals":obj['signals'],"correlated_training_poison_boundary":obj['correlated_training_poison_boundary']}))

if __name__=='__main__': main()
