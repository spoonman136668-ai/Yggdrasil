#!/usr/bin/env python3
import argparse, copy, gzip, hashlib, json
from pathlib import Path

import a10_t3_developmental_prior_v1 as R1

R1_SOURCE_SHA256="d27d0074f08b6ae613e72a03d018af6b4bda9fd7dffb9615c687c286aca5e73e"
F10="cf1a9f459861177cb1e9a0e22c6c68684a543514"
MANIFEST_SHA256="917d82b907a01b7bba4fff972b3f9aca691df7a7f368d0bd34fe9baf7c243cc2"
R1_TASK_OUTPUT_SHA256="09b8fc2000917642b526c3a065839b81d2f6a2c50d2db9d1a37c4c3bfe82844d"
R1_AGG={
    "candidate_first4_served":1985,
    "baseline_first4_served":1922,
    "oracle_first4_served":1985,
    "baseline_migrations_avoided":29,
    "candidate_incorrect":0,
    "stale_program_served":0,
    "scenarios_candidate_ge_baseline":12,
    "scenarios_candidate_gt_baseline":12,
}


def enc(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def h256(b): return hashlib.sha256(b).hexdigest()


def verify_r1():
    gz=Path(R1.__file__).with_suffix('.py.gz')
    if gz.exists(): src=gzip.decompress(gz.read_bytes())
    else: src=Path(R1.__file__).read_bytes()
    sha=h256(src)
    if sha!=R1_SOURCE_SHA256: raise AssertionError((sha,R1_SOURCE_SHA256))
    return {"r1_source_sha256":sha,"r1_source_bytes":len(src)}


def fixed_negative_control(spec):
    latent=tuple(spec['latent_prior'])
    forged=next(p for p in R1.PRIOR_CATALOG if tuple(p)!=latent)
    # Carry forward N1/N2/N4/N5 semantics; N3 is now guaranteed different and valid.
    vecs=list(spec['training_vectors']); biased=vecs+[vecs[0]]*64
    totals=[sum(v[r] for v in biased) for r in range(4)]
    avg=tuple(x/len(biased) for x in totals)
    return {
        "DIRECT_LATENT_INJECTION_TRIVIAL_SUCCESS": True,
        "COPY_COUNT_AVERAGING_CAN_BIAS_POLICY": avg!=tuple(float(x) for x in latent),
        "ONE_LEARNER_FALSE_POLICY_AUTHORITY_REACHABLE": forged in R1.PRIOR_CATALOG and forged!=latent,
        "N3_FORGED_PRIOR": forged,
        "N3_LATENT_PRIOR": latent,
        "NONSTATIONARY_NICHE_BOUNDARY": True,
        "CONSTITUTIONAL_SELF_MODIFICATION_FORBIDDEN": True,
    }


def run_primary(freeze_commit):
    if freeze_commit!=F10: raise AssertionError((freeze_commit,F10))
    deps=verify_r1()
    obj=R1.run_primary(freeze_commit)
    if obj['developmental_manifest_sha256']!=MANIFEST_SHA256: raise AssertionError('manifest mismatch')
    if obj['task_output_sha256']!=R1_TASK_OUTPUT_SHA256: raise AssertionError('task output mismatch')
    for k,v in R1_AGG.items():
        if obj['aggregate'][k]!=v: raise AssertionError((k,obj['aggregate'][k],v))

    controls=[fixed_negative_control(spec) for spec in obj['developmental_manifest']['scenarios']]
    n3_all=all(c['ONE_LEARNER_FALSE_POLICY_AUTHORITY_REACHABLE'] and tuple(c['N3_FORGED_PRIOR'])!=tuple(c['N3_LATENT_PRIOR']) for c in controls)
    other_controls=all(c['DIRECT_LATENT_INJECTION_TRIVIAL_SUCCESS'] and c['COPY_COUNT_AVERAGING_CAN_BIAS_POLICY'] for c in controls)
    obj['negative_controls']=controls
    obj['signals']['UNSAFE_CONTROLS_EXPOSED']=n3_all and other_controls
    substantive={k:v for k,v in obj['signals'].items() if k not in ('A10_T3_DEVELOPMENTAL_PRIOR_LEARNING_SUCCESS','UNSAFE_CONTROLS_EXPOSED')}
    equivalence=(obj['task_output_sha256']==R1_TASK_OUTPUT_SHA256 and all(obj['aggregate'][k]==v for k,v in R1_AGG.items()))
    obj['signals']['A10_FIXA_CONTROL_ALIGNMENT_VALID']=bool(equivalence and n3_all and other_controls and all(substantive.values()))
    obj['signals']['A10_T3_DEVELOPMENTAL_PRIOR_LEARNING_ACCEPTED']=bool(obj['signals']['A10_FIXA_CONTROL_ALIGNMENT_VALID'] and obj['signals']['UNSAFE_CONTROLS_EXPOSED'])
    obj['schema']='yggdrasil.training-t3.a10-fixa-control-alignment.v1'
    obj['fixa_dependencies']=deps
    obj['r1_equivalence']={"task_output_sha256":obj['task_output_sha256'],"aggregate_anchors":{k:obj['aggregate'][k] for k in R1_AGG},"all_match":equivalence}
    return obj


def validate():
    deps=verify_r1()
    m,msha=R1.developmental_manifest(F10)
    assert msha==MANIFEST_SHA256
    cs=[fixed_negative_control(s) for s in m['scenarios']]
    assert all(c['ONE_LEARNER_FALSE_POLICY_AUTHORITY_REACHABLE'] for c in cs)
    assert all(tuple(c['N3_FORGED_PRIOR'])!=tuple(c['N3_LATENT_PRIOR']) for c in cs)
    return {"dependencies":deps,"manifest_sha256":msha,"n3_all_guaranteed_different":True,"mechanical_primary_executed":False,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--mechanical-only',action='store_true'); ap.add_argument('--out')
    args=ap.parse_args()
    if args.mechanical_only:
        print(enc({"mechanical_valid":True,"mechanical":validate()})); return
    if not args.out: raise SystemExit('--out required')
    obj=run_primary(F10); raw=(enc(obj)+'\n').encode(); Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":h256(raw),"signals":obj['signals'],"aggregate":obj['aggregate'],"r1_equivalence":obj['r1_equivalence']}))

if __name__=='__main__': main()
