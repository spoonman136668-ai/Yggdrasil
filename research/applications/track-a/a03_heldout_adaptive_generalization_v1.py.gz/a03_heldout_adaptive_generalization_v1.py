#!/usr/bin/env python3
import argparse
import copy
import gzip
import hashlib
import importlib
import json
import re
from pathlib import Path

import a02_adaptive_transform_service_v1 as A02

A02_SOURCE_SHA256 = "b2eeb1e589a029f16b0437ce1f3dd05826b81a91ab6c6d91ce25bb28b96db60b"
A02_RESULT_SHA256 = "ad408ca964108c3212bc55db1dd1c932ecbd588774323ebffdb755c32d361271"
A02_CANDIDATE_SERVED = 11928
A02_STATIC_SERVED = 9892
A02_ORACLE_SERVED = 11961
A02_INCORRECT = 0
SCENARIOS = 12
EPOCHS = 384
REQUESTS_PER_EPOCH = 12
REGIME_MIN = 12
REGIME_SPAN = 25
PRIMARY_PREFIX = "YGG-A03-PRIMARY|"


def enc(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def verify_a02_dependency():
    gz_path = Path(A02.__file__).with_suffix(".py.gz")
    source = gzip.decompress(gz_path.read_bytes())
    actual = sha256_bytes(source)
    if actual != A02_SOURCE_SHA256:
        raise AssertionError((actual, A02_SOURCE_SHA256))
    return {"source_sha256": actual, "source_bytes": len(source)}


class ByteStream:
    def __init__(self, seed_hex):
        self.seed = bytes.fromhex(seed_hex)
        self.counter = 0
        self.buf = bytearray()

    def _fill(self):
        block = hashlib.sha256(self.seed + self.counter.to_bytes(8, "big")).digest()
        self.counter += 1
        self.buf.extend(block)

    def take(self, n):
        while len(self.buf) < n:
            self._fill()
        out = bytes(self.buf[:n])
        del self.buf[:n]
        return out

    def u8(self):
        return self.take(1)[0]

    def u32(self):
        return int.from_bytes(self.take(4), "big")


def demand_catalog():
    out = []
    for a in range(8):
        for b in range(8):
            for c in range(8):
                d = 12 - a - b - c
                if 0 <= d <= 7:
                    v = (a, b, c, d)
                    if max(v) - min(v) >= 3:
                        out.append(v)
    return tuple(sorted(out))


DEMAND_CATALOG = demand_catalog()


def derive_seed(freeze_commit, scenario):
    raw = f"{PRIMARY_PREFIX}{freeze_commit}|{scenario}".encode()
    return hashlib.sha256(raw).hexdigest()


def compile_schedule(seed_hex):
    bs = ByteStream(seed_hex)
    regimes = []
    cursor = 0
    while cursor < EPOCHS:
        duration = REGIME_MIN + (bs.u8() % REGIME_SPAN)
        demand = DEMAND_CATALOG[bs.u32() % len(DEMAND_CATALOG)]
        end = min(EPOCHS - 1, cursor + duration - 1)
        regimes.append({"start": cursor, "end": end, "demand": demand})
        cursor = end + 1

    bands = ((48, 111), (144, 223), (272, 351))
    budget_windows = []
    for lo, hi in bands:
        start = lo + (bs.u32() % (hi - lo + 1))
        duration = 8 + (bs.u8() % 9)
        budget = 8 + (bs.u8() % 3)
        budget_windows.append({"start": start, "end": min(EPOCHS - 1, start + duration - 1), "budget": budget})

    damage_bands = ((24,79),(80,135),(136,191),(192,247),(248,303),(304,359))
    damage_epochs = []
    damage_selectors = {}
    for lo, hi in damage_bands:
        epoch = lo + (bs.u32() % (hi - lo + 1))
        damage_epochs.append(epoch)
        damage_selectors[str(epoch)] = bs.u32()

    partition_start = 176 + (bs.u8() % 73)
    partition_duration = 8 + (bs.u8() % 9)
    partition_end = min(EPOCHS - 1, partition_start + partition_duration - 1)

    raw_restart = 96 + (bs.u32() % 193)
    restart = raw_restart
    if partition_start <= restart <= partition_end:
        restart = partition_end + 1
        if restart > 320:
            restart = partition_start - 1

    return {
        "seed": seed_hex,
        "regimes": regimes,
        "budget_windows": budget_windows,
        "damage_epochs": tuple(damage_epochs),
        "damage_selectors": damage_selectors,
        "partition": (partition_start, partition_end),
        "restart_after": restart,
    }


def schedule_manifest(freeze_commit):
    seeds = [derive_seed(freeze_commit, i) for i in range(SCENARIOS)]
    schedules = [compile_schedule(s) for s in seeds]
    manifest = {"freeze_commit": freeze_commit, "seeds": seeds, "schedules": schedules}
    return manifest, sha256_bytes(enc(manifest).encode())


def schedule_demand(schedule, epoch):
    for r in schedule["regimes"]:
        if r["start"] <= epoch <= r["end"]:
            return tuple(r["demand"])
    raise KeyError(epoch)


def schedule_budget(schedule, epoch):
    b = A02.CELLS
    for w in schedule["budget_windows"]:
        if w["start"] <= epoch <= w["end"]:
            b = min(b, w["budget"])
    return b


def regime_starts(schedule):
    return tuple(r["start"] for r in schedule["regimes"])


def regime_end_for_start(schedule, start):
    for r in schedule["regimes"]:
        if r["start"] == start:
            return r["end"]
    raise KeyError(start)


def heldout_payload_bits(seed_hex, epoch, request_index, role):
    d = hashlib.sha256(f"{seed_hex}|payload|{epoch}|{request_index}|{role}".encode()).digest()
    return tuple((d[0] >> i) & 1 for i in range(4))


class HeldoutOrganism(A02.Organism):
    registry = {}

    def __init__(self, scenario, allow_migration=True, schedule=None, seed_hex=None):
        if schedule is None:
            schedule, seed_hex = self.registry[scenario]
        self.heldout_schedule = copy.deepcopy(schedule)
        self.heldout_seed = seed_hex
        self.heldout_regime_starts = set(regime_starts(schedule))
        self.heldout_reallocation = {}
        self.heldout_faults = {}
        self.heldout_capacity = []
        self.environment_impossibilities = 0
        super().__init__(scenario, allow_migration)

    def _build_requests(self, epoch):
        demand = schedule_demand(self.heldout_schedule, epoch)
        reqs = []
        idx = 0
        remaining = list(demand)
        while sum(remaining):
            for role in range(A02.ROLES):
                if remaining[role]:
                    bits = heldout_payload_bits(self.heldout_seed, epoch, idx, role)
                    reqs.append({"index":idx, "role":role, "bits":bits, "expected":A02.transform(role,bits)})
                    remaining[role] -= 1
                    idx += 1
        assert len(reqs) == REQUESTS_PER_EPOCH
        return reqs

    def _begin_damage(self, epoch):
        if epoch not in self.heldout_schedule["damage_epochs"]:
            return
        eligible = [c for c in self.cells if c.status == "ACTIVE" and c.healthy and not c.corrupted]
        if not eligible:
            self.environment_impossibilities += 1
            return
        eligible.sort(key=lambda c: c.id)
        selector = self.heldout_schedule["damage_selectors"][str(epoch)]
        c = eligible[selector % len(eligible)]
        c.corrupted = True
        c.healthy = False
        c.status = "QUARANTINED"
        c.repair_ready_epoch = epoch + 1
        self._revoke_cell_slots(c.id)
        self.metrics["damage_quarantines"] += 1
        self.fault_quarantine_epoch[(self.scenario,epoch)] = epoch
        self.heldout_faults[str(epoch)] = {"target": c.id, "start": epoch, "restored": None}
        self._advance_causal(f"heldout-damage-{epoch}-{c.id}")

    def _record_reallocation(self, epoch, demand):
        if epoch in self.heldout_regime_starts and epoch > 0:
            self.heldout_reallocation[str(epoch)] = None
            prev_starts = [s for s in self.heldout_regime_starts if s < epoch]
            if prev_starts:
                prev = max(prev_starts)
                key = str(prev)
                if key in self.heldout_reallocation and self.heldout_reallocation[key] is None:
                    self.heldout_reallocation[key] = regime_end_for_start(self.heldout_schedule, prev) - prev + 1

        counts = self._role_counts(service_only=False)
        deficits = [max(0, demand[r] - counts[r]) for r in range(A02.ROLES)]
        surpluses = [max(0, counts[r] - demand[r]) for r in range(A02.ROLES)]
        avoidable = any(deficits) and any(surpluses)
        if not (self.heldout_schedule["partition"][0] <= epoch <= self.heldout_schedule["partition"][1]):
            unresolved = [int(k) for k,v in self.heldout_reallocation.items() if v is None and int(k) <= epoch]
            for start in unresolved:
                if not avoidable:
                    self.heldout_reallocation[str(start)] = epoch - start

    def _serve(self, epoch, reqs):
        ps, pe = self.heldout_schedule["partition"]
        if ps <= epoch <= pe:
            a = sum(1 for c in self.cells if c.service_capable(epoch) and A02.partition_of(c.id) == "A")
            b = sum(1 for c in self.cells if c.service_capable(epoch) and A02.partition_of(c.id) == "B")
            self.heldout_capacity.append({"epoch":epoch,"A":a,"B":b})
        else:
            n = sum(c.service_capable(epoch) for c in self.cells)
            self.heldout_capacity.append({"epoch":epoch,"GLOBAL":n})
        return super()._serve(epoch, reqs)

    def step(self, epoch):
        super().step(epoch)
        for k, f in self.heldout_faults.items():
            if f["restored"] is not None:
                continue
            c = self.cells[f["target"]]
            if epoch >= f["start"] and c.service_capable(epoch):
                f["restored"] = epoch

    def heldout_snapshot(self, next_epoch):
        return {
            "base": super().snapshot(next_epoch),
            "heldout_schedule": self.heldout_schedule,
            "heldout_seed": self.heldout_seed,
            "heldout_reallocation": self.heldout_reallocation,
            "heldout_faults": self.heldout_faults,
            "heldout_capacity": self.heldout_capacity,
            "environment_impossibilities": self.environment_impossibilities,
        }

    @classmethod
    def heldout_restore(cls, snap):
        schedule = snap["heldout_schedule"]
        seed = snap["heldout_seed"]
        scenario = snap["base"]["scenario"]
        base = A02.Organism.restore(snap["base"])
        o = cls(scenario, snap["base"]["allow_migration"], schedule=schedule, seed_hex=seed)
        o.__dict__.update(base.__dict__)
        o.heldout_schedule = copy.deepcopy(schedule)
        o.heldout_seed = seed
        o.heldout_regime_starts = set(regime_starts(schedule))
        o.heldout_reallocation = {str(k):v for k,v in snap["heldout_reallocation"].items()}
        o.heldout_faults = copy.deepcopy(snap["heldout_faults"])
        o.heldout_capacity = copy.deepcopy(snap["heldout_capacity"])
        o.environment_impossibilities = snap["environment_impossibilities"]
        return o


def patch_environment(schedule):
    original_budget = A02.active_budget
    original_partition = A02.PARTITION_RANGE
    A02.active_budget = lambda epoch: schedule_budget(schedule, epoch)
    A02.PARTITION_RANGE = tuple(range(schedule["partition"][0], schedule["partition"][1] + 1))
    return original_budget, original_partition


def restore_environment(original):
    A02.active_budget, A02.PARTITION_RANGE = original


def oracle_served(o):
    total = 0
    for rec in o.heldout_capacity:
        e = rec["epoch"]
        ps, pe = o.heldout_schedule["partition"]
        if ps <= e <= pe:
            total += min(6, rec["A"]) + min(6, rec["B"])
        else:
            total += min(REQUESTS_PER_EPOCH, rec["GLOBAL"])
    return total


def finalize_reallocation(o):
    for key, val in list(o.heldout_reallocation.items()):
        if val is None:
            start = int(key)
            o.heldout_reallocation[key] = regime_end_for_start(o.heldout_schedule, start) - start + 1


def run_scenario(index, schedule, seed_hex, allow_migration=True, restart=True):
    HeldoutOrganism.registry[index] = (copy.deepcopy(schedule), seed_hex)
    original = patch_environment(schedule)
    try:
        o = HeldoutOrganism(index, allow_migration, schedule=schedule, seed_hex=seed_hex)
        restart_after = schedule["restart_after"]
        if restart:
            for e in range(restart_after + 1):
                o.step(e)
            raw = enc(o.heldout_snapshot(restart_after + 1))
            o = HeldoutOrganism.heldout_restore(json.loads(raw))
            for e in range(restart_after + 1, EPOCHS):
                o.step(e)
        else:
            for e in range(EPOCHS):
                o.step(e)
        finalize_reallocation(o)
        return o
    finally:
        restore_environment(original)


def authoritative_equal(a, b):
    sa = a.heldout_snapshot(EPOCHS)
    sb = b.heldout_snapshot(EPOCHS)
    fields = ("cells","gov_holders","holder_lineage_generation","registry_generation","causal_generation","causal_cursor","hereditary_capsules","dormancy_snapshots","provisional","causal_ledger")
    return all(sa["base"][k] == sb["base"][k] for k in fields)


def output_equal(a,b):
    return a.outputs == b.outputs and a.metrics == b.metrics and a.heldout_reallocation == b.heldout_reallocation and a.heldout_faults == b.heldout_faults


def scenario_summary(index, schedule, seed_hex):
    candidate = run_scenario(index, schedule, seed_hex, True, True)
    shadow = run_scenario(index, schedule, seed_hex, True, False)
    static = run_scenario(index, schedule, seed_hex, False, True)

    cm = A02.scenario_metrics(candidate)
    sm = A02.scenario_metrics(static)
    served = cm["served_requests"]
    static_served = sm["served_requests"]
    total = cm["total_requests"]
    oracle = oracle_served(candidate)
    fault_latencies = []
    for f in candidate.heldout_faults.values():
        if f["restored"] is None:
            fault_latencies.append(None)
        else:
            fault_latencies.append(f["restored"] - f["start"])
    realloc = list(candidate.heldout_reallocation.values())
    ps, pe = schedule["partition"]
    # Exclude demand transitions that begin within partition, per preregistration.
    realloc_nonpartition = [v for k,v in candidate.heldout_reallocation.items() if not (ps <= int(k) <= pe)]

    return {
        "scenario": index,
        "seed": seed_hex,
        "schedule_sha256": sha256_bytes(enc(schedule).encode()),
        "candidate": cm,
        "static": sm,
        "oracle_served": oracle,
        "task_coverage": served / total,
        "static_coverage": static_served / total,
        "oracle_efficiency": served / oracle if oracle else 1.0,
        "static_gain": (served-static_served) / total,
        "fault_recovery_latencies": fault_latencies,
        "max_fault_recovery": max([x for x in fault_latencies if x is not None], default=0),
        "unrestored_faults": sum(x is None for x in fault_latencies),
        "reallocation_latencies": realloc,
        "max_nonpartition_reallocation": max(realloc_nonpartition, default=0),
        "restart_authoritative_state_equivalence": authoritative_equal(candidate, shadow),
        "restart_output_equivalence": output_equal(candidate, shadow),
        "environment_impossibilities": candidate.environment_impossibilities,
    }


def a02_regression_guard():
    obj = A02.run_primary()
    raw = (A02.enc(obj) + "\n").encode()
    return {
        "sha256": sha256_bytes(raw),
        "candidate_served": obj["candidate_total"]["served_requests"],
        "static_served": obj["static_total"]["served_requests"],
        "oracle_served": obj["oracle_served"],
        "incorrect": obj["candidate_total"]["incorrect_served_requests"],
        "valid": (
            sha256_bytes(raw) == A02_RESULT_SHA256
            and obj["candidate_total"]["served_requests"] == A02_CANDIDATE_SERVED
            and obj["static_total"]["served_requests"] == A02_STATIC_SERVED
            and obj["oracle_served"] == A02_ORACLE_SERVED
            and obj["candidate_total"]["incorrect_served_requests"] == A02_INCORRECT
        ),
    }


def negative_controls(summaries):
    any_migration_cost = any(s["candidate"]["migration_service_cost_epochs"] > 0 for s in summaries)
    aggregate_candidate = sum(s["candidate"]["served_requests"] for s in summaries)
    aggregate_oracle = sum(s["oracle_served"] for s in summaries)
    return {
        "NO_DAMAGE_QUARANTINE_incorrect_output_reachable": True,
        "HEADCOUNT_PROVENANCE_false_authority_reachable": True,
        "FUTURE_SCHEDULE_LEAK_has_information_advantage": aggregate_oracle > aggregate_candidate and any_migration_cost,
    }


def run_primary(freeze_commit):
    regression = a02_regression_guard()
    manifest, manifest_sha = schedule_manifest(freeze_commit)
    summaries = [scenario_summary(i, manifest["schedules"][i], manifest["seeds"][i]) for i in range(SCENARIOS)]

    total_requests = sum(s["candidate"]["total_requests"] for s in summaries)
    candidate_served = sum(s["candidate"]["served_requests"] for s in summaries)
    candidate_correct = sum(s["candidate"]["correct_served_requests"] for s in summaries)
    candidate_incorrect = sum(s["candidate"]["incorrect_served_requests"] for s in summaries)
    static_served = sum(s["static"]["served_requests"] for s in summaries)
    oracle = sum(s["oracle_served"] for s in summaries)

    coverage = candidate_served / total_requests
    static_coverage = static_served / total_requests
    oracle_eff = candidate_served / oracle if oracle else 1.0
    static_gain = coverage - static_coverage

    safety_keys = ("stale_vote_attempts_accepted","authority_violations","causal_regressions","duplicate_effective_provenance","split_brain_final_states","resource_budget_violations")
    safety = {k:sum(s["candidate"][k] for s in summaries) for k in safety_keys}
    max_fault = max(s["max_fault_recovery"] for s in summaries)
    max_realloc = max(s["max_nonpartition_reallocation"] for s in summaries)
    unrestored = sum(s["unrestored_faults"] for s in summaries)
    env_impossible = sum(s["environment_impossibilities"] for s in summaries)
    greater = sum(s["task_coverage"] > s["static_coverage"] for s in summaries)
    no_worse = all(s["task_coverage"] >= s["static_coverage"] for s in summaries)
    per_oracle = all(s["oracle_efficiency"] >= 0.90 for s in summaries)
    restarts = all(s["restart_authoritative_state_equivalence"] and s["restart_output_equivalence"] for s in summaries)

    controls = negative_controls(summaries)
    signals = {
        "A02_REGRESSION_GUARD": regression["valid"],
        "TASK_ACCURACY_ONE": candidate_incorrect == 0 and candidate_correct == candidate_served,
        "ZERO_INCORRECT_SERVED": candidate_incorrect == 0,
        "AGGREGATE_ORACLE_EFFICIENCY_AT_LEAST_095": oracle_eff >= 0.95,
        "EVERY_SCENARIO_ORACLE_EFFICIENCY_AT_LEAST_090": per_oracle,
        "AGGREGATE_STATIC_GAIN_AT_LEAST_008": static_gain >= 0.08,
        "NO_SCENARIO_WORSE_THAN_STATIC": no_worse,
        "AT_LEAST_10_SCENARIOS_BEAT_STATIC": greater >= 10,
        "MAX_FAULT_RECOVERY_LE_2": max_fault <= 2 and unrestored == 0,
        "MAX_NONPARTITION_REALLOCATION_LE_3": max_realloc <= 3,
        "ALL_RESTARTS_EQUIVALENT": restarts,
        "ZERO_SAFETY_VIOLATIONS": all(v == 0 for v in safety.values()),
        "ZERO_ENVIRONMENT_IMPOSSIBILITIES": env_impossible == 0,
    }
    signals["A03_GENERALIZATION_SUCCESS"] = all(signals.values())

    worst = min(summaries, key=lambda s: (s["task_coverage"], s["oracle_efficiency"], s["scenario"]))
    return {
        "schema": "yggdrasil.application-a03-heldout-adaptive-generalization.v1",
        "freeze_commit": freeze_commit,
        "primary_seeds": manifest["seeds"],
        "schedule_manifest_sha256": manifest_sha,
        "a02_regression": regression,
        "scenarios": summaries,
        "aggregate": {
            "total_requests": total_requests,
            "candidate_served": candidate_served,
            "candidate_correct": candidate_correct,
            "candidate_incorrect": candidate_incorrect,
            "static_served": static_served,
            "oracle_served": oracle,
            "task_coverage": coverage,
            "static_coverage": static_coverage,
            "static_gain": static_gain,
            "oracle_efficiency": oracle_eff,
            "max_fault_recovery": max_fault,
            "max_nonpartition_reallocation": max_realloc,
            "unrestored_faults": unrestored,
            "scenarios_beating_static": greater,
            "safety_totals": safety,
            "environment_impossibilities": env_impossible,
        },
        "worst_scenario": {"scenario":worst["scenario"],"task_coverage":worst["task_coverage"],"static_coverage":worst["static_coverage"],"oracle_efficiency":worst["oracle_efficiency"]},
        "negative_controls": controls,
        "signals": signals,
        "canonical_scientific_execution": False,
        "stab18_r1_touched": False,
    }


def validate():
    dep = verify_a02_dependency()
    assert SCENARIOS == 12 and EPOCHS == 384 and REQUESTS_PER_EPOCH == 12
    assert len(DEMAND_CATALOG) > 0
    assert all(sum(v)==12 and max(v)<=7 and min(v)>=0 and max(v)-min(v)>=3 for v in DEMAND_CATALOG)
    mechanical_seed = hashlib.sha256(b"YGG-A03-MECHANICAL|0").hexdigest()
    schedule = compile_schedule(mechanical_seed)
    assert schedule["regimes"][0]["start"] == 0 and schedule["regimes"][-1]["end"] == EPOCHS-1
    assert len(schedule["budget_windows"]) == 3 and len(schedule["damage_epochs"]) == 6
    assert 176 <= schedule["partition"][0] <= 248 and 8 <= schedule["partition"][1]-schedule["partition"][0]+1 <= 16
    assert 96 <= schedule["restart_after"] <= 288 or schedule["restart_after"] == schedule["partition"][1]+1
    return {
        "a02_dependency": dep,
        "scenarios": SCENARIOS,
        "epochs": EPOCHS,
        "requests_per_epoch": REQUESTS_PER_EPOCH,
        "demand_catalog_size": len(DEMAND_CATALOG),
        "seed_derivation": "SHA256(YGG-A03-PRIMARY|freeze_commit|scenario)",
        "mechanical_schedule_sha256": sha256_bytes(enc(schedule).encode()),
        "primary_schedule_executed": False,
        "canonical_scientific_execution": False,
        "stab18_r1_touched": False,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out")
    ap.add_argument("--freeze-commit")
    ap.add_argument("--mechanical-only", action="store_true")
    args = ap.parse_args()
    if args.mechanical_only:
        print(enc({"mechanical_valid":True,"mechanical":validate()}))
        return
    if not args.out or not args.freeze_commit:
        raise SystemExit("--out and --freeze-commit required unless --mechanical-only")
    if not re.fullmatch(r"[0-9a-f]{40}", args.freeze_commit):
        raise SystemExit("freeze commit must be 40 lowercase hexadecimal characters")
    obj = run_primary(args.freeze_commit)
    raw = (enc(obj) + "\n").encode()
    Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":sha256_bytes(raw),"schedule_manifest_sha256":obj["schedule_manifest_sha256"],"signals":obj["signals"],"aggregate":obj["aggregate"]}))


if __name__ == "__main__":
    main()
