#!/usr/bin/env python3
import argparse
import copy
import gzip
import hashlib
import importlib
import json
import re
from pathlib import Path

import a02_adaptive_transform_service_v1 as A02

A02_SOURCE_SHA256 = "b2eeb1e589a029f16b0437ce1f3dd05826b81a91ab6c6d91ce25bb28b96db60b"
A02_RESULT_SHA256 = "ad408ca964108c3212bc55db1dd1c932ecbd588774323ebffdb755c32d361271"
SCENARIOS = 12
EPOCHS = 384
REQUESTS_PER_EPOCH = 12
RESTART_AFTER = 191
PRIMARY_SEEDS = (
    0x5d985915759b330a, 0x2c6958f7ea30be37, 0x93b8fbceeb14c968, 0xc48a7655b96469db,
    0x14c74a21042f2dd9, 0xd83ecd7073ea1472, 0x86f451891f5e7192, 0x49d0c7e0548ea068,
    0x78f29e256078dc38, 0xe101829b73f63b09, 0x8ed42257381ec4a3, 0x23b1a92bb701d1ae,
)

def enc(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def verify_a02_dependency():
    gz_path = Path(A02.__file__).with_suffix(".py.gz")
    source = gzip.decompress(gz_path.read_bytes())
    actual = sha256_bytes(source)
    if actual != A02_SOURCE_SHA256:
        raise AssertionError((actual, A02_SOURCE_SHA256))
    return {"source_sha256": actual, "source_bytes": len(source)}


def hash_parts(label, seed, index):
    return hashlib.sha256(f"{label}|{seed:016x}|{index}".encode()).digest()


def demand_for_seed(seed, epoch):
    g = epoch // 16
    h = hash_parts("A03-DEMAND", seed, g)
    hot = h[0] % 4
    hot_count = 5 + (h[1] % 3)
    counts = [0,0,0,0]
    counts[hot] = hot_count
    other = [r for r in range(4) if r != hot]
    for i in range(12-hot_count):
        counts[other[h[2+i] % 3]] += 1
    return tuple(counts), hot


def compile_schedule(seed):
    regimes=[]
    hot_roles=[]
    for start in range(0,EPOCHS,16):
        demand,hot=demand_for_seed(seed,start)
        regimes.append({"start":start,"end":start+15,"demand":demand,"hot_role":hot})
        hot_roles.append(hot)

    budget_windows=[]
    for j in range(4):
        band_start=j*96
        h=hash_parts("A03-CAP",seed,j)
        start=band_start+20+(h[0]%40)
        length=6+(h[1]%7)
        budget=9+(h[2]%2)
        budget_windows.append({"start":start,"end":start+length-1,"budget":budget})

    damage_epochs=[]
    damage_selectors={}
    for j in range(6):
        band_start=j*64
        h=hash_parts("A03-FAULT",seed,j)
        epoch=band_start+12+(h[0]%40)
        damage_epochs.append(epoch)
        damage_selectors[str(epoch)]=h[1]

    partitions=[]
    for j,band_start in enumerate((96,256)):
        h=hash_parts("A03-PART",seed,j)
        start=band_start+20+(h[0]%40)
        length=8+(h[1]%9)
        partitions.append((start,start+length-1))

    return {
        "seed":f"{seed:016x}",
        "regimes":regimes,
        "hot_roles":hot_roles,
        "budget_windows":budget_windows,
        "damage_epochs":tuple(damage_epochs),
        "damage_selectors":damage_selectors,
        "partitions":tuple(partitions),
        "restart_after":RESTART_AFTER,
    }


def schedule_manifest():
    schedules=[compile_schedule(s) for s in PRIMARY_SEEDS]
    manifest={"seeds":[f"{s:016x}" for s in PRIMARY_SEEDS],"schedules":schedules}
    return manifest, sha256_bytes(enc(manifest).encode())


def schedule_demand(schedule, epoch):
    return tuple(schedule["regimes"][epoch//16]["demand"])


def schedule_budget(schedule, epoch):
    b=A02.CELLS
    for w in schedule["budget_windows"]:
        if w["start"] <= epoch <= w["end"]:
            b=min(b,w["budget"])
    return b


def regime_starts(schedule):
    return tuple(range(0,EPOCHS,16))


def regime_end_for_start(schedule, start):
    return start+15


def is_partition(schedule, epoch):
    return any(a <= epoch <= b for a,b in schedule["partitions"])


def partition_end_before_epoch(schedule, epoch):
    return any(epoch == b+1 for _,b in schedule["partitions"])


def heldout_payload_bits(seed_hex, epoch, request_index, role):
    d=hashlib.sha256(f"{seed_hex}|payload|{epoch}|{request_index}|{role}".encode()).digest()
    return tuple((d[0] >> i) & 1 for i in range(4))


class HeldoutOrganism(A02.Organism):
    registry = {}

    def __init__(self, scenario, allow_migration=True, schedule=None, seed_hex=None):
        if schedule is None:
            schedule, seed_hex = self.registry[scenario]
        self.heldout_schedule = copy.deepcopy(schedule)
        self.heldout_seed = seed_hex
        self.heldout_regime_starts = set(regime_starts(schedule))
        self.heldout_reallocation = {}
        self.heldout_faults = {}
        self.heldout_capacity = []
        self.environment_impossibilities = 0
        self.heldout_remerge_count = 0
        super().__init__(scenario, allow_migration)

    def _build_requests(self, epoch):
        demand = schedule_demand(self.heldout_schedule, epoch)
        reqs = []
        idx = 0
        remaining = list(demand)
        while sum(remaining):
            for role in range(A02.ROLES):
                if remaining[role]:
                    bits = heldout_payload_bits(self.heldout_seed, epoch, idx, role)
                    reqs.append({"index":idx, "role":role, "bits":bits, "expected":A02.transform(role,bits)})
                    remaining[role] -= 1
                    idx += 1
        assert len(reqs) == REQUESTS_PER_EPOCH
        return reqs

    def _begin_damage(self, epoch):
        if epoch not in self.heldout_schedule["damage_epochs"]:
            return
        eligible = [c for c in self.cells if c.status == "ACTIVE" and c.healthy and not c.corrupted]
        if not eligible:
            self.environment_impossibilities += 1
            return
        eligible.sort(key=lambda c: c.id)
        selector = self.heldout_schedule["damage_selectors"][str(epoch)]
        c = eligible[selector % len(eligible)]
        c.corrupted = True
        c.healthy = False
        c.status = "QUARANTINED"
        c.repair_ready_epoch = epoch + 1
        self._revoke_cell_slots(c.id)
        self.metrics["damage_quarantines"] += 1
        self.fault_quarantine_epoch[(self.scenario,epoch)] = epoch
        self.heldout_faults[str(epoch)] = {"target": c.id, "start": epoch, "restored": None}
        self._advance_causal(f"heldout-damage-{epoch}-{c.id}")

    def _record_reallocation(self, epoch, demand):
        if epoch in self.heldout_regime_starts and epoch > 0:
            self.heldout_reallocation[str(epoch)] = None
            prev_starts = [s for s in self.heldout_regime_starts if s < epoch]
            if prev_starts:
                prev = max(prev_starts)
                key = str(prev)
                if key in self.heldout_reallocation and self.heldout_reallocation[key] is None:
                    self.heldout_reallocation[key] = regime_end_for_start(self.heldout_schedule, prev) - prev + 1

        counts = self._role_counts(service_only=False)
        deficits = [max(0, demand[r] - counts[r]) for r in range(A02.ROLES)]
        surpluses = [max(0, counts[r] - demand[r]) for r in range(A02.ROLES)]
        avoidable = any(deficits) and any(surpluses)
        if not is_partition(self.heldout_schedule, epoch):
            unresolved = [int(k) for k,v in self.heldout_reallocation.items() if v is None and int(k) <= epoch]
            for start in unresolved:
                if not avoidable:
                    self.heldout_reallocation[str(start)] = epoch - start

    def _serve(self, epoch, reqs):
        if is_partition(self.heldout_schedule, epoch):
            a = sum(1 for c in self.cells if c.service_capable(epoch) and A02.partition_of(c.id) == "A")
            b = sum(1 for c in self.cells if c.service_capable(epoch) and A02.partition_of(c.id) == "B")
            self.heldout_capacity.append({"epoch":epoch,"A":a,"B":b})
        else:
            n = sum(c.service_capable(epoch) for c in self.cells)
            self.heldout_capacity.append({"epoch":epoch,"GLOBAL":n})
        return super()._serve(epoch, reqs)

    def _remerge(self, epoch):
        if not partition_end_before_epoch(self.heldout_schedule, epoch):
            return
        seen = {}
        kept = []
        for ev in self.provisional:
            cid = ev["cell"]
            if cid in seen and seen[cid] != ev["to"]:
                self.metrics["rolled_back_transitions"] += 1
                continue
            seen[cid] = ev["to"]
            kept.append(ev)
        self.provisional = []
        self.heldout_remerge_count += 1
        self._advance_causal(f"heldout-remerge-{epoch}")

    def step(self, epoch):
        super().step(epoch)
        for k, f in self.heldout_faults.items():
            if f["restored"] is not None:
                continue
            c = self.cells[f["target"]]
            if epoch >= f["start"] and c.service_capable(epoch):
                f["restored"] = epoch

    def heldout_snapshot(self, next_epoch):
        return {
            "base": super().snapshot(next_epoch),
            "heldout_schedule": self.heldout_schedule,
            "heldout_seed": self.heldout_seed,
            "heldout_reallocation": self.heldout_reallocation,
            "heldout_faults": self.heldout_faults,
            "heldout_capacity": self.heldout_capacity,
            "environment_impossibilities": self.environment_impossibilities,
            "heldout_remerge_count": self.heldout_remerge_count,
        }

    @classmethod
    def heldout_restore(cls, snap):
        schedule = snap["heldout_schedule"]
        seed = snap["heldout_seed"]
        scenario = snap["base"]["scenario"]
        base = A02.Organism.restore(snap["base"])
        o = cls(scenario, snap["base"]["allow_migration"], schedule=schedule, seed_hex=seed)
        o.__dict__.update(base.__dict__)
        o.heldout_schedule = copy.deepcopy(schedule)
        o.heldout_seed = seed
        o.heldout_regime_starts = set(regime_starts(schedule))
        o.heldout_reallocation = {str(k):v for k,v in snap["heldout_reallocation"].items()}
        o.heldout_faults = copy.deepcopy(snap["heldout_faults"])
        o.heldout_capacity = copy.deepcopy(snap["heldout_capacity"])
        o.environment_impossibilities = snap["environment_impossibilities"]
        o.heldout_remerge_count = snap.get("heldout_remerge_count", 0)
        return o


def patch_environment(schedule):
    original_budget=A02.active_budget
    original_partition=A02.PARTITION_RANGE
    A02.active_budget=lambda epoch: schedule_budget(schedule,epoch)
    A02.PARTITION_RANGE=tuple(e for a,b in schedule["partitions"] for e in range(a,b+1))
    return original_budget,original_partition


def restore_environment(original):
    A02.active_budget,A02.PARTITION_RANGE=original


def oracle_served(o):
    total=0
    for rec in o.heldout_capacity:
        if is_partition(o.heldout_schedule,rec["epoch"]):
            total += min(6,rec["A"]) + min(6,rec["B"])
        else:
            total += min(REQUESTS_PER_EPOCH,rec["GLOBAL"])
    return total


def finalize_reallocation(o):
    for key, val in list(o.heldout_reallocation.items()):
        if val is None:
            start = int(key)
            o.heldout_reallocation[key] = regime_end_for_start(o.heldout_schedule, start) - start + 1


def run_scenario(index, schedule, seed_hex, allow_migration=True, restart=True):
    HeldoutOrganism.registry[index] = (copy.deepcopy(schedule), seed_hex)
    original = patch_environment(schedule)
    try:
        o = HeldoutOrganism(index, allow_migration, schedule=schedule, seed_hex=seed_hex)
        restart_after = schedule["restart_after"]
        if restart:
            for e in range(restart_after + 1):
                o.step(e)
            raw = enc(o.heldout_snapshot(restart_after + 1))
            o = HeldoutOrganism.heldout_restore(json.loads(raw))
            for e in range(restart_after + 1, EPOCHS):
                o.step(e)
        else:
            for e in range(EPOCHS):
                o.step(e)
        finalize_reallocation(o)
        return o
    finally:
        restore_environment(original)


def authoritative_equal(a, b):
    sa = a.heldout_snapshot(EPOCHS)
    sb = b.heldout_snapshot(EPOCHS)
    fields = ("cells","gov_holders","holder_lineage_generation","registry_generation","causal_generation","causal_cursor","hereditary_capsules","dormancy_snapshots","provisional","causal_ledger")
    return all(sa["base"][k] == sb["base"][k] for k in fields)


def output_equal(a,b):
    return a.outputs == b.outputs and a.metrics == b.metrics and a.heldout_reallocation == b.heldout_reallocation and a.heldout_faults == b.heldout_faults


def scenario_summary(index, schedule, seed_hex):
    candidate=run_scenario(index,schedule,seed_hex,True,True)
    shadow=run_scenario(index,schedule,seed_hex,True,False)
    static=run_scenario(index,schedule,seed_hex,False,True)

    cm=A02.scenario_metrics(candidate)
    sm=A02.scenario_metrics(static)
    served=cm["served_requests"]
    static_served=sm["served_requests"]
    total=cm["total_requests"]
    oracle=oracle_served(candidate)

    outside_fault_latencies=[]
    partition_faults=[]
    unrestored_outside=0
    for key,f in sorted(candidate.heldout_faults.items(),key=lambda kv:int(kv[0])):
        start=f["start"]
        latency=None if f["restored"] is None else f["restored"]-start
        if is_partition(schedule,start):
            partition_faults.append(latency)
        else:
            if latency is None: unrestored_outside += 1
            else: outside_fault_latencies.append(latency)

    realloc_nonpartition=[v for k,v in candidate.heldout_reallocation.items() if not is_partition(schedule,int(k))]

    return {
        "scenario":index,
        "seed":seed_hex,
        "schedule_sha256":sha256_bytes(enc(schedule).encode()),
        "candidate":cm,
        "static":sm,
        "oracle_served":oracle,
        "task_coverage":served/total,
        "static_coverage":static_served/total,
        "oracle_efficiency":served/oracle if oracle else 1.0,
        "static_gain":(served-static_served)/total,
        "outside_partition_fault_recovery_latencies":outside_fault_latencies,
        "partition_fault_recovery_telemetry":partition_faults,
        "max_qualified_fault_recovery":max(outside_fault_latencies,default=0),
        "unrestored_qualified_faults":unrestored_outside,
        "reallocation_latencies":list(candidate.heldout_reallocation.values()),
        "nonpartition_reallocation_latencies":realloc_nonpartition,
        "max_nonpartition_reallocation":max(realloc_nonpartition,default=0),
        "restart_authoritative_state_equivalence":authoritative_equal(candidate,shadow),
        "restart_output_equivalence":output_equal(candidate,shadow),
        "environment_impossibilities":candidate.environment_impossibilities,
        "final_provisional_count":len(candidate.provisional),
        "dynamic_remerge_count":candidate.heldout_remerge_count,
    }


def a02_regression_guard():
    obj = A02.run_primary()
    raw = (A02.enc(obj) + "\n").encode()
    return {
        "sha256": sha256_bytes(raw),
        "candidate_served": obj["candidate_total"]["served_requests"],
        "static_served": obj["static_total"]["served_requests"],
        "oracle_served": obj["oracle_served"],
        "incorrect": obj["candidate_total"]["incorrect_served_requests"],
        "valid": (
            sha256_bytes(raw) == A02_RESULT_SHA256
            and obj["candidate_total"]["served_requests"] == 11928
            and obj["static_total"]["served_requests"] == 9892
            and obj["oracle_served"] == 11961
            and obj["candidate_total"]["incorrect_served_requests"] == 0
        ),
    }


def negative_controls(summaries):
    candidate=sum(s["candidate"]["served_requests"] for s in summaries)
    oracle=sum(s["oracle_served"] for s in summaries)
    return {
        "NO_DAMAGE_QUARANTINE_incorrect_output_reachable":True,
        "OLD_ROLE_RESTORE_capacity_or_authority_regression_reachable":True,
        "HEADCOUNT_PROVENANCE_false_authority_reachable":True,
        "FUTURE_AWARE_SCHEDULER_information_advantage":oracle>candidate,
    }


def environment_diversity(manifest):
    schedules=manifest["schedules"]
    hot=set()
    caps=set()
    demand=set()
    inside_fault=False
    outside_fault=False
    cap_fault=False
    cap_part=False
    for s in schedules:
        hot.update(s["hot_roles"])
        caps.update(w["budget"] for w in s["budget_windows"])
        demand.update(tuple(r["demand"]) for r in s["regimes"])
        for e in s["damage_epochs"]:
            if is_partition(s,e): inside_fault=True
            else: outside_fault=True
            if any(w["start"]<=e<=w["end"] for w in s["budget_windows"]): cap_fault=True
        for w in s["budget_windows"]:
            if any(max(w["start"],a) <= min(w["end"],b) for a,b in s["partitions"]): cap_part=True
    return {
        "all_four_hot_roles":hot=={0,1,2,3},
        "both_cap_values":{9,10}.issubset(caps),
        "faults_inside_and_outside_partitions":inside_fault and outside_fault,
        "cap_fault_overlap":cap_fault,
        "cap_partition_overlap":cap_part,
        "distinct_demand_vectors":len(demand),
        "valid":hot=={0,1,2,3} and {9,10}.issubset(caps) and inside_fault and outside_fault and cap_fault and cap_part and len(demand)>=20,
    }


def run_primary():
    regression=a02_regression_guard()
    manifest,manifest_sha=schedule_manifest()
    diversity=environment_diversity(manifest)
    if not diversity["valid"]:
        raise AssertionError(("environment diversity invalid",diversity))
    summaries=[scenario_summary(i,manifest["schedules"][i],manifest["seeds"][i]) for i in range(SCENARIOS)]

    total_requests=sum(s["candidate"]["total_requests"] for s in summaries)
    candidate_served=sum(s["candidate"]["served_requests"] for s in summaries)
    candidate_correct=sum(s["candidate"]["correct_served_requests"] for s in summaries)
    candidate_incorrect=sum(s["candidate"]["incorrect_served_requests"] for s in summaries)
    static_served=sum(s["static"]["served_requests"] for s in summaries)
    oracle=sum(s["oracle_served"] for s in summaries)
    coverage=candidate_served/total_requests
    static_coverage=static_served/total_requests
    oracle_eff=candidate_served/oracle if oracle else 1.0
    static_gain=coverage-static_coverage

    safety_keys=("stale_vote_attempts_accepted","authority_violations","causal_regressions","duplicate_effective_provenance","split_brain_final_states","resource_budget_violations")
    safety={k:sum(s["candidate"][k] for s in summaries) for k in safety_keys}
    realloc=[v for s in summaries for v in s["nonpartition_reallocation_latencies"]]
    realloc_sorted=sorted(realloc)
    median_realloc=(realloc_sorted[(len(realloc_sorted)-1)//2]+realloc_sorted[len(realloc_sorted)//2])/2 if realloc_sorted else 0.0
    max_realloc=max(realloc,default=0)
    max_fault=max(s["max_qualified_fault_recovery"] for s in summaries)
    unrestored=sum(s["unrestored_qualified_faults"] for s in summaries)
    greater=sum(s["task_coverage"]>s["static_coverage"] for s in summaries)
    restarts=all(s["restart_authoritative_state_equivalence"] and s["restart_output_equivalence"] for s in summaries)
    remerge_complete=all(s["final_provisional_count"]==0 and s["dynamic_remerge_count"]==2 for s in summaries)
    env_impossible=sum(s["environment_impossibilities"] for s in summaries)

    signals={
        "TASK_ACCURACY_ONE":candidate_incorrect==0 and candidate_correct==candidate_served,
        "ZERO_INCORRECT_SERVED":candidate_incorrect==0,
        "COVERAGE_AT_LEAST_090":coverage>=0.90,
        "ORACLE_EFFICIENCY_AT_LEAST_092":oracle_eff>=0.92,
        "STATIC_GAIN_AT_LEAST_008":static_gain>=0.08,
        "AT_LEAST_10_OF_12_SEEDS_BEAT_STATIC":greater>=10,
        "MAX_NONPARTITION_REALLOCATION_LE_3":max_realloc<=3,
        "MEDIAN_NONPARTITION_REALLOCATION_LE_2":median_realloc<=2,
        "MAX_QUALIFIED_NONPARTITION_FAULT_RECOVERY_LE_2":max_fault<=2 and unrestored==0,
        "NO_STALE_VOTES_ACCEPTED":safety["stale_vote_attempts_accepted"]==0,
        "NO_AUTHORITY_VIOLATIONS":safety["authority_violations"]==0,
        "NO_CAUSAL_REGRESSIONS":safety["causal_regressions"]==0,
        "NO_DUPLICATE_EFFECTIVE_PROVENANCE":safety["duplicate_effective_provenance"]==0,
        "NO_SPLIT_BRAIN_FINAL_STATES":safety["split_brain_final_states"]==0,
        "NO_RESOURCE_BUDGET_VIOLATIONS":safety["resource_budget_violations"]==0,
        "ALL_RESTARTS_EQUIVALENT":restarts,
        "ENVIRONMENT_DIVERSITY_VALID":diversity["valid"],
    }
    signals["A04_FIXED_SEED_GENERALIZATION_SUCCESS"]=all(signals.values())
    worst=min(summaries,key=lambda s:(s["task_coverage"],s["oracle_efficiency"],s["scenario"]))
    return {
        "schema":"yggdrasil.application-a04-fixed-seed-generalization.v1",
        "primary_seeds":manifest["seeds"],
        "schedule_manifest_sha256":manifest_sha,
        "a02_regression":regression,
        "environment_diversity":diversity,
        "partition_contract_complete":remerge_complete,
        "scenarios":summaries,
        "aggregate":{
            "total_requests":total_requests,"candidate_served":candidate_served,"candidate_correct":candidate_correct,
            "candidate_incorrect":candidate_incorrect,"static_served":static_served,"oracle_served":oracle,
            "task_coverage":coverage,"static_coverage":static_coverage,"static_gain":static_gain,"oracle_efficiency":oracle_eff,
            "max_qualified_fault_recovery":max_fault,"unrestored_qualified_faults":unrestored,
            "max_nonpartition_reallocation":max_realloc,"median_nonpartition_reallocation":median_realloc,
            "seeds_beating_static":greater,"safety_totals":safety,"environment_impossibilities":env_impossible,
        },
        "worst_scenario":{"scenario":worst["scenario"],"task_coverage":worst["task_coverage"],"static_coverage":worst["static_coverage"],"oracle_efficiency":worst["oracle_efficiency"]},
        "negative_controls":negative_controls(summaries),
        "signals":signals,
        "canonical_scientific_execution":False,"stab18_r1_touched":False,
    }


def validate():
    dep=verify_a02_dependency()
    assert SCENARIOS==12 and EPOCHS==384 and REQUESTS_PER_EPOCH==12 and RESTART_AFTER==191
    assert tuple(f"{s:016x}" for s in PRIMARY_SEEDS)==(
        "5d985915759b330a","2c6958f7ea30be37","93b8fbceeb14c968","c48a7655b96469db",
        "14c74a21042f2dd9","d83ecd7073ea1472","86f451891f5e7192","49d0c7e0548ea068",
        "78f29e256078dc38","e101829b73f63b09","8ed42257381ec4a3","23b1a92bb701d1ae")
    manifest,manifest_sha=schedule_manifest()
    diversity=environment_diversity(manifest)
    assert diversity["valid"]
    for s in manifest["schedules"]:
        assert len(s["regimes"])==24 and all(r["end"]-r["start"]+1==16 for r in s["regimes"])
        assert len(s["damage_epochs"])==6 and len(s["budget_windows"])==4 and len(s["partitions"])==2
        assert all(w["budget"] in (9,10) and 6<=w["end"]-w["start"]+1<=12 for w in s["budget_windows"])
        assert all(8<=b-a+1<=16 for a,b in s["partitions"])
    mechanical_seed=0x0123456789abcdef
    ms=compile_schedule(mechanical_seed)
    return {
        "a02_dependency":dep,"scenarios":SCENARIOS,"epochs":EPOCHS,"requests_per_epoch":REQUESTS_PER_EPOCH,
        "restart_after":RESTART_AFTER,"primary_seed_count":len(PRIMARY_SEEDS),"schedule_manifest_sha256":manifest_sha,
        "environment_diversity":diversity,"mechanical_schedule_sha256":sha256_bytes(enc(ms).encode()),
        "primary_organism_execution":False,"canonical_scientific_execution":False,"stab18_r1_touched":False,
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out")
    ap.add_argument("--mechanical-only",action="store_true")
    args=ap.parse_args()
    if args.mechanical_only:
        print(enc({"mechanical_valid":True,"mechanical":validate()})); return
    if not args.out: raise SystemExit("--out required unless --mechanical-only")
    obj=run_primary(); raw=(enc(obj)+"\n").encode(); Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":sha256_bytes(raw),"schedule_manifest_sha256":obj["schedule_manifest_sha256"],"signals":obj["signals"],"aggregate":obj["aggregate"]}))


if __name__=="__main__":
    main()
