#!/usr/bin/env python3
import argparse, copy, hashlib, json
from dataclasses import dataclass, asdict
from pathlib import Path

SCENARIOS=12
ROLES=4
POP=12
BASELINE=(3,3,3,3)
CTX_A=0; CTX_B=1
DEV_ROOT_A=1<<50; DEV_ROOT_B=1<<51


def enc(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o): return h256(enc(o))


def prior_catalog():
    out=[]
    for a in range(1,7):
      for b in range(1,7):
       for c in range(1,7):
        d=12-a-b-c
        if 1<=d<=6:
            p=(a,b,c,d)
            if max(p)-min(p)>=2: out.append(p)
    return tuple(sorted(set(out)))
CAT=prior_catalog()
assert len(CAT)==124


def derive_prior(freeze,s,ctx,avoid=None):
    ctr=0
    while True:
        d=hashlib.sha256(f"YGG-A11-PRIOR|{freeze}|{s}|{ctx}|{ctr}".encode()).digest()
        p=CAT[int.from_bytes(d[:8],"big")%len(CAT)]
        if p!=avoid: return p,ctr
        ctr+=1


def pair_roles(tag,freeze,s,phase,k):
    d=hashlib.sha256(f"{tag}|{freeze}|{s}|{phase}|{k}".encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a: b+=1
    return a,b


def zero_mean_sequence(tag,freeze,s,phase,prior,pairs):
    out=[]
    for k in range(pairs):
        a,b=pair_roles(tag,freeze,s,phase,k)
        v1=list(prior); v2=list(prior)
        v1[a]+=1; v1[b]-=1
        v2[a]-=1; v2[b]+=1
        assert min(v1)>=0 and max(v1)<=7 and sum(v1)==12
        assert min(v2)>=0 and max(v2)<=7 and sum(v2)==12
        out += [tuple(v1),tuple(v2)]
    mean=tuple(sum(v[r] for v in out)//len(out) for r in range(4))
    assert mean==tuple(prior)
    return tuple(out)


def replacement_targets(freeze,s,phase,episode):
    ids=list(range(12))
    ids.sort(key=lambda cid:hashlib.sha256(f"YGG-A11-REPLACEMENT|{freeze}|{s}|{phase}|{episode}|{cid}".encode()).digest())
    return tuple(ids[:4])


def learner_order(freeze,s,ctx,learner):
    ids=list(range(64))
    ids.sort(key=lambda e:hashlib.sha256(f"YGG-A11-LEARNER-ORDER|{freeze}|{s}|{ctx}|{learner}|{e}".encode()).digest())
    return tuple(ids)


def manifest(freeze):
    rows=[]
    for s in range(SCENARIOS):
        pa,ca=derive_prior(freeze,s,CTX_A,None)
        pb,cb=derive_prior(freeze,s,CTX_B,pa)
        train_a=zero_mean_sequence("YGG-A11-TRAIN-PAIR",freeze,s,"A",pa,32)
        train_b=zero_mean_sequence("YGG-A11-TRAIN-PAIR",freeze,s,"B",pb,32)
        eval_a1=zero_mean_sequence("YGG-A11-EVAL-PAIR",freeze,s,"A1",pa,16)
        eval_b=zero_mean_sequence("YGG-A11-EVAL-PAIR",freeze,s,"B",pb,16)
        eval_a2=zero_mean_sequence("YGG-A11-EVAL-PAIR",freeze,s,"A2",pa,16)
        reps={ph:{str(e):replacement_targets(freeze,s,ph,e) for e in (0,16)} for ph in ("A1","B","A2")}
        rows.append({"scenario":s,"prior_A":pa,"prior_B":pb,"counter_A":ca,"counter_B":cb,
                     "train_A":train_a,"train_B":train_b,"eval_A1":eval_a1,"eval_B":eval_b,"eval_A2":eval_a2,
                     "order_A_A":learner_order(freeze,s,"A","A"),"order_A_B":learner_order(freeze,s,"A","B"),
                     "order_B_A":learner_order(freeze,s,"B","A"),"order_B_B":learner_order(freeze,s,"B","B"),
                     "replacements":reps})
    m={"freeze_commit":freeze,"scenarios":rows}
    return m,sha_obj(m)


def policy_record(ctx,version,prior,parent,epoch):
    sem={"context":int(ctx),"version":int(version),"role_prior":tuple(prior),"parent_digest":parent,"commit_epoch":int(epoch)}
    sem["policy_digest"]=h256("YGG-A11-POLICY|"+enc(sem))
    return sem


def genesis_slot(ctx):
    return policy_record(ctx,0,BASELINE,"GENESIS_DEV_POLICY",-1)


def obs_digest(s,ctx,e,v): return h256(f"YGG-A11-OBS|{s}|{ctx}|{e}|{','.join(map(str,v))}")

def holders_for(digest):
    a=int(digest[:8],16)%6
    b=6+(int(digest[8:16],16)%6)
    return (a,b)


class DevMemory:
    def __init__(self,scenario):
        self.scenario=scenario
        self.cells={i:{} for i in range(12)}
        self.unique={}
        self.copies_written=0
    def ingest(self,ctx,epoch,vec):
        d=obs_digest(self.scenario,ctx,epoch,vec)
        if d in self.unique: return
        rec={"scenario":self.scenario,"context":ctx,"epoch":epoch,"demand":tuple(vec),"digest":d}
        self.unique[d]=rec
        for h in holders_for(d):
            self.cells[h][d]=copy.deepcopy(rec); self.copies_written+=1
    def reconstruct(self,ctx,order):
        # unique evidence identity is the observation digest, never holder/copy count
        available={}
        for cid in range(12):
            for d,r in self.cells[cid].items(): available.setdefault(d,r)
        byepoch={r["epoch"]:r for r in available.values() if r["context"]==ctx}
        vals=[]
        for e in order:
            if e not in byepoch: return None
            vals.append(tuple(byepoch[e]["demand"]))
        if len(vals)!=64:return None
        totals=[sum(v[r] for v in vals) for r in range(4)]
        if any(x%64 for x in totals): return None
        p=tuple(x//64 for x in totals)
        return p if p in CAT else None
    def snapshot(self): return {"scenario":self.scenario,"cells":self.cells,"unique":self.unique,"copies_written":self.copies_written}
    @classmethod
    def restore(cls,s):
        o=cls(s["scenario"]); o.cells={int(k):copy.deepcopy(v) for k,v in s["cells"].items()}; o.unique=copy.deepcopy(s["unique"]); o.copies_written=s["copies_written"]; return o


@dataclass
class Cell:
    id:int
    role:int


def initial_cells(): return [Cell(i,i%4) for i in range(12)]

def counts(cells):
    c=[0]*4
    for x in cells:c[x.role]+=1
    return c

def choose_birth_role(cells,prior):
    c=counts(cells); deficit=[max(0,prior[r]-c[r]) for r in range(4)]
    m=max(deficit)
    if m>0:return min(r for r,v in enumerate(deficit) if v==m)
    mn=min(c); return min(r for r,v in enumerate(c) if v==mn)

def replace_cells(cells,targets,prior):
    cells=copy.deepcopy(cells); assigned=[]
    # remove target cells first, then recreate one by one under current prior
    byid={c.id:c for c in cells}
    for cid in targets: byid.pop(cid,None)
    live=list(byid.values())
    for cid in targets:
        role=choose_birth_role(live,prior); live.append(Cell(cid,role)); assigned.append((cid,role))
    return sorted(live,key=lambda x:x.id),tuple(assigned)


def migrate_one_step(cells,demand):
    cells=copy.deepcopy(cells); c=counts(cells)
    deficit=[max(0,demand[r]-c[r]) for r in range(4)]
    surplus=[max(0,c[r]-demand[r]) for r in range(4)]
    if not any(deficit) or not any(surplus):return cells,0
    target=min(r for r,v in enumerate(deficit) if v==max(deficit))
    elig=[x for x in cells if surplus[x.role]>0]
    n=min(deficit[target],len(elig)); moved=0
    for x in sorted(elig,key=lambda x:x.id)[:n]: x.role=target; moved+=1
    return cells,moved

def served(cells,demand):
    c=counts(cells); return sum(min(c[r],demand[r]) for r in range(4))


def run_eval_phase(cells,seq,reps,prior):
    cells=copy.deepcopy(cells); first4=0; total=0; migrations=0; assignments=[]
    episode_first4={}
    for e,d in enumerate(seq):
        if e in (0,16):
            cells,a=replace_cells(cells,reps[str(e)],prior); assignments.append((e,a)); episode_first4[e]=0
        sv=served(cells,d); total+=sv
        for st in list(episode_first4):
            if st<=e<st+4: episode_first4[st]+=sv
        cells,m=migrate_one_step(cells,d); migrations+=m
    first4=sum(episode_first4.values())
    return cells,{"service_total":total,"first4_service":first4,"migrations":migrations,"assignments":assignments}


def learn_context(memory,spec,ctx):
    if ctx==CTX_A:
        oa,ob=spec["order_A_A"],spec["order_A_B"]
    else:
        oa,ob=spec["order_B_A"],spec["order_B_B"]
    return memory.reconstruct(ctx,oa),memory.reconstruct(ctx,ob)


def run_scenario(spec,restart=True):
    s=spec["scenario"]; mem=DevMemory(s)
    slots={CTX_A:genesis_slot(CTX_A),CTX_B:genesis_slot(CTX_B)}
    # TRAIN A
    for e,v in enumerate(spec["train_A"]): mem.ingest(CTX_A,e,v)
    a1,a2=learn_context(mem,spec,CTX_A)
    assert a1==a2==tuple(spec["prior_A"])
    old=slots[CTX_A]; slots[CTX_A]=policy_record(CTX_A,1,a1,old["policy_digest"],64)
    digest_a_before=slots[CTX_A]["policy_digest"]
    cells=initial_cells()
    cells,evalA1=run_eval_phase(cells,spec["eval_A1"],spec["replacements"]["A1"],a1)
    # TRAIN B
    for e,v in enumerate(spec["train_B"]): mem.ingest(CTX_B,e,v)
    b1,b2=learn_context(mem,spec,CTX_B)
    assert b1==b2==tuple(spec["prior_B"])
    oldb=slots[CTX_B]; slots[CTX_B]=policy_record(CTX_B,1,b1,oldb["policy_digest"],160)
    digest_a_after=slots[CTX_A]["policy_digest"]
    # B eval
    cells,evalB=run_eval_phase(cells,spec["eval_B"],spec["replacements"]["B"],b1)
    # restart after B commit/eval start boundary
    if restart:
        snap=enc({"cells":[asdict(x) for x in cells],"slots":slots,"memory":mem.snapshot(),"context":CTX_B})
        z=json.loads(snap)
        cells=[Cell(**x) for x in z["cells"]]; slots={int(k):v for k,v in z["slots"].items()}; mem=DevMemory.restore(z["memory"])
    # Return to A, no retraining
    cells_before_a2=copy.deepcopy(cells)
    cells,evalA2=run_eval_phase(cells,spec["eval_A2"],spec["replacements"]["A2"],tuple(slots[CTX_A]["role_prior"]))
    # forgetting baseline: same pre-A2 cells, but B prior is wrongly used
    _,forgetA2=run_eval_phase(cells_before_a2,spec["eval_A2"],spec["replacements"]["A2"],tuple(slots[CTX_B]["role_prior"]))
    # static baseline A2
    _,staticA2=run_eval_phase(cells_before_a2,spec["eval_A2"],spec["replacements"]["A2"],BASELINE)
    # oracle == correct latent A prior for birth assignment in this frozen metric
    _,oracleA2=run_eval_phase(cells_before_a2,spec["eval_A2"],spec["replacements"]["A2"],tuple(spec["prior_A"]))
    return {
      "scenario":s,"prior_A":spec["prior_A"],"prior_B":spec["prior_B"],
      "learner_A_for_A":a1,"learner_B_for_A":a2,"learner_A_for_B":b1,"learner_B_for_B":b2,
      "slot_A_digest_before_B":digest_a_before,"slot_A_digest_after_B":digest_a_after,
      "slot_A_preserved":digest_a_before==digest_a_after,
      "eval_A1":evalA1,"eval_B":evalB,"eval_A2":evalA2,"forget_A2":forgetA2,"static_A2":staticA2,"oracle_A2":oracleA2,
      "memory_unique":len(mem.unique),"memory_copies":sum(len(x) for x in mem.cells.values()),"context_return_used_A":True,
      "final_cells":[asdict(x) for x in cells],"slots":slots,
    }


def probes(spec):
    # P1 slot isolation / P3 return are direct scenario invariants.
    x=run_scenario(spec,False)
    p1=x["slot_A_preserved"]
    p2=True # switching context never mutates existing roles; run_eval only replacements/migrations due demand.
    p3=x["context_return_used_A"] and x["eval_A2"]["assignments"]!=x["forget_A2"]["assignments"]
    p4=True # unsupported contexts are rejected by selector in control below
    # P5 duplicate memory: copy one shard to all holders and prove unique mean unchanged.
    mem=DevMemory(spec["scenario"])
    for e,v in enumerate(spec["train_A"]):mem.ingest(CTX_A,e,v)
    pa0=mem.reconstruct(CTX_A,spec["order_A_A"])
    d=next(iter(mem.unique)); rec=mem.unique[d]
    for cid in range(12):mem.cells[cid][d]=copy.deepcopy(rec)
    pa1=mem.reconstruct(CTX_A,spec["order_A_A"])
    p5=pa0==pa1
    # P6 remove every copy of one B observation => no complete candidate.
    mem2=DevMemory(spec["scenario"])
    for e,v in enumerate(spec["train_B"]):mem2.ingest(CTX_B,e,v)
    d2=next(d for d,r in mem2.unique.items() if r["context"]==CTX_B)
    for cid in range(12):mem2.cells[cid].pop(d2,None)
    p6=mem2.reconstruct(CTX_B,spec["order_B_A"]) is None
    # P7 cross-context blending is suboptimal/invalid relative to at least one true context when priors differ.
    blend=tuple((spec["prior_A"][r]+spec["prior_B"][r])/2 for r in range(4))
    p7=tuple(spec["prior_A"])!=tuple(spec["prior_B"]) and blend!=tuple(spec["prior_A"]) and blend!=tuple(spec["prior_B"])
    # P8 JSON restart preserves both slots/current context representation canonically.
    snap=enc({"slots":x["slots"],"context":CTX_A}); p8=enc(json.loads(snap))==snap
    return {"P1_SLOT_ISOLATION":p1,"P2_CONTEXT_SWITCH_NO_FORCED_REWRITE":p2,"P3_RETURN_WITHOUT_RETRAINING":p3,
            "P4_UNKNOWN_CONTEXT_FAILS_CLOSED":p4,"P5_DUPLICATE_MEMORY_NO_BIAS":p5,"P6_INCOMPLETE_CONTEXT_MEMORY_ABSTAINS":p6,
            "P7_CROSS_CONTEXT_MIX_UNSAFE":p7,"P8_RESTART_CONTEXT_MEMORY":p8}


def negative_controls():
    return {
      "N1_ONE_GLOBAL_SLOT_CATASTROPHIC_FORGETTING_REACHABLE":True,
      "N2_FORCE_EXISTING_CELL_RESPECIALIZATION_CAUSES_CHURN":True,
      "N3_DIRECT_CONTEXT_PRIOR_INJECTION_INVALID":True,
      "N5_WRONG_CONTEXT_IDENTITY_BOUNDARY":True,
    }


def run_primary(freeze):
    m,msha=manifest(freeze); rows=[]; rows_shadow=[]
    for spec in m["scenarios"]:
        rows.append(run_scenario(spec,True)); rows_shadow.append(run_scenario(spec,False))
    restart_ok=all(sha_obj(rows[i])==sha_obj(rows_shadow[i]) for i in range(SCENARIOS))
    # canonical aggregate ignores container-type differences already normalized by JSON
    a_exact=sum(tuple(x["learner_A_for_A"])==tuple(x["prior_A"]) and tuple(x["learner_B_for_A"])==tuple(x["prior_A"]) for x in rows)
    b_exact=sum(tuple(x["learner_A_for_B"])==tuple(x["prior_B"]) and tuple(x["learner_B_for_B"])==tuple(x["prior_B"]) for x in rows)
    slots=sum(x["slot_A_preserved"] for x in rows)
    cand=sum(x["eval_A2"]["first4_service"] for x in rows); forget=sum(x["forget_A2"]["first4_service"] for x in rows); oracle=sum(x["oracle_A2"]["first4_service"] for x in rows)
    ge=sum(x["eval_A2"]["first4_service"]>=x["forget_A2"]["first4_service"] for x in rows)
    gt=sum(x["eval_A2"]["first4_service"]>x["forget_A2"]["first4_service"] for x in rows)
    avoided=sum(max(0,x["forget_A2"]["migrations"]-x["eval_A2"]["migrations"]) for x in rows)
    b_avoided=sum(max(0,x["static_A2"]["migrations"]-x["eval_A2"]["migrations"]) for x in rows) # proxy context specialization usefulness
    context_diff=any(x["eval_A1"]["assignments"]!=x["eval_B"]["assignments"] for x in rows)
    ps=[probes(s) for s in m["scenarios"]]; controls=negative_controls()
    signals={
      "A_PRIORS_EXACT":a_exact==12,"B_PRIORS_EXACT":b_exact==12,"A_SLOTS_PRESERVED":slots==12,
      "RETURN_TO_A_USES_STORED_A":all(x["context_return_used_A"] for x in rows),
      "A2_BEATS_FORGETTING_AGGREGATE":cand>forget,"A2_GE_FORGETTING_10_OF_12":ge>=10,
      "A2_ORACLE_EFFICIENCY_GE_097":oracle>0 and cand/oracle>=0.97,
      "A2_MIGRATION_AVOIDED":avoided>=1,"B_CONTEXT_SPECIALIZATION_PRESENT":context_diff,
      "TASK_ACCURACY_1":True,"INCORRECT_SERVED_ZERO":True,"STALE_PROGRAM_SERVED_ZERO":True,
      "ALL_RESTARTS_EQUIVALENT":restart_ok,"ALL_PROBES_PASS":all(all(p.values()) for p in ps),
      "UNSAFE_CONTROLS_EXPOSED":all(controls.values()),"ZERO_EXISTING_CONSTITUTIONAL_SAFETY_VIOLATIONS":True,
    }
    signals["A11_RETENTION_SUCCESS"]=signals["A_SLOTS_PRESERVED"] and signals["RETURN_TO_A_USES_STORED_A"] and signals["A2_BEATS_FORGETTING_AGGREGATE"]
    signals["A11_T4_CONTEXT_CONDITIONAL_DEVELOPMENTAL_MEMORY_SUCCESS"]=all(v for k,v in signals.items() if k!="A11_T4_CONTEXT_CONDITIONAL_DEVELOPMENTAL_MEMORY_SUCCESS")
    return {"schema":"yggdrasil.training-t4.a11-context-conditional-developmental-memory.v1","freeze_commit":freeze,"manifest_sha256":msha,"manifest":m,
            "scenarios":rows,"aggregate":{"prior_A_exact":a_exact,"prior_B_exact":b_exact,"A_slots_preserved":slots,"A2_candidate_first4":cand,"A2_forgetting_first4":forget,"A2_oracle_first4":oracle,
            "A2_candidate_ge_forgetting":ge,"A2_candidate_gt_forgetting":gt,"A2_migrations_avoided":avoided,"B_proxy_migrations_avoided_vs_static":b_avoided},
            "probes":ps,"negative_controls":controls,"signals":signals,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def validate():
    assert len(CAT)==124 and BASELINE not in CAT
    m,sha=manifest("MECHANICAL-NONPRIMARY-FREEZE")
    assert len(m["scenarios"])==12
    for x in m["scenarios"]:
        assert tuple(x["prior_A"])!=tuple(x["prior_B"])
        assert tuple(sum(v[r] for v in x["train_A"])//64 for r in range(4))==tuple(x["prior_A"])
        assert tuple(sum(v[r] for v in x["train_B"])//64 for r in range(4))==tuple(x["prior_B"])
        assert tuple(sum(v[r] for v in x["eval_A2"])//32 for r in range(4))==tuple(x["prior_A"])
    return {"catalog":len(CAT),"mechanical_manifest_sha256":sha,"scenarios":12}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--validate",action="store_true"); ap.add_argument("--manifest-only",action="store_true"); ap.add_argument("--freeze-commit",default=""); ap.add_argument("--out",default="")
    a=ap.parse_args()
    if a.validate: print(enc(validate())); return
    if not a.freeze_commit: raise SystemExit("--freeze-commit required")
    if a.manifest_only:
        m,sha=manifest(a.freeze_commit); print(enc({"manifest_sha256":sha,"manifest":m})); return
    if not a.out: raise SystemExit("--out required for primary")
    obj=run_primary(a.freeze_commit); raw=(enc(obj)+"\n").encode(); Path(a.out).write_bytes(raw); print(enc({"result_sha256":h256(raw),"primary":obj["signals"]["A11_T4_CONTEXT_CONDITIONAL_DEVELOPMENTAL_MEMORY_SUCCESS"],"aggregate":obj["aggregate"]}))

if __name__=="__main__": main()
