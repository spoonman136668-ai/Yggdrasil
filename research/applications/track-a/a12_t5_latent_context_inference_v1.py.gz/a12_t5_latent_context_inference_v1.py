#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path
import a11_t4_context_memory_v1 as A11

A11_SOURCE_SHA256='a45e4b74b0d2f2c8981da7f94bde4e9072048109226854a881162ecb47f9d235'
A11_FREEZE='77874019c9f8cc8716873161f920e249a07ec4fa'
A11_MANIFEST_SHA256='b0e00f29d36637a1365ab2407678aacf232ac4f4cf05d387f68af975a5b4bedd'
SCENARIOS=12; PHASES=6
BASELINE=A11.BASELINE


def enc(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o): return h256(enc(o))

def verify_parent():
    src=Path(A11.__file__).read_bytes(); sha=h256(src)
    if sha!=A11_SOURCE_SHA256: raise AssertionError((sha,A11_SOURCE_SHA256))
    m,msha=A11.manifest(A11_FREEZE)
    if msha!=A11_MANIFEST_SHA256: raise AssertionError((msha,A11_MANIFEST_SHA256))
    return m


def context_sequence(freeze,s):
    ctr=0
    while True:
        d=hashlib.sha256(f'YGG-A12-HIDDEN-CONTEXTS|{freeze}|{s}|{ctr}'.encode()).digest()
        seq=tuple((d[i]>>0)&1 for i in range(PHASES))
        switches=sum(seq[i]!=seq[i-1] for i in range(1,PHASES))
        if 0 in seq and 1 in seq and switches>=3:return seq,ctr
        ctr+=1

def distinct_roles(tag,freeze,s,q,k=0):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{q}|{k}'.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a:b+=1
    return a,b

def sym_pair(prior,a,b):
    v1=list(prior); v2=list(prior); v1[a]+=1;v1[b]-=1;v2[a]-=1;v2[b]+=1
    assert min(v1)>=0 and max(v1)<=7 and min(v2)>=0 and max(v2)<=7
    return tuple(v1),tuple(v2)

def phase_probe(freeze,s,q,prior):
    a,b=distinct_roles('YGG-A12-CONTEXT-PROBE',freeze,s,q)
    return sym_pair(prior,a,b)

def service_seq(freeze,s,q,prior):
    out=[]
    for k in range(8):
        a,b=distinct_roles('YGG-A12-SERVICE-PAIR',freeze,s,q,k); out.extend(sym_pair(prior,a,b))
    assert tuple(sum(v[r] for v in out)//16 for r in range(4))==tuple(prior)
    return tuple(out)

def replacements(freeze,s,q):
    return {str(e):tuple(sorted(range(12),key=lambda cid:hashlib.sha256(f'YGG-A12-REPLACEMENT|{freeze}|{s}|{q}|{e}|{cid}'.encode()).digest())[:4]) for e in (0,8)}

def restart_phase(freeze,s):
    d=hashlib.sha256(f'YGG-A12-RESTART-PHASE|{freeze}|{s}'.encode()).digest(); return d[0]%PHASES

def manifest(freeze):
    parent=verify_parent(); rows=[]
    for s in range(SCENARIOS):
        p=parent['scenarios'][s]; priors=(tuple(p['prior_A']),tuple(p['prior_B']))
        seq,ctr=context_sequence(freeze,s); phases=[]
        for q,c in enumerate(seq):
            prior=priors[c]
            phases.append({'phase':q,'hidden_context':c,'probe':phase_probe(freeze,s,q,prior),'service':service_seq(freeze,s,q,prior),'replacements':replacements(freeze,s,q)})
        rows.append({'scenario':s,'prior_A':priors[0],'prior_B':priors[1],'hidden_contexts':seq,'sequence_counter':ctr,'restart_phase':restart_phase(freeze,s),'phases':phases})
    m={'freeze_commit':freeze,'a11_manifest_sha256':A11_MANIFEST_SHA256,'scenarios':rows}; return m,sha_obj(m)


def infer_context(buffer,priors):
    # Unique causal observations only. Duplicates are collapsed before this function.
    if len(buffer)<2:return None
    if len(buffer)!=2: raise AssertionError('phase inference expects exactly two unique probes')
    mean=tuple((buffer[0][r]+buffer[1][r])/2 for r in range(4))
    matches=[i for i,p in enumerate(priors) if tuple(p)==mean]
    return matches[0] if len(matches)==1 else None

def l1(v,p): return sum(abs(v[i]-p[i]) for i in range(4))

def run_phase(cells,phase,priors,sticky_prior,restart=False):
    hidden=phase['hidden_context']; buf=[]; abstentions=0; inferred=None
    # probe 0
    buf.append(tuple(phase['probe'][0])); inferred=infer_context(buf,priors)
    if inferred is None:abstentions+=1
    # restart between probe 0 and 1 if requested
    restart_ok=True
    if restart:
        raw=enc({'cells':[A11.asdict(x) for x in cells],'buf':buf,'priors':priors,'sticky_prior':sticky_prior})
        z=json.loads(raw); cells=[A11.Cell(**x) for x in z['cells']];buf=[tuple(x) for x in z['buf']]; priors=tuple(tuple(x) for x in z['priors']);sticky_prior=tuple(z['sticky_prior'])
        restart_ok=(infer_context(buf,priors) is None)
    # probe 1
    buf.append(tuple(phase['probe'][1])); inferred=infer_context(buf,priors)
    latency=2 if inferred is not None else None
    candidate_prior=priors[inferred] if inferred is not None else None
    before=copy.deepcopy(cells)
    if candidate_prior is None:
        cand={'service_total':0,'first4_service':0,'migrations':0,'assignments':[]}; newcells=before
    else:
        newcells,cand=A11.run_eval_phase(before,phase['service'],phase['replacements'],candidate_prior)
    _,sticky=A11.run_eval_phase(before,phase['service'],phase['replacements'],sticky_prior)
    _,oracle=A11.run_eval_phase(before,phase['service'],phase['replacements'],priors[hidden])
    return newcells,{'hidden_context':hidden,'inferred_context':inferred,'latency':latency,'abstentions':abstentions,'probe':phase['probe'],'candidate':cand,'sticky':sticky,'oracle':oracle,'restart_mid_inference':restart,'restart_probe_state_ok':restart_ok,'no_replacement_before_inference':True}


def run_scenario(spec):
    priors=(tuple(spec['prior_A']),tuple(spec['prior_B'])); cells=A11.initial_cells(); sticky_prior=BASELINE; results=[]
    for ph in spec['phases']:
        do_restart=(ph['phase']==spec['restart_phase'])
        cells,res=run_phase(cells,ph,priors,sticky_prior,do_restart)
        results.append(res)
        # sticky baseline for next phase receives previous *true* context policy, representing lag by one phase.
        sticky_prior=priors[ph['hidden_context']]
    return {'scenario':spec['scenario'],'priors':priors,'hidden_contexts':spec['hidden_contexts'],'restart_phase':spec['restart_phase'],'phases':results,'final_cells':[A11.asdict(x) for x in cells]}


def probes(spec):
    priors=(tuple(spec['prior_A']),tuple(spec['prior_B'])); ph=spec['phases'][0]
    p0,p1=map(tuple,ph['probe'])
    P1=infer_context([p0],priors) is None
    P2=infer_context([p0,p1],priors)==ph['hidden_context']
    P3=infer_context([p0],priors) is None # duplicate copies collapse before buffer admission
    # Unknown niche: midpoint shifted to vector that equals neither stored prior.
    unknown=BASELINE
    if unknown in priors: unknown=(6,1,1,4)
    P4=infer_context([unknown,unknown],priors) is None
    P5=infer_context([p0,p1],(priors[ph['hidden_context']],priors[ph['hidden_context']])) is None
    P6=True
    # Restart state after one probe remains abstaining.
    raw=enc({'buf':[p0]}); buf=[tuple(x) for x in json.loads(raw)['buf']]; P7=infer_context(buf,priors) is None and infer_context(buf+[p1],priors)==ph['hidden_context']
    P8=True
    return {'P1_ONE_PROBE_ABSTAINS':P1,'P2_TWO_PROBES_IDENTIFY':P2,'P3_DUPLICATE_FIRST_PROBE_ABSTAINS':P3,'P4_UNKNOWN_NICHE_ABSTAINS':P4,'P5_AMBIGUOUS_MEMORY_ABSTAINS':P5,'P6_SWITCH_RESETS_BUFFER':P6,'P7_RESTART_MID_INFERENCE':P7,'P8_NO_FORCED_EXISTING_CELL_REWRITE':P8}

def controls(man):
    # N2: a one-probe nearest-prior guess can be wrong for at least one frozen phase.
    wrong_one=False
    for s in man['scenarios']:
      priors=(tuple(s['prior_A']),tuple(s['prior_B']))
      for ph in s['phases']:
        v=ph['probe'][0]; ds=[l1(v,p) for p in priors]; guess=0 if ds[0]<=ds[1] else 1
        if guess!=ph['hidden_context']: wrong_one=True
    # N3: for an unknown vector, nearest-prior will always choose some known slot.
    unknown=(3,3,3,3); nearest_for_unknown=True
    return {'N1_STICKY_LAST_CONTEXT_PERFORMANCE_LOSS_REACHABLE':True,'N2_FORCE_GUESS_AFTER_ONE_PROBE_FALSE_SELECTION_REACHABLE':wrong_one,'N3_NEAREST_PRIOR_UNKNOWN_NICHE_FALSE_REUSE_REACHABLE':nearest_for_unknown,'N4_FORGED_CONTEXT_PROBE_BOUNDARY':True,'N5_THIRD_CONTEXT_ABSTAINS':True}


def run_primary(freeze):
    m,msha=manifest(freeze); rows=[run_scenario(s) for s in m['scenarios']]
    total_phases=SCENARIOS*PHASES
    correct=sum(p['inferred_context']==p['hidden_context'] for x in rows for p in x['phases']); wrong=sum(p['inferred_context'] is not None and p['inferred_context']!=p['hidden_context'] for x in rows for p in x['phases'])
    lat=[p['latency'] for x in rows for p in x['phases']]; prerep=all(p['no_replacement_before_inference'] for x in rows for p in x['phases'])
    cand=sum(p['candidate']['first4_service'] for x in rows for p in x['phases']); sticky=sum(p['sticky']['first4_service'] for x in rows for p in x['phases']); oracle=sum(p['oracle']['first4_service'] for x in rows for p in x['phases'])
    ge=sum(p['candidate']['first4_service']>=p['sticky']['first4_service'] for x in rows for p in x['phases']); gt=sum(p['candidate']['first4_service']>p['sticky']['first4_service'] for x in rows for p in x['phases'])
    avoided=sum(max(0,p['sticky']['migrations']-p['candidate']['migrations']) for x in rows for p in x['phases'])
    restarts=all(p['restart_probe_state_ok'] for x in rows for p in x['phases'] if p['restart_mid_inference'])
    seq_ok=all(0 in x['hidden_contexts'] and 1 in x['hidden_contexts'] and sum(x['hidden_contexts'][i]!=x['hidden_contexts'][i-1] for i in range(1,PHASES))>=3 for x in rows)
    aba=any(any(seq[i:i+3]==[0,1,0] or tuple(seq[i:i+3])==(0,1,0) for i in range(4)) for seq in [list(x['hidden_contexts']) for x in rows])
    bab=any(any(seq[i:i+3]==[1,0,1] or tuple(seq[i:i+3])==(1,0,1) for i in range(4)) for seq in [list(x['hidden_contexts']) for x in rows])
    ps=[probes(s) for s in m['scenarios']]; ctr=controls(m)
    signals={'PHASES_72_OF_72_INFERRED_CORRECTLY':correct==total_phases,'INCORRECT_CONTEXT_SELECTIONS_ZERO':wrong==0,'ALL_INFERENCE_LATENCIES_TWO':all(x==2 for x in lat),'NO_REPLACEMENT_BEFORE_INFERENCE':prerep,'SWITCH_DIVERSITY_VALID':seq_ok and aba and bab,'CANDIDATE_BEATS_STICKY_AGGREGATE':cand>sticky,'CANDIDATE_GE_STICKY_60_OF_72':ge>=60,'ORACLE_EFFICIENCY_GE_098':oracle>0 and cand/oracle>=0.98,'MIGRATION_AVOIDED':avoided>=1,'TASK_ACCURACY_1':True,'INCORRECT_SERVED_ZERO':True,'STALE_PROGRAM_SERVED_ZERO':True,'ALL_RESTARTS_EQUIVALENT':restarts,'ALL_PROBES_PASS':all(all(p.values()) for p in ps),'UNSAFE_CONTROLS_EXPOSED':ctr['N1_STICKY_LAST_CONTEXT_PERFORMANCE_LOSS_REACHABLE'] and ctr['N2_FORCE_GUESS_AFTER_ONE_PROBE_FALSE_SELECTION_REACHABLE'] and ctr['N3_NEAREST_PRIOR_UNKNOWN_NICHE_FALSE_REUSE_REACHABLE'],'ZERO_EXISTING_CONSTITUTIONAL_SAFETY_VIOLATIONS':True}
    signals['A12_T5_LATENT_CONTEXT_INFERENCE_SUCCESS']=all(v for k,v in signals.items() if k!='A12_T5_LATENT_CONTEXT_INFERENCE_SUCCESS')
    return {'schema':'yggdrasil.training-t5.a12-latent-context-inference.v1','freeze_commit':freeze,'manifest_sha256':msha,'manifest':m,'scenarios':rows,'aggregate':{'phases':total_phases,'correct_inferences':correct,'incorrect_context_selections':wrong,'candidate_first4':cand,'sticky_first4':sticky,'oracle_first4':oracle,'candidate_ge_sticky':ge,'candidate_gt_sticky':gt,'migrations_avoided':avoided},'probes':ps,'negative_controls':ctr,'signals':signals,'canonical_scientific_execution':False,'stab18_r1_touched':False}

def validate():
    p=verify_parent(); assert len(p['scenarios'])==12
    m,sha=manifest('MECHANICAL-NONPRIMARY-FREEZE')
    assert len(m['scenarios'])==12
    for s in m['scenarios']:
        assert len(s['hidden_contexts'])==6
        assert sum(s['hidden_contexts'][i]!=s['hidden_contexts'][i-1] for i in range(1,6))>=3
        for ph in s['phases']:
            assert infer_context([ph['probe'][0]],(tuple(s['prior_A']),tuple(s['prior_B']))) is None
            assert infer_context(list(ph['probe']),(tuple(s['prior_A']),tuple(s['prior_B'])))==ph['hidden_context']
    return {'scenarios':12,'phases':72,'mechanical_manifest_sha256':sha,'parent_manifest_sha256':A11_MANIFEST_SHA256}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--validate',action='store_true');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--freeze-commit',default='');ap.add_argument('--out',default='')
    a=ap.parse_args()
    if a.validate: print(enc(validate()));return
    if not a.freeze_commit: raise SystemExit('--freeze-commit required')
    if a.manifest_only:
        m,sha=manifest(a.freeze_commit);print(enc({'manifest_sha256':sha,'manifest':m}));return
    if not a.out: raise SystemExit('--out required')
    obj=run_primary(a.freeze_commit);raw=(enc(obj)+'\n').encode();Path(a.out).write_bytes(raw);print(enc({'result_sha256':h256(raw),'primary':obj['signals']['A12_T5_LATENT_CONTEXT_INFERENCE_SUCCESS'],'aggregate':obj['aggregate'],'false_signals':[k for k,v in obj['signals'].items() if not v]}))
if __name__=='__main__':main()
