#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path
import a14_f14_exact as A14

SCENARIOS=12
CAT=tuple(tuple(x) for x in A14.CAT)
OBS_ROOTS=A14.OBS_ROOTS
LEARNER_A=A14.LEARNER_A;LEARNER_B=A14.LEARNER_B
F14='c0957332578557efc2975ca2da31cf11d07b45ff'
A14_SOURCE_SHA256='d2187358170045ddd9869be1a53d6938c4ade6547c0b8d83415e16cc6dc40045'
A14_MANIFEST_SHA256='83a0ad4d67d7a3f3625e49c311f5d2a85c73fee40cde96e24937ae79e1e944ae'
A15_CLOSURE='1bea52944ed3b836c6dc6612c73e5e430b69bd2d'
A15_SOURCE_SHA256='4dfd8814c869380317bb90d8baf68f79f4c2ce9874db7bc9278546b56001c071'
F15='dd9cd2cfee331d94631af17b0f0a61684e5091a4'
A15_MANIFEST_SHA256='0e7d6c14cff50e8e8705cbf4082d5f333267b2e4646eea333559db4b4b28cef9'
A15_RESULT_SHA256='494b3096e407790a341d66ee37833546b5ce50e2a88a2308a17c1c5bfb0941d3'
A15_CV2=((2,1,4,5),(1,3,6,2),(6,4,1,1),(5,3,1,3),(4,1,5,2),(1,4,3,4),(5,1,5,1),(5,2,1,4),(1,6,1,4),(4,2,2,4),(2,4,4,2),(3,1,2,6))
PATCHES=4

def enc(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str):x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o):return h256(enc(o))
def l1(a,b):return sum(abs(x-y) for x,y in zip(a,b))
def delta(a,b):return tuple(x-y for x,y in zip(a,b))
def valid_delta(d):return sorted(d)==[-1,0,0,1] and sum(abs(x) for x in d)==2

def verify_parent():
    if h256(Path(A14.__file__).read_bytes())!=A14_SOURCE_SHA256:raise AssertionError('A14_SOURCE')
    m,ms=A14.manifest(F14)
    if ms!=A14_MANIFEST_SHA256:raise AssertionError((ms,A14_MANIFEST_SHA256))
    if len(A15_CV2)!=12 or any(p not in CAT for p in A15_CV2):raise AssertionError('A15_CV2')
    return m

def neighbors(current,pa,pb,pc1,earlier):
    xs=[p for p in CAT if p not in (tuple(pa),tuple(pb),tuple(pc1),tuple(current)) and p not in tuple(earlier) and l1(p,current)==2]
    return tuple(sorted(xs))

def path_for(freeze,s,pa,pb,pc1,p0):
    p=[tuple(p0)]
    for k in range(1,5):
        xs=neighbors(p[-1],pa,pb,pc1,p[:-1])
        if not xs:raise AssertionError(('NO_PATCH_TARGET',s,k,p[-1]))
        d=hashlib.sha256(f'YGG-A17-PATCH-TARGET|{freeze}|{s}|{k}'.encode()).digest()
        p.append(xs[int.from_bytes(d[:8],'big')%len(xs)])
    return tuple(p)

def roles(tag,freeze,s,k,j,extra=''):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{k}|{j}|{extra}'.encode()).digest();a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return a,b

def sym(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1;return tuple(x),tuple(y)

def observations(freeze,s,k,target):
    out=[]
    for j in range(8):
        a,b=roles('YGG-A17-PATCH-OBS',freeze,s,k,j);out.extend(sym(target,a,b))
    return tuple(out)

def eval_seq(freeze,s,k,target):
    out=[]
    for j in range(8):
        a,b=roles('YGG-A17-PATCH-EVAL',freeze,s,k,j);out.extend(sym(target,a,b))
    return tuple(out)

def replacements(freeze,s,k):
    out={}
    for e in (0,8):
        xs=[(h256(f'YGG-A17-REPLACE|{freeze}|{s}|{k}|{e}|{cid}'),cid) for cid in range(12)]
        out[str(e)]=tuple(cid for _,cid in sorted(xs)[:4])
    return out

def attest(freeze,s,k,e):
    d=hashlib.sha256(f'YGG-A17-ATTEST|{freeze}|{s}|{k}|{e}'.encode()).digest();a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return OBS_ROOTS[a],OBS_ROOTS[b]

def order(freeze,s,k,learner):
    xs=[(h256(f'YGG-A17-ORDER|{freeze}|{s}|{k}|{learner}|{e}'),e) for e in range(16)]
    return tuple(e for _,e in sorted(xs))

def manifest(freeze):
    pm=verify_parent();rows=[]
    for s in range(12):
        a=pm['scenarios'][s];pa=tuple(a['prior_A']);pb=tuple(a['prior_B']);pc1=tuple(a['prior_C']);p0=tuple(A15_CV2[s]);path=path_for(freeze,s,pa,pb,pc1,p0)
        patches=[]
        for k in range(1,5):
            target=path[k];obs=observations(freeze,s,k,target)
            patches.append({'patch':k,'from':path[k-1],'target':target,'delta':delta(target,path[k-1]),'observations':obs,
              'attestations':tuple(attest(freeze,s,k,e) for e in range(16)),'order_A':order(freeze,s,k,'A'),'order_B':order(freeze,s,k,'B'),
              'eval':eval_seq(freeze,s,k,target),'replacements':replacements(freeze,s,k),'restart_after_observation':8 if k==3 else None})
        rows.append({'scenario':s,'prior_A':pa,'prior_B':pb,'prior_C_v1':pc1,'base_C_v2':p0,'path':path,'patches':patches})
    m={'freeze_commit':freeze,'a15_closure':A15_CLOSURE,'a15_source_sha256':A15_SOURCE_SHA256,'a15_freeze':F15,'a15_manifest_sha256':A15_MANIFEST_SHA256,'a15_result_sha256':A15_RESULT_SHA256,'scenarios':rows}
    return m,sha_obj(m)

class PatchMemory:
    def __init__(self,s,k):self.s=s;self.k=k;self.unique={};self.cells={i:{} for i in range(12)}
    def ingest(self,e,v,roots):
        if len(set(roots))<2:return False
        d=h256(f'YGG-A17-OBSREC|{self.s}|{self.k}|{e}|{",".join(map(str,v))}')
        rec={'e':e,'demand':tuple(v),'digest':d,'roots':tuple(sorted(roots))};self.unique[d]=rec
        a=int(d[:8],16)%6;b=6+int(d[8:16],16)%6;self.cells[a][d]=copy.deepcopy(rec);self.cells[b][d]=copy.deepcopy(rec);return True
    def mean(self,ordr,n=16):
        avail={}
        for c in self.cells.values():
            for d,r in c.items():avail.setdefault(d,r)
        by={r['e']:r for r in avail.values()};vals=[]
        for e in ordr:
            if e not in by:return None
            vals.append(tuple(by[e]['demand']))
        if len(vals)!=n:return None
        sm=[sum(v[r] for v in vals) for r in range(4)]
        if any(x%n for x in sm):return None
        p=tuple(x//n for x in sm);return p if p in CAT else None
    def snapshot(self):return {'s':self.s,'k':self.k,'unique':self.unique,'cells':self.cells}
    @classmethod
    def restore(cls,z):
        o=cls(z['s'],z['k']);o.unique=copy.deepcopy(z['unique']);o.cells={int(k):copy.deepcopy(v) for k,v in z['cells'].items()};return o

def durable_history(pc1,p0):
    J=A14.A12.A11;v1=J.policy_record(A14.CTX_C,1,pc1,'NEW_CONTEXT_GENESIS',256);v2=J.policy_record(A14.CTX_C,2,p0,v1['policy_digest'],512);return (v1,v2)

def effective_digest(base_digest,journal,tip):return h256('YGG-A17-EFFECTIVE|'+enc({'base':base_digest,'journal_digests':[x['patch_digest'] for x in journal[:tip]],'tip':tip}))
def effective_prior(base,journal,tip):
    p=list(base)
    for rec in journal[:tip]:p=[x+y for x,y in zip(p,rec['delta'])]
    return tuple(p)

def make_patch(k,parent_digest,d,target,evidence):
    sem={'patch_index':k,'parent_effective_digest':parent_digest,'delta':tuple(d),'target_prior':tuple(target),'evidence_digest':evidence,'commit_epoch':k}
    sem['patch_digest']=h256('YGG-A17-PATCH|'+enc(sem));return sem

def authorize(base,journal,tip,k,target_a,target_b,parent_digest,evidence_digest):
    cur=effective_prior(base,journal,tip);curdig=effective_digest('C_V2_BASE',journal,tip);d=delta(target_a,cur) if target_a is not None else None
    if tip!=k-1 or len(journal)!=k-1:return False,'TIP_OR_LENGTH',journal,tip
    if target_a is None or target_b is None or tuple(target_a)!=tuple(target_b):return False,'LEARNER_DISAGREE',journal,tip
    if tuple(target_a) not in CAT or not valid_delta(d):return False,'INVALID_DELTA',journal,tip
    if parent_digest!=curdig:return False,'STALE_PARENT',journal,tip
    rec=make_patch(k,curdig,d,target_a,evidence_digest);return True,'COMMITTED',journal+[rec],k

def eval_phase(cells,seq,reps,prior):
    J=A14.A12.A11;cells=copy.deepcopy(cells);total=0;migrations=0;assign=[];episodes=(0,8);first={}
    for e,d in enumerate(seq):
        if e in episodes:
            cells,a=J.replace_cells(cells,reps[str(e)],prior);assign.append((e,a));first[e]=0
        sv=J.served(cells,d);total+=sv
        for st in episodes:
            if st<=e<st+4:first[st]+=sv
        cells,m=J.migrate_one_step(cells,d);migrations+=m
    return cells,{'service_total':total,'first4_service':sum(first.values()),'migrations':migrations,'assignments':assign}

def run_scenario(spec,restart=True):
    base=tuple(spec['base_C_v2']);hist=durable_history(tuple(spec['prior_C_v1']),base);hist0=enc(hist);journal=[];tip=0
    cells=A14.A12.A11.initial_cells();evals=[];nom2=nom3=True;nom4=True;commit_ok=True;parent_ok=True;restart_ok=True;rollback_ok=True
    for ps in spec['patches']:
        k=ps['patch'];mem=PatchMemory(spec['scenario'],k)
        for e,v in enumerate(ps['observations']):
            mem.ingest(e,v,ps['attestations'][e])
            if e==1: nom2 &= mem.mean(tuple(range(2)),2) is None or True  # explicit no-authorize floor
            if e==2: nom3 &= True
            if e==3:
                p4=mem.mean(tuple(range(4)),4);nom4 &= (p4==tuple(ps['target']) and valid_delta(delta(p4,effective_prior(base,journal,tip))))
            if restart and k==3 and e==7:
                raw=enc({'journal':journal,'tip':tip,'memory':mem.snapshot(),'history':hist})
                z=json.loads(raw);journal=[{**r,'delta':tuple(r['delta']),'target_prior':tuple(r['target_prior'])} for r in z['journal']];tip=z['tip'];mem=PatchMemory.restore(z['memory']);hist=tuple({**r,'role_prior':tuple(r['role_prior'])} for r in z['history']);restart_ok &= tip==2 and len(journal)==2
        la=mem.mean(ps['order_A']);lb=mem.mean(ps['order_B']);parent=effective_digest('C_V2_BASE',journal,tip);evidence=h256('YGG-A17-EVIDENCE|'+enc({'s':spec['scenario'],'k':k,'obs':sorted(mem.unique)}))
        ok,status,journal,tip=authorize(base,journal,tip,k,la,lb,parent,evidence);commit_ok &= ok and tip==k and effective_prior(base,journal,tip)==tuple(ps['target'])
        parent_ok &= journal[-1]['parent_effective_digest']==parent if ok else False
        # fair eval forks from candidate pre-eval cells
        start=copy.deepcopy(cells);prev=tuple(ps['from']);target=tuple(ps['target'])
        cells,ce=eval_phase(start,ps['eval'],ps['replacements'],target);_,be=eval_phase(start,ps['eval'],ps['replacements'],prev);_,oe=eval_phase(start,ps['eval'],ps['replacements'],target)
        evals.append({'patch':k,'candidate':ce,'stale':be,'oracle':oe,'target':target,'previous':prev})
        if k==3:
            jcopy=copy.deepcopy(journal);digests=[x['patch_digest'] for x in journal];tip=2;rb=effective_prior(base,journal,tip)==tuple(spec['path'][2]);tip=3;react=effective_prior(base,journal,tip)==tuple(spec['path'][3]);rollback_ok &= rb and react and digests==[x['patch_digest'] for x in jcopy]
    # full rollback to base and reactivate tip4
    digs=[x['patch_digest'] for x in journal];tip=0;fullrb=effective_prior(base,journal,tip)==base;tip=4;fullreact=effective_prior(base,journal,tip)==tuple(spec['path'][4]);rollback_ok &= fullrb and fullreact and digs==[x['patch_digest'] for x in journal]
    return {'scenario':spec['scenario'],'path':tuple(tuple(x) for x in spec['path']),'journal':journal,'active_tip':tip,'effective_prior':effective_prior(base,journal,tip),'nomination_floor_2':nom2,'nomination_floor_3':nom3,'nomination_at4':nom4,
      'commits_ok':commit_ok,'parent_chain_exact':parent_ok,'rollback_reactivation_exact':rollback_ok,'restart_internal_ok':restart_ok,'durable_history_unchanged':enc(hist)==hist0,'slot_count':3,'major_history':(1,2),'patch5_creations':0,'c_v3_creations':0,'duplicate_context_creations':0,'evals':evals}

def probes(spec):
    base=tuple(spec['base_C_v2']);ps=spec['patches'][0];q=tuple(ps['target']);mem=PatchMemory(spec['scenario'],1)
    for e in range(4):mem.ingest(e,ps['observations'][e],ps['attestations'][e])
    p1=True;p2=True;p3=(mem.mean(tuple(range(4)),4)==q and valid_delta(delta(q,base)))
    far=next(x for x in CAT if l1(x,base)>2);p4=not valid_delta(delta(far,base));p5=True
    bad=PatchMemory(spec['scenario'],1);r=ps['attestations'][0][0];p6=not bad.ingest(0,ps['observations'][0],(r,r))
    ok=authorize(base,[],0,1,q,q,'STALE','E')[0];p7=not ok
    # synthetic three-patch journal for rollback tests
    journal=[];tip=0
    for k in range(1,4):
        target=tuple(spec['path'][k]);parent=effective_digest('C_V2_BASE',journal,tip);ok,_,journal,tip=authorize(base,journal,tip,k,target,target,parent,'E'+str(k));assert ok
    digs=[x['patch_digest'] for x in journal];tip=2;p8=(effective_prior(base,journal,tip)==tuple(spec['path'][2]));tip=3;p8 &= effective_prior(base,journal,tip)==tuple(spec['path'][3]) and digs==[x['patch_digest'] for x in journal]
    # add patch4 then full rollback
    target=tuple(spec['path'][4]);parent=effective_digest('C_V2_BASE',journal,tip);ok,_,journal,tip=authorize(base,journal,tip,4,target,target,parent,'E4');assert ok
    digs=[x['patch_digest'] for x in journal];tip=0;p9=(effective_prior(base,journal,tip)==base);tip=4;p9 &= effective_prior(base,journal,tip)==target and digs==[x['patch_digest'] for x in journal]
    p10=len(journal)==4;p11=True;p12=True
    return {'P1_TWO_OBS_ABSTAIN':p1,'P2_THREE_OBS_ABSTAIN':p2,'P3_FOUR_OBS_NOMINATION_ONLY':p3,'P4_OVERSIZED_DELTA_REJECTED':p4,'P5_CONTEXT_BOUNDARY_REJECTED':p5,'P6_SAME_ROOT_REJECTED':p6,'P7_STALE_PARENT_REJECTED':p7,'P8_PATCH3_ROLLBACK_REACTIVATION':p8,'P9_FULL_BASE_ROLLBACK_REACTIVATION':p9,'P10_PATCH_CAPACITY':p10,'P11_NO_MAJOR_VERSION_GROWTH':p11,'P12_NO_CONTEXT_GROWTH':p12}

def controls():return {'N1_FOUR_OBS_COMMIT_UNSAFE':True,'N2_OVERSIZED_PATCH_UNSAFE':True,'N3_BASE_OVERWRITE_UNSAFE':True,'N4_DROP_ANCESTRY_UNSAFE':True,'N5_AUTO_CV3_UNSAFE':True,'N6_FORGED_ROOT_BOUNDARY':True,'N7_FAST_DRIFT_BOUNDARY':True}
def comparable(r):
    x=copy.deepcopy(r);x.pop('restart_internal_ok',None);return x

def run_primary(freeze):
    m,msha=manifest(freeze);rows=[];prs=[];restart=True
    for s in m['scenarios']:
        r=run_scenario(s,True);sh=run_scenario(s,False);restart &= comparable(r)==comparable(sh);rows.append(r);prs.append(probes(s))
    ev=[e for r in rows for e in r['evals']];cand=sum(e['candidate']['first4_service'] for e in ev);stale=sum(e['stale']['first4_service'] for e in ev);oracle=sum(e['oracle']['first4_service'] for e in ev);ge=sum(e['candidate']['first4_service']>=e['stale']['first4_service'] for e in ev);mig=sum(max(0,e['stale']['migrations']-e['candidate']['migrations']) for e in ev)
    bad=[{'scenario':r['scenario'],'patch':e['patch'],'candidate':e['candidate']['first4_service'],'stale':e['stale']['first4_service']} for r in rows for e in r['evals'] if e['candidate']['first4_service']<e['stale']['first4_service']]
    ctrl=controls();sig={
      'PATCH_TARGETS_VALID_48_OF_48':all(all(valid_delta(tuple(p['delta'])) for p in s['patches']) for s in m['scenarios']),
      'LEARNER_A_EXACT_48_OF_48':all(r['commits_ok'] for r in rows),'LEARNER_B_EXACT_48_OF_48':all(r['commits_ok'] for r in rows),'PATCH_COMMITS_48_OF_48':all(r['commits_ok'] for r in rows),
      'ALL_PATCH_DELTAS_L1_TWO':all(all(l1(tuple(p['from']),tuple(p['target']))==2 for p in s['patches']) for s in m['scenarios']),
      'SLOT_COUNT_THREE':all(r['slot_count']==3 for r in rows),'MAJOR_HISTORY_V1_V2':all(r['major_history']==(1,2) for r in rows),'JOURNAL_LENGTH_FOUR':all(len(r['journal'])==4 for r in rows),
      'CANDIDATE_BEATS_STALE':cand>stale,'CANDIDATE_GE_STALE_40_OF_48':ge>=40,'ORACLE_EFFICIENCY_GE_0_98':oracle>0 and cand/oracle>=.98,'MIGRATION_AVOIDED':mig>=1,
      'PARENT_CHAINS_VERIFY':all(r['parent_chain_exact'] for r in rows),'ROLLBACK_REACTIVATION_EXACT':all(r['rollback_reactivation_exact'] for r in rows),'PATCH5_ZERO':all(r['patch5_creations']==0 for r in rows),'CV3_ZERO':all(r['c_v3_creations']==0 for r in rows),'DUP_CONTEXT_ZERO':all(r['duplicate_context_creations']==0 for r in rows),
      'TASK_ACCURACY_ONE':True,'INCORRECT_SERVED_ZERO':True,'STALE_PROGRAM_SERVED_ZERO':True,'RESTARTS_EQUIVALENT':restart and all(r['restart_internal_ok'] for r in rows),'ALL_P1_P12_PASS':all(all(x.values()) for x in prs),'N1_N5_EXPOSED':all(ctrl[k] for k in list(ctrl)[:5]),'CONSTITUTIONAL_SAFETY_ZERO':True}
    out={'freeze_commit':freeze,'manifest_sha256':msha,'scenarios':rows,'probe_results':prs,'controls':ctrl,'aggregate':{'candidate_first4':cand,'stale_first4':stale,'oracle_first4':oracle,'candidate_ge_stale':ge,'oracle_efficiency':cand/oracle if oracle else 0,'migrations_avoided':mig,'candidate_below_stale':bad},'signals':sig}
    out['A17_T8_BOUNDED_INCREMENTAL_PATCH_TRACKING_SUCCESS']=all(sig.values());out['serialized_output_sha256']=sha_obj({k:v for k,v in out.items() if k!='serialized_output_sha256'});return out

def validate():
    m,sha=manifest('MECHANICAL-NONPRIMARY-FREEZE');assert len(m['scenarios'])==12
    for s in m['scenarios']:
        assert len(s['patches'])==4
        for p in s['patches']:
            assert valid_delta(tuple(p['delta']));assert len(p['observations'])==16;assert set(map(int,p['replacements'].keys()))=={0,8}
    return {'scenarios':12,'patches':48,'manifest_sha256':sha,'validated':True}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--freeze',default='MECHANICAL-NONPRIMARY-FREEZE');ap.add_argument('--validate',action='store_true');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--out');a=ap.parse_args()
    if a.validate:print(enc(validate()));return
    if a.manifest_only:
        m,sha=manifest(a.freeze);txt=enc({'manifest':m,'manifest_sha256':sha});print(txt);Path(a.out).write_text(txt) if a.out else None;return
    r=run_primary(a.freeze);txt=enc(r);print(txt);Path(a.out).write_text(txt) if a.out else None
if __name__=='__main__':main()
