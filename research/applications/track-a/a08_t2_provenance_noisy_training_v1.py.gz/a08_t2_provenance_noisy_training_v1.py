#!/usr/bin/env python3
import argparse, copy, gzip, hashlib, json
from pathlib import Path

import a07_t1_experience_learning_v1 as A07

A07_SOURCE_SHA256="de26ba2c1530f9086a878521f4705896c8f2ad332179ceec0fde9d5f6d71d0ad"
A07_FREEZE="ee9014bde9c210ca31fbea7d94bb2a514c6e6f62"
A07_MANIFEST_SHA256="6abcdd47683edf0b5b4c814518b19709d205f69f25e5db49b3057526f3818139"
SCENARIOS=12
EPOCHS=384
TRAIN_INPUTS=A07.TRAIN_INPUTS
HOLDOUT_INPUTS=A07.HOLDOUT_INPUTS
LEARNER_ROOTS=A07.LEARNER_ROOTS
EXPERIENCE_ROOTS=tuple(1<<i for i in range(44,50))
EXPERIENCE_ROOT_NAMES=tuple(f"E{i}" for i in range(6))
QUALIFIED_ROOTS=4


def enc(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def h256(b): return hashlib.sha256(b).hexdigest()


def verify_dependencies():
    gz=Path(A07.__file__).with_suffix('.py.gz')
    src=gzip.decompress(gz.read_bytes())
    sha=h256(src)
    if sha!=A07_SOURCE_SHA256: raise AssertionError((sha,A07_SOURCE_SHA256))
    m,msha=A07.target_manifest(A07_FREEZE)
    if msha!=A07_MANIFEST_SHA256: raise AssertionError((msha,A07_MANIFEST_SHA256))
    return {"a07_source_sha256":sha,"a07_source_bytes":len(src),"a07_manifest_sha256":msha}


def derive_target(freeze_commit,scenario,current_truth):
    counter=0
    while True:
        suffix=f"|{counter}" if counter else ""
        d=hashlib.sha256(f"YGG-A08-TARGET|{freeze_commit}|{scenario}{suffix}".encode()).digest()
        mask,truth=A07.QUADRATIC_CATALOG[int.from_bytes(d[:8],'big')%len(A07.QUADRATIC_CATALOG)]
        if truth!=current_truth: return mask,truth,counter
        counter+=1


def corrupted_root_indices(freeze_commit,scenario):
    d=hashlib.sha256(f"YGG-A08-CORRUPT-ROOTS|{freeze_commit}|{scenario}".encode()).digest()
    first=int.from_bytes(d[:8],'big')%6
    second=int.from_bytes(d[8:16],'big')%5
    if second>=first: second+=1
    return tuple(sorted((first,second)))


def root_order(freeze_commit,scenario,input_index):
    return tuple(sorted(range(6),key=lambda e:hashlib.sha256(
        f"YGG-A08-ROOT-ORDER|{freeze_commit}|{scenario}|{input_index}|{e}".encode()).digest()))


def duplicate_count(freeze_commit,scenario,input_index,root_index):
    d=hashlib.sha256(f"YGG-A08-DUPLICATES|{freeze_commit}|{scenario}|{input_index}|{root_index}".encode()).digest()
    return 1+(d[0]%4)


def event_order_key(freeze_commit,scenario,learner,epoch,event_id):
    return hashlib.sha256(f"YGG-A08-LEARNER-EVENT-ORDER|{freeze_commit}|{scenario}|{learner}|{epoch}|{event_id}".encode()).digest()


def training_manifest(freeze_commit):
    initial,initial_sha=A07.A06.A05.task_program_manifest(A07.A06.A05_FREEZE)
    env,env_sha=A07.A06.A05.A03.schedule_manifest(A07.A06.A03_ENV_FREEZE)
    scenarios=[]
    for s in range(SCENARIOS):
        init=A07.A06.A05.programs_for_scenario(initial,s)
        point=A07.A06.select_update_point(env['schedules'][s])
        role=point['target_role']
        mask,truth,counter=derive_target(freeze_commit,s,init[role])
        roots=corrupted_root_indices(freeze_commit,s)
        ro={str(x):root_order(freeze_commit,s,x) for x in TRAIN_INPUTS}
        dup={str(x):{str(e):duplicate_count(freeze_commit,s,x,e) for e in range(6)} for x in TRAIN_INPUTS}
        scenarios.append({
            "scenario":s,"target_role":role,"transition_start":point['transition_start'],
            "commit_epoch":point['update_epoch'],"training_start":point['update_epoch']-22,
            "target_coefficient_mask":mask,"target_truth_table":truth,"target_truth_table_hex":f"0x{truth:04x}",
            "derivation_counter":counter,"corrupted_root_indices":roots,
            "corrupted_root_names":tuple(EXPERIENCE_ROOT_NAMES[i] for i in roots),
            "root_orders":ro,"duplicate_counts":dup,
        })
    m={"freeze_commit":freeze_commit,"experience_roots":EXPERIENCE_ROOTS,"qualification_threshold":QUALIFIED_ROOTS,
       "train_inputs":TRAIN_INPUTS,"holdout_inputs":HOLDOUT_INPUTS,"learner_roots":LEARNER_ROOTS,"scenarios":scenarios}
    return m,h256(enc(m).encode())


def new_ledger():
    return {str(i):{} for i in TRAIN_INPUTS}


def observe_ledger(ledger,input_index,root,label):
    row=ledger[str(input_index)]
    k=str(int(root)); label=int(label)
    prior=row.get(k,None)
    if prior is None:
        row[k]=label
        return "NEW"
    if prior=="CONFLICTED": return "IGNORED_CONFLICTED"
    if int(prior)==label: return "DUPLICATE"
    row[k]="CONFLICTED"
    return "CONFLICTED"


def evidence_status(ledger,input_index):
    row=ledger[str(input_index)]
    z=o=conf=0
    for v in row.values():
        if v=="CONFLICTED": conf+=1
        elif int(v)==0: z+=1
        else: o+=1
    qualified=0 if z>=QUALIFIED_ROOTS else (1 if o>=QUALIFIED_ROOTS else None)
    return {"zero_roots":z,"one_roots":o,"conflicted_roots":conf,"effective_roots":z+o,
            "qualified_label":qualified,"winning_margin":abs(z-o)}


def qualified_examples(ledger):
    out=[]
    for i in TRAIN_INPUTS:
        q=evidence_status(ledger,i)['qualified_label']
        if q is not None: out.append((i,q))
    return out


def ledger_candidate(ledger):
    ex=qualified_examples(ledger)
    if len(ex)<11: return None
    return A07.gf2_solve(ex)


def ledger_snapshot_summary(ledger):
    return {str(i):evidence_status(ledger,i) for i in TRAIN_INPUTS}


class NoisyLearningOrganism(A07.A06.ProgramOrganism):
    def __init__(self,scenario,allow_migration=True,schedule=None,seed_hex=None,initial_programs=None,training_spec=None,evaluator_target=None):
        public_spec={k:training_spec[k] for k in ('target_role','commit_epoch','transition_start')}
        public_spec['update_epoch']=training_spec['commit_epoch']
        super().__init__(scenario,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=public_spec)
        self.training_spec=copy.deepcopy(public_spec)
        self.evidence_ledgers={"A":new_ledger(),"B":new_ledger()}
        self.learner_candidates={"A":None,"B":None}
        self.noisy_learning_metrics={
            "raw_observations_A":0,"raw_observations_B":0,
            "duplicates_collapsed_A":0,"duplicates_collapsed_B":0,
            "root_conflicts_A":0,"root_conflicts_B":0,
            "learned_program_commits":0,"learner_agreements":0,"incomplete_candidate_attempts":0,
            "round1_status_A":None,"round1_status_B":None,
        }
        self._evaluator_target=evaluator_target

    def observe_experience(self,learner,input_index,root,label):
        if learner not in ('A','B'): raise KeyError(learner)
        if input_index not in TRAIN_INPUTS: raise AssertionError('held-out input leaked into learner')
        self.noisy_learning_metrics[f"raw_observations_{learner}"]+=1
        result=observe_ledger(self.evidence_ledgers[learner],input_index,root,label)
        if result=="DUPLICATE": self.noisy_learning_metrics[f"duplicates_collapsed_{learner}"]+=1
        if result=="CONFLICTED": self.noisy_learning_metrics[f"root_conflicts_{learner}"]+=1

    def _learner_candidate(self,learner): return ledger_candidate(self.evidence_ledgers[learner])

    def _process_program_update(self,epoch):
        if epoch!=self.training_spec['commit_epoch']: return
        ca=self._learner_candidate('A'); cb=self._learner_candidate('B')
        self.learner_candidates={"A":copy.deepcopy(ca),"B":copy.deepcopy(cb)}
        if ca is None or cb is None:
            self.noisy_learning_metrics['incomplete_candidate_attempts']+=1
            self.program_metrics['program_update_abstentions']+=1
            return
        if ca['truth_table']!=cb['truth_table']:
            self.program_metrics['program_update_abstentions']+=1
            return
        self.noisy_learning_metrics['learner_agreements']+=1
        role=self.training_spec['target_role']; cur=self.program_authority[role]
        proposal=A07.A06.program_record(self.scenario,role,cur['version']+1,ca['truth_table'],cur['program_digest'],epoch)
        attest=({"root":LEARNER_ROOTS['A'],"digest":proposal['program_digest']},
                {"root":LEARNER_ROOTS['B'],"digest":proposal['program_digest']})
        if self._commit_program_update(proposal,attest): self.noisy_learning_metrics['learned_program_commits']+=1

    def _build_requests(self,epoch):
        demand=A07.A06.A05.A03.schedule_demand(self.heldout_schedule,epoch)
        reqs=[]; idx=0; remaining=list(demand)
        committed=self.program_metrics['program_updates_committed']>0
        target_role=self.training_spec['target_role']
        while sum(remaining):
            for role in range(4):
                if remaining[role]:
                    bits=A07.A06.A05.A03.heldout_payload_bits(self.heldout_seed,epoch,idx,role)
                    if role==target_role and committed:
                        expected=A07.A06.A05.program_eval(self._evaluator_target,bits)
                    else:
                        expected=A07.A06.A05.program_eval(self.initial_programs[role],bits)
                    reqs.append({"index":idx,"role":role,"bits":bits,"expected":expected})
                    remaining[role]-=1; idx+=1
        assert len(reqs)==12
        return reqs

    def heldout_snapshot(self,next_epoch):
        s=super().heldout_snapshot(next_epoch)
        s['noisy_learning_layer']={
            "training_spec":self.training_spec,"evidence_ledgers":self.evidence_ledgers,
            "learner_candidates":self.learner_candidates,"noisy_learning_metrics":self.noisy_learning_metrics,
        }
        return s

    @classmethod
    def heldout_restore_with_evaluator(cls,snap,evaluator_target):
        schedule=snap['heldout_schedule']; seed=snap['heldout_seed']; scenario=snap['base']['scenario']
        p=snap['program_layer']; l=snap['noisy_learning_layer']
        base=A07.A06.ProgramOrganism.heldout_restore(snap)
        o=cls(scenario,snap['base']['allow_migration'],schedule=schedule,seed_hex=seed,
              initial_programs=tuple(p['initial_programs']),training_spec=l['training_spec'],evaluator_target=evaluator_target)
        o.__dict__.update(base.__dict__)
        o.training_spec=copy.deepcopy(l['training_spec'])
        o.evidence_ledgers=copy.deepcopy(l['evidence_ledgers'])
        o.learner_candidates=copy.deepcopy(l['learner_candidates'])
        o.noisy_learning_metrics=copy.deepcopy(l['noisy_learning_metrics'])
        o._evaluator_target=evaluator_target
        return o


def events_for_epoch(freeze_commit,scenario,epoch,spec,target_mask):
    start=spec['training_start']; pos=epoch-start
    if pos<0 or pos>=22: return []
    round_index=0 if pos<11 else 1
    input_index=TRAIN_INPUTS[pos%11]
    order=spec['root_orders'][str(input_index)]
    roots=order[:3] if round_index==0 else order[3:]
    corrupted=set(spec['corrupted_root_indices'])
    correct=A07.qeval_mask(target_mask,input_index)
    events=[]
    for root_index in roots:
        label=correct^(1 if root_index in corrupted else 0)
        copies=spec['duplicate_counts'][str(input_index)][str(root_index)]
        for c in range(copies):
            event_id=f"x{input_index}-r{root_index}-c{c}"
            events.append({"event_id":event_id,"input_index":input_index,"root_index":root_index,
                           "root":EXPERIENCE_ROOTS[root_index],"label":label})
    return events


def deliver_training(o,epoch,spec,freeze_commit):
    events=events_for_epoch(freeze_commit,o.scenario,epoch,spec,spec['target_coefficient_mask'])
    if not events: return
    for learner in ('A','B'):
        ordered=sorted(events,key=lambda ev:event_order_key(freeze_commit,o.scenario,learner,epoch,ev['event_id']))
        for ev in ordered: o.observe_experience(learner,ev['input_index'],ev['root'],ev['label'])
    if epoch==spec['training_start']+10:
        o.noisy_learning_metrics['round1_status_A']=ledger_snapshot_summary(o.evidence_ledgers['A'])
        o.noisy_learning_metrics['round1_status_B']=ledger_snapshot_summary(o.evidence_ledgers['B'])


def run_scenario(index,schedule,seed_hex,initial_programs,spec,freeze_commit,allow_migration=True,restart=True,restart_epoch=None):
    original=A07.A06.A05.A03.patch_environment(schedule)
    try:
        o=NoisyLearningOrganism(index,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,
                                training_spec=spec,evaluator_target=spec['target_truth_table'])
        ra=schedule['restart_after'] if restart_epoch is None else restart_epoch
        if restart:
            for e in range(ra+1):
                deliver_training(o,e,spec,freeze_commit); o.step(e)
            raw=enc(o.heldout_snapshot(ra+1)); o=NoisyLearningOrganism.heldout_restore_with_evaluator(json.loads(raw),spec['target_truth_table'])
            for e in range(ra+1,EPOCHS):
                deliver_training(o,e,spec,freeze_commit); o.step(e)
        else:
            for e in range(EPOCHS):
                deliver_training(o,e,spec,freeze_commit); o.step(e)
        A07.A06.A05.A03.finalize_reallocation(o)
        return o
    finally:
        A07.A06.A05.A03.restore_environment(original)


def authoritative_equal(a,b):
    return A07.A06.authoritative_equal(a,b) and a.evidence_ledgers==b.evidence_ledgers and a.learner_candidates==b.learner_candidates


def output_equal(a,b):
    return A07.A06.output_equal(a,b) and a.noisy_learning_metrics==b.noisy_learning_metrics


def learner_eval(candidate,target_mask,ledger):
    if candidate is None: return None
    train_error=sum(A07.qeval_mask(candidate['coefficient_mask'],i)!=A07.qeval_mask(target_mask,i) for i in TRAIN_INPUTS)
    holdout_error=sum(A07.qeval_mask(candidate['coefficient_mask'],i)!=A07.qeval_mask(target_mask,i) for i in HOLDOUT_INPUTS)
    return {"rank":A07.learner_rank(qualified_examples(ledger)),"candidate_coefficient_mask":candidate['coefficient_mask'],
            "candidate_truth_table":candidate['truth_table'],"training_error":train_error,"holdout_error":holdout_error,
            "final_evidence":ledger_snapshot_summary(ledger)}


def scenario_summary(index,schedule,seed_hex,initial_programs,spec,freeze_commit):
    cand=run_scenario(index,schedule,seed_hex,initial_programs,spec,freeze_commit,True,True)
    shadow=run_scenario(index,schedule,seed_hex,initial_programs,spec,freeze_commit,True,False)
    cm=A07.A06.A05.A03.A02.scenario_metrics(cand)
    la=learner_eval(cand.learner_candidates['A'],spec['target_coefficient_mask'],cand.evidence_ledgers['A'])
    lb=learner_eval(cand.learner_candidates['B'],spec['target_coefficient_mask'],cand.evidence_ledgers['B'])
    return {
        "scenario":index,"seed":seed_hex,"target_role":spec['target_role'],"training_start":spec['training_start'],"commit_epoch":spec['commit_epoch'],
        "target_coefficient_mask":spec['target_coefficient_mask'],"target_truth_table":spec['target_truth_table'],
        "corrupted_root_indices":spec['corrupted_root_indices'],"corrupted_root_names":spec['corrupted_root_names'],
        "learner_A":la,"learner_B":lb,
        "candidate_agreement":cand.learner_candidates['A'] is not None and cand.learner_candidates['B'] is not None and cand.learner_candidates['A']['truth_table']==cand.learner_candidates['B']['truth_table'],
        "candidate":cm,"program_metrics":copy.deepcopy(cand.program_metrics),"noisy_learning_metrics":copy.deepcopy(cand.noisy_learning_metrics),
        "restart_authoritative_state_equivalence":authoritative_equal(cand,shadow),"restart_output_equivalence":output_equal(cand,shadow),
        "dynamic_remerge_count":cand.heldout_remerge_count,"final_provisional_count":len(cand.provisional),"_outputs":list(cand.outputs),
    }


def simple_ledger(labels):
    led={"0":{}}
    for root,label in labels: observe_ledger({"0":led["0"]},0,root,label)
    return {"0":led["0"]}


def evidence_probes(spec,freeze_commit,schedule,seed_hex,initial_programs):
    target_label=A07.qeval_mask(spec['target_coefficient_mask'],TRAIN_INPUTS[0])
    wrong=1-target_label
    # P1: 64 copies of one bad root cannot outweigh independent roots.
    led=new_ledger()
    for _ in range(64): observe_ledger(led,TRAIN_INPUTS[0],EXPERIENCE_ROOTS[0],wrong)
    for r in EXPERIENCE_ROOTS[1:4]: observe_ledger(led,TRAIN_INPUTS[0],r,target_label)
    pre=evidence_status(led,TRAIN_INPUTS[0])['qualified_label'] is None
    observe_ledger(led,TRAIN_INPUTS[0],EXPERIENCE_ROOTS[4],target_label)
    post=evidence_status(led,TRAIN_INPUTS[0])['qualified_label']==target_label
    p1=pre and post and evidence_status(led,TRAIN_INPUTS[0])['effective_roots']==5
    # P2: copied descendants represented by same provenance root collapse.
    led2=new_ledger()
    for _ in range(4): observe_ledger(led2,TRAIN_INPUTS[0],EXPERIENCE_ROOTS[0],wrong)
    p2=evidence_status(led2,TRAIN_INPUTS[0])['effective_roots']==1 and evidence_status(led2,TRAIN_INPUTS[0])['qualified_label'] is None
    # P3: 3/3 conflict abstains.
    led3=new_ledger()
    for r in EXPERIENCE_ROOTS[:3]: observe_ledger(led3,TRAIN_INPUTS[0],r,0)
    for r in EXPERIENCE_ROOTS[3:]: observe_ledger(led3,TRAIN_INPUTS[0],r,1)
    p3=evidence_status(led3,TRAIN_INPUTS[0])['qualified_label'] is None
    # P4: self-contradicting root invalidated; four honest still qualify.
    led4=new_ledger(); r0=EXPERIENCE_ROOTS[0]
    observe_ledger(led4,TRAIN_INPUTS[0],r0,target_label); observe_ledger(led4,TRAIN_INPUTS[0],r0,wrong)
    for r in EXPERIENCE_ROOTS[1:5]: observe_ledger(led4,TRAIN_INPUTS[0],r,target_label)
    st4=evidence_status(led4,TRAIN_INPUTS[0]); p4=st4['conflicted_roots']==1 and st4['qualified_label']==target_label
    # P5: two bad roots across all inputs still reconstruct exact target.
    led5=new_ledger()
    for x in TRAIN_INPUTS:
        true=A07.qeval_mask(spec['target_coefficient_mask'],x)
        for ri,r in enumerate(EXPERIENCE_ROOTS): observe_ledger(led5,x,r,true^(1 if ri in (0,1) else 0))
    c5=ledger_candidate(led5); p5=c5 is not None and c5['truth_table']==spec['target_truth_table']
    # P6 / M1: restart after round 1 is byte-equivalent to uninterrupted.
    mid=spec['training_start']+10
    rr=run_scenario(spec['scenario'],schedule,seed_hex,initial_programs,spec,freeze_commit,True,True,restart_epoch=mid)
    uu=run_scenario(spec['scenario'],schedule,seed_hex,initial_programs,spec,freeze_commit,True,False)
    p6=authoritative_equal(rr,uu) and output_equal(rr,uu)
    # P7: event-order invariance on all primary events.
    la=new_ledger(); lb=new_ledger()
    for e in range(spec['training_start'],spec['commit_epoch']):
        ev=events_for_epoch(freeze_commit,spec['scenario'],e,spec,spec['target_coefficient_mask'])
        for item in sorted(ev,key=lambda q:q['event_id']): observe_ledger(la,item['input_index'],item['root'],item['label'])
        for item in sorted(ev,key=lambda q:q['event_id'],reverse=True): observe_ledger(lb,item['input_index'],item['root'],item['label'])
    p7=la==lb and ledger_candidate(la)==ledger_candidate(lb)
    # P8: inherited A06 hereditary probes against learned target.
    a06spec={"target_role":spec['target_role'],"update_epoch":spec['commit_epoch'],"transition_start":spec['transition_start'],"new_truth_table":spec['target_truth_table']}
    h=A07.A06.probe_suite(schedule,seed_hex,initial_programs,a06spec)
    p8=all(h.values())
    return {"SAME_ROOT_AMPLIFICATION_SUPPRESSED":p1,"COPIED_DESCENDANTS_COLLAPSE":p2,"THREE_THREE_CONFLICT_ABSTAINS":p3,
            "SELF_CONTRADICTING_ROOT_INVALIDATED":p4,"TWO_CORRELATED_BAD_ROOTS_TOLERATED":p5,
            "ROUND1_MEMORY_RESTART_EQUIVALENT":p6,"LEARNER_ORDER_INVARIANT":p7,"HEREDITARY_PROPAGATION":p8}


def negative_controls(spec,schedule,seed_hex,initial_programs):
    target=A07.qeval_mask(spec['target_coefficient_mask'],TRAIN_INPUTS[0]); wrong=1-target
    # N1 raw headcount: one corrupt root sends 64 wrong vs three honest single observations.
    raw=[wrong]*64+[target]*3; n1=(sum(raw)>len(raw)/2)==bool(wrong)
    # N2 anonymous copies can fake four independent supports.
    anonymous=[wrong]*4; n2=len(anonymous)>=4 and all(x==wrong for x in anonymous)
    # N3 forced tie-break on 3/3 can choose a wrong label.
    forced=0; n3=(forced!=target) if target==1 else ((1-target)!=target)
    # N4 four genuinely distinct corrupted roots satisfy frozen quorum for wrong label.
    led4=new_ledger()
    for ri,r in enumerate(EXPERIENCE_ROOTS): observe_ledger(led4,TRAIN_INPUTS[0],r,wrong if ri<4 else target)
    n4=evidence_status(led4,TRAIN_INPUTS[0])['qualified_label']==wrong
    # N5 forged root metadata: one bad source pretending to be four roots can satisfy quorum.
    led5=new_ledger()
    for fake in (1<<55,1<<56,1<<57,1<<58): observe_ledger(led5,TRAIN_INPUTS[0],fake,wrong)
    n5=evidence_status(led5,TRAIN_INPUTS[0])['qualified_label']==wrong
    # N6 governance unavailable blocks a correctly learned candidate.
    a06spec={"target_role":spec['target_role'],"update_epoch":spec['commit_epoch'],"transition_start":spec['transition_start'],"new_truth_table":spec['target_truth_table']}
    inherited=A07.A06.negative_controls(schedule,seed_hex,initial_programs,a06spec)
    n6=inherited['GOVERNANCE_UNAVAILABLE_FAIL_CLOSED']
    return {"RAW_HEADCOUNT_FALSE_EVIDENCE_REACHABLE":n1,"ANONYMOUS_COPIES_FALSE_INDEPENDENCE_REACHABLE":n2,
            "FORCED_TIEBREAK_FALSE_LABEL_REACHABLE":n3,"FOUR_CORRUPTED_ROOTS_BOUNDARY":n4,
            "FORGED_ROOT_METADATA_BOUNDARY":n5,"GOVERNANCE_UNAVAILABLE_FAILS_CLOSED":n6}


def run_primary(freeze_commit):
    deps=verify_dependencies()
    initial,initial_sha=A07.A06.A05.task_program_manifest(A07.A06.A05_FREEZE)
    env,env_sha=A07.A06.A05.A03.schedule_manifest(A07.A06.A03_ENV_FREEZE)
    manifest,msha=training_manifest(freeze_commit)
    summaries=[]; outputs=[]
    for s in range(SCENARIOS):
        init=A07.A06.A05.programs_for_scenario(initial,s); spec=manifest['scenarios'][s]
        x=scenario_summary(s,env['schedules'][s],env['seeds'][s],init,spec,freeze_commit); outputs.extend(x.pop('_outputs')); summaries.append(x)
    total=sum(x['candidate']['total_requests'] for x in summaries); served=sum(x['candidate']['served_requests'] for x in summaries)
    correct=sum(x['candidate']['correct_served_requests'] for x in summaries); incorrect=sum(x['candidate']['incorrect_served_requests'] for x in summaries)
    exactA=sum(x['learner_A']['candidate_truth_table']==x['target_truth_table'] for x in summaries)
    exactB=sum(x['learner_B']['candidate_truth_table']==x['target_truth_table'] for x in summaries)
    agree=sum(x['candidate_agreement'] for x in summaries)
    holdout_correct=sum(5-x['learner_A']['holdout_error'] for x in summaries)+sum(5-x['learner_B']['holdout_error'] for x in summaries)
    commits=sum(x['program_metrics']['program_updates_committed'] for x in summaries)
    stale_served=sum(x['program_metrics']['stale_program_served_requests'] for x in summaries)
    migrations=sum(x['program_metrics']['migration_program_inheritances'] for x in summaries)
    restarts=sum(not (x['restart_authoritative_state_equivalence'] and x['restart_output_equivalence']) for x in summaries)
    raw_obs=sum(x['noisy_learning_metrics']['raw_observations_A']+x['noisy_learning_metrics']['raw_observations_B'] for x in summaries)
    collapsed=sum(x['noisy_learning_metrics']['duplicates_collapsed_A']+x['noisy_learning_metrics']['duplicates_collapsed_B'] for x in summaries)
    correct42=True
    for x in summaries:
        target=x['target_coefficient_mask']
        for learner in ('learner_A','learner_B'):
            for idx_s,st in x[learner]['final_evidence'].items():
                true=A07.qeval_mask(target,int(idx_s)); wrong=1-true
                if true==0: correct42 &= st['zero_roots']==4 and st['one_roots']==2
                else: correct42 &= st['one_roots']==4 and st['zero_roots']==2
    safety_keys=('stale_vote_attempts_accepted','authority_violations','causal_regressions','duplicate_effective_provenance','split_brain_final_states','resource_budget_violations')
    safety={k:sum(x['candidate'][k] for x in summaries) for k in safety_keys}
    probes=[]; controls=[]
    for i,spec in enumerate(manifest['scenarios']):
        init=A07.A06.A05.programs_for_scenario(initial,i); sched=env['schedules'][i]; seed=env['seeds'][i]
        probes.append(evidence_probes(spec,freeze_commit,sched,seed,init)); controls.append(negative_controls(spec,sched,seed,init))
    probes_pass=all(all(v for v in p.values()) for p in probes)
    controls_pass=all(c['RAW_HEADCOUNT_FALSE_EVIDENCE_REACHABLE'] and c['ANONYMOUS_COPIES_FALSE_INDEPENDENCE_REACHABLE'] and c['FORCED_TIEBREAK_FALSE_LABEL_REACHABLE'] and c['GOVERNANCE_UNAVAILABLE_FAILS_CLOSED'] for c in controls)
    boundaries=all(c['FOUR_CORRUPTED_ROOTS_BOUNDARY'] and c['FORGED_ROOT_METADATA_BOUNDARY'] for c in controls)
    signals={
        "LEARNER_A_EXACT_12_OF_12":exactA==12,"LEARNER_B_EXACT_12_OF_12":exactB==12,"LEARNER_PAIRS_AGREE_12_OF_12":agree==12,
        "HELDOUT_120_OF_120":holdout_correct==120,"PROGRAM_COMMITS_12_OF_12":commits==12,
        "TASK_ACCURACY_ONE":incorrect==0 and correct==served,"ZERO_INCORRECT_SERVED":incorrect==0,"ZERO_STALE_PROGRAM_SERVED":stale_served==0,
        "FINAL_EVIDENCE_FOUR_CORRECT_TWO_INCORRECT":bool(correct42),"DUPLICATES_COLLAPSED":collapsed>0 and raw_obs>0,
        "MIGRATION_INHERITANCE_EXERCISED":migrations>=1,"NOISY_EXPERIENCE_PROBES_PASS":probes_pass,
        "UNSAFE_CONTROLS_EXPOSED_AND_GOVERNANCE_FAILS_CLOSED":controls_pass,"ALL_RESTARTS_EQUIVALENT":restarts==0,
        "ZERO_EXISTING_SAFETY_VIOLATIONS":all(v==0 for v in safety.values()),
        "PARTITION_REMERGE_COMPLETE":all(x['dynamic_remerge_count']==1 and x['final_provisional_count']==0 for x in summaries),
    }
    signals['A08_T2_PROVENANCE_AWARE_NOISY_TRAINING_SUCCESS']=all(signals.values())
    return {"schema":"yggdrasil.training-t2.a08-provenance-aware-noisy-training.v1","freeze_commit":freeze_commit,
            "training_manifest_sha256":msha,"training_manifest":manifest,"dependencies":deps,"scenarios":summaries,
            "aggregate":{"total_requests":total,"candidate_served":served,"candidate_correct":correct,"candidate_incorrect":incorrect,
                         "learner_A_exact":exactA,"learner_B_exact":exactB,"learner_pairs_agree":agree,"heldout_predictions_correct":holdout_correct,
                         "program_commits":commits,"migration_program_inheritances":migrations,"stale_program_served_requests":stale_served,
                         "restart_mismatches":restarts,"raw_experience_observations":raw_obs,"duplicates_collapsed":collapsed,"safety_totals":safety},
            "task_output_sha256":h256(enc(outputs).encode()),"noisy_experience_probes":probes,"negative_controls":controls,
            "boundary_signals":{"FOUR_CORRUPTED_ROOTS_BOUNDARY":all(c['FOUR_CORRUPTED_ROOTS_BOUNDARY'] for c in controls),
                                "FORGED_ROOT_METADATA_BOUNDARY":all(c['FORGED_ROOT_METADATA_BOUNDARY'] for c in controls),
                                "BOUNDARIES_EXPOSED":boundaries},
            "signals":signals,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def validate():
    deps=verify_dependencies()
    assert len(EXPERIENCE_ROOTS)==6 and len(set(EXPERIENCE_ROOTS))==6
    assert QUALIFIED_ROOTS==4
    assert len(A07.QUADRATIC_CATALOG)==840
    assert A07.gf2_rank([A07.qfeatures(i) for i in TRAIN_INPUTS])==11
    m,msha=training_manifest('MECHANICAL-NONPRIMARY-FREEZE')
    assert len(m['scenarios'])==12
    duplicate_gt_one=False
    for s in m['scenarios']:
        assert s['training_start']==s['commit_epoch']-22 and s['training_start']>=0
        assert len(s['corrupted_root_indices'])==2 and len(set(s['corrupted_root_indices']))==2
        for x in TRAIN_INPUTS:
            ro=s['root_orders'][str(x)]; assert len(ro)==6 and set(ro)==set(range(6))
            ds=s['duplicate_counts'][str(x)]; assert set(ds)==set(str(i) for i in range(6))
            for v in ds.values(): assert 1<=v<=4; duplicate_gt_one |= v>1
        # Mechanical end-state evidence must be 4 correct / 2 incorrect and solve target.
        led=new_ledger(); bad=set(s['corrupted_root_indices'])
        for x in TRAIN_INPUTS:
            true=A07.qeval_mask(s['target_coefficient_mask'],x)
            for ri,r in enumerate(EXPERIENCE_ROOTS): observe_ledger(led,x,r,true^(1 if ri in bad else 0))
            st=evidence_status(led,x); assert st['qualified_label']==true
        c=ledger_candidate(led); assert c and c['truth_table']==s['target_truth_table']
    assert duplicate_gt_one
    return {"dependencies":deps,"experience_roots":EXPERIENCE_ROOTS,"qualification_threshold":QUALIFIED_ROOTS,
            "quadratic_catalog_size":len(A07.QUADRATIC_CATALOG),"train_feature_rank":11,
            "mechanical_training_manifest_sha256":msha,"mechanical_primary_target_derivation":False,
            "canonical_scientific_execution":False,"stab18_r1_touched":False}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--freeze-commit'); ap.add_argument('--manifest-only',action='store_true'); ap.add_argument('--mechanical-only',action='store_true'); ap.add_argument('--out')
    args=ap.parse_args()
    if args.mechanical_only: print(enc({"mechanical_valid":True,"mechanical":validate()})); return
    if not args.freeze_commit: raise SystemExit('--freeze-commit required')
    if args.manifest_only:
        m,sha=training_manifest(args.freeze_commit); print(enc({"freeze_commit":args.freeze_commit,"training_manifest_sha256":sha,"training_manifest":m})); return
    if not args.out: raise SystemExit('--out required')
    obj=run_primary(args.freeze_commit); raw=(enc(obj)+'\n').encode(); Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":h256(raw),"training_manifest_sha256":obj['training_manifest_sha256'],
               "aggregate":obj['aggregate'],"signals":obj['signals'],"boundary_signals":obj['boundary_signals']}))

if __name__=='__main__': main()
