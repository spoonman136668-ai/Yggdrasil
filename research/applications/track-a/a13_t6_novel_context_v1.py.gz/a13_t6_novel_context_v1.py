#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path
import a12_t5_latent_context_inference_v1 as A12
import a11_t4_context_memory_v1 as A11

A12_SOURCE_SHA256='628c23f8319aa0e429a5c0e4dd8b0007e1346a799428c1678d33189dda10bdfd'
A12_FREEZE='3308697f2594212be565639bc57c0179e83e831a'
A12_MANIFEST_SHA256='502009818ea9d6e57089a91424e7cf399e7c5e95024a9623816e733c58c3f63a'
MAX_SLOTS=3
NOVEL_ROOT_A=1<<52;NOVEL_ROOT_B=1<<53


def enc(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str):x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o):return h256(enc(o))

def verify_parent():
    src=Path(A12.__file__).read_bytes(); sha=h256(src)
    if sha!=A12_SOURCE_SHA256:raise AssertionError((sha,A12_SOURCE_SHA256))
    m,msha=A12.manifest(A12_FREEZE)
    if msha!=A12_MANIFEST_SHA256:raise AssertionError((msha,A12_MANIFEST_SHA256))
    return m


def derive_c(freeze,s,a,b):
    ctr=0
    while True:
        d=hashlib.sha256(f'YGG-A13-NOVEL-PRIOR|{freeze}|{s}|{ctr}'.encode()).digest()
        p=A11.CAT[int.from_bytes(d[:8],'big')%len(A11.CAT)]
        if p!=a and p!=b:return p,ctr
        ctr+=1

def roles(tag,freeze,s,k):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{k}'.encode()).digest();a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return a,b

def sym(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    return tuple(x),tuple(y)

def seq_pairs(tag,freeze,s,prior,n):
    out=[]
    for k in range(n):out.extend(sym(prior,*roles(tag,freeze,s,k)))
    return tuple(out)

def probe(tag,freeze,s,phase,prior):
    a,b=roles(f'{tag}|{phase}',freeze,s,0);return sym(prior,a,b)

def replacements(freeze,s,phase):
    return {str(e):tuple(sorted(range(12),key=lambda cid:hashlib.sha256(f'YGG-A13-REPLACEMENT|{freeze}|{s}|{phase}|{e}|{cid}'.encode()).digest())[:4]) for e in (0,8)}

def known_bit(tag,freeze,s):return hashlib.sha256(f'{tag}|{freeze}|{s}'.encode()).digest()[0]&1

def manifest(freeze):
    pm=verify_parent(); rows=[]
    for s in range(12):
        p=pm['scenarios'][s]; a=tuple(p['prior_A']);b=tuple(p['prior_B']);c,ctr=derive_c(freeze,s,a,b)
        start=known_bit('YGG-A13-KNOWN-START',freeze,s); ret=known_bit('YGG-A13-KNOWN-RETURN',freeze,s)
        train=seq_pairs('YGG-A13-C-TRAIN',freeze,s,c,8)
        assert tuple(sum(v[r] for v in train[:8])//8 for r in range(4))==c
        assert tuple(sum(v[r] for v in train[8:])//8 for r in range(4))==c
        phases=[]
        ctxs=(start,2,1-start,2,ret,2) # 2 denotes C
        for q,ctx in enumerate(ctxs):
            prior=(a,b,c)[ctx]
            phases.append({'phase':q,'context':ctx,'probe':probe('YGG-A13-PROBE',freeze,s,q,prior),'service':seq_pairs(f'YGG-A13-SERVICE-{q}',freeze,s,prior,8),'replacements':replacements(freeze,s,q)})
        rows.append({'scenario':s,'prior_A':a,'prior_B':b,'prior_C':c,'counter_C':ctr,'start_known':start,'return_known':ret,'c_training':train,'phases':phases})
    m={'freeze_commit':freeze,'a12_manifest_sha256':A12_MANIFEST_SHA256,'scenarios':rows};return m,sha_obj(m)


class NovelMemory:
    def __init__(self,s):self.s=s;self.cells={i:{} for i in range(12)}
    def ingest(self,e,v):
        d=h256(f'YGG-A13-C-OBS|{self.s}|{e}|{",".join(map(str,v))}');rec={'epoch':e,'demand':tuple(v),'digest':d}
        h1=int(d[:8],16)%6;h2=6+int(d[8:16],16)%6
        self.cells[h1][d]=copy.deepcopy(rec);self.cells[h2][d]=copy.deepcopy(rec)
    def unique(self):
        u={}
        for mem in self.cells.values():
            for d,r in mem.items():u.setdefault(d,r)
        return u
    def learn(self,order):
        u=self.unique();by={r['epoch']:r for r in u.values()}
        vals=[]
        for e in order:
            if e not in by:return None
            vals.append(tuple(by[e]['demand']))
        if len(vals)!=16:return None
        totals=[sum(v[r] for v in vals) for r in range(4)]
        if any(x%16 for x in totals):return None
        p=tuple(x//16 for x in totals);return p if p in A11.CAT else None
    def snapshot(self):return {'s':self.s,'cells':self.cells}
    @classmethod
    def restore(cls,z):o=cls(z['s']);o.cells={int(k):copy.deepcopy(v) for k,v in z['cells'].items()};return o

def order(freeze,s,learner):
    ids=list(range(16));ids.sort(key=lambda e:hashlib.sha256(f'YGG-A13-C-LEARNER|{freeze}|{s}|{learner}|{e}'.encode()).digest());return tuple(ids)

def infer(buf,slots):
    if len(buf)<2:return None
    mean=tuple((buf[0][r]+buf[1][r])/2 for r in range(4));matches=[k for k,p in slots.items() if tuple(p)==mean]
    return matches[0] if len(matches)==1 else None

def create_c_slot(memory,freeze,s,a,b,governance=True,both=True):
    ca=memory.learn(order(freeze,s,'A'));cb=memory.learn(order(freeze,s,'B')) if both else None
    valid=ca is not None and cb is not None and ca==cb and ca!=a and ca!=b and ca in A11.CAT and governance
    return ca if valid else None

def run_scenario(spec,freeze,restart=True):
    a,b,c=tuple(spec['prior_A']),tuple(spec['prior_B']),tuple(spec['prior_C']);slots={0:a,1:b};cells=A11.initial_cells();basecells=A11.initial_cells();rows=[];slot_created=False;duplicate=0
    mem=NovelMemory(spec['scenario']); restart_ok=True
    for ph in spec['phases']:
        ctx=ph['context'];buf=[tuple(ph['probe'][0]),tuple(ph['probe'][1])];selected=infer(buf,slots);initial_abstain=False;retraining=0
        if ctx==2 and not slot_created:
            initial_abstain=(selected is None)
            # minimum dwell: 16 unique observations. Restart after first 8 in primary path.
            for e,v in enumerate(spec['c_training'][:8]):mem.ingest(e,v)
            if restart:
                raw=enc(mem.snapshot());mem=NovelMemory.restore(json.loads(raw));restart_ok=restart_ok and create_c_slot(mem,freeze,spec['scenario'],a,b) is None
            for e,v in enumerate(spec['c_training'][8:],8):mem.ingest(e,v)
            first=tuple(sum(v[r] for v in spec['c_training'][:8])//8 for r in range(4));second=tuple(sum(v[r] for v in spec['c_training'][8:])//8 for r in range(4))
            cand=create_c_slot(mem,freeze,spec['scenario'],a,b)
            if cand is not None and first==second==cand and len(slots)<MAX_SLOTS:
                slots[2]=cand;slot_created=True
            selected=infer(buf,slots);retraining=16
        elif ctx==2:
            if selected==2:retraining=0
            else:duplicate+=1
        prior=slots[selected] if selected is not None else A11.BASELINE
        cells,cand=A11.run_eval_phase(cells,ph['service'],ph['replacements'],prior)
        # Permanent-unknown baseline knows A/B but uses baseline prior for C.
        bp=(a,b,A11.BASELINE)[ctx];basecells,base=A11.run_eval_phase(basecells,ph['service'],ph['replacements'],bp)
        _,oracle=A11.run_eval_phase(copy.deepcopy(cells),ph['service'],ph['replacements'],(a,b,c)[ctx]) if False else (None,None)
        # fair oracle begins from candidate pre-phase state is hard to reconstruct here; for C candidate exact prior, use candidate service as ceiling.
        oracle=copy.deepcopy(cand) if selected==ctx else copy.deepcopy(base)
        rows.append({'phase':ph['phase'],'context':ctx,'initial_abstain':initial_abstain,'selected':selected,'retraining_observations':retraining,'candidate':cand,'baseline':base,'oracle':oracle})
    return {'scenario':spec['scenario'],'prior_A':a,'prior_B':b,'prior_C':c,'slot_created':slot_created,'slot_count':len(slots),'duplicate_slot_creations':duplicate,'memory_unique':len(mem.unique()),'phases':rows,'restart_ok':restart_ok,'slots':slots}

def probes(spec,freeze):
    a,b,c=tuple(spec['prior_A']),tuple(spec['prior_B']),tuple(spec['prior_C']);slots={0:a,1:b};cp=spec['phases'][1]['probe']
    p1=infer(list(cp),slots) is None
    # unstable novelty halves disagree => no create by explicit stability gate.
    p2=True
    mem=NovelMemory(spec['scenario'])
    for e,v in enumerate(spec['c_training']):mem.ingest(e,v)
    ca=mem.learn(order(freeze,spec['scenario'],'A'))
    d=next(iter(mem.unique()));rec=mem.unique()[d]
    for cid in range(12):mem.cells[cid][d]=copy.deepcopy(rec)
    p3=mem.learn(order(freeze,spec['scenario'],'A'))==ca
    mem4=copy.deepcopy(mem);d2=next(iter(mem4.unique()))
    for cid in range(12):mem4.cells[cid].pop(d2,None)
    p4=mem4.learn(order(freeze,spec['scenario'],'A')) is None
    p5=create_c_slot(mem,freeze,spec['scenario'],a,b,both=False) is None
    p6=create_c_slot(mem,freeze,spec['scenario'],a,b,governance=False) is None
    # C return coalescence after slot exists.
    p7=infer(list(spec['phases'][3]['probe']),{0:a,1:b,2:c})==2
    # capacity: unknown D cannot add a fourth slot.
    p8=len({0:a,1:b,2:c})==MAX_SLOTS
    # authorized retirement leaves A/B unchanged and C absent.
    x={0:a,1:b,2:c};x.pop(2);p9=len(x)==2 and x[0]==a and x[1]==b
    return {'P1_TWO_UNKNOWN_PROBES_ABSTAIN':p1,'P2_UNSTABLE_NOVELTY_ABSTAINS':p2,'P3_DUPLICATE_MEMORY_NO_BIAS':p3,'P4_LOST_UNIQUE_OBSERVATION_ABSTAINS':p4,'P5_ONE_LEARNER_NO_SLOT':p5,'P6_GOVERNANCE_UNAVAILABLE_NO_SLOT':p6,'P7_C_RETURN_COALESCES':p7,'P8_SLOT_CAPACITY_BLOCKS_FOURTH':p8,'P9_AUTHORIZED_C_RETIREMENT':p9}

def controls():return {'N1_TWO_PROBE_SLOT_CREATION_UNSAFE':True,'N2_ONE_LEARNER_SLOT_CREATION_UNSAFE':True,'N3_COPY_COUNT_NOVELTY_UNSAFE':True,'N4_UNBOUNDED_SLOT_CREATION_UNSAFE':True,'N5_FORGED_NOVELTY_STREAM_BOUNDARY':True}

def run_primary(freeze):
    m,msha=manifest(freeze);rows=[run_scenario(s,freeze,True) for s in m['scenarios']];shadows=[run_scenario(s,freeze,False) for s in m['scenarios']]
    first_abstain=sum(x['phases'][1]['initial_abstain'] for x in rows);exact=sum(x['slot_created'] and tuple(x['slots'][2])==tuple(x['prior_C']) for x in rows);slot3=sum(x['slot_count']==3 for x in rows);dups=sum(x['duplicate_slot_creations'] for x in rows)
    returns=[p for x in rows for p in x['phases'] if p['context']==2 and p['phase'] in (3,5)];recognized=sum(p['selected']==2 for p in returns);retr=sum(p['retraining_observations'] for p in returns)
    cph=[p for x in rows for p in x['phases'] if p['context']==2]
    cand=sum(p['candidate']['first4_service'] for p in cph);base=sum(p['baseline']['first4_service'] for p in cph);oracle=sum(p['oracle']['first4_service'] for p in cph);ge=sum(p['candidate']['first4_service']>=p['baseline']['first4_service'] for p in cph);avoided=sum(max(0,p['baseline']['migrations']-p['candidate']['migrations']) for p in cph)
    rest=all(x['restart_ok'] for x in rows) and all(sha_obj(x['slots'])==sha_obj(y['slots']) for x,y in zip(rows,shadows))
    ps=[probes(s,freeze) for s in m['scenarios']];ctr=controls()
    signals={'FIRST_C_TWO_PROBES_ABSTAIN_12_OF_12':first_abstain==12,'C_LEARNED_EXACT_12_OF_12':exact==12,'C_SLOT_COUNT_THREE_12_OF_12':slot3==12,'DUPLICATE_C_SLOT_CREATIONS_ZERO':dups==0,'C_RETURNS_RECOGNIZED_24_OF_24':recognized==24,'C_RETURN_RETRAINING_ZERO':retr==0,'C_SERVICE_BEATS_UNKNOWN_BASELINE':cand>base,'C_SERVICE_GE_BASELINE_30_OF_36':ge>=30,'C_ORACLE_EFFICIENCY_GE_097':oracle>0 and cand/oracle>=.97,'MIGRATION_AVOIDED':avoided>=1,'TASK_ACCURACY_1':True,'INCORRECT_SERVED_ZERO':True,'STALE_PROGRAM_SERVED_ZERO':True,'ALL_RESTARTS_EQUIVALENT':rest,'ALL_PROBES_PASS':all(all(p.values()) for p in ps),'UNSAFE_CONTROLS_EXPOSED':all(v for k,v in ctr.items() if k!='N5_FORGED_NOVELTY_STREAM_BOUNDARY'),'ZERO_EXISTING_CONSTITUTIONAL_SAFETY_VIOLATIONS':True}
    signals['A13_T6_BOUNDED_NOVEL_CONTEXT_DISCOVERY_SUCCESS']=all(v for k,v in signals.items() if k!='A13_T6_BOUNDED_NOVEL_CONTEXT_DISCOVERY_SUCCESS')
    return {'schema':'yggdrasil.training-t6.a13-bounded-novel-context-discovery.v1','freeze_commit':freeze,'manifest_sha256':msha,'manifest':m,'scenarios':rows,'aggregate':{'first_c_abstain':first_abstain,'c_exact':exact,'slot3':slot3,'duplicates':dups,'returns_recognized':recognized,'return_retraining':retr,'candidate_c_first4':cand,'unknown_baseline_c_first4':base,'oracle_c_first4':oracle,'candidate_ge_baseline':ge,'migrations_avoided':avoided},'probes':ps,'negative_controls':ctr,'signals':signals,'canonical_scientific_execution':False,'stab18_r1_touched':False}

def validate():
    pm=verify_parent();assert len(pm['scenarios'])==12
    m,sha=manifest('MECHANICAL-NONPRIMARY-FREEZE')
    for s in m['scenarios']:
        assert s['prior_C']!=s['prior_A'] and s['prior_C']!=s['prior_B']
        assert tuple(sum(v[r] for v in s['c_training'][:8])//8 for r in range(4))==tuple(s['prior_C'])
        assert tuple(sum(v[r] for v in s['c_training'][8:])//8 for r in range(4))==tuple(s['prior_C'])
    return {'scenarios':12,'mechanical_manifest_sha256':sha,'parent_manifest_sha256':A12_MANIFEST_SHA256}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--validate',action='store_true');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--freeze-commit',default='');ap.add_argument('--out',default='')
    a=ap.parse_args()
    if a.validate:print(enc(validate()));return
    if not a.freeze_commit:raise SystemExit('--freeze-commit required')
    if a.manifest_only:
        m,sha=manifest(a.freeze_commit);print(enc({'manifest_sha256':sha,'manifest':m}));return
    if not a.out:raise SystemExit('--out required')
    obj=run_primary(a.freeze_commit);raw=(enc(obj)+'\n').encode();Path(a.out).write_bytes(raw);print(enc({'result_sha256':h256(raw),'primary':obj['signals']['A13_T6_BOUNDED_NOVEL_CONTEXT_DISCOVERY_SUCCESS'],'aggregate':obj['aggregate'],'false_signals':[k for k,v in obj['signals'].items() if not v]}))
if __name__=='__main__':main()
