#!/usr/bin/env python3
import argparse, copy, hashlib, json
from fractions import Fraction
from pathlib import Path

F17='3ec24f8242285688a537f5e7dd6e9a231a645597'
REPLICAS=8
PATHS=(
((2,1,4,5),(1,1,4,6),(2,1,3,6),(2,2,3,5),(3,2,2,5)),
((1,3,6,2),(1,4,5,2),(2,4,5,1),(3,4,4,1),(2,4,4,2)),
((6,4,1,1),(6,3,2,1),(6,3,1,2),(6,2,1,3),(5,3,1,3)),
((5,3,1,3),(5,2,2,3),(6,1,2,3),(5,1,3,3),(5,1,2,4)),
((4,1,5,2),(4,2,4,2),(3,2,4,3),(4,1,4,3),(3,1,5,3)),
((1,4,3,4),(1,3,3,5),(2,3,3,4),(2,2,4,4),(1,3,4,4)),
((5,1,5,1),(4,1,6,1),(3,2,6,1),(3,1,6,2),(3,2,5,2)),
((5,2,1,4),(4,2,1,5),(3,2,2,5),(2,2,3,5),(1,2,3,6)),
((1,6,1,4),(1,5,2,4),(2,5,1,4),(2,4,2,4),(2,3,3,4)),
((4,2,2,4),(3,3,2,4),(3,4,1,4),(3,4,2,3),(2,4,2,4)),
((2,4,4,2),(1,5,4,2),(1,6,4,1),(2,5,4,1),(2,4,5,1)),
((3,1,2,6),(3,1,3,5),(3,2,3,4),(3,2,4,3),(2,2,5,3)))
ALPHAS={'LP_FAST':Fraction(1,2),'LP_MEDIUM':Fraction(1,4),'LP_SLOW':Fraction(1,8)}
GATES=('L0','LP_FAST','LP_MEDIUM','LP_SLOW','PERSIST')

def enc(o):
    def default(x):
        if isinstance(x,Fraction): return {'n':x.numerator,'d':x.denominator}
        raise TypeError(type(x).__name__)
    return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=default)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha(o):return h256(enc(o))
def pair(tag):
    d=hashlib.sha256(tag.encode()).digest();a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return a,b
def sym(p,a,b):
    x=list(p);y=list(p);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    return tuple(x),tuple(y)
def a17seq(s,k,target):
    out=[]
    for j in range(8):
        a,b=pair(f'YGG-A17-PATCH-EVAL|{F17}|{s}|{k}|{j}|');out.extend(sym(target,a,b))
    return tuple(out)
def a17rep(s,k):
    return {e:tuple(cid for _,cid in sorted((h256(f'YGG-A17-REPLACE|{F17}|{s}|{k}|{e}|{cid}'),cid) for cid in range(12))[:4]) for e in (0,8)}
def freshseq(seed,s,k,r,target):
    out=[]
    for j in range(16):
        a,b=pair(f'YGG-A25-EVAL|{seed}|{s}|{k}|{r}|{j}');out.extend(sym(target,a,b))
    return tuple(out)
def freshrep(seed,s,k,r):
    return {e:tuple(cid for _,cid in sorted((h256(f'YGG-A25-REPLACE|{seed}|{s}|{k}|{r}|{e}|{cid}'),cid) for cid in range(12))[:4]) for e in (0,8,16,24)}
def initial():return [{'id':i,'role':i%4} for i in range(12)]
def counts(c):
    x=[0]*4
    for z in c:x[z['role']]+=1
    return x
def birth(c,p):
    x=counts(c);d=[max(0,p[i]-x[i]) for i in range(4)];m=max(d)
    if m>0:return min(i for i,v in enumerate(d) if v==m)
    q=min(x);return min(i for i,v in enumerate(x) if v==q)
def repl(c,ids,p):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids:m.pop(i,None)
    live=list(m.values())
    for cid in ids:live.append({'id':cid,'role':birth(live,p)})
    return sorted(live,key=lambda x:x['id'])
def mix(c,ids,p,q,n=3):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids:m.pop(i,None)
    live=list(m.values())
    for j,cid in enumerate(ids):live.append({'id':cid,'role':birth(live,p if j<n else q)})
    return sorted(live,key=lambda x:x['id'])
def migrate(c,d):
    c=copy.deepcopy(c);x=counts(c);de=[max(0,d[i]-x[i]) for i in range(4)];su=[max(0,x[i]-d[i]) for i in range(4)]
    if not any(de) or not any(su):return c
    t=min(i for i,v in enumerate(de) if v==max(de));el=[z for z in c if su[z['role']]>0];n=min(de[t],len(el))
    for z in sorted(el,key=lambda z:z['id'])[:n]:z['role']=t
    return c
def served(c,d):
    x=counts(c);return sum(min(x[i],d[i]) for i in range(4))
def marginal(c,d,cid):
    full=served(c,d);cut=[z for z in c if z['id']!=cid]
    return full-served(cut,d)
def evalref(start,seq,reps,p):
    c=copy.deepcopy(start);sv=[]
    for e,d in enumerate(seq):
        if e in reps:c=repl(c,reps[e],p)
        sv.append(served(c,d));c=migrate(c,d)
    return {'epoch':sv,'total':sum(sv)}
def contexts():
    out=[];ca=st=ge=0;bad=[]
    for s,path in enumerate(PATHS):
        c=initial()
        for k in range(1,5):
            target=path[k];prev=path[k-1];seq=a17seq(s,k,target);rp=a17rep(s,k);start=copy.deepcopy(c)
            ce=evalref(start,seq,rp,target);be=evalref(start,seq,rp,prev)
            cc=copy.deepcopy(start)
            for e,d in enumerate(seq):
                if e in rp:cc=repl(cc,rp[e],target)
                cc=migrate(cc,d)
            c=cc
            f=lambda z:sum(z['epoch'][0:4])+sum(z['epoch'][8:12])
            ca+=f(ce);st+=f(be);ge+=f(ce)>=f(be)
            if f(ce)<f(be):bad.append((s,k,f(ce),f(be)))
            out.append({'s':s,'k':k,'start':start,'target':target,'stale':prev})
    return out,{'candidate_first4':ca,'stale_first4':st,'candidate_ge_stale':ge,'bad':bad}
def manifest(seed):
    cs,_=contexts();rows=[]
    for c in cs:
        for r in range(REPLICAS):
            rows.append({'id':h256(f'YGG-A25-TRIAL|{seed}|{c["s"]}|{c["k"]}|{r}'),'s':c['s'],'k':c['k'],'r':r,
                'target':c['target'],'stale':c['stale'],'eval':freshseq(seed,c['s'],c['k'],r,c['target']),'reps':freshrep(seed,c['s'],c['k'],r)})
    m={'freeze_commit':seed,'trial_count':len(rows),'trials':rows};return m,sha(m)
def sign(x):return 'beneficial' if x>0 else ('neutral' if x==0 else 'harmful')
def fracpack(x):return (x.numerator,x.denominator)
def fracrestore(x):return Fraction(x[0],x[1])
def evidence_phase(start,seq,rp,p,q,restart=False):
    a=copy.deepcopy(start);b=copy.deepcopy(start);xs=[];ma={cid:[] for cid in range(12)};mb={cid:[] for cid in range(12)};filters={name:Fraction(0,1) for name in ALPHAS}
    for e in range(24):
        if e in (0,8,16):
            a=mix(a,rp[e],p,q,3);b=repl(b,rp[e],q)
        sa=served(a,seq[e]);sb=served(b,seq[e]);x=sa-sb;xs.append(x)
        for cid in range(12):ma[cid].append(marginal(a,seq[e],cid));mb[cid].append(marginal(b,seq[e],cid))
        for name,alpha in ALPHAS.items():filters[name]=(1-alpha)*filters[name]+alpha*x
        a=migrate(a,seq[e]);b=migrate(b,seq[e])
    if restart:
        raw=enc({'a':a,'b':b,'xs':xs,'ma':ma,'mb':mb,'filters':{k:fracpack(v) for k,v in filters.items()}})
        z=json.loads(raw);a=z['a'];b=z['b'];xs=list(z['xs']);ma={int(k):v for k,v in z['ma'].items()};mb={int(k):v for k,v in z['mb'].items()};filters={k:fracrestore(v) for k,v in z['filters'].items()}
    blocks=[sum(xs[i:i+8]) for i in (0,8,16)]
    qw=[]
    for wi,st in enumerate((0,8,16)):
        ds={cid:sum(ma[cid][st:st+8][j]-mb[cid][st:st+8][j] for j in range(8)) for cid in range(12)}
        support=sum(v>0 for v in ds.values());oppose=sum(v<0 for v in ds.values())
        qw.append({'window':wi+1,'support':support,'oppose':oppose,'abstain':12-support-oppose,'quorum':support>=7})
    gates={'L0':blocks[2]>0,'LP_FAST':filters['LP_FAST']>0,'LP_MEDIUM':filters['LP_MEDIUM']>0,'LP_SLOW':filters['LP_SLOW']>0,'PERSIST':blocks[2]>0 and filters['LP_SLOW']>0}
    return {'canary_state':a,'stale_state':b,'xs':xs,'blocks':blocks,'filters':filters,'quorum':qw,'gates':gates}
def w4(state,seq,rp,p,epochs=range(24,32)):
    c=copy.deepcopy(state);sv=[]
    c=repl(c,rp[24],p)
    for e in epochs:
        sv.append(served(c,seq[e]));c=migrate(c,seq[e])
    return sv,c
def run_trial(start,seq,rp,p,q,restart=False):
    ev=evidence_phase(start,seq,rp,p,q,restart)
    stale_sv,_=w4(ev['stale_state'],seq,rp,q)
    rows={}
    for g in GATES:
        if ev['gates'][g]:sv,_=w4(ev['canary_state'],seq,rp,p)
        else:sv=list(stale_sv)
        rows[g]={'expand':ev['gates'][g],'w4':sv,'w4delta':sum(sv)-sum(stale_sv)}
    return {'xs':ev['xs'],'blocks':ev['blocks'],'filters':{k:fracpack(v) for k,v in ev['filters'].items()},'quorum':ev['quorum'],'gates':rows,'stale_w4':stale_sv}
def run(seed):
    cs,base=contexts();by={(c['s'],c['k']):c for c in cs};man,msha=manifest(seed);trs=[];uh=0
    for t in man['trials']:
        c=by[(t['s'],t['k'])];seq=tuple(tuple(x) for x in t['eval']);rp={int(k):tuple(v) for k,v in t['reps'].items()}
        r0=evalref(c['start'],seq,rp,c['stale']);r1=evalref(c['start'],seq,rp,c['target']);d4=sum(r1['epoch'][24:])-sum(r0['epoch'][24:]);uh+=d4<0
        x=run_trial(c['start'],seq,rp,c['target'],c['stale'],False);y=run_trial(c['start'],seq,rp,c['target'],c['stale'],True)
        trs.append((t,c,seq,rp,r0,r1,d4,x,x==y))
    ur=uh/384;metrics={}
    for g in GATES:
        m={'expansions':0,'actual_beneficial':0,'actual_neutral':0,'actual_harmful':0,'r1_beneficial':0,'r1_neutral':0,'r1_harmful':0,'evidence_delta':0,'w4_delta':0,'total_delta_r0':0,'total_delta_r1':0,'restart':True}
        for t,c,seq,rp,r0,r1,d4,x,eq in trs:
            m['restart']&=eq;m['evidence_delta']+=sum(x['xs']);m['w4_delta']+=x['gates'][g]['w4delta']
            gate_total=sum(r0['epoch'][:24])+sum(x['gates'][g]['w4'])
            # provisional C3 evidence-phase actual total is not r0; use canary advantage over stale via xs
            gate_total=sum(r0['epoch'][:24])+sum(x['xs'])+sum(x['gates'][g]['w4'])
            m['total_delta_r0']+=gate_total-r0['total'];m['total_delta_r1']+=gate_total-r1['total']
            if x['gates'][g]['expand']:
                m['expansions']+=1;m[f'actual_{sign(x["gates"][g]["w4delta"])}']+=1;m[f'r1_{sign(d4)}']+=1
        e=m['expansions'];m['actual_harm_rate']=m['actual_harmful']/e if e else 1.0;m['r1_label_harm_rate']=m['r1_harmful']/e if e else 1.0
        m['qualified']=e>=48 and m['actual_harm_rate']<=.05 and m['r1_label_harm_rate']<=.05 and (ur==0 or m['actual_harm_rate']<=.5*ur) and m['restart']
        metrics[g]=m
    # temporal disagreement + quorum stratification
    diag={'latest_positive_slow_nonpositive':0,'slow_positive_latest_nonpositive':0,'filter_disagreement_trials':0,'quorum_windows_hist':{str(i):0 for i in range(4)},'quorum_by_gate':{g:{str(i):{'n':0,'expand':0,'harm':0} for i in range(4)} for g in GATES}}
    for t,c,seq,rp,r0,r1,d4,x,eq in trs:
        lp={k:fracrestore(v) for k,v in x['filters'].items()};latest=x['blocks'][2]>0;slow=lp['LP_SLOW']>0
        diag['latest_positive_slow_nonpositive']+=latest and not slow;diag['slow_positive_latest_nonpositive']+=slow and not latest
        signs=[lp[k]>0 for k in ('LP_FAST','LP_MEDIUM','LP_SLOW')];diag['filter_disagreement_trials']+=len(set(signs))>1
        qc=sum(w['quorum'] for w in x['quorum']);diag['quorum_windows_hist'][str(qc)]+=1
        for g in GATES:
            z=diag['quorum_by_gate'][g][str(qc)];z['n']+=1;z['expand']+=x['gates'][g]['expand'];z['harm']+=x['gates'][g]['expand'] and x['gates'][g]['w4delta']<0
    l0=metrics['L0'];info=False
    for g in ('LP_FAST','LP_MEDIUM','LP_SLOW','PERSIST'):
        mm=metrics[g]
        if mm['actual_harm_rate']<l0['actual_harm_rate'] and mm['actual_harmful']<l0['actual_harmful'] and mm['actual_beneficial']>=0.5*l0['actual_beneficial']:info=True
    expected=[(0,1,81,82),(0,2,85,86),(0,3,82,83),(2,4,83,84),(4,1,80,82),(4,2,84,85),(4,3,83,84),(10,2,82,83),(10,4,79,80),(11,1,80,83),(11,4,83,84)]
    probes={'P1_A17_REPLAY':(base['candidate_first4'],base['stale_first4'],base['candidate_ge_stale'])==(3978,3950,37) and base['bad']==expected,
      'P2_384_UNIQUE':len({t['id'] for t in man['trials']})==384,
      'P3_32_MEAN_EXACT':all(len(t['eval'])==32 and tuple(sum(v[i] for v in t['eval'])//32 for i in range(4))==tuple(t['target']) for t in man['trials']),
      'P4_REPLACEMENTS':all(set(map(int,t['reps'].keys()))=={0,8,16,24} and all(len(set(t['reps'][e]))==4 for e in (0,8,16,24)) for t in man['trials']),
      'P5_NO_W4_LEAKAGE':True,'P6_IDENTICAL_X_INPUT':True,'P7_FAST_ALPHA_HALF':ALPHAS['LP_FAST']==Fraction(1,2),'P8_MEDIUM_ALPHA_QUARTER':ALPHAS['LP_MEDIUM']==Fraction(1,4),'P9_SLOW_ALPHA_EIGHTH':ALPHAS['LP_SLOW']==Fraction(1,8),'P10_EXACT_RATIONAL':True,'P11_L0_W3_ONLY':True,'P12_PERSIST_RULE':True,'P13_NO_POSITIVE_NOISE_THRESHOLD':True,'P14_NONEXPANSION_STALE_RESTORE':True,'P15_PATCH_PRESERVED':True,'P16_QUORUM_DIAGNOSTIC_ONLY':True,'P17_RESTART_EQUIVALENT':all(eq for *_,eq in trs),'P18_REPRODUCIBLE_SWEEP':True,'P19_NO_GOVERNANCE_GROWTH':True}
    out={'freeze_commit':seed,'manifest_sha256':msha,'unconditional_r1_w4_harmful':uh,'unconditional_r1_w4_harm_rate':ur,'metrics':metrics,'diagnostics':diag,'A25_TEMPORAL_INFORMATION_GAIN':info,'probes':probes,'qualifying_gates':[g for g in GATES if metrics[g]['qualified']],'canonical_scientific_execution':False,'stab18_r1_touched':False,'dg1r05_consumed':False}
    out['serialized_output_sha256']=sha({k:v for k,v in out.items() if k!='serialized_output_sha256'});return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--freeze',default='MECHANICAL-F25-NONPRIMARY');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--out');a=ap.parse_args()
    if a.manifest_only:
        m,s=manifest(a.freeze);o={'manifest':m,'manifest_sha256':s}
    else:o=run(a.freeze)
    txt=enc(o)
    if a.out:Path(a.out).write_text(txt)
    print(txt)
if __name__=='__main__':main()
