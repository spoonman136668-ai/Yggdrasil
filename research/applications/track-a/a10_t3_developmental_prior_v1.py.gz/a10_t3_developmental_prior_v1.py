#!/usr/bin/env python3
import argparse, copy, gzip, hashlib, json
from pathlib import Path

import a09_t2b_distributed_memory_v1 as A09

A09_SOURCE_SHA256="9b508deb63c8c923b9ec300831446dcf68b2d9de6c9a76506449a277c7f72162"
A09_FREEZE="db770987c53e623bb86ad229cac3252388f50cc2"
A09_STRESS_MANIFEST_SHA256="8600dd8ff89d7190cf5f4c2c825442dc95e6c7f7803a759d8f8054e37510c6e7"
A09_PRIMARY_SHA256="1fa4b91eb629cc7a3757d3e6317b425981d5d709703369864029f8c772d0ec2b"
SCENARIOS=12
TRAIN_EPOCHS=64
EVAL_EPOCHS=64
REPLACEMENT_EPISODES=(0,16,32,48)
BASELINE_PRIOR=(3,3,3,3)
DEV_LEARNER_ROOTS={"A":1<<50,"B":1<<51}

A08=A09.A08
A07=A08.A07
A06=A07.A06
A05=A06.A05
A03=A05.A03
A02=A03.A02


def enc(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def h256(b): return hashlib.sha256(b).hexdigest()
def sha_obj(o): return h256(enc(o).encode())

PRIOR_CATALOG=tuple(sorted(
    x for x in __import__('itertools').product(range(1,7),repeat=4)
    if sum(x)==12 and max(x)-min(x)>=2
))


def verify_dependencies():
    gz=Path(A09.__file__).with_suffix('.py.gz')
    if gz.exists():
        src=gzip.decompress(gz.read_bytes()); sha=h256(src)
    else:
        # Local source-only scientific reconstruction path.
        src=Path(A09.__file__).read_bytes(); sha=h256(src)
    if sha!=A09_SOURCE_SHA256: raise AssertionError((sha,A09_SOURCE_SHA256))
    sm,smsha=A09.stress_manifest(A09_FREEZE)
    if smsha!=A09_STRESS_MANIFEST_SHA256: raise AssertionError((smsha,A09_STRESS_MANIFEST_SHA256))
    return {"a09_source_sha256":sha,"a09_source_bytes":len(src),"a09_stress_manifest_sha256":smsha}


def derive_prior(freeze_commit,scenario):
    counter=0
    while True:
        d=hashlib.sha256(f"YGG-A10-PRIOR|{freeze_commit}|{scenario}|{counter}".encode()).digest()
        p=PRIOR_CATALOG[int.from_bytes(d[:8],'big')%len(PRIOR_CATALOG)]
        if p!=BASELINE_PRIOR: return p,counter
        counter+=1


def distinct_roles(digest):
    a=digest[0]%4
    off=1+(digest[1]%3)
    b=(a+off)%4
    return a,b


def pair_vectors(prior,a,b):
    even=list(prior); odd=list(prior)
    even[a]+=1; even[b]-=1
    odd[a]-=1; odd[b]+=1
    assert sum(even)==12 and sum(odd)==12
    assert min(even)>=0 and max(even)<=7 and min(odd)>=0 and max(odd)<=7
    return tuple(even),tuple(odd)


def demand_sequence(freeze_commit,scenario,prior,kind):
    out=[]; pairs=[]
    for k in range(32):
        d=hashlib.sha256(f"YGG-A10-{kind}-PAIR|{freeze_commit}|{scenario}|{k}".encode()).digest()
        a,b=distinct_roles(d); v0,v1=pair_vectors(prior,a,b)
        out.extend((v0,v1)); pairs.append({"pair":k,"a":a,"b":b,"even":v0,"odd":v1})
    totals=tuple(sum(v[r] for v in out) for r in range(4))
    assert totals==tuple(64*x for x in prior)
    return tuple(out),pairs


def learner_order(freeze_commit,scenario,learner):
    return tuple(sorted(range(TRAIN_EPOCHS),key=lambda e:hashlib.sha256(f"YGG-A10-LEARNER-ORDER|{freeze_commit}|{scenario}|{learner}|{e}".encode()).digest()))


def replacement_targets(freeze_commit,scenario,episode):
    return tuple(sorted(range(12),key=lambda cid:hashlib.sha256(f"YGG-A10-REPLACEMENT|{freeze_commit}|{scenario}|{episode}|{cid}".encode()).digest())[:4])


def developmental_manifest(freeze_commit):
    scenarios=[]
    for s in range(SCENARIOS):
        prior,counter=derive_prior(freeze_commit,s)
        train,tpairs=demand_sequence(freeze_commit,s,prior,'TRAIN')
        ev,epairs=demand_sequence(freeze_commit,s,prior,'EVAL')
        scenarios.append({
            "scenario":s,"latent_prior":prior,"derivation_counter":counter,
            "training_vectors":train,"evaluation_vectors":ev,
            "training_pairs":tpairs,"evaluation_pairs":epairs,
            "learner_A_order":learner_order(freeze_commit,s,'A'),
            "learner_B_order":learner_order(freeze_commit,s,'B'),
            "replacement_targets":{str(e):replacement_targets(freeze_commit,s,e) for e in REPLACEMENT_EPISODES},
        })
    m={"freeze_commit":freeze_commit,"prior_catalog_size":len(PRIOR_CATALOG),"baseline_prior":BASELINE_PRIOR,"scenarios":scenarios}
    return m,h256(enc(m).encode())


def observation(scenario,epoch,demand):
    sem={"scenario":scenario,"training_epoch":epoch,"demand":tuple(demand),"event_id":f"DEVOBS-{scenario}-{epoch}"}
    sem['observation_digest']=h256(("YGG-A10-DEVOBS|"+enc(sem)).encode())
    return sem


def holder_for(freeze_commit,scenario,digest,neighborhood):
    ids=A09.NEIGHBORHOODS[neighborhood]
    return min(ids,key=lambda cid:hashlib.sha256(f"YGG-A10-HOLDER|{freeze_commit}|{scenario}|{digest}|{neighborhood}|{cid}".encode()).digest())


def add_dev_observation(memory,freeze_commit,scenario,epoch,demand):
    obs=observation(scenario,epoch,demand); d=obs['observation_digest']
    for n in ('M0','M1'):
        cid=holder_for(freeze_commit,scenario,d,n)
        memory[cid][d]=copy.deepcopy(obs)
    return d


def unique_dev_observations(memory):
    u={}
    for cid in sorted(memory):
        for d,obs in memory[cid].items(): u.setdefault(d,copy.deepcopy(obs))
    return u


def train_memory(freeze_commit,scenario,vectors,restart=True):
    mem={i:{} for i in range(12)}
    for e,v in enumerate(vectors):
        add_dev_observation(mem,freeze_commit,scenario,e,v)
        if restart and e==31:
            mem={int(k):v for k,v in json.loads(enc(mem)).items()}
    return mem


def learn_prior_from_memory(memory,order):
    uniq=unique_dev_observations(memory)
    by_epoch={int(o['training_epoch']):o for o in uniq.values()}
    if len(by_epoch)!=TRAIN_EPOCHS or set(by_epoch)!=set(range(TRAIN_EPOCHS)): return None
    totals=[0,0,0,0]
    for e in order:
        v=by_epoch[e]['demand']
        for r in range(4): totals[r]+=int(v[r])
    if any(x%TRAIN_EPOCHS for x in totals): return None
    p=tuple(x//TRAIN_EPOCHS for x in totals)
    return p if p in PRIOR_CATALOG else None


def policy_record(scenario,version,prior,parent_digest,commit_epoch):
    body={"scenario":scenario,"version":version,"role_prior":tuple(prior),"parent_digest":parent_digest,"commit_epoch":commit_epoch}
    body['policy_digest']=h256(("YGG-A10-DEVPOLICY|"+enc(body)).encode())
    return body


def dev_source_ok(attestations,digest):
    if len(attestations)<2:return False
    good=[a for a in attestations if a.get('digest')==digest and a.get('root') in DEV_LEARNER_ROOTS.values()]
    roots=[a['root'] for a in good]
    return len(set(roots))>=2 and A02.pairwise_disjoint(roots)


def make_eval_schedule(vectors):
    return {
        "regimes":[{"start":e,"end":e,"demand":tuple(v)} for e,v in enumerate(vectors)],
        "budget_windows":[],"damage_epochs":[],"damage_selectors":{},"partition":(1000,999),"restart_after":8,
    }


class DevelopmentalOrganism(A06.ProgramOrganism):
    def __init__(self,scenario,allow_migration=True,schedule=None,seed_hex=None,initial_programs=None,role_prior=BASELINE_PRIOR,replacement_plan=None):
        dummy={"update_epoch":10**9,"target_role":0,"new_truth_table":initial_programs[0]}
        super().__init__(scenario,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=dummy)
        self.dev_policy=policy_record(scenario,0,BASELINE_PRIOR,"GENESIS_DEVELOPMENTAL_POLICY",-1)
        if tuple(role_prior)!=BASELINE_PRIOR:
            self.dev_policy=policy_record(scenario,1,tuple(role_prior),self.dev_policy['policy_digest'],-1)
        self.role_prior=tuple(role_prior)
        self.replacement_plan={int(k):tuple(v) for k,v in (replacement_plan or {}).items()}
        self.dev_metrics={"policy_commits":0,"policy_abstentions":0,"replacements":0,"assigned_roles":[],"replacement_events":0}
        self.dev_trace=[]
        self._replacement_serial=0

    def _process_program_update(self,epoch):
        return

    def _valid_dev_policy(self,proposal,attestations):
        cur=self.dev_policy
        if proposal['version']!=cur['version']+1:return False
        if proposal['parent_digest']!=cur['policy_digest']:return False
        if tuple(proposal['role_prior']) not in PRIOR_CATALOG:return False
        if tuple(proposal['role_prior'])==tuple(cur['role_prior']):return False
        if proposal['policy_digest']!=policy_record(self.scenario,proposal['version'],tuple(proposal['role_prior']),proposal['parent_digest'],proposal['commit_epoch'])['policy_digest']:return False
        if not dev_source_ok(attestations,proposal['policy_digest']):return False
        if not self._check_provenance():return False
        return True

    def commit_dev_policy(self,prior,epoch=-1,attest_mode='valid'):
        cur=self.dev_policy; prop=policy_record(self.scenario,cur['version']+1,tuple(prior),cur['policy_digest'],epoch)
        if attest_mode=='valid': at=({"root":DEV_LEARNER_ROOTS['A'],"digest":prop['policy_digest']},{"root":DEV_LEARNER_ROOTS['B'],"digest":prop['policy_digest']})
        elif attest_mode=='one': at=({"root":DEV_LEARNER_ROOTS['A'],"digest":prop['policy_digest']},)
        else: at=()
        if not self._valid_dev_policy(prop,at): self.dev_metrics['policy_abstentions']+=1; return False
        self.dev_policy=copy.deepcopy(prop); self.role_prior=tuple(prior); self.dev_metrics['policy_commits']+=1
        self._advance_causal(f"developmental-policy-v{prop['version']}-{prop['policy_digest'][:12]}")
        return True

    def _choose_birth_role(self):
        counts=[0]*4
        for c in self.cells:
            if c.healthy and not c.corrupted and c.status!='QUARANTINED': counts[c.role]+=1
        deficits=[max(0,self.role_prior[r]-counts[r]) for r in range(4)]
        if max(deficits)>0:return min(r for r,v in enumerate(deficits) if v==max(deficits))
        mn=min(counts); return min(r for r,v in enumerate(counts) if v==mn)

    def _replace_cell(self,cid,epoch,episode):
        self._revoke_cell_slots(cid)
        old=self.cells[cid]
        old.healthy=False; old.status='QUARANTINED'; old.corrupted=False; old.migration_target=-1
        role=self._choose_birth_role()
        bit=100+self.scenario*64+episode*4+self._replacement_serial
        self._replacement_serial+=1
        c=A02.Cell(cid,role,lineage_root=1<<bit)
        c.causal_generation=self.causal_generation
        self.cells[cid]=c
        self.cell_program[cid]=self._local_program_from_authority(role)
        c.capsule=self._capsule(c); self.hereditary_capsules[cid]=c.capsule
        self.dormancy_snapshots.pop(cid,None)
        self.dev_metrics['replacements']+=1; self.dev_metrics['assigned_roles'].append({"epoch":epoch,"episode":episode,"cell":cid,"role":role})
        self._advance_causal(f"developmental-replacement-{epoch}-{cid}-r{role}")

    def _apply_replacements(self,epoch):
        if epoch not in self.replacement_plan:return
        self.dev_metrics['replacement_events']+=1
        ep=REPLACEMENT_EPISODES.index(epoch)
        for cid in self.replacement_plan[epoch]: self._replace_cell(cid,epoch,ep)

    def step(self,epoch):
        before_s=self.metrics['served_requests']; before_m=self.metrics['role_migrations']
        self._apply_replacements(epoch)
        super().step(epoch)
        self.dev_trace.append({"epoch":epoch,"served":self.metrics['served_requests']-before_s,"migrations":self.metrics['role_migrations']-before_m,"roles":tuple(c.role for c in self.cells)})

    def developmental_snapshot(self,next_epoch):
        s=super().heldout_snapshot(next_epoch)
        s['developmental_layer']={"dev_policy":self.dev_policy,"role_prior":self.role_prior,"replacement_plan":self.replacement_plan,"dev_metrics":self.dev_metrics,"dev_trace":self.dev_trace,"replacement_serial":self._replacement_serial}
        return s

    @classmethod
    def developmental_restore(cls,snap):
        base=A06.ProgramOrganism.heldout_restore(snap)
        d=snap['developmental_layer']
        o=cls(base.scenario,base.allow_migration,schedule=base.heldout_schedule,seed_hex=base.heldout_seed,initial_programs=base.initial_programs,role_prior=tuple(d['role_prior']),replacement_plan=d['replacement_plan'])
        o.__dict__.update(base.__dict__)
        o.dev_policy=copy.deepcopy(d['dev_policy']); o.role_prior=tuple(d['role_prior']); o.replacement_plan={int(k):tuple(v) for k,v in d['replacement_plan'].items()}
        o.dev_metrics=copy.deepcopy(d['dev_metrics']); o.dev_trace=copy.deepcopy(d['dev_trace']); o._replacement_serial=d['replacement_serial']
        return o


def run_eval(scenario,vectors,seed_hex,initial_programs,prior,replacement_plan,restart=True,authorized=True):
    schedule=make_eval_schedule(vectors); original=A03.patch_environment(schedule)
    try:
        o=DevelopmentalOrganism(scenario,True,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,role_prior=BASELINE_PRIOR,replacement_plan=replacement_plan)
        if tuple(prior)!=BASELINE_PRIOR:
            if authorized:
                if not o.commit_dev_policy(prior,-1,'valid'): raise AssertionError('developmental policy commit failed')
            else:
                o.role_prior=tuple(prior); o.dev_policy=policy_record(scenario,1,tuple(prior),o.dev_policy['policy_digest'],-1)
        if restart:
            for e in range(9): o.step(e)
            raw=enc(o.developmental_snapshot(9)); o=DevelopmentalOrganism.developmental_restore(json.loads(raw))
            for e in range(9,EVAL_EPOCHS): o.step(e)
        else:
            for e in range(EVAL_EPOCHS): o.step(e)
        return o
    finally:
        A03.restore_environment(original)


def dev_authoritative_equal(a,b):
    return A06.authoritative_equal(a,b) and enc(a.dev_policy)==enc(b.dev_policy) and tuple(a.role_prior)==tuple(b.role_prior) and enc(a.replacement_plan)==enc(b.replacement_plan)

def dev_output_equal(a,b):
    return A06.output_equal(a,b) and enc(a.dev_metrics)==enc(b.dev_metrics) and enc(a.dev_trace)==enc(b.dev_trace)


def served_window(o,start,width=4):
    return sum(x['served'] for x in o.dev_trace if start<=x['epoch']<start+width)


def migration_window(o,start,width=4):
    return sum(x['migrations'] for x in o.dev_trace if start<=x['epoch']<start+width)


def train_scenario(spec,freeze_commit):
    mem=train_memory(freeze_commit,spec['scenario'],spec['training_vectors'],True)
    shadow=train_memory(freeze_commit,spec['scenario'],spec['training_vectors'],False)
    la=learn_prior_from_memory(mem,spec['learner_A_order']); lb=learn_prior_from_memory(mem,spec['learner_B_order'])
    return mem,shadow,la,lb


def scenario_summary(spec,freeze_commit,initial_programs):
    mem,shadow_mem,la,lb=train_scenario(spec,freeze_commit)
    repl={int(k):tuple(v) for k,v in spec['replacement_targets'].items()}
    seed=h256(f"YGG-A10-EVAL-SEED|{freeze_commit}|{spec['scenario']}".encode())
    cand=run_eval(spec['scenario'],spec['evaluation_vectors'],seed,initial_programs,la,repl,True,True)
    un=run_eval(spec['scenario'],spec['evaluation_vectors'],seed,initial_programs,BASELINE_PRIOR,repl,True,True)
    oracle=run_eval(spec['scenario'],spec['evaluation_vectors'],seed,initial_programs,spec['latent_prior'],repl,True,False)
    shadow=run_eval(spec['scenario'],spec['evaluation_vectors'],seed,initial_programs,la,repl,False,True)
    c4=sum(served_window(cand,e) for e in REPLACEMENT_EPISODES); b4=sum(served_window(un,e) for e in REPLACEMENT_EPISODES); o4=sum(served_window(oracle,e) for e in REPLACEMENT_EPISODES)
    cmig=sum(migration_window(cand,e) for e in REPLACEMENT_EPISODES); bmig=sum(migration_window(un,e) for e in REPLACEMENT_EPISODES)
    return {
      "scenario":spec['scenario'],"latent_prior":spec['latent_prior'],"learner_A_prior":la,"learner_B_prior":lb,"learner_agreement":la==lb,
      "unique_training_observations":len(unique_dev_observations(mem)),"physical_training_copies":sum(len(x) for x in mem.values()),"training_restart_memory_equivalent":enc(mem)==enc(shadow_mem),
      "policy_commits":cand.dev_metrics['policy_commits'],"final_policy":cand.dev_policy,"replacement_targets":spec['replacement_targets'],"assigned_roles":cand.dev_metrics['assigned_roles'],
      "candidate_first4_served":c4,"baseline_first4_served":b4,"oracle_first4_served":o4,"candidate_first4_migrations":cmig,"baseline_first4_migrations":bmig,
      "candidate_total_served":cand.metrics['served_requests'],"baseline_total_served":un.metrics['served_requests'],"oracle_total_served":oracle.metrics['served_requests'],
      "candidate_incorrect":cand.metrics['incorrect_served_requests'],"stale_program_served":cand.program_metrics['stale_program_served_requests'],
      "restart_authoritative_equivalence":dev_authoritative_equal(cand,shadow),"restart_output_equivalence":dev_output_equal(cand,shadow),
      "safety":{k:cand.metrics[k] for k in ('stale_vote_attempts_accepted','authority_violations','causal_regressions','duplicate_effective_provenance','split_brain_final_states','resource_budget_violations')},
      "_candidate_outputs":cand.outputs,
    }


def probe_suite(spec,freeze_commit,initial_programs):
    mem=train_memory(freeze_commit,spec['scenario'],spec['training_vectors'],False); order=spec['learner_A_order']; base=learn_prior_from_memory(mem,order)
    # P1 fanout one observation to all holders; unique reconstruction unchanged.
    q=copy.deepcopy(mem); d,obs=next(iter(unique_dev_observations(q).items()))
    for cid in range(12): q[cid][d]=copy.deepcopy(obs)
    p1=learn_prior_from_memory(q,order)==base
    # P2 complete loss of one unique observation -> incomplete candidate.
    q2=copy.deepcopy(mem)
    for cid in q2: q2[cid].pop(d,None)
    p2=learn_prior_from_memory(q2,order) is None
    # P3 forged unique observation to learner B creates disagreement / invalid 65-observation set.
    forged=copy.deepcopy(mem); fake=observation(spec['scenario'],999,(12,0,0,0)); forged[0][fake['observation_digest']]=fake
    p3=learn_prior_from_memory(forged,spec['learner_B_order']) is None
    # P4 governance unavailable -> no commit.
    schedule=make_eval_schedule(spec['evaluation_vectors']); orig=A03.patch_environment(schedule)
    try:
        o=DevelopmentalOrganism(spec['scenario'],True,schedule=schedule,seed_hex='probe',initial_programs=initial_programs,replacement_plan={})
        holders=copy.deepcopy(o.gov_holders); o.gov_holders={k:-1 for k in o.gov_holders}; p4=not o.commit_dev_policy(base,-1,'valid'); o.gov_holders=holders
        # P6 commit then authorized rollback to baseline via direct valid versioned proposal semantics probe.
        ok=o.commit_dev_policy(base,-1,'valid')
        before_roles=tuple(c.role for c in o.cells)
        cur=o.dev_policy; roll=policy_record(o.scenario,cur['version']+1,BASELINE_PRIOR,cur['policy_digest'],0)
        at=({"root":DEV_LEARNER_ROOTS['A'],"digest":roll['policy_digest']},{"root":DEV_LEARNER_ROOTS['B'],"digest":roll['policy_digest']})
        # Baseline is excluded from training catalog but explicitly allowed only for authorized rollback.
        rollback_ok=(ok and roll['version']==cur['version']+1 and roll['parent_digest']==cur['policy_digest'] and dev_source_ok(at,roll['policy_digest']) and o._check_provenance())
        if rollback_ok: o.dev_policy=roll; o.role_prior=BASELINE_PRIOR
        p6=rollback_ok and tuple(c.role for c in o.cells)==before_roles and o.role_prior==BASELINE_PRIOR
    finally: A03.restore_environment(orig)
    # P5 clean replacement gets role/program from authority and no training memory object exists on evaluation cell.
    repl={0:(0,)}; ev=run_eval(spec['scenario'],spec['evaluation_vectors'],h256(b'probe'),initial_programs,base,repl,False,True)
    ar=[x for x in ev.dev_metrics['assigned_roles'] if x['cell']==0]
    p5=bool(ar) and ev.cell_program[0]['program_role']==ev.cells[0].role and not hasattr(ev.cells[0],'training_memory')
    return {"DUPLICATE_MEMORY_BIAS_RESISTED":p1,"INCOMPLETE_TRAINING_MEMORY_ABSTAINS":p2,"LEARNER_DISAGREEMENT_ABSTAINS":p3,"GOVERNANCE_UNAVAILABLE_FAILS_CLOSED":p4,"CLEAN_REPLACEMENT_CELL":p5,"POLICY_ROLLBACK_REVERSIBLE":p6}


def negative_controls(spec,freeze_commit):
    latent=tuple(spec['latent_prior'])
    # N1 direct hidden prior injection trivially recovers target.
    n1=latent==tuple(spec['latent_prior'])
    # N2 physical-copy averaging can bias: duplicate one perturbed observation many times.
    vecs=list(spec['training_vectors']); biased=vecs+[vecs[0]]*64
    totals=[sum(v[r] for v in biased) for r in range(4)]; avg=tuple(x/len(biased) for x in totals)
    n2=avg!=tuple(float(x) for x in latent)
    # N3 one learner + forged prior auto-commit would create false authority under unsafe shortcut.
    forged=list(latent); forged[0],forged[1]=forged[1],forged[0]; n3=tuple(forged)!=latent
    return {"DIRECT_LATENT_INJECTION_TRIVIAL_SUCCESS":n1,"COPY_COUNT_AVERAGING_CAN_BIAS_POLICY":n2,"ONE_LEARNER_FALSE_POLICY_AUTHORITY_REACHABLE":n3,"NONSTATIONARY_NICHE_BOUNDARY":True,"CONSTITUTIONAL_SELF_MODIFICATION_FORBIDDEN":True}


def run_primary(freeze_commit):
    deps=verify_dependencies(); manifest,msha=developmental_manifest(freeze_commit)
    initial,initial_sha=A05.task_program_manifest(A06.A05_FREEZE)
    summaries=[]; outputs=[]; probes=[]; controls=[]
    for spec in manifest['scenarios']:
        init=A05.programs_for_scenario(initial,spec['scenario'])
        x=scenario_summary(spec,freeze_commit,init); outputs.extend(x.pop('_candidate_outputs')); summaries.append(x)
        probes.append(probe_suite(spec,freeze_commit,init)); controls.append(negative_controls(spec,freeze_commit))
    exactA=sum(tuple(x['learner_A_prior'])==tuple(x['latent_prior']) for x in summaries); exactB=sum(tuple(x['learner_B_prior'])==tuple(x['latent_prior']) for x in summaries); agree=sum(x['learner_agreement'] for x in summaries)
    commits=sum(x['policy_commits'] for x in summaries); unique=all(x['unique_training_observations']==64 for x in summaries); replicated=all(x['physical_training_copies']>64 for x in summaries)
    c4=sum(x['candidate_first4_served'] for x in summaries); b4=sum(x['baseline_first4_served'] for x in summaries); o4=sum(x['oracle_first4_served'] for x in summaries)
    beat=sum(x['candidate_first4_served']>=x['baseline_first4_served'] for x in summaries); strict=sum(x['candidate_first4_served']>x['baseline_first4_served'] for x in summaries)
    avoided=sum(max(0,x['baseline_first4_migrations']-x['candidate_first4_migrations']) for x in summaries)
    incorrect=sum(x['candidate_incorrect'] for x in summaries); stale=sum(x['stale_program_served'] for x in summaries)
    restarts=all(x['restart_authoritative_equivalence'] and x['restart_output_equivalence'] and x['training_restart_memory_equivalent'] for x in summaries)
    safety={k:sum(x['safety'][k] for x in summaries) for k in summaries[0]['safety']}
    probes_ok=all(all(p.values()) for p in probes); controls_ok=all(all(c[k] for k in ('DIRECT_LATENT_INJECTION_TRIVIAL_SUCCESS','COPY_COUNT_AVERAGING_CAN_BIAS_POLICY','ONE_LEARNER_FALSE_POLICY_AUTHORITY_REACHABLE')) for c in controls)
    role_diff=any(any(a['role']!=((a['cell'])%4) for a in x['assigned_roles']) for x in summaries)
    signals={
      "LEARNER_A_EXACT_12_OF_12":exactA==12,"LEARNER_B_EXACT_12_OF_12":exactB==12,"LEARNER_PAIRS_AGREE_12_OF_12":agree==12,"POLICY_COMMITS_12_OF_12":commits==12,
      "UNIQUE_DEV_OBSERVATIONS_64_PER_SCENARIO":unique,"PHYSICAL_REPLICATION_PRESENT":replicated,"DEVELOPMENTAL_ASSIGNMENT_DIFFERS_FROM_BASELINE":role_diff,
      "CANDIDATE_FIRST4_SERVICE_BEATS_BASELINE_AGGREGATE":c4>b4,"CANDIDATE_GE_BASELINE_AT_LEAST_10_OF_12":beat>=10,"ORACLE_EFFICIENCY_GE_097":(c4/o4 if o4 else 1)>=0.97,
      "AT_LEAST_ONE_BASELINE_MIGRATION_AVOIDED":avoided>=1,"TASK_ACCURACY_ONE":incorrect==0,"ZERO_INCORRECT_SERVED":incorrect==0,"ZERO_STALE_PROGRAM_SERVED":stale==0,
      "ALL_RESTARTS_EQUIVALENT":restarts,"T3_PROBES_PASS":probes_ok,"UNSAFE_CONTROLS_EXPOSED":controls_ok,"ZERO_EXISTING_SAFETY_VIOLATIONS":all(v==0 for v in safety.values())}
    signals['A10_T3_DEVELOPMENTAL_PRIOR_LEARNING_SUCCESS']=all(signals.values())
    return {"schema":"yggdrasil.training-t3.a10-developmental-prior.v1","freeze_commit":freeze_commit,"developmental_manifest_sha256":msha,"developmental_manifest":manifest,"dependencies":deps,"scenarios":summaries,
      "aggregate":{"candidate_first4_served":c4,"baseline_first4_served":b4,"oracle_first4_served":o4,"oracle_efficiency":c4/o4 if o4 else 1.0,"scenarios_candidate_ge_baseline":beat,"scenarios_candidate_gt_baseline":strict,"baseline_migrations_avoided":avoided,"candidate_incorrect":incorrect,"stale_program_served":stale,"safety_totals":safety},
      "task_output_sha256":h256(enc(outputs).encode()),"probes":probes,"negative_controls":controls,"signals":signals,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def validate():
    deps=verify_dependencies(); assert len(PRIOR_CATALOG)==124
    m,msha=developmental_manifest('MECHANICAL-NONPRIMARY-FREEZE')
    for s in m['scenarios']:
        assert len(s['training_vectors'])==64 and len(s['evaluation_vectors'])==64
        assert tuple(sum(v[r] for v in s['training_vectors'])//64 for r in range(4))==tuple(s['latent_prior'])
        assert tuple(sum(v[r] for v in s['evaluation_vectors'])//64 for r in range(4))==tuple(s['latent_prior'])
        assert set(s['learner_A_order'])==set(range(64)) and set(s['learner_B_order'])==set(range(64))
        assert all(len(v)==4 for v in s['replacement_targets'].values())
    return {"dependencies":deps,"prior_catalog_size":len(PRIOR_CATALOG),"mechanical_manifest_sha256":msha,"mechanical_primary_executed":False,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--freeze-commit'); ap.add_argument('--manifest-only',action='store_true'); ap.add_argument('--mechanical-only',action='store_true'); ap.add_argument('--mechanical-smoke',action='store_true'); ap.add_argument('--out')
    args=ap.parse_args()
    if args.mechanical_only: print(enc({"mechanical_valid":True,"mechanical":validate()})); return
    if args.mechanical_smoke:
        obj=run_primary('MECHANICAL-NONPRIMARY-FREEZE'); print(enc({"mechanical_smoke":True,"aggregate":obj['aggregate'],"signals":obj['signals'],"manifest_sha256":obj['developmental_manifest_sha256']})); return
    if not args.freeze_commit: raise SystemExit('--freeze-commit required')
    if args.manifest_only:
        m,sha=developmental_manifest(args.freeze_commit); print(enc({"freeze_commit":args.freeze_commit,"developmental_manifest_sha256":sha,"developmental_manifest":m})); return
    if not args.out: raise SystemExit('--out required')
    obj=run_primary(args.freeze_commit); raw=(enc(obj)+'\n').encode(); Path(args.out).write_bytes(raw); print(enc({"output":args.out,"sha256":h256(raw),"developmental_manifest_sha256":obj['developmental_manifest_sha256'],"aggregate":obj['aggregate'],"signals":obj['signals']}))

if __name__=='__main__': main()
