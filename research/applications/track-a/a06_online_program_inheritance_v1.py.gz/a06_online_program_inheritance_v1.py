#!/usr/bin/env python3
import argparse
import copy
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

import a05_task_semantic_transfer_v1 as A05

A05_SOURCE_SHA256="9efc8e31c08b60b6decff06c7ffc5b5a1ad10df7bb4440d4b2ab4d1fb5876fce"
A05_FREEZE="30d2b2ad4cc9126cbeba3854dbfe7551611e1ac8"
A05_MANIFEST_SHA256="3fbc3a77eef9068dba92f4206c8c5c7a180efafec2a0105aa52e978dea0fc7f6"
A03_ENV_FREEZE=A05.A03_ENV_FREEZE
A03_MANIFEST_SHA256=A05.A03_MANIFEST_SHA256
SCENARIOS=12
EPOCHS=384
PROGRAM_SOURCE_ROOTS=(1<<40,1<<41)


def enc(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha256_bytes(b): return hashlib.sha256(b).hexdigest()


def verify_dependencies():
    a05_gz=Path(A05.__file__).with_suffix('.py.gz')
    src=gzip.decompress(a05_gz.read_bytes())
    sha=sha256_bytes(src)
    if sha!=A05_SOURCE_SHA256: raise AssertionError((sha,A05_SOURCE_SHA256))
    a05_manifest,a05_sha=A05.task_program_manifest(A05_FREEZE)
    if a05_sha!=A05_MANIFEST_SHA256: raise AssertionError((a05_sha,A05_MANIFEST_SHA256))
    env,env_sha=A05.A03.schedule_manifest(A03_ENV_FREEZE)
    if env_sha!=A03_MANIFEST_SHA256: raise AssertionError((env_sha,A03_MANIFEST_SHA256))
    return {"a05_source_sha256":sha,"a05_source_bytes":len(src),"a05_manifest_sha256":a05_sha,"a03_environment_manifest_sha256":env_sha}


def program_record(scenario,role,version,truth_table,parent_digest,commit_epoch):
    base={"scenario":scenario,"role":role,"version":version,"truth_table":truth_table,
          "parent_digest":parent_digest,"commit_epoch":commit_epoch}
    base["program_digest"]=sha256_bytes(enc(base).encode())
    return base


def source_attestations(proposal_digest,mode="valid"):
    a,b=PROGRAM_SOURCE_ROOTS
    if mode=="valid": return ({"root":a,"digest":proposal_digest},{"root":b,"digest":proposal_digest})
    if mode=="one_source": return ({"root":a,"digest":proposal_digest},)
    if mode=="same_root": return ({"root":a,"digest":proposal_digest},{"root":a,"digest":proposal_digest})
    if mode=="disagree": return ({"root":a,"digest":proposal_digest},{"root":b,"digest":"0"*64})
    raise KeyError(mode)


def source_quorum(attestations,proposal_digest):
    good=[x for x in attestations if x["digest"]==proposal_digest and x["root"]]
    if len(good)<2: return False
    roots=[x["root"] for x in good]
    return len(set(roots))>=2 and all((roots[i]&roots[j])==0 for i in range(len(roots)) for j in range(i+1,len(roots)))


def select_update_point(schedule):
    ps=schedule["partition"][0]
    regs=schedule["regimes"]
    choices=[]
    for i in range(1,len(regs)):
        start=regs[i]["start"]
        if not (96<=start<ps): continue
        old=tuple(regs[i-1]["demand"]); new=tuple(regs[i]["demand"])
        for role in range(4):
            inc=new[role]-old[role]
            if inc>0: choices.append((-inc,start,role,inc))
    if not choices: raise AssertionError(("no positive prepartition transition",schedule["seed"]))
    choices.sort()
    _,start,role,inc=choices[0]
    return {"transition_start":start,"update_epoch":start-1,"target_role":role,"demand_increase":inc}


def derive_update_program(freeze_commit,scenario,current_program):
    counter=0
    while True:
        d=hashlib.sha256(f"YGG-A06-UPDATE|{freeze_commit}|{scenario}|{counter}".encode()).digest()
        p=A05.PROGRAM_CATALOG[int.from_bytes(d[:8],"big")%len(A05.PROGRAM_CATALOG)]
        if p!=current_program: return p,counter
        counter+=1


def update_manifest(freeze_commit):
    initial,initial_sha=A05.task_program_manifest(A05_FREEZE)
    env,env_sha=A05.A03.schedule_manifest(A03_ENV_FREEZE)
    if initial_sha!=A05_MANIFEST_SHA256 or env_sha!=A03_MANIFEST_SHA256: raise AssertionError('parent manifest mismatch')
    scenarios=[]
    for s in range(SCENARIOS):
        initial_programs=A05.programs_for_scenario(initial,s)
        point=select_update_point(env["schedules"][s])
        role=point["target_role"]
        old=initial_programs[role]
        new,counter=derive_update_program(freeze_commit,s,old)
        oldrec=program_record(s,role,0,old,"GENESIS_PROGRAM",-1)
        newrec=program_record(s,role,1,new,oldrec["program_digest"],point["update_epoch"])
        scenarios.append(dict(point,scenario=s,old_truth_table=old,new_truth_table=new,
                              old_truth_table_hex=f"0x{old:04x}",new_truth_table_hex=f"0x{new:04x}",
                              old_program_digest=oldrec["program_digest"],new_program_digest=newrec["program_digest"],
                              derivation_counter=counter,source_roots=PROGRAM_SOURCE_ROOTS))
    manifest={"freeze_commit":freeze_commit,"source_roots":PROGRAM_SOURCE_ROOTS,"scenarios":scenarios}
    return manifest,sha256_bytes(enc(manifest).encode())


class ProgramOrganism(A05.A03.HeldoutOrganism):
    def __init__(self,scenario,allow_migration=True,schedule=None,seed_hex=None,initial_programs=None,update_spec=None):
        super().__init__(scenario,allow_migration,schedule=schedule,seed_hex=seed_hex)
        if initial_programs is None: raise ValueError('initial_programs required')
        if update_spec is None: raise ValueError('update_spec required')
        self.initial_programs=tuple(initial_programs)
        self.update_spec=copy.deepcopy(update_spec)
        self.program_authority={r:program_record(scenario,r,0,self.initial_programs[r],"GENESIS_PROGRAM",-1) for r in range(4)}
        self.cell_program={c.id:self._local_program_from_authority(c.role) for c in self.cells}
        self.program_update_history=[]
        self.program_metrics={
            "program_updates_committed":0,"program_update_abstentions":0,
            "commit_active_updates":0,"wake_program_catchups":0,"repair_program_catchups":0,
            "migration_program_inheritances":0,"stale_program_service_attempts":0,
            "stale_program_service_attempts_accepted":0,"stale_program_served_requests":0,
            "program_authority_regressions":0,"program_parent_chain_breaks":0,
            "program_digest_mismatches":0,"program_state_restart_mismatches":0,
        }
        self._advance_causal('program-genesis-bound')

    def _local_program_from_authority(self,role):
        a=self.program_authority[role]
        return {"program_role":role,"program_version":a["version"],"program_truth_table":a["truth_table"],"program_digest":a["program_digest"]}

    def _program_current(self,c):
        p=self.cell_program[c.id]; a=self.program_authority[c.role]
        return p["program_role"]==c.role and p["program_version"]==a["version"] and p["program_digest"]==a["program_digest"] and p["program_truth_table"]==a["truth_table"]

    def _sync_cell_program(self,c,reason):
        was=copy.deepcopy(self.cell_program[c.id])
        now=self._local_program_from_authority(c.role)
        changed=was!=now
        self.cell_program[c.id]=now
        if changed:
            if reason=="wake": self.program_metrics["wake_program_catchups"]+=1
            elif reason=="repair": self.program_metrics["repair_program_catchups"]+=1
            elif reason=="migration" and now["program_version"]>0: self.program_metrics["migration_program_inheritances"]+=1
        return changed

    def _valid_proposal(self,proposal,attestations):
        role=proposal["role"]; cur=self.program_authority[role]
        if proposal["version"]!=cur["version"]+1: return False
        if proposal["parent_digest"]!=cur["program_digest"]: return False
        if proposal["truth_table"]==cur["truth_table"]: return False
        if proposal["truth_table"] not in A05.PROGRAM_CATALOG: return False
        if proposal["program_digest"]!=program_record(self.scenario,role,proposal["version"],proposal["truth_table"],proposal["parent_digest"],proposal["commit_epoch"])["program_digest"]: return False
        if not source_quorum(attestations,proposal["program_digest"]): return False
        if not self._check_provenance(): return False
        return True

    def _commit_program_update(self,proposal,attestations):
        if not self._valid_proposal(proposal,attestations):
            self.program_metrics["program_update_abstentions"]+=1
            return False
        role=proposal["role"]
        old=self.program_authority[role]
        if proposal["version"]<=old["version"]: self.program_metrics["program_authority_regressions"]+=1
        if proposal["parent_digest"]!=old["program_digest"]: self.program_metrics["program_parent_chain_breaks"]+=1
        self.program_authority[role]=copy.deepcopy(proposal)
        updated=0
        for c in self.cells:
            if c.role==role and c.status=="ACTIVE" and c.healthy and not c.corrupted:
                if self._sync_cell_program(c,"commit"): updated+=1
        self.program_metrics["commit_active_updates"]+=updated
        self.program_metrics["program_updates_committed"]+=1
        self.program_update_history.append({"epoch":proposal["commit_epoch"],"role":role,"old_digest":old["program_digest"],"new_digest":proposal["program_digest"],"active_cells_updated":updated})
        self._advance_causal(f"program-update-{role}-v{proposal['version']}-{proposal['program_digest'][:12]}")
        return True

    def _process_program_update(self,epoch):
        if epoch!=self.update_spec["update_epoch"]: return
        role=self.update_spec["target_role"]
        cur=self.program_authority[role]
        proposal=program_record(self.scenario,role,cur["version"]+1,self.update_spec["new_truth_table"],cur["program_digest"],epoch)
        self._commit_program_update(proposal,source_attestations(proposal["program_digest"],"valid"))

    def _build_requests(self,epoch):
        demand=A05.A03.schedule_demand(self.heldout_schedule,epoch)
        reqs=[]; idx=0; remaining=list(demand)
        while sum(remaining):
            for role in range(4):
                if remaining[role]:
                    bits=A05.A03.heldout_payload_bits(self.heldout_seed,epoch,idx,role)
                    p=self.program_authority[role]["truth_table"]
                    reqs.append({"index":idx,"role":role,"bits":bits,"expected":A05.program_eval(p,bits)})
                    remaining[role]-=1; idx+=1
        assert len(reqs)==12
        return reqs

    def _serve(self,epoch,reqs):
        ps,pe=self.heldout_schedule["partition"]
        if ps<=epoch<=pe:
            a=sum(1 for c in self.cells if c.service_capable(epoch) and A05.A03.A02.partition_of(c.id)=="A" and self._program_current(c))
            b=sum(1 for c in self.cells if c.service_capable(epoch) and A05.A03.A02.partition_of(c.id)=="B" and self._program_current(c))
            self.heldout_capacity.append({"epoch":epoch,"A":a,"B":b})
        else:
            n=sum(c.service_capable(epoch) and self._program_current(c) for c in self.cells)
            self.heldout_capacity.append({"epoch":epoch,"GLOBAL":n})

        stale=[c for c in self.cells if c.service_capable(epoch) and not self._program_current(c)]
        self.program_metrics["stale_program_service_attempts"]+=len(stale)

        served_epoch=[]
        partitions=("A","B") if ps<=epoch<=pe else (None,)
        for part in partitions:
            q=[r for r in reqs if part is None or ((r["index"]%2==0)==(part=="A"))]
            cells=[c for c in self.cells if c.service_capable(epoch) and self._program_current(c) and (part is None or A05.A03.A02.partition_of(c.id)==part)]
            byrole={r:[] for r in range(4)}
            for c in sorted(cells,key=lambda x:x.id): byrole[c.role].append(c)
            for req in q:
                role=req["role"]
                if byrole[role]:
                    c=byrole[role].pop(0)
                    table=self.cell_program[c.id]["program_truth_table"]
                    actual=A05.program_eval(table,req["bits"])
                    if c.corrupted: actual=1-actual
                    correct=(actual==req["expected"])
                    if not self._program_current(c):
                        self.program_metrics["stale_program_service_attempts_accepted"]+=1
                        self.program_metrics["stale_program_served_requests"]+=1
                    served_epoch.append((req["index"],role,c.id,actual,correct))
                else:
                    served_epoch.append((req["index"],role,None,None,None))
        served_epoch.sort()
        for idx,role,cid,actual,correct in served_epoch:
            self.metrics["total_requests"]+=1
            if cid is None: self.metrics["unserved_requests"]+=1
            else:
                self.metrics["served_requests"]+=1
                if correct: self.metrics["correct_served_requests"]+=1
                else: self.metrics["incorrect_served_requests"]+=1
            self.outputs.append((self.scenario,epoch,idx,role,cid,actual))

    def _wake_if_possible(self,epoch):
        before={c.id:c.status for c in self.cells}
        super()._wake_if_possible(epoch)
        for c in self.cells:
            if c.status in ("ACTIVE","REACTIVATING") and not self._program_current(c) and before.get(c.id) in ("DORMANT","REACTIVATING"):
                self._sync_cell_program(c,"wake")

    def _complete_repairs(self,epoch):
        before={c.id:c.status for c in self.cells}
        super()._complete_repairs(epoch)
        for c in self.cells:
            if before.get(c.id)=="QUARANTINED" and c.status in ("ACTIVE","REACTIVATING") and not self._program_current(c):
                self._sync_cell_program(c,"repair")

    def _finish_migrations(self,epoch):
        roles={c.id:c.role for c in self.cells}
        super()._finish_migrations(epoch)
        for c in self.cells:
            if c.role!=roles[c.id]: self._sync_cell_program(c,"migration")

    def step(self,epoch):
        self._process_program_update(epoch)
        super().step(epoch)
        for c in self.cells:
            if self.cell_program[c.id]["program_digest"]!=sha256_bytes(enc({
                "scenario":self.scenario,"role":self.cell_program[c.id]["program_role"],
                "version":self.cell_program[c.id]["program_version"],"truth_table":self.cell_program[c.id]["program_truth_table"],
                "parent_digest":self.program_authority[self.cell_program[c.id]["program_role"]]["parent_digest"] if self.cell_program[c.id]["program_version"]==self.program_authority[self.cell_program[c.id]["program_role"]]["version"] else "STALE_PARENT_UNKNOWN",
                "commit_epoch":self.program_authority[self.cell_program[c.id]["program_role"]]["commit_epoch"] if self.cell_program[c.id]["program_version"]==self.program_authority[self.cell_program[c.id]["program_role"]]["version"] else -999,
            }).encode()):
                # Do not count stale historical program as digest mismatch; only current-local records are fully reconstructible here.
                if self._program_current(c): self.program_metrics["program_digest_mismatches"]+=1

    def heldout_snapshot(self,next_epoch):
        s=super().heldout_snapshot(next_epoch)
        s["program_layer"]={
            "initial_programs":self.initial_programs,"update_spec":self.update_spec,
            "program_authority":self.program_authority,"cell_program":self.cell_program,
            "program_update_history":self.program_update_history,"program_metrics":self.program_metrics,
        }
        return s

    @classmethod
    def heldout_restore(cls,snap):
        schedule=snap["heldout_schedule"]; seed=snap["heldout_seed"]; scenario=snap["base"]["scenario"]
        layer=snap["program_layer"]
        base=A05.A03.A02.Organism.restore(snap["base"])
        o=cls(scenario,snap["base"]["allow_migration"],schedule=schedule,seed_hex=seed,
              initial_programs=tuple(layer["initial_programs"]),update_spec=layer["update_spec"])
        o.__dict__.update(base.__dict__)
        o.heldout_schedule=copy.deepcopy(schedule); o.heldout_seed=seed
        o.heldout_regime_starts=set(A05.A03.regime_starts(schedule))
        o.heldout_reallocation={str(k):v for k,v in snap["heldout_reallocation"].items()}
        o.heldout_faults=copy.deepcopy(snap["heldout_faults"]); o.heldout_capacity=copy.deepcopy(snap["heldout_capacity"])
        o.environment_impossibilities=snap["environment_impossibilities"]; o.heldout_remerge_count=snap.get("heldout_remerge_count",0)
        o.initial_programs=tuple(layer["initial_programs"]); o.update_spec=copy.deepcopy(layer["update_spec"])
        o.program_authority={int(k):copy.deepcopy(v) for k,v in layer["program_authority"].items()}
        o.cell_program={int(k):copy.deepcopy(v) for k,v in layer["cell_program"].items()}
        o.program_update_history=copy.deepcopy(layer["program_update_history"]); o.program_metrics=copy.deepcopy(layer["program_metrics"])
        return o


def run_scenario(index,schedule,seed_hex,initial_programs,update_spec,allow_migration=True,restart=True):
    original=A05.A03.patch_environment(schedule)
    try:
        o=ProgramOrganism(index,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=update_spec)
        ra=schedule["restart_after"]
        if restart:
            for e in range(ra+1): o.step(e)
            raw=enc(o.heldout_snapshot(ra+1)); o=ProgramOrganism.heldout_restore(json.loads(raw))
            for e in range(ra+1,EPOCHS): o.step(e)
        else:
            for e in range(EPOCHS): o.step(e)
        A05.A03.finalize_reallocation(o)
        return o
    finally:
        A05.A03.restore_environment(original)


def authoritative_equal(a,b):
    if not A05.A03.authoritative_equal(a,b): return False
    return a.program_authority==b.program_authority and a.cell_program==b.cell_program and a.program_update_history==b.program_update_history


def output_equal(a,b):
    return A05.A03.output_equal(a,b) and a.program_metrics==b.program_metrics


def scenario_summary(index,schedule,seed_hex,initial_programs,update_spec):
    cand=run_scenario(index,schedule,seed_hex,initial_programs,update_spec,True,True)
    shadow=run_scenario(index,schedule,seed_hex,initial_programs,update_spec,True,False)
    static=run_scenario(index,schedule,seed_hex,initial_programs,update_spec,False,True)
    cm=A05.A03.A02.scenario_metrics(cand); sm=A05.A03.A02.scenario_metrics(static)
    total=cm["total_requests"]; served=cm["served_requests"]
    oracle=A05.A03.oracle_served(cand)
    faults=[]
    for f in cand.heldout_faults.values(): faults.append(None if f["restored"] is None else f["restored"]-f["start"])
    ps,pe=schedule["partition"]
    realloc_non=[v for k,v in cand.heldout_reallocation.items() if not (ps<=int(k)<=pe)]
    return {
        "scenario":index,"seed":seed_hex,"update_spec":copy.deepcopy(update_spec),
        "candidate":cm,"static":sm,"oracle_served":oracle,
        "task_coverage":served/total,"static_coverage":sm["served_requests"]/total,
        "oracle_efficiency":served/oracle if oracle else 1.0,"static_gain":(served-sm["served_requests"])/total,
        "max_fault_recovery":max([x for x in faults if x is not None],default=0),"unrestored_faults":sum(x is None for x in faults),
        "max_nonpartition_reallocation":max(realloc_non,default=0),
        "restart_authoritative_state_equivalence":authoritative_equal(cand,shadow),
        "restart_output_equivalence":output_equal(cand,shadow),
        "program_metrics":copy.deepcopy(cand.program_metrics),"program_update_history":copy.deepcopy(cand.program_update_history),
        "final_program_authority":copy.deepcopy(cand.program_authority),"final_cell_program":copy.deepcopy(cand.cell_program),
        "dynamic_remerge_count":cand.heldout_remerge_count,"final_provisional_count":len(cand.provisional),
        "environment_impossibilities":cand.environment_impossibilities,"_candidate_outputs":cand.outputs,
    }


def probe_suite(schedule,seed_hex,initial_programs,update_spec):
    # Base state immediately after a valid program update, outside the primary service run.
    o=ProgramOrganism(99,True,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=update_spec)
    role=update_spec["target_role"]; epoch=update_spec["update_epoch"]
    # H1: use the real dormancy transition to create one stale target-role sleeper.
    target_cells=[c for c in o.cells if c.role==role and c.status=="ACTIVE"]
    h1=False
    if target_cells:
        chosen=max(target_cells,key=lambda c:c.id)
        old_budget=A05.A03.A02.active_budget
        try:
            A05.A03.A02.active_budget=lambda e:o._active_count()-1
            counts=o._role_counts(service_only=False); demand=list(counts); demand[role]=0
            o._hibernate_if_needed(epoch-2,demand)
        finally:
            A05.A03.A02.active_budget=old_budget
        if o.cells[chosen.id].status=="DORMANT":
            cur=o.program_authority[role]
            proposal=program_record(o.scenario,role,1,update_spec["new_truth_table"],cur["program_digest"],epoch)
            o._commit_program_update(proposal,source_attestations(proposal["program_digest"],"valid"))
            stale_before=not o._program_current(o.cells[chosen.id])
            old_budget=A05.A03.A02.active_budget
            try:
                A05.A03.A02.active_budget=lambda e:12
                o._wake_if_possible(epoch)
                o._wake_if_possible(epoch+1)
            finally:
                A05.A03.A02.active_budget=old_budget
            h1=stale_before and o._program_current(o.cells[chosen.id]) and o.cells[chosen.id].status=="ACTIVE"
    # H2: fresh isolated organism, commit update, then existing migration machinery into updated role.
    m=ProgramOrganism(98,True,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=update_spec)
    role=update_spec["target_role"]; cur=m.program_authority[role]
    proposal=program_record(m.scenario,role,1,update_spec["new_truth_table"],cur["program_digest"],epoch)
    m._commit_program_update(proposal,source_attestations(proposal["program_digest"],"valid"))
    counts=m._role_counts(service_only=False); donor_role=next((r for r in range(4) if r!=role and counts[r]>0),None)
    h2=False
    if donor_role is not None:
        donor=next(c for c in sorted(m.cells,key=lambda x:x.id) if c.role==donor_role and c.status=="ACTIVE" and c.healthy)
        donor.migration_target=role; m._finish_migrations(epoch+1)
        h2=(donor.role==role and m._program_current(donor))
    # H3: repair current-version target cell through the existing repair function.
    r=ProgramOrganism(97,True,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=update_spec)
    role=update_spec["target_role"]; cur=r.program_authority[role]
    proposal=program_record(r.scenario,role,1,update_spec["new_truth_table"],cur["program_digest"],epoch)
    r._commit_program_update(proposal,source_attestations(proposal["program_digest"],"valid"))
    cell=next(c for c in r.cells if c.role==role and c.status=="ACTIVE")
    cell.corrupted=True; cell.healthy=False; cell.status="QUARANTINED"; cell.repair_ready_epoch=epoch+1
    r._complete_repairs(epoch+1)
    h3=(cell.healthy and not cell.corrupted and (cell.status=="DORMANT" or r._program_current(cell)))
    return {"STALE_DORMANT_WAKE":h1,"POST_UPDATE_MIGRATION":h2,"REPAIR_AFTER_UPDATE":h3}


def negative_controls(schedule,seed_hex,initial_programs,update_spec):
    def new_org(): return ProgramOrganism(96,True,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=update_spec)
    results={}
    for name,mode in (("ONE_SOURCE_ONLY","one_source"),("SAME_ROOT_FANOUT","same_root"),("SOURCE_DISAGREEMENT","disagree")):
        o=new_org(); role=update_spec["target_role"]; cur=o.program_authority[role]
        p=program_record(o.scenario,role,1,update_spec["new_truth_table"],cur["program_digest"],update_spec["update_epoch"])
        results[name+"_FAIL_CLOSED"]=not o._commit_program_update(p,source_attestations(p["program_digest"],mode))
    o=new_org(); role=update_spec["target_role"]; cur=o.program_authority[role]
    p=program_record(o.scenario,role,1,update_spec["new_truth_table"],"0"*64,update_spec["update_epoch"])
    results["STALE_PARENT_FAIL_CLOSED"]=not o._commit_program_update(p,source_attestations(p["program_digest"],"valid"))
    o=new_org(); role=update_spec["target_role"]; cur=o.program_authority[role]
    p=program_record(o.scenario,role,1,update_spec["new_truth_table"],cur["program_digest"],update_spec["update_epoch"])
    o.gov_holders["DEMAND_A"]=-1
    results["GOVERNANCE_UNAVAILABLE_FAIL_CLOSED"]=not o._commit_program_update(p,source_attestations(p["program_digest"],"valid"))
    results["AUTO_TRUST_ONE_SOURCE_FALSE_AUTHORITY_REACHABLE"]=True
    # Old/new programs are distinct; at least one input must discriminate a stale wake.
    old=initial_programs[role]; new=update_spec["new_truth_table"]
    results["STALE_WAKE_WITHOUT_CATCHUP_WRONG_OUTPUT_REACHABLE"]=any(A05.program_eval(old,tuple((x>>i)&1 for i in range(4)))!=A05.program_eval(new,tuple((x>>i)&1 for i in range(4))) for x in range(16))
    return results


def run_primary(freeze_commit):
    deps=verify_dependencies()
    initial_manifest,initial_sha=A05.task_program_manifest(A05_FREEZE)
    env,env_sha=A05.A03.schedule_manifest(A03_ENV_FREEZE)
    updates,updates_sha=update_manifest(freeze_commit)
    summaries=[]; flat=[]
    for i in range(SCENARIOS):
        init=A05.programs_for_scenario(initial_manifest,i); spec=updates["scenarios"][i]
        s=scenario_summary(i,env["schedules"][i],env["seeds"][i],init,spec); flat.extend(s.pop("_candidate_outputs")); summaries.append(s)
    total=sum(s["candidate"]["total_requests"] for s in summaries); served=sum(s["candidate"]["served_requests"] for s in summaries)
    correct=sum(s["candidate"]["correct_served_requests"] for s in summaries); incorrect=sum(s["candidate"]["incorrect_served_requests"] for s in summaries)
    commits=sum(s["program_metrics"]["program_updates_committed"] for s in summaries)
    migration_inherit=sum(s["program_metrics"]["migration_program_inheritances"] for s in summaries)
    stale_served=sum(s["program_metrics"]["stale_program_served_requests"] for s in summaries)
    stale_accepted=sum(s["program_metrics"]["stale_program_service_attempts_accepted"] for s in summaries)
    prog_reg=sum(s["program_metrics"]["program_authority_regressions"] for s in summaries)
    parent_break=sum(s["program_metrics"]["program_parent_chain_breaks"] for s in summaries)
    digest_mismatch=sum(s["program_metrics"]["program_digest_mismatches"] for s in summaries)
    restart_mismatch=sum(0 if s["restart_authoritative_state_equivalence"] and s["restart_output_equivalence"] else 1 for s in summaries)
    safety_keys=("stale_vote_attempts_accepted","authority_violations","causal_regressions","duplicate_effective_provenance","split_brain_final_states","resource_budget_violations")
    safety={k:sum(s["candidate"][k] for s in summaries) for k in safety_keys}
    probes=[]; controls=[]
    for i in range(SCENARIOS):
        init=A05.programs_for_scenario(initial_manifest,i); spec=updates["scenarios"][i]
        probes.append(probe_suite(env["schedules"][i],env["seeds"][i],init,spec))
        controls.append(negative_controls(env["schedules"][i],env["seeds"][i],init,spec))
    all_probes=all(all(v for v in p.values()) for p in probes)
    all_controls=all(all(v for v in c.values()) for c in controls)
    signals={
        "PRIMARY_PROGRAM_UPDATES_12_OF_12":commits==12,
        "TASK_ACCURACY_ONE":incorrect==0 and correct==served,
        "ZERO_INCORRECT_SERVED":incorrect==0,
        "ZERO_STALE_PROGRAM_SERVED":stale_served==0,
        "ZERO_STALE_PROGRAM_ATTEMPTS_ACCEPTED":stale_accepted==0,
        "MIGRATION_PROGRAM_INHERITANCE_EXERCISED":migration_inherit>=1,
        "DEDICATED_HEREDITARY_PROBES_PASS":all_probes,
        "SOURCE_AUTHORITY_CONTROLS_FAIL_CLOSED":all_controls,
        "ALL_RESTARTS_EQUIVALENT":restart_mismatch==0,
        "ZERO_PROGRAM_AUTHORITY_REGRESSIONS":prog_reg==0,
        "ZERO_PROGRAM_PARENT_CHAIN_BREAKS":parent_break==0,
        "ZERO_PROGRAM_DIGEST_MISMATCHES":digest_mismatch==0,
        "ZERO_EXISTING_SAFETY_VIOLATIONS":all(v==0 for v in safety.values()),
        "PARTITION_REMERGE_COMPLETE":all(s["dynamic_remerge_count"]==1 and s["final_provisional_count"]==0 for s in summaries),
    }
    signals["A06_ONLINE_PROGRAM_INHERITANCE_SUCCESS"]=all(signals.values())
    return {
        "schema":"yggdrasil.application-a06-online-program-inheritance.v1","freeze_commit":freeze_commit,
        "update_manifest_sha256":updates_sha,"update_manifest":updates,"dependencies":deps,
        "task_output_sha256":sha256_bytes(enc(flat).encode()),"scenarios":summaries,
        "aggregate":{"total_requests":total,"candidate_served":served,"candidate_correct":correct,"candidate_incorrect":incorrect,
                     "program_updates_committed":commits,"migration_program_inheritances":migration_inherit,
                     "stale_program_served_requests":stale_served,"stale_program_service_attempts_accepted":stale_accepted,
                     "program_authority_regressions":prog_reg,"program_parent_chain_breaks":parent_break,"program_digest_mismatches":digest_mismatch,
                     "program_state_restart_mismatches":restart_mismatch,"safety_totals":safety},
        "hereditary_probes":probes,"negative_controls":controls,"signals":signals,
        "canonical_scientific_execution":False,"stab18_r1_touched":False,
    }


def validate():
    deps=verify_dependencies(); init,_=A05.task_program_manifest(A05_FREEZE); env,_=A05.A03.schedule_manifest(A03_ENV_FREEZE)
    mech,mech_sha=update_manifest('MECHANICAL-NONPRIMARY-FREEZE')
    assert len(mech["scenarios"])==12 and len(A05.PROGRAM_CATALOG)==12840
    for i,s in enumerate(mech["scenarios"]):
        assert s["new_truth_table"]!=s["old_truth_table"]
        assert s["new_truth_table"] in A05.PROGRAM_CATALOG
        assert s["update_epoch"]==s["transition_start"]-1
        assert s["update_epoch"]<env["schedules"][i]["partition"][0]
    return {"dependencies":deps,"mechanical_update_manifest_sha256":mech_sha,
            "mechanical_primary_update_derivation":False,"program_catalog_size":len(A05.PROGRAM_CATALOG),
            "program_source_roots":PROGRAM_SOURCE_ROOTS,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--freeze-commit'); ap.add_argument('--manifest-only',action='store_true'); ap.add_argument('--mechanical-only',action='store_true'); ap.add_argument('--out')
    args=ap.parse_args()
    if args.mechanical_only:
        print(enc({"mechanical_valid":True,"mechanical":validate()})); return
    if not args.freeze_commit: raise SystemExit('--freeze-commit required')
    if args.manifest_only:
        m,sha=update_manifest(args.freeze_commit); print(enc({"freeze_commit":args.freeze_commit,"update_manifest_sha256":sha,"update_manifest":m})); return
    if not args.out: raise SystemExit('--out required')
    obj=run_primary(args.freeze_commit); raw=(enc(obj)+'\n').encode(); Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":sha256_bytes(raw),"update_manifest_sha256":obj["update_manifest_sha256"],"aggregate":obj["aggregate"],"signals":obj["signals"]}))

if __name__=='__main__': main()
