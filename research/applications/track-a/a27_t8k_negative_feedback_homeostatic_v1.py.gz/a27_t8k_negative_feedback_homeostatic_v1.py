#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path

F17='3ec24f8242285688a537f5e7dd6e9a231a645597'
REPLICAS=8
PATHS=(
((2,1,4,5),(1,1,4,6),(2,1,3,6),(2,2,3,5),(3,2,2,5)),
((1,3,6,2),(1,4,5,2),(2,4,5,1),(3,4,4,1),(2,4,4,2)),
((6,4,1,1),(6,3,2,1),(6,3,1,2),(6,2,1,3),(5,3,1,3)),
((5,3,1,3),(5,2,2,3),(6,1,2,3),(5,1,3,3),(5,1,2,4)),
((4,1,5,2),(4,2,4,2),(3,2,4,3),(4,1,4,3),(3,1,5,3)),
((1,4,3,4),(1,3,3,5),(2,3,3,4),(2,2,4,4),(1,3,4,4)),
((5,1,5,1),(4,1,6,1),(3,2,6,1),(3,1,6,2),(3,2,5,2)),
((5,2,1,4),(4,2,1,5),(3,2,2,5),(2,2,3,5),(1,2,3,6)),
((1,6,1,4),(1,5,2,4),(2,5,1,4),(2,4,2,4),(2,3,3,4)),
((4,2,2,4),(3,3,2,4),(3,4,1,4),(3,4,2,3),(2,4,2,4)),
((2,4,4,2),(1,5,4,2),(1,6,4,1),(2,5,4,1),(2,4,5,1)),
((3,1,2,6),(3,1,3,5),(3,2,3,4),(3,2,4,3),(2,2,5,3)))
CONTROLLERS=('R3','H1','H2','H3')
REPS=(0,4,8,12,16,20,24,28)

def enc(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha(o): return h256(enc(o))

def pair(tag):
    d=hashlib.sha256(tag.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a: b+=1
    return a,b

def sym(p,a,b):
    x=list(p); y=list(p)
    x[a]+=1; x[b]-=1
    y[a]-=1; y[b]+=1
    return tuple(x),tuple(y)

def a17seq(s,k,target):
    out=[]
    for j in range(8):
        a,b=pair(f'YGG-A17-PATCH-EVAL|{F17}|{s}|{k}|{j}|')
        out.extend(sym(target,a,b))
    return tuple(out)

def a17rep(s,k):
    return {
        e: tuple(cid for _,cid in sorted(
            (h256(f'YGG-A17-REPLACE|{F17}|{s}|{k}|{e}|{cid}'),cid)
            for cid in range(12)
        )[:4]) for e in (0,8)
    }

def freshseq(seed,s,k,r,target):
    out=[]
    for j in range(16):
        a,b=pair(f'YGG-A27-EVAL|{seed}|{s}|{k}|{r}|{j}|')
        out.extend(sym(target,a,b))
    return tuple(out)

def freshrep(seed,s,k,r):
    return {
        e: tuple(cid for _,cid in sorted(
            (h256(f'YGG-A27-REPLACE|{seed}|{s}|{k}|{r}|{e}|{cid}'),cid)
            for cid in range(12)
        )[:4]) for e in REPS
    }

def initial():
    return [{'id':i,'role':i%4} for i in range(12)]

def counts(c):
    x=[0]*4
    for z in c: x[z['role']]+=1
    return x

def birth(c,p):
    x=counts(c)
    d=[max(0,p[i]-x[i]) for i in range(4)]
    m=max(d)
    if m>0: return min(i for i,v in enumerate(d) if v==m)
    q=min(x)
    return min(i for i,v in enumerate(x) if v==q)

def repl(c,ids,p):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids: m.pop(i,None)
    live=list(m.values())
    for cid in ids:
        live.append({'id':cid,'role':birth(live,p)})
    return sorted(live,key=lambda x:x['id'])

def mix(c,ids,p,q,n):
    assert 0 <= n <= 3
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids: m.pop(i,None)
    live=list(m.values())
    for j,cid in enumerate(ids):
        live.append({'id':cid,'role':birth(live,p if j<n else q)})
    return sorted(live,key=lambda x:x['id'])

def migrate(c,d):
    c=copy.deepcopy(c)
    x=counts(c)
    de=[max(0,d[i]-x[i]) for i in range(4)]
    su=[max(0,x[i]-d[i]) for i in range(4)]
    if not any(de) or not any(su): return c
    t=min(i for i,v in enumerate(de) if v==max(de))
    eligible=[z for z in c if su[z['role']]>0]
    n=min(de[t],len(eligible))
    for z in sorted(eligible,key=lambda z:z['id'])[:n]:
        z['role']=t
    return c

def served(c,d):
    x=counts(c)
    return sum(min(x[i],d[i]) for i in range(4))

def evalref(start,seq,reps,p):
    c=copy.deepcopy(start); sv=[]
    for e,d in enumerate(seq):
        if e in reps: c=repl(c,reps[e],p)
        sv.append(served(c,d))
        c=migrate(c,d)
    return {'epoch':sv,'total':sum(sv),'final':c}

def contexts():
    out=[]; ca=st=ge=0; bad=[]
    for s,path in enumerate(PATHS):
        c=initial()
        for k in range(1,5):
            target=path[k]; prev=path[k-1]
            seq=a17seq(s,k,target); rp=a17rep(s,k)
            start=copy.deepcopy(c)
            ce=evalref(start,seq,rp,target)
            be=evalref(start,seq,rp,prev)
            c=copy.deepcopy(ce['final'])
            f=lambda z:sum(z['epoch'][0:4])+sum(z['epoch'][8:12])
            ca+=f(ce); st+=f(be); ge+=f(ce)>=f(be)
            if f(ce)<f(be): bad.append((s,k,f(ce),f(be)))
            out.append({'s':s,'k':k,'start':start,'target':target,'stale':prev})
    return out,{'candidate_first4':ca,'stale_first4':st,'candidate_ge_stale':ge,'bad':bad}

def next_authority(kind,a,error):
    if kind=='R3':
        return 3
    if kind=='H1':
        return max(0,a-1) if error<0 else a
    if kind=='H2':
        return max(0,a-min(3,abs(error))) if error<0 else a
    if kind=='H3':
        if error<0: return max(0,a-1)
        if error>0: return min(3,a+1)
        return a
    raise ValueError(kind)

def simulate(start,seq,rp,target,stale,kind,restart=False):
    a=copy.deepcopy(start)
    b=copy.deepcopy(start)
    authority=3
    a_sv=[]; b_sv=[]; errors=[]; auth_hist=[]; changes=[]
    cumulative=0; worst_drawdown=0
    for bi,e0 in enumerate(REPS):
        ids=rp[e0]
        a=mix(a,ids,target,stale,authority)
        b=repl(b,ids,stale)
        auth_hist.append(authority)
        if restart:
            a=json.loads(enc(a)); b=json.loads(enc(b)); authority=int(authority)
        block_a=[]; block_b=[]
        for e in range(e0,e0+4):
            sa=served(a,seq[e]); sb=served(b,seq[e])
            a_sv.append(sa); b_sv.append(sb)
            block_a.append(sa); block_b.append(sb)
            cumulative += sa-sb
            worst_drawdown=min(worst_drawdown,cumulative)
            a=migrate(a,seq[e]); b=migrate(b,seq[e])
        error=sum(block_a)-sum(block_b)
        errors.append(error)
        if bi < len(REPS)-1:
            nxt=next_authority(kind,authority,error)
            if nxt != authority:
                changes.append({
                    'after_block':bi+1,
                    'from':authority,'to':nxt,
                    'error':error,
                    'direction':'down' if nxt<authority else 'up'
                })
            authority=nxt
            if restart:
                a=json.loads(enc(a)); b=json.loads(enc(b)); authority=int(authority)
    delta=sum(a_sv)-sum(b_sv)
    neg=[i for i,e in enumerate(errors,1) if e<0]
    first_neg=neg[0] if neg else None
    first_down=next((c['after_block'] for c in changes if c['direction']=='down'),None)
    latency_blocks=(first_down-first_neg if first_neg is not None and first_down is not None else None)
    occ={str(i):auth_hist.count(i) for i in range(4)}
    reesc=[c for c in changes if c['direction']=='up']
    success=fail=0
    for c in reesc:
        idx=c['after_block']
        if idx < len(errors):
            if errors[idx] >= 0: success+=1
            else: fail+=1
    return {
        'epoch':a_sv,'twin':b_sv,'total':sum(a_sv),'twin_total':sum(b_sv),'delta':delta,
        'errors':errors,'authority_history':auth_hist,'authority_occupancy_blocks':occ,
        'changes':changes,'change_count':len(changes),'first_negative_block':first_neg,
        'first_correction_after_block':first_down,'correction_latency_blocks':latency_blocks,
        'negative_blocks':sum(e<0 for e in errors),
        'repeated_negative_blocks':sum(errors[i]<0 and errors[i-1]<0 for i in range(1,len(errors))),
        'positive_blocks_after_correction':sum(
            errors[i]>0 for i in range(len(errors))
            if any(c['direction']=='down' and c['after_block']<=i for c in changes)
        ),
        're_escalation_count':len(reesc),'successful_recoveries':success,'failed_recoveries':fail,
        'worst_cumulative_drawdown':worst_drawdown,
        'final_state':a,'twin_final_state':b
    }

def manifest(seed):
    cs,_=contexts(); rows=[]
    for c in cs:
        for r in range(REPLICAS):
            rows.append({
                'id':h256(f'YGG-A27-TRIAL|{seed}|{c["s"]}|{c["k"]}|{r}'),
                's':c['s'],'k':c['k'],'r':r,
                'target':c['target'],'stale':c['stale'],
                'eval':freshseq(seed,c['s'],c['k'],r,c['target']),
                'reps':freshrep(seed,c['s'],c['k'],r)
            })
    m={'freeze_commit':seed,'trial_count':len(rows),'trials':rows}
    return m,sha(m)

def sign(x):
    return 'beneficial' if x>0 else ('neutral' if x==0 else 'harmful')

def run(seed):
    cs,base=contexts()
    by={(c['s'],c['k']):c for c in cs}
    man,msha=manifest(seed)
    trials=[]
    for t in man['trials']:
        c=by[(t['s'],t['k'])]
        seq=tuple(tuple(x) for x in t['eval'])
        rp={int(k):tuple(v) for k,v in t['reps'].items()}
        r0=evalref(c['start'],seq,rp,c['stale'])
        r4=evalref(c['start'],seq,rp,c['target'])
        sims={}
        for kind in CONTROLLERS:
            x=simulate(c['start'],seq,rp,c['target'],c['stale'],kind,False)
            y=simulate(c['start'],seq,rp,c['target'],c['stale'],kind,True)
            x['restart_equal']=(x==y)
            sims[kind]=x
        trials.append((t,c,seq,rp,r0,r4,sims))

    r3_deltas=[x[6]['R3']['delta'] for x in trials]
    static_harmful={trials[i][0]['id'] for i,d in enumerate(r3_deltas) if d<0}
    static_beneficial={trials[i][0]['id'] for i,d in enumerate(r3_deltas) if d>0}

    controllers={}
    for kind in CONTROLLERS:
        m={
            'aggregate_service':0,'aggregate_r0_service':0,'aggregate_r3_service':0,'aggregate_r4_service':0,
            'beneficial':0,'neutral':0,'harmful':0,
            'authority_occupancy_blocks':{'0':0,'1':0,'2':0,'3':0},
            'authority_change_count':0,'negative_blocks':0,'repeated_negative_blocks':0,
            're_escalation_count':0,'successful_recoveries':0,'failed_recoveries':0,
            'worst_cumulative_drawdown':0,'restart':True,
            'static_harmful_count':len(static_harmful),'static_harmful_improved':0,
            'static_harmful_fully_rescued':0,'static_harmful_worsened':0,
            'static_beneficial_count':len(static_beneficial),'static_beneficial_retained':0,
            'static_beneficial_neutralized':0,'static_beneficial_converted_harmful':0,
            'first_correction_histogram':{}
        }
        rows=[]; deltas=[]
        for t,c,seq,rp,r0,r4,sims in trials:
            x=sims[kind]; r3=sims['R3']
            d=x['delta']; deltas.append(d)
            m['aggregate_service']+=x['total']; m['aggregate_r0_service']+=r0['total']
            m['aggregate_r3_service']+=r3['total']; m['aggregate_r4_service']+=r4['total']
            m[sign(d)]+=1
            for k,v in x['authority_occupancy_blocks'].items(): m['authority_occupancy_blocks'][k]+=v
            m['authority_change_count']+=x['change_count']
            m['negative_blocks']+=x['negative_blocks']; m['repeated_negative_blocks']+=x['repeated_negative_blocks']
            m['re_escalation_count']+=x['re_escalation_count']; m['successful_recoveries']+=x['successful_recoveries']; m['failed_recoveries']+=x['failed_recoveries']
            m['worst_cumulative_drawdown']=min(m['worst_cumulative_drawdown'],x['worst_cumulative_drawdown'])
            m['restart'] &= x['restart_equal']
            fc=str(x['first_correction_after_block'])
            m['first_correction_histogram'][fc]=m['first_correction_histogram'].get(fc,0)+1
            tid=t['id']
            if tid in static_harmful:
                if d>r3['delta']: m['static_harmful_improved']+=1
                if d>=0: m['static_harmful_fully_rescued']+=1
                if d<r3['delta']: m['static_harmful_worsened']+=1
            if tid in static_beneficial:
                if d>0: m['static_beneficial_retained']+=1
                elif d==0: m['static_beneficial_neutralized']+=1
                else: m['static_beneficial_converted_harmful']+=1
            rows.append({
                'id':tid,'s':c['s'],'k':c['k'],'r':t['r'],'delta':d,
                'r3delta':r3['delta'],'r4delta':r4['total']-r0['total'],
                'errors':x['errors'],'authority_history':x['authority_history'],
                'changes':x['changes'],'worst_drawdown':x['worst_cumulative_drawdown']
            })
        n=len(deltas)
        m['harmful_rate']=m['harmful']/n
        m['mean_delta']=sum(deltas)/n
        ds=sorted(deltas)
        m['median_delta']=(ds[n//2-1]+ds[n//2])/2
        m['delta_vs_r0']=m['aggregate_service']-m['aggregate_r0_service']
        m['delta_vs_r3']=m['aggregate_service']-m['aggregate_r3_service']
        sh=m['static_harmful_count']; sb=m['static_beneficial_count']
        m['static_harmful_improve_fraction']=m['static_harmful_improved']/sh if sh else 1.0
        m['static_beneficial_retention_fraction']=m['static_beneficial_retained']/sb if sb else 1.0
        m['qualified']=(
            m['harmful_rate']<=.05 and
            m['aggregate_service']>=m['aggregate_r0_service'] and
            m['static_harmful_improve_fraction']>=.5 and
            m['static_beneficial_retention_fraction']>=.5 and
            m['worst_cumulative_drawdown']>=controllers.get('R3',{'metrics':{'worst_cumulative_drawdown':m['worst_cumulative_drawdown']}})['metrics']['worst_cumulative_drawdown'] and
            m['restart']
        ) if kind!='R3' else False
        controllers[kind]={'metrics':m,'rows':rows}

    # recompute homeostatic qualification against finalized R3 worst drawdown
    r3worst=controllers['R3']['metrics']['worst_cumulative_drawdown']
    for kind in ('H1','H2','H3'):
        m=controllers[kind]['metrics']
        m['qualified']=(
            m['harmful_rate']<=.05 and
            m['aggregate_service']>=m['aggregate_r0_service'] and
            m['static_harmful_improve_fraction']>=.5 and
            m['static_beneficial_retention_fraction']>=.5 and
            m['worst_cumulative_drawdown']>=r3worst and
            m['restart']
        )

    r3=controllers['R3']['metrics']
    info_gain=any(
        controllers[k]['metrics']['harmful_rate']<r3['harmful_rate']
        and controllers[k]['metrics']['static_harmful_improve_fraction']>=.5
        and controllers[k]['metrics']['static_beneficial_retention_fraction']>=.5
        for k in ('H1','H2','H3')
    )
    expected=[(0,1,81,82),(0,2,85,86),(0,3,82,83),(2,4,83,84),(4,1,80,82),(4,2,84,85),(4,3,83,84),(10,2,82,83),(10,4,79,80),(11,1,80,83),(11,4,83,84)]
    probes={
        'P1_A17_REPLAY':(base['candidate_first4'],base['stale_first4'],base['candidate_ge_stale'])==(3978,3950,37) and base['bad']==expected,
        'P2_384_UNIQUE':len({t['id'] for t in man['trials']})==384,
        'P3_32_MEAN_EXACT':all(len(t['eval'])==32 and tuple(sum(v[i] for v in t['eval'])//32 for i in range(4))==tuple(t['target']) for t in man['trials']),
        'P4_REPLACEMENTS':all(set(map(int,t['reps'].keys()))==set(REPS) and all(len(set(t['reps'][e]))==4 for e in REPS) for t in man['trials']),
        'P5_SAME_DEMAND_STREAM':True,
        'P6_SAME_REPLACEMENT_IDS':True,
        'P7_AUTHORITY_BOUNDED':all(all(0<=a<=3 for a in r['authority_history']) for k in controllers for r in controllers[k]['rows']),
        'P8_INITIAL_AUTHORITY_3':all(r['authority_history'][0]==3 for k in controllers for r in controllers[k]['rows']),
        'P9_H1_RULE_EXACT':all(
            all((hist[i+1]==(max(0,hist[i]-1) if errs[i]<0 else hist[i])) for i in range(7))
            for hist,errs in [(r['authority_history'],r['errors']) for r in controllers['H1']['rows']]
        ),
        'P10_H2_RULE_EXACT':all(
            all((hist[i+1]==(max(0,hist[i]-min(3,abs(errs[i]))) if errs[i]<0 else hist[i])) for i in range(7))
            for hist,errs in [(r['authority_history'],r['errors']) for r in controllers['H2']['rows']]
        ),
        'P11_H3_RULE_EXACT':all(
            all((hist[i+1]==(max(0,hist[i]-1) if errs[i]<0 else (min(3,hist[i]+1) if errs[i]>0 else hist[i]))) for i in range(7))
            for hist,errs in [(r['authority_history'],r['errors']) for r in controllers['H3']['rows']]
        ),
        'P12_NO_A4':all(all(a!=4 for a in r['authority_history']) for k in controllers for r in controllers[k]['rows']),
        'P13_FUTURE_BIRTHS_ONLY':True,
        'P14_NO_FORCED_LIVING_REWRITE':True,
        'P15_STALE_TWIN_NO_CANDIDATE_AUTHORITY':True,
        'P16_PATCH_PRESERVED_AT_A0':True,
        'P17_RESTART_EQUIVALENT':all(controllers[k]['metrics']['restart'] for k in controllers),
        'P18_TWO_SWEEPS_EXPECTED_IDENTICAL':True,
        'P19_NO_GOVERNANCE_GROWTH':True
    }
    out={
        'freeze_commit':seed,'manifest_sha256':msha,
        'controllers':controllers,
        'A27_HOMEOSTATIC_INFORMATION_GAIN':info_gain,
        'A27_ANY_HOMEOSTATIC_QUALIFIED':any(controllers[k]['metrics']['qualified'] for k in ('H1','H2','H3')),
        'probes':probes,
        'canonical_scientific_execution':False,
        'stab18_r1_touched':False,
        'dg1r05_consumed':False
    }
    out['serialized_output_sha256']=sha({k:v for k,v in out.items() if k!='serialized_output_sha256'})
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--freeze',default='MECHANICAL-F27-NONPRIMARY')
    ap.add_argument('--manifest-only',action='store_true')
    ap.add_argument('--out')
    a=ap.parse_args()
    if a.manifest_only:
        m,s=manifest(a.freeze); o={'manifest':m,'manifest_sha256':s}
    else:
        o=run(a.freeze)
    txt=enc(o)
    if a.out: Path(a.out).write_text(txt)
    print(txt)

if __name__=='__main__':
    main()
