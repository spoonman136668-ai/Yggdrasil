#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path
import a16_f16_exact as A16

F16='90279bc5b90682e2538721ef152aa3accdedbddf'
A16_SOURCE_SHA256='cd89dbc46174c97e0bea0bc0a1db4b65eea9b5732521ca30f00ed30f06b792fa'
A16_MANIFEST_SHA256='5feef8c8bde1e8a6380d68fb7ab55f57ab7f29c93879b766fc4f48b30041313e'
A16_HISTORICAL_RESULT='c4ecb7c90742fd737d370e2f378f398ccddd948bf5154c46d917fd3250fb339f'

def enc(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str):x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o):return h256(enc(o))

def verify_parent():
    p=Path(A16.__file__)
    if h256(p.read_bytes())!=A16_SOURCE_SHA256:raise AssertionError(('A16_SOURCE',h256(p.read_bytes())))
    _,msha=A16.manifest(F16)
    if msha!=A16_MANIFEST_SHA256:raise AssertionError(('A16_MANIFEST',msha))
    return True

def corrected_eval(cells,seq,reps,prior):
    J=A16.A14.A12.A11
    cells=copy.deepcopy(cells);total=0;migrations=0;assignments=[]
    episodes=tuple(sorted(int(k) for k in reps.keys()))
    episode_first4={}
    for e,d in enumerate(seq):
        if e in episodes:
            cells,a=J.replace_cells(cells,reps[str(e)],prior);assignments.append((e,a));episode_first4[e]=0
        sv=J.served(cells,d);total+=sv
        for st in episodes:
            if st in episode_first4 and st<=e<st+4:episode_first4[st]+=sv
        cells,m=J.migrate_one_step(cells,d);migrations+=m
    return cells,{'service_total':total,'first4_service':sum(episode_first4.values()),'migrations':migrations,'assignments':assignments}

def run_corrected(freeze=F16):
    verify_parent()
    J=A16.A14.A12.A11;old=J.run_eval_phase
    try:
        J.run_eval_phase=corrected_eval
        r=A16.run_primary(freeze)
    finally:
        J.run_eval_phase=old
    # Structural episode accounting.
    cand=base=oracle=0
    all_two=True
    for s in r['scenarios']:
        for e in s['evals']:
            cand+=len(e['candidate']['assignments']);base+=len(e['baseline']['assignments']);oracle+=len(e['oracle']['assignments'])
            all_two &= len(e['candidate']['assignments'])==2 and len(e['baseline']['assignments'])==2 and len(e['oracle']['assignments'])==2
    expected=12*7*2
    learning_keys=[
      'TRANSIENT_SINGLE_BLOCK_NO_UPDATE_12_OF_12','TRANSIENT_REVERSION_CLEARS_PENDING_12_OF_12',
      'ALL_TRUE_FIRST_BLOCKS_ABSTAIN','ALL_TRUE_SECOND_BLOCKS_UPDATE','WORKING_PATH_EXACT_12_OF_12',
      'FINAL_PRIOR_P0_12_OF_12','FINAL_GENERATION_7_12_OF_12','DURABLE_HISTORY_IMMUTABLE_12_OF_12',
      'SLOT_COUNT_THREE_12_OF_12','C_V3_CREATIONS_ZERO','NEW_CONTEXT_CREATIONS_ZERO','PARENT_DIGEST_CHAINS_EXACT',
      'RESTARTS_EQUIVALENT','ALL_P1_P10_PROBES_PASS','N1_N5_UNSAFE_CONTROLS_EXPOSED','TASK_ACCURACY_ONE',
      'INCORRECT_SERVED_ZERO','STALE_PROGRAM_SERVED_ZERO','CONSTITUTIONAL_SAFETY_ZERO']
    learning_equiv=all(r['components'][k] for k in learning_keys)
    corrective={
      'F16_UNCHANGED':freeze==F16,
      'MANIFEST_UNCHANGED':r['manifest_sha256']==A16_MANIFEST_SHA256,
      'ALL_EVALUATIONS_HAVE_TWO_REPLACEMENTS':all_two,
      'CANDIDATE_REPLACEMENT_EPISODES_168':cand==expected,
      'STALE_REPLACEMENT_EPISODES_168':base==expected,
      'ORACLE_REPLACEMENT_EPISODES_168':oracle==expected,
      'LEARNING_HYSTERESIS_EQUIVALENCE':learning_equiv,
      'CANDIDATE_SERVICE_BEATS_STALE':r['components']['CANDIDATE_SERVICE_BEATS_STALE'],
      'CANDIDATE_GE_STALE_AT_LEAST_60_OF_72':r['components']['CANDIDATE_GE_STALE_AT_LEAST_60_OF_72'],
      'ORACLE_EFFICIENCY_GE_0_98':r['components']['ORACLE_EFFICIENCY_GE_0_98'],
      'MIGRATION_AVOIDED_AT_LEAST_ONE':r['components']['MIGRATION_AVOIDED_AT_LEAST_ONE'],
      'FINAL_P0_SERVICE_MATCHES_ORACLE':r['components']['FINAL_P0_SERVICE_MATCHES_ORACLE'],
    }
    out={'fixa':'A16-FIXA','freeze_commit':F16,'manifest_sha256':r['manifest_sha256'],'historical_result_sha256':A16_HISTORICAL_RESULT,
         'corrected_a16_result':r,'replacement_episode_counts':{'candidate':cand,'stale':base,'oracle':oracle},'corrective_components':corrective}
    out['A16_FIXA_EVALUATION_ALIGNMENT_VALID']=all(corrective.values())
    out['A16_T8_HYSTERETIC_MOVING_DRIFT_ACCEPTED']=out['A16_FIXA_EVALUATION_ALIGNMENT_VALID']
    out['serialized_output_sha256']=sha_obj({k:v for k,v in out.items() if k!='serialized_output_sha256'})
    return out

def validate():
    verify_parent();m,_=A16.manifest(F16)
    # structural only: frozen A16 replacement maps contain exactly 0 and 4
    assert all(tuple(sorted(map(int,s['replacements'][ph].keys())))==(0,4) for s in m['scenarios'] for ph in A16.PHASES)
    # tiny helper check on first frozen eval without claiming primary evidence
    s=m['scenarios'][0];cells=A16.A14.A12.A11.initial_cells();_,x=corrected_eval(cells,s['evals']['P1'],s['replacements']['P1'],tuple(s['targets']['P1']))
    assert [a[0] for a in x['assignments']]==[0,4]
    return {'parent':'PASS','frozen_replacement_keys':'0,4','helper_executes':'0,4','validated':True}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--validate',action='store_true');ap.add_argument('--out')
    a=ap.parse_args()
    if a.validate:print(enc(validate()));return
    if not a.out:raise SystemExit('--out required for corrective primary evidence')
    r=run_corrected();Path(a.out).write_text(enc(r)+'\n',encoding='utf-8');print(enc({'out':a.out,'signal':r['A16_T8_HYSTERETIC_MOVING_DRIFT_ACCEPTED'],'sha':r['serialized_output_sha256']}))
if __name__=='__main__':main()
