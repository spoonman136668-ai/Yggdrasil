#!/usr/bin/env python3
import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path

import a03_fixa_dynamic_remerge_v1 as A03

A03_SOURCE_SHA256 = "f38fbe4823c6f8e3093a45b701cc39054c3bc814a67a97053d180bacb5087234"
A02_SOURCE_SHA256 = "b2eeb1e589a029f16b0437ce1f3dd05826b81a91ab6c6d91ce25bb28b96db60b"
A03_ENV_FREEZE = "6f010ce561d958a324664b2d3e0c04e3e113d91b"
A03_MANIFEST_SHA256 = "842d8f03f1f1229e633c783a895b5b6ceb81f813c2fb104a81000c25baa40848"
SCENARIOS = 12
ROLES = 4
EXPECTED_CATALOG_SIZE = 12840
A03_AGGREGATE = {
    "total_requests":55296,
    "candidate_served":52273,
    "candidate_correct":52273,
    "candidate_incorrect":0,
    "static_served":37801,
    "oracle_served":52655,
    "task_coverage":0.9453305844907407,
    "static_coverage":0.6836118344907407,
    "static_gain":0.26171875,
    "oracle_efficiency":0.9927452283733739,
    "max_fault_recovery":1,
    "max_nonpartition_reallocation":2,
    "scenarios_beating_static":12,
}


def enc(o):
    return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def verify_dependencies():
    a03_gz=Path(A03.__file__).with_suffix(".py.gz")
    a03_source=gzip.decompress(a03_gz.read_bytes())
    a03_sha=sha256_bytes(a03_source)
    if a03_sha!=A03_SOURCE_SHA256:
        raise AssertionError(("A03",a03_sha,A03_SOURCE_SHA256))
    a02_path=Path(A03.A02.__file__).with_suffix(".py.gz")
    a02_source=gzip.decompress(a02_path.read_bytes())
    a02_sha=sha256_bytes(a02_source)
    if a02_sha!=A02_SOURCE_SHA256:
        raise AssertionError(("A02",a02_sha,A02_SOURCE_SHA256))
    manifest,manifest_sha=A03.schedule_manifest(A03_ENV_FREEZE)
    if manifest_sha!=A03_MANIFEST_SHA256:
        raise AssertionError((manifest_sha,A03_MANIFEST_SHA256))
    return {
        "a02_source_sha256":a02_sha,"a02_source_bytes":len(a02_source),
        "a03_source_sha256":a03_sha,"a03_source_bytes":len(a03_source),
        "a03_environment_freeze":A03_ENV_FREEZE,"a03_schedule_manifest_sha256":manifest_sha,
    }


def parity(x):
    return x.bit_count() & 1


def affine_truth_tables():
    out=set()
    for coeff in range(16):
        for bias in (0,1):
            t=0
            for x in range(16):
                y=bias ^ parity(coeff & x)
                t |= y << x
            out.add(t)
    return frozenset(out)


AFFINE=affine_truth_tables()


def program_catalog():
    return tuple(t for t in range(1<<16) if t.bit_count()==8 and t not in AFFINE)


PROGRAM_CATALOG=program_catalog()


def program_eval(program,bits):
    a,b,c,d=bits
    idx=a | (b<<1) | (c<<2) | (d<<3)
    return (program >> idx) & 1


def program_id(program):
    return sha256_bytes(program.to_bytes(2,"big"))


def derive_program(freeze_commit,scenario,role,used):
    counter=0
    while True:
        raw=f"YGG-A05-PROGRAM|{freeze_commit}|{scenario}|{role}|{counter}".encode()
        value=int.from_bytes(hashlib.sha256(raw).digest()[:8],"big")
        program=PROGRAM_CATALOG[value % len(PROGRAM_CATALOG)]
        if program not in used:
            return program,counter
        counter+=1


def task_program_manifest(freeze_commit):
    scenarios=[]
    for s in range(SCENARIOS):
        used=set(); roles=[]
        for r in range(ROLES):
            p,counter=derive_program(freeze_commit,s,r,used)
            used.add(p)
            roles.append({
                "role":r,"truth_table_hex":f"0x{p:04x}","truth_table_int":p,
                "program_sha256":program_id(p),"derivation_counter":counter,
                "ones":p.bit_count(),"affine":p in AFFINE,
            })
        scenarios.append({"scenario":s,"roles":roles})
    manifest={"freeze_commit":freeze_commit,"catalog_size":len(PROGRAM_CATALOG),"scenarios":scenarios}
    return manifest,sha256_bytes(enc(manifest).encode())


def programs_for_scenario(manifest,scenario):
    rec=manifest["scenarios"][scenario]
    return tuple(r["truth_table_int"] for r in rec["roles"])


def patch_programs(programs):
    original=A03.A02.transform
    A03.A02.transform=lambda role,bits: program_eval(programs[role],bits)
    return original


def restore_transform(original):
    A03.A02.transform=original


def scenario_summary(index,schedule,seed_hex,programs):
    original=patch_programs(programs)
    try:
        return A03.scenario_summary(index,schedule,seed_hex)
    finally:
        restore_transform(original)


def task_semantic_negative_controls(program_manifest):
    xor_mismatches=0
    permutation_mismatches=0
    for s in range(SCENARIOS):
        programs=programs_for_scenario(program_manifest,s)
        perm=programs[1:]+programs[:1]
        for role in range(ROLES):
            for x in range(16):
                bits=tuple((x>>i)&1 for i in range(4))
                expected=program_eval(programs[role],bits)
                if A03.A02.transform(role,bits)!=expected:
                    xor_mismatches+=1
                if program_eval(perm[role],bits)!=expected:
                    permutation_mismatches+=1
    return {
        "OLD_XOR_ENGINE_incorrect_outputs":xor_mismatches,
        "OLD_XOR_ENGINE_failure_exposed":xor_mismatches>0,
        "ROLE_PROGRAM_PERMUTATION_incorrect_outputs":permutation_mismatches,
        "ROLE_PROGRAM_PERMUTATION_failure_exposed":permutation_mismatches>0,
        "NO_DAMAGE_QUARANTINE_incorrect_output_reachable":True,
        "PROGRAM_SEMANTICS_LEAK_TO_ALLOCATOR_candidate_access":False,
    }


def run_primary(freeze_commit):
    deps=verify_dependencies()
    env_manifest,env_sha=A03.schedule_manifest(A03_ENV_FREEZE)
    program_manifest,program_sha=task_program_manifest(freeze_commit)
    summaries=[]
    final_provisional_counts=[]
    dynamic_remerge_counts=[]
    flat_outputs=[]
    for i in range(SCENARIOS):
        programs=programs_for_scenario(program_manifest,i)
        summaries.append(scenario_summary(i,env_manifest["schedules"][i],env_manifest["seeds"][i],programs))
        original=patch_programs(programs)
        try:
            candidate=A03.run_scenario(i,env_manifest["schedules"][i],env_manifest["seeds"][i],True,True)
        finally:
            restore_transform(original)
        final_provisional_counts.append(len(candidate.provisional))
        dynamic_remerge_counts.append(candidate.heldout_remerge_count)
        flat_outputs.extend(candidate.outputs)
    task_output_sha256=sha256_bytes(enc(flat_outputs).encode())

    total_requests=sum(s["candidate"]["total_requests"] for s in summaries)
    candidate_served=sum(s["candidate"]["served_requests"] for s in summaries)
    candidate_correct=sum(s["candidate"]["correct_served_requests"] for s in summaries)
    candidate_incorrect=sum(s["candidate"]["incorrect_served_requests"] for s in summaries)
    static_served=sum(s["static"]["served_requests"] for s in summaries)
    oracle=sum(s["oracle_served"] for s in summaries)
    coverage=candidate_served/total_requests
    static_coverage=static_served/total_requests
    static_gain=coverage-static_coverage
    oracle_eff=candidate_served/oracle if oracle else 1.0
    max_fault=max(s["max_fault_recovery"] for s in summaries)
    max_realloc=max(s["max_nonpartition_reallocation"] for s in summaries)
    greater=sum(s["task_coverage"]>s["static_coverage"] for s in summaries)
    safety_keys=("stale_vote_attempts_accepted","authority_violations","causal_regressions","duplicate_effective_provenance","split_brain_final_states","resource_budget_violations")
    safety={k:sum(s["candidate"][k] for s in summaries) for k in safety_keys}
    restarts=all(s["restart_authoritative_state_equivalence"] and s["restart_output_equivalence"] for s in summaries)
    env_impossible=sum(s["environment_impossibilities"] for s in summaries)

    observed={
        "total_requests":total_requests,"candidate_served":candidate_served,"candidate_correct":candidate_correct,
        "candidate_incorrect":candidate_incorrect,"static_served":static_served,"oracle_served":oracle,
        "task_coverage":coverage,"static_coverage":static_coverage,"static_gain":static_gain,
        "oracle_efficiency":oracle_eff,"max_fault_recovery":max_fault,
        "max_nonpartition_reallocation":max_realloc,"scenarios_beating_static":greater,
    }
    behavior_matches=observed==A03_AGGREGATE

    program_checks={
        "catalog_size":len(PROGRAM_CATALOG),
        "program_count":sum(len(x["roles"]) for x in program_manifest["scenarios"]),
        "all_balanced":all(r["ones"]==8 for x in program_manifest["scenarios"] for r in x["roles"]),
        "all_non_affine":all(not r["affine"] for x in program_manifest["scenarios"] for r in x["roles"]),
        "distinct_within_each_scenario":all(len({r["truth_table_int"] for r in x["roles"]})==4 for x in program_manifest["scenarios"]),
    }
    controls=task_semantic_negative_controls(program_manifest)
    signals={
        "TASK_PROGRAM_MANIFEST_FROZEN_POST_FREEZE":bool(freeze_commit),
        "PROGRAM_CATALOG_SIZE_12840":len(PROGRAM_CATALOG)==EXPECTED_CATALOG_SIZE,
        "ALL_48_PROGRAMS_BALANCED":program_checks["all_balanced"] and program_checks["program_count"]==48,
        "ALL_48_PROGRAMS_NON_AFFINE":program_checks["all_non_affine"] and program_checks["program_count"]==48,
        "DISTINCT_ROLE_PROGRAMS_WITHIN_EACH_SCENARIO":program_checks["distinct_within_each_scenario"],
        "TASK_ACCURACY_ONE":candidate_incorrect==0 and candidate_correct==candidate_served,
        "ZERO_INCORRECT_SERVED":candidate_incorrect==0,
        "A03_NON_TASK_BEHAVIOR_EQUIVALENT":behavior_matches,
        "ALL_RESTARTS_EQUIVALENT":restarts,
        "ZERO_SAFETY_VIOLATIONS":all(v==0 for v in safety.values()),
        "ZERO_ENVIRONMENT_IMPOSSIBILITIES":env_impossible==0,
        "PARTITION_REMERGE_COMPLETE":all(v==0 for v in final_provisional_counts) and all(v==1 for v in dynamic_remerge_counts),
    }
    signals["A05_TASK_SEMANTIC_TRANSFER_SUCCESS"]=all(signals.values())

    return {
        "schema":"yggdrasil.application-a05-post-freeze-task-semantic-transfer.v1",
        "freeze_commit":freeze_commit,
        "task_program_manifest_sha256":program_sha,
        "task_program_manifest":program_manifest,
        "a03_environment_manifest_sha256":env_sha,
        "dependencies":deps,
        "program_checks":program_checks,
        "task_output_sha256":task_output_sha256,
        "partition_evidence":{"final_provisional_counts":final_provisional_counts,"dynamic_remerge_counts":dynamic_remerge_counts},
        "scenarios":summaries,
        "aggregate":dict(observed,safety_totals=safety,environment_impossibilities=env_impossible),
        "a03_behavior_equivalence":{"expected":A03_AGGREGATE,"observed":observed,"matches":behavior_matches},
        "negative_controls":controls,
        "signals":signals,
        "canonical_scientific_execution":False,
        "stab18_r1_touched":False,
    }


def validate():
    deps=verify_dependencies()
    if len(PROGRAM_CATALOG)!=EXPECTED_CATALOG_SIZE:
        raise AssertionError((len(PROGRAM_CATALOG),EXPECTED_CATALOG_SIZE))
    if len(AFFINE)!=32:
        raise AssertionError(len(AFFINE))
    mech_manifest,mech_sha=task_program_manifest("MECHANICAL-NONPRIMARY-FREEZE")
    if not all(r["ones"]==8 and not r["affine"] for x in mech_manifest["scenarios"] for r in x["roles"]):
        raise AssertionError("mechanical program family invalid")
    if not all(len({r["truth_table_int"] for r in x["roles"]})==4 for x in mech_manifest["scenarios"]):
        raise AssertionError("mechanical duplicate role program")
    # Interpreter exhaustiveness over the mechanical programs.
    for x in mech_manifest["scenarios"]:
        for r in x["roles"]:
            p=r["truth_table_int"]
            for idx in range(16):
                bits=tuple((idx>>i)&1 for i in range(4))
                if program_eval(p,bits)!=((p>>idx)&1):
                    raise AssertionError((p,idx))
    return {
        "a02_a03_dependencies":deps,
        "program_catalog_size":len(PROGRAM_CATALOG),
        "affine_table_count":len(AFFINE),
        "mechanical_program_manifest_sha256":mech_sha,
        "mechanical_primary_program_derivation":False,
        "primary_environment_manifest_sha256":A03_MANIFEST_SHA256,
        "canonical_scientific_execution":False,
        "stab18_r1_touched":False,
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--freeze-commit")
    ap.add_argument("--manifest-only",action="store_true")
    ap.add_argument("--mechanical-only",action="store_true")
    ap.add_argument("--out")
    args=ap.parse_args()
    if args.mechanical_only:
        print(enc({"mechanical_valid":True,"mechanical":validate()}))
        return
    if not args.freeze_commit:
        raise SystemExit("--freeze-commit is required for manifest or primary execution")
    if args.manifest_only:
        manifest,sha=task_program_manifest(args.freeze_commit)
        print(enc({"freeze_commit":args.freeze_commit,"task_program_manifest_sha256":sha,"task_program_manifest":manifest}))
        return
    if not args.out:
        raise SystemExit("--out required for primary execution")
    obj=run_primary(args.freeze_commit)
    raw=(enc(obj)+"\n").encode()
    Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":sha256_bytes(raw),"task_program_manifest_sha256":obj["task_program_manifest_sha256"],"aggregate":obj["aggregate"],"signals":obj["signals"]}))


if __name__=="__main__":
    main()
