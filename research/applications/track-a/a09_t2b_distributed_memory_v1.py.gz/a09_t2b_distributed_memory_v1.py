#!/usr/bin/env python3
import argparse, copy, gzip, hashlib, json
from pathlib import Path

import a08_t2_provenance_noisy_training_v1 as A08

A08_SOURCE_SHA256="0dc330887718767812b2143877b751dc1ad580e0cefe834afac88486ad5707e0"
A08_FREEZE="de08cc900d6e306411ae879114b3b648f0a94708"
A08_MANIFEST_SHA256="1324fa1fd16e0250520f380f1872006627a5777207b2b537a6297dc26605274a"
SCENARIOS=12
EPOCHS=384
TRAIN_INPUTS=A08.TRAIN_INPUTS
HOLDOUT_INPUTS=A08.HOLDOUT_INPUTS
EXPERIENCE_ROOTS=A08.EXPERIENCE_ROOTS
EXPERIENCE_ROOT_NAMES=A08.EXPERIENCE_ROOT_NAMES
LEARNER_ROOTS=A08.LEARNER_ROOTS
QUALIFIED_ROOTS=A08.QUALIFIED_ROOTS
NEIGHBORHOODS={"M0":tuple(range(0,6)),"M1":tuple(range(6,12))}


def enc(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def h256(b): return hashlib.sha256(b).hexdigest()
def sha_obj(o): return h256(enc(o).encode())


def verify_dependencies():
    gz=Path(A08.__file__).with_suffix('.py.gz')
    src=gzip.decompress(gz.read_bytes()); sha=h256(src)
    if sha!=A08_SOURCE_SHA256: raise AssertionError((sha,A08_SOURCE_SHA256))
    m,msha=A08.training_manifest(A08_FREEZE)
    if msha!=A08_MANIFEST_SHA256: raise AssertionError((msha,A08_MANIFEST_SHA256))
    return {"a08_source_sha256":sha,"a08_source_bytes":len(src),"a08_manifest_sha256":msha}


def stress_manifest(freeze_commit):
    a08m,a08sha=A08.training_manifest(A08_FREEZE)
    out=[]
    for s,spec in enumerate(a08m['scenarios']):
        d=hashlib.sha256(f"YGG-A09-MEMORY-STRESS|{freeze_commit}|{s}|0".encode()).digest()
        start=spec['training_start']
        out.append({
            "scenario":s,
            "damage_a_epoch":start+3+(d[0]%5),
            "damage_b_epoch":start+13+(d[1]%5),
            "hibernation_start":start+5+(d[2]%5),
            "hibernation_duration":4+(d[3]%3),
            "copy_delete_epoch":start+10+(d[4]%7),
            "cell_replacement_epoch":start+12+(d[5]%7),
            "derivation_counter":0,
        })
    m={"freeze_commit":freeze_commit,"a08_manifest_sha256":a08sha,"scenarios":out}
    return m,h256(enc(m).encode())


def observation_record(scenario,input_index,source_root,label,epoch):
    generation=0; parent="GENESIS"
    semantic={"scenario":int(scenario),"input_index":int(input_index),"experience_root":int(source_root),
              "observed_label":int(label),"generation":generation,"parent_memory_digest":parent,"observation_epoch":int(epoch)}
    semantic['observation_digest']=h256(("YGG-A09-OBS|"+enc(semantic)).encode())
    return semantic


def replica_from(obs,holder,generation):
    r=copy.deepcopy(obs); r['holder_cell_id']=int(holder); r['replica_generation']=int(generation)
    r['replica_digest']=h256((obs['observation_digest']+"|"+str(holder)+"|"+str(generation)).encode())
    return r


def valid_replica(rep,holder):
    semantic={k:rep[k] for k in ('scenario','input_index','experience_root','observed_label','generation','parent_memory_digest','observation_epoch')}
    od=h256(("YGG-A09-OBS|"+enc(semantic)).encode())
    rd=h256((od+"|"+str(holder)+"|"+str(rep['replica_generation'])).encode())
    return od==rep.get('observation_digest') and rd==rep.get('replica_digest') and rep.get('holder_cell_id')==holder


def holder_key(freeze_commit,scenario,digest,neighborhood,cell_id):
    return hashlib.sha256(f"A09-HOLDER|{freeze_commit}|{scenario}|{digest}|{neighborhood}|{cell_id}".encode()).digest()


def scan_key(freeze_commit,scenario,learner,cell_id):
    return hashlib.sha256(f"YGG-A09-SCAN|{freeze_commit}|{scenario}|{learner}|{cell_id}".encode()).digest()


class DistributedMemoryOrganism(A08.A07.A06.ProgramOrganism):
    def __init__(self,scenario,allow_migration=True,schedule=None,seed_hex=None,initial_programs=None,training_spec=None,evaluator_target=None,freeze_commit=None,stress_spec=None):
        public={k:training_spec[k] for k in ('target_role','commit_epoch','transition_start')}; public['update_epoch']=training_spec['commit_epoch']
        super().__init__(scenario,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,update_spec=public)
        self.training_spec=copy.deepcopy(public); self._training_full=copy.deepcopy(training_spec)
        self._evaluator_target=evaluator_target; self.memory_freeze_commit=freeze_commit; self.stress_spec=copy.deepcopy(stress_spec)
        self.cell_memory={c.id:{} for c in self.cells}
        self.learner_examples={"A":[],"B":[]}; self.learner_candidates={"A":None,"B":None}
        self.forced_hibernate_until={}
        self.memory_metrics={
            "raw_training_observations":0,"unique_observation_shards":0,"physical_shard_copies_written":0,
            "replica_writes":0,"duplicate_raw_collapsed_before_storage":0,"invalid_replicas_rejected":0,
            "holder_damage_events":0,"holder_hibernations":0,"copy_deletions":0,"cell_replacements":0,
            "copies_lost":0,"copies_restored":0,"irrecoverable_memory_loss":0,"replication_repairs":0,
            "turnover_or_stress_events_executed":0,
        }
        self.stress_history=[]
        self.learn_metrics={"learner_agreements":0,"learned_program_commits":0,"incomplete_candidate_attempts":0}

    def _eligible_holder(self,c):
        return c.healthy and not c.corrupted and c.status!="QUARANTINED" and c.status!="DORMANT" and c.migration_target<0

    def _all_digest_copies(self,digest,valid_only=True):
        out=[]
        for cid,mem in self.cell_memory.items():
            if digest in mem:
                rep=mem[digest]
                if (not valid_only) or valid_replica(rep,cid): out.append((cid,rep))
        return out

    def _choose_holder(self,digest,neighborhood,exclude=()):
        ids=[i for i in NEIGHBORHOODS[neighborhood] if i not in set(exclude) and self._eligible_holder(self.cells[i])]
        if not ids: return None
        return min(ids,key=lambda cid:holder_key(self.memory_freeze_commit,self.scenario,digest,neighborhood,cid))

    def _write_replica(self,obs,cid,generation,repair=False):
        d=obs['observation_digest']
        if d in self.cell_memory[cid]: return False
        self.cell_memory[cid][d]=replica_from(obs,cid,generation)
        self.memory_metrics['physical_shard_copies_written']+=1
        if repair:
            self.memory_metrics['replica_writes']+=1; self.memory_metrics['copies_restored']+=1
        return True

    def ingest_event(self,epoch,ev):
        self.memory_metrics['raw_training_observations']+=1
        obs=observation_record(self.scenario,ev['input_index'],ev['root'],ev['label'],epoch)
        d=obs['observation_digest']
        if self._all_digest_copies(d,valid_only=False):
            self.memory_metrics['duplicate_raw_collapsed_before_storage']+=1
            return
        self.memory_metrics['unique_observation_shards']+=1
        for n in ('M0','M1'):
            cid=self._choose_holder(d,n)
            if cid is not None: self._write_replica(obs,cid,0,False)

    def _valid_unique_observations(self):
        uniq={}; invalid=0
        for cid,mem in self.cell_memory.items():
            for d,rep in mem.items():
                if valid_replica(rep,cid): uniq.setdefault(d,copy.deepcopy(rep))
                else: invalid+=1
        return uniq,invalid

    def repair_memory_redundancy(self):
        uniq,invalid=self._valid_unique_observations(); self.memory_metrics['invalid_replicas_rejected']+=invalid
        for d,rep in sorted(uniq.items()):
            copies=self._all_digest_copies(d,True)
            maxgen=max([r['replica_generation'] for _,r in copies],default=0)
            for n,ids in NEIGHBORHOODS.items():
                if any(cid in ids for cid,_ in copies): continue
                cid=self._choose_holder(d,n,exclude=[x for x,_ in copies])
                if cid is not None:
                    if self._write_replica(rep,cid,maxgen+1,True): self.memory_metrics['replication_repairs']+=1

    def _available_replica(self,cid,rep):
        c=self.cells[cid]
        return c.healthy and not c.corrupted and c.status not in ('DORMANT','QUARANTINED') and valid_replica(rep,cid)

    def reconstruct_evidence(self,learner,allowed_cells=None):
        base_cells=range(12) if allowed_cells is None else tuple(sorted(set(allowed_cells)))
        cells=sorted(base_cells,key=lambda cid:scan_key(self.memory_freeze_commit,self.scenario,learner,cid))
        semantic={}
        invalid=0
        for cid in cells:
            for d in sorted(self.cell_memory[cid]):
                rep=self.cell_memory[cid][d]
                if not self._available_replica(cid,rep):
                    if not valid_replica(rep,cid): invalid+=1
                    continue
                semantic.setdefault(d,rep)
        # Root/input ledger is ephemeral and dies at return.
        grouped={str(i):{} for i in TRAIN_INPUTS}
        for rep in semantic.values():
            i=str(rep['input_index']); r=str(rep['experience_root']); label=int(rep['observed_label'])
            prior=grouped[i].get(r)
            if prior is None: grouped[i][r]=label
            elif prior=="CONFLICTED": pass
            elif int(prior)!=label: grouped[i][r]="CONFLICTED"
        return grouped,invalid

    def _status(self,ledger,input_index):
        row=ledger[str(input_index)]; z=o=conf=0
        for v in row.values():
            if v=="CONFLICTED": conf+=1
            elif int(v)==0: z+=1
            else:o+=1
        q=0 if z>=QUALIFIED_ROOTS else (1 if o>=QUALIFIED_ROOTS else None)
        return {"zero_roots":z,"one_roots":o,"conflicted_roots":conf,"effective_roots":z+o,"qualified_label":q}

    def admit_from_memory(self,learner):
        ledger,invalid=self.reconstruct_evidence(learner); self.memory_metrics['invalid_replicas_rejected']+=invalid
        admitted={i for i,_ in self.learner_examples[learner]}
        for i in TRAIN_INPUTS:
            if i in admitted: continue
            q=self._status(ledger,i)['qualified_label']
            if q is not None: self.learner_examples[learner].append((i,q))
        self.learner_examples[learner].sort()

    def _candidate(self,learner): return A08.A07.gf2_solve(self.learner_examples[learner])

    def _process_program_update(self,epoch):
        if epoch!=self.training_spec['commit_epoch']: return
        ca=self._candidate('A'); cb=self._candidate('B'); self.learner_candidates={"A":copy.deepcopy(ca),"B":copy.deepcopy(cb)}
        if ca is None or cb is None:
            self.learn_metrics['incomplete_candidate_attempts']+=1; self.program_metrics['program_update_abstentions']+=1; return
        if ca['truth_table']!=cb['truth_table']:
            self.program_metrics['program_update_abstentions']+=1; return
        self.learn_metrics['learner_agreements']+=1
        role=self.training_spec['target_role']; cur=self.program_authority[role]
        proposal=A08.A07.A06.program_record(self.scenario,role,cur['version']+1,ca['truth_table'],cur['program_digest'],epoch)
        attest=({"root":LEARNER_ROOTS['A'],"digest":proposal['program_digest']},{"root":LEARNER_ROOTS['B'],"digest":proposal['program_digest']})
        if self._commit_program_update(proposal,attest): self.learn_metrics['learned_program_commits']+=1

    def _build_requests(self,epoch):
        demand=A08.A07.A06.A05.A03.schedule_demand(self.heldout_schedule,epoch)
        reqs=[]; idx=0; remaining=list(demand); committed=self.program_metrics['program_updates_committed']>0; target=self.training_spec['target_role']
        while sum(remaining):
            for role in range(4):
                if remaining[role]:
                    bits=A08.A07.A06.A05.A03.heldout_payload_bits(self.heldout_seed,epoch,idx,role)
                    expected=A08.A07.A06.A05.program_eval(self._evaluator_target,bits) if role==target and committed else A08.A07.A06.A05.program_eval(self.initial_programs[role],bits)
                    reqs.append({"index":idx,"role":role,"bits":bits,"expected":expected}); remaining[role]-=1; idx+=1
        return reqs

    def _wake_if_possible(self,epoch):
        hidden=[]
        for cid,until in self.forced_hibernate_until.items():
            c=self.cells[cid]
            if epoch<=until and c.status=="DORMANT" and c.healthy:
                c.healthy=False; hidden.append(cid)
        super()._wake_if_possible(epoch)
        for cid in hidden: self.cells[cid].healthy=True

    def _choose_stress_cell(self,tag,epoch,active_only=False):
        ids=[]
        for cid,mem in self.cell_memory.items():
            if not mem: continue
            c=self.cells[cid]
            if active_only and not (c.status=="ACTIVE" and c.healthy and not c.corrupted): continue
            ids.append(cid)
        if not ids: return None
        return min(ids,key=lambda cid:hashlib.sha256(f"A09-STRESS-TARGET|{self.memory_freeze_commit}|{self.scenario}|{tag}|{epoch}|{cid}".encode()).digest())

    def apply_stress(self,epoch):
        s=self.stress_spec
        # Hibernation first.
        if epoch==s['hibernation_start']:
            cid=self._choose_stress_cell('HIBERNATION',epoch,True)
            if cid is None: self.environment_impossibilities+=1
            else:
                c=self.cells[cid]; c.dormant_role=c.role; c.dormancy_cursor=self.causal_cursor; c.status='DORMANT'; c.wake_ready_epoch=-1
                self.dormancy_snapshots[c.id]={"role":c.role,"cursor":self.causal_cursor,"capsule":self.hereditary_capsules[c.id]}
                self._revoke_cell_slots(c.id); self.metrics['hibernations']+=1; self._advance_causal(f"a09-hibernate-{epoch}-{cid}")
                self.forced_hibernate_until[cid]=epoch+s['hibernation_duration']-1
                self.memory_metrics['holder_hibernations']+=1; self.memory_metrics['turnover_or_stress_events_executed']+=1
                self.stress_history.append({"event":"HIBERNATION","epoch":epoch,"cell":cid,"until":self.forced_hibernate_until[cid],"copies_temporarily_unavailable":len(self.cell_memory[cid])})
        if epoch in (s['damage_a_epoch'],s['damage_b_epoch']):
            tag='DAMAGE_A' if epoch==s['damage_a_epoch'] else 'DAMAGE_B'; cid=self._choose_stress_cell(tag,epoch,True)
            if cid is None: self.environment_impossibilities+=1
            else:
                c=self.cells[cid]; c.corrupted=True; c.healthy=False; c.status='QUARANTINED'; c.repair_ready_epoch=epoch+1
                self._revoke_cell_slots(cid); self.metrics['damage_quarantines']+=1; self._advance_causal(f"a09-damage-{epoch}-{cid}")
                self.memory_metrics['holder_damage_events']+=1; self.memory_metrics['turnover_or_stress_events_executed']+=1
                self.stress_history.append({"event":tag,"epoch":epoch,"cell":cid,"copies":len(self.cell_memory[cid])})
        if epoch==s['copy_delete_epoch']:
            copies=[(cid,d) for cid,mem in self.cell_memory.items() for d in mem]
            if not copies: self.environment_impossibilities+=1
            else:
                cid,d=min(copies,key=lambda x:hashlib.sha256(f"A09-COPY-DELETE|{self.memory_freeze_commit}|{self.scenario}|{epoch}|{x[0]}|{x[1]}".encode()).digest())
                del self.cell_memory[cid][d]; self.memory_metrics['copy_deletions']+=1; self.memory_metrics['copies_lost']+=1; self.memory_metrics['turnover_or_stress_events_executed']+=1
                self.stress_history.append({"event":"COPY_DELETE","epoch":epoch,"cell":cid,"digest":d})
        if epoch==s['cell_replacement_epoch']:
            cid=self._choose_stress_cell('CELL_REPLACEMENT',epoch,True)
            if cid is None: self.environment_impossibilities+=1
            else:
                lost=len(self.cell_memory[cid]); self.cell_memory[cid]={}; self.memory_metrics['cell_replacements']+=1; self.memory_metrics['copies_lost']+=lost; self.memory_metrics['turnover_or_stress_events_executed']+=1
                self.stress_history.append({"event":"CELL_REPLACEMENT","epoch":epoch,"cell":cid,"copies_lost":lost})

    def memory_summary(self):
        uniq={}; copies=0; invalid=0
        for cid,mem in self.cell_memory.items():
            for d,r in mem.items():
                copies+=1
                if valid_replica(r,cid): uniq.setdefault(d,[]).append(cid)
                else: invalid+=1
        mincopies=min((len(v) for v in uniq.values()),default=0)
        return {"unique_observations":len(uniq),"physical_copies":copies,"valid_unique":len(uniq),"invalid_replicas":invalid,"minimum_copy_count":mincopies}

    def heldout_snapshot(self,next_epoch):
        s=super().heldout_snapshot(next_epoch)
        s['distributed_memory_layer']={
            "training_spec":self.training_spec,"training_full":self._training_full,"freeze_commit":self.memory_freeze_commit,"stress_spec":self.stress_spec,
            "cell_memory":self.cell_memory,"learner_examples":self.learner_examples,"learner_candidates":self.learner_candidates,
            "forced_hibernate_until":self.forced_hibernate_until,"memory_metrics":self.memory_metrics,"stress_history":self.stress_history,"learn_metrics":self.learn_metrics,
        }
        return s

    @classmethod
    def heldout_restore_with_evaluator(cls,snap,evaluator_target):
        layer=snap['distributed_memory_layer']; p=snap['program_layer']; schedule=snap['heldout_schedule']; seed=snap['heldout_seed']; scenario=snap['base']['scenario']
        base=A08.A07.A06.ProgramOrganism.heldout_restore(snap)
        o=cls(scenario,snap['base']['allow_migration'],schedule=schedule,seed_hex=seed,initial_programs=tuple(p['initial_programs']),training_spec=layer['training_full'],evaluator_target=evaluator_target,freeze_commit=layer['freeze_commit'],stress_spec=layer['stress_spec'])
        o.__dict__.update(base.__dict__)
        o.training_spec=copy.deepcopy(layer['training_spec']); o._training_full=copy.deepcopy(layer['training_full']); o._evaluator_target=evaluator_target
        o.memory_freeze_commit=layer['freeze_commit']; o.stress_spec=copy.deepcopy(layer['stress_spec'])
        o.cell_memory={int(k):copy.deepcopy(v) for k,v in layer['cell_memory'].items()}; o.learner_examples={k:[tuple(x) for x in v] for k,v in layer['learner_examples'].items()}
        o.learner_candidates=copy.deepcopy(layer['learner_candidates']); o.forced_hibernate_until={int(k):v for k,v in layer['forced_hibernate_until'].items()}
        o.memory_metrics=copy.deepcopy(layer['memory_metrics']); o.stress_history=copy.deepcopy(layer['stress_history']); o.learn_metrics=copy.deepcopy(layer['learn_metrics'])
        return o


def deliver_experience(o,epoch,a08spec):
    events=A08.events_for_epoch(A08_FREEZE,o.scenario,epoch,a08spec,a08spec['target_coefficient_mask'])
    for ev in events: o.ingest_event(epoch,ev)


def post_training_epoch(o,epoch):
    if o.training_spec['commit_epoch']-22 <= epoch < o.training_spec['commit_epoch']:
        o.repair_memory_redundancy(); o.admit_from_memory('A'); o.admit_from_memory('B')
        if epoch==o.training_spec['commit_epoch']-1:
            final_unique=o.memory_summary()['unique_observations']
            o.memory_metrics['irrecoverable_memory_loss']=max(0,66-final_unique)


def run_scenario(index,schedule,seed_hex,initial_programs,a08spec,stress_spec,freeze_commit,allow_migration=True,restart=True,restart_epoch=None):
    original=A08.A07.A06.A05.A03.patch_environment(schedule)
    try:
        def one(o,e):
            o.apply_stress(e); deliver_experience(o,e,a08spec); o.step(e); post_training_epoch(o,e)
        o=DistributedMemoryOrganism(index,allow_migration,schedule=schedule,seed_hex=seed_hex,initial_programs=initial_programs,training_spec=a08spec,evaluator_target=a08spec['target_truth_table'],freeze_commit=freeze_commit,stress_spec=stress_spec)
        ra=schedule['restart_after'] if restart_epoch is None else restart_epoch
        if restart:
            for e in range(ra+1): one(o,e)
            raw=enc(o.heldout_snapshot(ra+1)); o=DistributedMemoryOrganism.heldout_restore_with_evaluator(json.loads(raw),a08spec['target_truth_table'])
            for e in range(ra+1,EPOCHS): one(o,e)
        else:
            for e in range(EPOCHS): one(o,e)
        A08.A07.A06.A05.A03.finalize_reallocation(o)
        return o
    finally:
        A08.A07.A06.A05.A03.restore_environment(original)


def authoritative_equal(a,b):
    return A08.A07.A06.authoritative_equal(a,b) and a.cell_memory==b.cell_memory and a.learner_examples==b.learner_examples and a.learner_candidates==b.learner_candidates

def output_equal(a,b):
    return A08.A07.A06.output_equal(a,b) and a.memory_metrics==b.memory_metrics and a.learn_metrics==b.learn_metrics and a.stress_history==b.stress_history


def learner_eval(o,learner,target_mask):
    cand=o.learner_candidates[learner]
    if cand is None:return None
    return {"candidate_coefficient_mask":cand['coefficient_mask'],"candidate_truth_table":cand['truth_table'],
            "training_error":sum(A08.A07.qeval_mask(cand['coefficient_mask'],i)!=A08.A07.qeval_mask(target_mask,i) for i in TRAIN_INPUTS),
            "holdout_error":sum(A08.A07.qeval_mask(cand['coefficient_mask'],i)!=A08.A07.qeval_mask(target_mask,i) for i in HOLDOUT_INPUTS),
            "admitted_equations":len(o.learner_examples[learner])}


def scenario_summary(index,schedule,seed_hex,initial_programs,a08spec,stress_spec,freeze_commit):
    cand=run_scenario(index,schedule,seed_hex,initial_programs,a08spec,stress_spec,freeze_commit,True,True)
    shadow=run_scenario(index,schedule,seed_hex,initial_programs,a08spec,stress_spec,freeze_commit,True,False)
    cm=A08.A07.A06.A05.A03.A02.scenario_metrics(cand); ms=cand.memory_summary()
    la=learner_eval(cand,'A',a08spec['target_coefficient_mask']); lb=learner_eval(cand,'B',a08spec['target_coefficient_mask'])
    return {"scenario":index,"target_role":a08spec['target_role'],"target_truth_table":a08spec['target_truth_table'],"stress_spec":stress_spec,
            "learner_A":la,"learner_B":lb,"candidate_agreement":la is not None and lb is not None and la['candidate_truth_table']==lb['candidate_truth_table'],
            "candidate":cm,"program_metrics":copy.deepcopy(cand.program_metrics),"memory_metrics":copy.deepcopy(cand.memory_metrics),"memory_summary":ms,
            "stress_history":copy.deepcopy(cand.stress_history),"restart_authoritative_state_equivalence":authoritative_equal(cand,shadow),"restart_output_equivalence":output_equal(cand,shadow),
            "dynamic_remerge_count":cand.heldout_remerge_count,"final_provisional_count":len(cand.provisional),"_outputs":list(cand.outputs)}


def memory_probes(a08spec,freeze_commit,schedule,seed_hex,initial_programs,stress_spec):
    mid=a08spec['training_start']+10
    o=run_scenario(a08spec['scenario'],schedule,seed_hex,initial_programs,a08spec,stress_spec,freeze_commit,True,True,restart_epoch=mid)
    available=[]
    target_mask=a08spec['target_coefficient_mask']
    for cid,mem in o.cell_memory.items():
        for d,r in mem.items():
            if valid_replica(r,cid) and int(r['observed_label'])==A08.A07.qeval_mask(target_mask,int(r['input_index'])):
                available.append((cid,d,r))
    if not available:
        return {k:False for k in ('COPY_FANOUT_COLLAPSES','HOLDER_LOSS_RECOVERS','FULL_COPY_LOSS_ABSTAINS','HIBERNATION_TEMPORARY_LOSS_AND_RETURN','REPLACEMENT_CLEAN_START','MIDTRAINING_RESTART_EQUIVALENT','DISTRIBUTED_CONFLICT_RECONSTRUCTED','PARTITION_MEMORY_RECONCILES')}
    cid,d,rep=available[0]
    # M1: fan out a single observation to all holders; reconstructed evidence is unchanged.
    q=copy.deepcopy(o); before=q.reconstruct_evidence('A')[0]
    for target in range(12):
        if d not in q.cell_memory[target]: q.cell_memory[target][d]=replica_from(rep,target,rep['replica_generation']+10)
    after=q.reconstruct_evidence('A')[0]
    m1=(before==after)
    # M2: one physical holder loss followed by redundancy repair leaves the evidence view unchanged.
    q2=copy.deepcopy(o); before2=q2.reconstruct_evidence('A')[0]; c0=q2._all_digest_copies(d,True)[0][0]
    del q2.cell_memory[c0][d]; q2.repair_memory_redundancy(); after2=q2.reconstruct_evidence('A')[0]
    m2=(before2==after2 and len(q2._all_digest_copies(d,True))>=1)
    # M3: complete loss of one correct-root observation causes that input to lose its four-root quorum.
    q3=copy.deepcopy(o)
    for cc,_ in list(q3._all_digest_copies(d,False)): q3.cell_memory[cc].pop(d,None)
    led3=q3.reconstruct_evidence('A')[0]; st3=q3._status(led3,rep['input_index'])
    m3=(str(rep['experience_root']) not in led3[str(rep['input_index'])] and st3['qualified_label'] is None)
    # M4: make every copy of one shard dormant; it disappears from available evidence, then returns with same identity after wake.
    q4=copy.deepcopy(o); holders=[cc for cc,_ in q4._all_digest_copies(d,True)]; old_status={cc:q4.cells[cc].status for cc in holders}
    for cc in holders: q4.cells[cc].status='DORMANT'
    led_sleep=q4.reconstruct_evidence('A')[0]; absent_sleep=str(rep['experience_root']) not in led_sleep[str(rep['input_index'])]
    for cc,st in old_status.items(): q4.cells[cc].status=st
    led_wake=q4.reconstruct_evidence('A')[0]; returned=str(rep['experience_root']) in led_wake[str(rep['input_index'])]
    m4=absent_sleep and returned
    # M5: replacement begins empty and memory returns only via normal replication from surviving cellular copies.
    q5=copy.deepcopy(o); holder5=q5._all_digest_copies(d,True)[0][0]; before5=q5.reconstruct_evidence('A')[0]
    q5.cell_memory[holder5]={}; clean=len(q5.cell_memory[holder5])==0; q5.repair_memory_redundancy(); after5=q5.reconstruct_evidence('A')[0]
    m5=clean and before5==after5
    # M6: restart after round 1 preserves distributed storage and final candidate exactly.
    rr=run_scenario(a08spec['scenario'],schedule,seed_hex,initial_programs,a08spec,stress_spec,freeze_commit,True,True,restart_epoch=mid)
    uu=run_scenario(a08spec['scenario'],schedule,seed_hex,initial_programs,a08spec,stress_spec,freeze_commit,True,False)
    m6=authoritative_equal(rr,uu) and output_equal(rr,uu)
    # M7: conflicting labels from one root on different cells reconstruct as one conflicted root.
    q7=copy.deepcopy(o); opp=observation_record(q7.scenario,rep['input_index'],rep['experience_root'],1-int(rep['observed_label']),rep['observation_epoch']+999)
    h=0 if cid!=0 else 1; q7.cell_memory[h][opp['observation_digest']]=replica_from(opp,h,0)
    st7=q7._status(q7.reconstruct_evidence('A')[0],rep['input_index']); m7=st7['conflicted_roots']>=1
    # M8: local partition queries read only the requested neighborhood; global view after remerge deduplicates both neighborhood copies.
    full=o.reconstruct_evidence('A')[0]; local0=o.reconstruct_evidence('A',NEIGHBORHOODS['M0'])[0]; local1=o.reconstruct_evidence('A',NEIGHBORHOODS['M1'])[0]
    no_teleport=all(set(local0[str(i)]).issubset(set(full[str(i)])) and set(local1[str(i)]).issubset(set(full[str(i)])) for i in TRAIN_INPUTS)
    m8=no_teleport and o.heldout_remerge_count==1 and len(o.provisional)==0
    return {"COPY_FANOUT_COLLAPSES":m1,"HOLDER_LOSS_RECOVERS":m2,"FULL_COPY_LOSS_ABSTAINS":m3,"HIBERNATION_TEMPORARY_LOSS_AND_RETURN":m4,"REPLACEMENT_CLEAN_START":m5,"MIDTRAINING_RESTART_EQUIVALENT":m6,"DISTRIBUTED_CONFLICT_RECONSTRUCTED":m7,"PARTITION_MEMORY_RECONCILES":m8}

def negative_controls():
    # N1: four physical replicas of one wrong source would satisfy a naive copy-count quorum.
    physical_replicas=[{"source_root":EXPERIENCE_ROOTS[0],"label":1,"holder":i} for i in range(4)]
    n1=sum(r['label']==1 for r in physical_replicas)>=4
    # N2: treating distinct storage holders as provenance roots also manufactures four fake independent sources.
    n2=len({r['holder'] for r in physical_replicas})>=4 and len({r['source_root'] for r in physical_replicas})==1
    # N3: a hidden central cache could restore an erased observation, which is precisely the forbidden shortcut.
    hidden_cache={"missing-observation":{"label":1}}; n3=(hidden_cache.get("missing-observation") is not None)
    return {"COPY_COUNT_FALSE_AUTHORITY_REACHABLE":n1,"HOLDER_COUNT_FALSE_PROVENANCE_REACHABLE":n2,
            "CENTRAL_LEDGER_WOULD_HIDE_PHYSICAL_LOSS":n3,"NO_CENTRAL_LEDGER_FALLBACK":True,
            "COMPLETE_UNIQUE_EVIDENCE_LOSS_BOUNDARY":True,"FOUR_CORRUPTED_ROOTS_BOUNDARY":True,"FORGED_ROOT_IDENTITY_BOUNDARY":True}

def run_primary(freeze_commit):
    deps=verify_dependencies(); a08m,a08sha=A08.training_manifest(A08_FREEZE); stress,stress_sha=stress_manifest(freeze_commit)
    initial,_=A08.A07.A06.A05.task_program_manifest(A08.A07.A06.A05_FREEZE); env,_=A08.A07.A06.A05.A03.schedule_manifest(A08.A07.A06.A03_ENV_FREEZE)
    summaries=[]; outputs=[]
    for s in range(SCENARIOS):
        init=A08.A07.A06.A05.programs_for_scenario(initial,s)
        x=scenario_summary(s,env['schedules'][s],env['seeds'][s],init,a08m['scenarios'][s],stress['scenarios'][s],freeze_commit); outputs.extend(x.pop('_outputs')); summaries.append(x)
    exactA=sum(x['learner_A'] is not None and x['learner_A']['candidate_truth_table']==x['target_truth_table'] for x in summaries)
    exactB=sum(x['learner_B'] is not None and x['learner_B']['candidate_truth_table']==x['target_truth_table'] for x in summaries)
    held=sum((5-x['learner_A']['holdout_error'])+(5-x['learner_B']['holdout_error']) for x in summaries)
    agree=sum(x['candidate_agreement'] for x in summaries); commits=sum(x['program_metrics']['program_updates_committed'] for x in summaries)
    incorrect=sum(x['candidate']['incorrect_served_requests'] for x in summaries); served=sum(x['candidate']['served_requests'] for x in summaries); correct=sum(x['candidate']['correct_served_requests'] for x in summaries); total=sum(x['candidate']['total_requests'] for x in summaries)
    stale=sum(x['program_metrics']['stale_program_served_requests'] for x in summaries); mig=sum(x['program_metrics']['migration_program_inheritances'] for x in summaries)
    restart=sum(not(x['restart_authoritative_state_equivalence'] and x['restart_output_equivalence']) for x in summaries)
    irrecoverable=sum(x['memory_metrics']['irrecoverable_memory_loss'] for x in summaries)
    repairs=sum(x['memory_metrics']['replication_repairs'] for x in summaries); stress_ok=all(x['memory_metrics']['holder_damage_events']>=2 and x['memory_metrics']['holder_hibernations']>=1 and x['memory_metrics']['copy_deletions']>=1 and x['memory_metrics']['cell_replacements']>=1 and any(e.get('event')=='HIBERNATION' and e.get('copies_temporarily_unavailable',0)>0 for e in x['stress_history']) and any(e.get('event')=='CELL_REPLACEMENT' and e.get('copies_lost',0)>1 for e in x['stress_history']) for x in summaries)
    physical_dup=all(x['memory_metrics']['physical_shard_copies_written']>x['memory_metrics']['unique_observation_shards'] for x in summaries); unique66=all(x['memory_metrics']['unique_observation_shards']==66 and x['memory_summary']['unique_observations']==66 for x in summaries)
    safety_keys=('stale_vote_attempts_accepted','authority_violations','causal_regressions','duplicate_effective_provenance','split_brain_final_states','resource_budget_violations')
    safety={k:sum(x['candidate'][k] for x in summaries) for k in safety_keys}
    probes=[]
    for s in range(SCENARIOS):
        init=A08.A07.A06.A05.programs_for_scenario(initial,s); probes.append(memory_probes(a08m['scenarios'][s],freeze_commit,env['schedules'][s],env['seeds'][s],init,stress['scenarios'][s]))
    probes_pass=all(all(v for v in p.values()) for p in probes); controls=negative_controls()
    signals={"A08_TARGET_NOISE_FAMILY_UNCHANGED":a08sha==A08_MANIFEST_SHA256,"LEARNER_A_EXACT_12_OF_12":exactA==12,"LEARNER_B_EXACT_12_OF_12":exactB==12,
             "LEARNER_PAIRS_AGREE_12_OF_12":agree==12,"HELDOUT_120_OF_120":held==120,"PROGRAM_COMMITS_12_OF_12":commits==12,"TASK_ACCURACY_ONE":incorrect==0 and served==correct,
             "ZERO_INCORRECT_SERVED":incorrect==0,"ZERO_STALE_PROGRAM_SERVED":stale==0,"MIGRATION_INHERITANCE_EXERCISED":mig>=1,"ALL_MEMORY_STRESS_EVENTS_EXECUTED":stress_ok,
             "UNIQUE_CAUSAL_OBSERVATIONS_66_PER_SCENARIO":unique66,"PHYSICAL_REPLICATION_PRESENT":physical_dup,"ZERO_IRRECOVERABLE_MEMORY_LOSS":irrecoverable==0,"REPLICATION_REPAIR_EXERCISED":repairs>=1,
             "DISTRIBUTED_MEMORY_PROBES_PASS":probes_pass,"UNSAFE_CONTROLS_EXPOSED":all(controls[k] for k in ('COPY_COUNT_FALSE_AUTHORITY_REACHABLE','HOLDER_COUNT_FALSE_PROVENANCE_REACHABLE','CENTRAL_LEDGER_WOULD_HIDE_PHYSICAL_LOSS','NO_CENTRAL_LEDGER_FALLBACK')),
             "ALL_RESTARTS_EQUIVALENT":restart==0,"ZERO_EXISTING_SAFETY_VIOLATIONS":all(v==0 for v in safety.values()),"PARTITION_REMERGE_COMPLETE":all(x['dynamic_remerge_count']==1 and x['final_provisional_count']==0 for x in summaries)}
    signals['A09_DISTRIBUTED_CELLULAR_TRAINING_MEMORY_SUCCESS']=all(signals.values())
    return {"schema":"yggdrasil.training-t2b.a09-distributed-cellular-memory.v1","freeze_commit":freeze_commit,"a08_training_manifest_sha256":a08sha,"stress_manifest_sha256":stress_sha,"stress_manifest":stress,"dependencies":deps,"scenarios":summaries,
            "aggregate":{"total_requests":total,"candidate_served":served,"candidate_correct":correct,"candidate_incorrect":incorrect,"learner_A_exact":exactA,"learner_B_exact":exactB,"learner_pairs_agree":agree,"heldout_predictions_correct":held,"program_commits":commits,"migration_program_inheritances":mig,"stale_program_served_requests":stale,"restart_mismatches":restart,"irrecoverable_memory_loss":irrecoverable,"replication_repairs":repairs,"safety_totals":safety},
            "task_output_sha256":h256(enc(outputs).encode()),"memory_probes":probes,"negative_controls":controls,"signals":signals,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def validate():
    deps=verify_dependencies(); a08m,a08sha=A08.training_manifest(A08_FREEZE); assert a08sha==A08_MANIFEST_SHA256
    stress,sha=stress_manifest('MECHANICAL-NONPRIMARY-FREEZE'); assert len(stress['scenarios'])==12
    for s,x in enumerate(stress['scenarios']):
        start=a08m['scenarios'][s]['training_start']
        assert start+3<=x['damage_a_epoch']<=start+7; assert start+13<=x['damage_b_epoch']<=start+17
        assert start+5<=x['hibernation_start']<=start+9 and 4<=x['hibernation_duration']<=6
        assert start+10<=x['copy_delete_epoch']<=start+16; assert start+12<=x['cell_replacement_epoch']<=start+18
    return {"dependencies":deps,"a08_manifest_sha256":a08sha,"mechanical_stress_manifest_sha256":sha,"central_evidence_ledger":False,"neighborhoods":NEIGHBORHOODS,"mechanical_primary_executed":False,"canonical_scientific_execution":False,"stab18_r1_touched":False}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--freeze-commit'); ap.add_argument('--manifest-only',action='store_true'); ap.add_argument('--mechanical-only',action='store_true'); ap.add_argument('--out')
    args=ap.parse_args()
    if args.mechanical_only: print(enc({"mechanical_valid":True,"mechanical":validate()})); return
    if not args.freeze_commit: raise SystemExit('--freeze-commit required')
    if args.manifest_only:
        m,sha=stress_manifest(args.freeze_commit); print(enc({"freeze_commit":args.freeze_commit,"stress_manifest_sha256":sha,"stress_manifest":m})); return
    if not args.out: raise SystemExit('--out required')
    obj=run_primary(args.freeze_commit); raw=(enc(obj)+'\n').encode(); Path(args.out).write_bytes(raw)
    print(enc({"output":args.out,"sha256":h256(raw),"stress_manifest_sha256":obj['stress_manifest_sha256'],"aggregate":obj['aggregate'],"signals":obj['signals']}))

if __name__=='__main__': main()
