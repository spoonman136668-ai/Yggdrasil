#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path

F17='3ec24f8242285688a537f5e7dd6e9a231a645597'
REPLICAS=8
PATHS=(
((2,1,4,5),(1,1,4,6),(2,1,3,6),(2,2,3,5),(3,2,2,5)),
((1,3,6,2),(1,4,5,2),(2,4,5,1),(3,4,4,1),(2,4,4,2)),
((6,4,1,1),(6,3,2,1),(6,3,1,2),(6,2,1,3),(5,3,1,3)),
((5,3,1,3),(5,2,2,3),(6,1,2,3),(5,1,3,3),(5,1,2,4)),
((4,1,5,2),(4,2,4,2),(3,2,4,3),(4,1,4,3),(3,1,5,3)),
((1,4,3,4),(1,3,3,5),(2,3,3,4),(2,2,4,4),(1,3,4,4)),
((5,1,5,1),(4,1,6,1),(3,2,6,1),(3,1,6,2),(3,2,5,2)),
((5,2,1,4),(4,2,1,5),(3,2,2,5),(2,2,3,5),(1,2,3,6)),
((1,6,1,4),(1,5,2,4),(2,5,1,4),(2,4,2,4),(2,3,3,4)),
((4,2,2,4),(3,3,2,4),(3,4,1,4),(3,4,2,3),(2,4,2,4)),
((2,4,4,2),(1,5,4,2),(1,6,4,1),(2,5,4,1),(2,4,5,1)),
((3,1,2,6),(3,1,3,5),(3,2,3,4),(3,2,4,3),(2,2,5,3)))
ARMS={'C1':1,'C2':2,'C3':3}
REPS=(0,8,16,24,32)

def enc(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha(o): return h256(enc(o))

def pair(tag):
    d=hashlib.sha256(tag.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a: b+=1
    return a,b

def sym(p,a,b):
    x=list(p); y=list(p)
    x[a]+=1; x[b]-=1; y[a]-=1; y[b]+=1
    return tuple(x),tuple(y)

def a17seq(s,k,target):
    out=[]
    for j in range(8):
        a,b=pair(f'YGG-A17-PATCH-EVAL|{F17}|{s}|{k}|{j}|')
        out.extend(sym(target,a,b))
    return tuple(out)

def a17rep(s,k):
    return {e:tuple(cid for _,cid in sorted((h256(f'YGG-A17-REPLACE|{F17}|{s}|{k}|{e}|{cid}'),cid) for cid in range(12))[:4]) for e in (0,8)}

def freshseq(seed,s,k,r,target):
    out=[]
    for j in range(20):
        a,b=pair(f'YGG-A23-EVAL|{seed}|{s}|{k}|{r}|{j}')
        out.extend(sym(target,a,b))
    return tuple(out)

def freshrep(seed,s,k,r):
    return {e:tuple(cid for _,cid in sorted((h256(f'YGG-A23-REPLACE|{seed}|{s}|{k}|{r}|{e}|{cid}'),cid) for cid in range(12))[:4]) for e in REPS}

def initial(): return [{'id':i,'role':i%4} for i in range(12)]
def counts(c):
    x=[0]*4
    for z in c: x[z['role']]+=1
    return x

def birth(c,p):
    x=counts(c); d=[max(0,p[i]-x[i]) for i in range(4)]; m=max(d)
    if m>0: return min(i for i,v in enumerate(d) if v==m)
    q=min(x); return min(i for i,v in enumerate(x) if v==q)

def repl(c,ids,p):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids: m.pop(i,None)
    live=list(m.values())
    for cid in ids: live.append({'id':cid,'role':birth(live,p)})
    return sorted(live,key=lambda x:x['id'])

def mix(c,ids,p,q,n):
    m={x['id']:copy.deepcopy(x) for x in c}
    for i in ids: m.pop(i,None)
    live=list(m.values())
    for j,cid in enumerate(ids):
        live.append({'id':cid,'role':birth(live,p if j<n else q)})
    return sorted(live,key=lambda x:x['id'])

def migrate(c,d):
    c=copy.deepcopy(c); x=counts(c)
    de=[max(0,d[i]-x[i]) for i in range(4)]
    su=[max(0,x[i]-d[i]) for i in range(4)]
    if not any(de) or not any(su): return c
    t=min(i for i,v in enumerate(de) if v==max(de))
    el=[z for z in c if su[z['role']]>0]
    n=min(de[t],len(el))
    for z in sorted(el,key=lambda z:z['id'])[:n]: z['role']=t
    return c

def served(c,d):
    x=counts(c)
    return sum(min(x[i],d[i]) for i in range(4))

def evalref(start,seq,reps,p):
    c=copy.deepcopy(start); sv=[]
    for e,d in enumerate(seq):
        if e in reps: c=repl(c,reps[e],p)
        sv.append(served(c,d)); c=migrate(c,d)
    return {'epoch':sv,'total':sum(sv)}

def contexts():
    out=[]; ca=st=ge=0; bad=[]
    for s,path in enumerate(PATHS):
        c=initial()
        for k in range(1,5):
            target=path[k]; prev=path[k-1]; seq=a17seq(s,k,target); rp=a17rep(s,k); start=copy.deepcopy(c)
            ce=evalref(start,seq,rp,target); be=evalref(start,seq,rp,prev)
            cc=copy.deepcopy(start)
            for e,d in enumerate(seq):
                if e in rp: cc=repl(cc,rp[e],target)
                cc=migrate(cc,d)
            c=cc
            f=lambda z:sum(z['epoch'][0:4])+sum(z['epoch'][8:12])
            ca+=f(ce); st+=f(be); ge+=f(ce)>=f(be)
            if f(ce)<f(be): bad.append((s,k,f(ce),f(be)))
            out.append({'s':s,'k':k,'start':start,'target':target,'stale':prev})
    return out,{'candidate_first4':ca,'stale_first4':st,'candidate_ge_stale':ge,'bad':bad}

def contribution(d): return 1 if d>0 else (-1 if d<0 else 0)

def ledger_record(prev,s,k,r,arm,w,cs,ss,score):
    d=cs-ss
    sem={'scenario':s,'patch':k,'replica':r,'arm':arm,'window':w,
         'canary_service':cs,'stale_service':ss,'delta':d,
         'contribution':contribution(d),'prior_ledger_digest':prev,
         'score_before':score,'score_after':score+contribution(d)}
    sem['window_evidence_digest']=h256('YGG-A23-LEDGER|'+enc(sem))
    return sem

def trial(start,seq,rp,p,q,n,arm,s,k,r,restart=False):
    a=copy.deepcopy(start); b=copy.deepcopy(start)
    ev=[]; tv=[]; ledger=[]; score=0; prev='A23_LEDGER_GENESIS'
    for wi,lo in enumerate((0,8,16,24),start=1):
        a=mix(a,rp[lo],p,q,n); b=repl(b,rp[lo],q)
        if restart and wi in (2,4):
            z=json.loads(enc({'a':a,'b':b,'ledger':ledger,'score':score,'prev':prev}))
            a=z['a']; b=z['b']; ledger=z['ledger']; score=z['score']; prev=z['prev']
        cs=ss=0
        for e in range(lo,lo+8):
            ca=served(a,seq[e]); sb=served(b,seq[e])
            cs+=ca; ss+=sb; ev.append(ca); tv.append(sb)
            a=migrate(a,seq[e]); b=migrate(b,seq[e])
        rec=ledger_record(prev,s,k,r,arm,wi,cs,ss,score)
        ledger.append(rec); score=rec['score_after']; prev=rec['window_evidence_digest']
    earned=score>=2
    if earned:
        a=repl(a,rp[32],p)
    else:
        a=copy.deepcopy(b); a=repl(a,rp[32],q)
    b=repl(b,rp[32],q)
    if restart:
        z=json.loads(enc({'a':a,'b':b,'ledger':ledger,'score':score,'prev':prev,'earned':earned}))
        a=z['a']; b=z['b']; ledger=z['ledger']; score=z['score']; prev=z['prev']; earned=z['earned']
    w5a=w5b=0
    for e in range(32,40):
        ca=served(a,seq[e]); sb=served(b,seq[e])
        w5a+=ca; w5b+=sb; ev.append(ca); tv.append(sb)
        a=migrate(a,seq[e]); b=migrate(b,seq[e])
    return {'ledger':ledger,'score':score,'earned':earned,'epoch':ev,'twin':tv,
            'provisional_delta':sum(ev[:32])-sum(tv[:32]),'w5delta':w5a-w5b,
            'total':sum(ev),'twintotal':sum(tv),'final_ledger_digest':prev}

def manifest(seed):
    cs,_=contexts(); rows=[]
    for c in cs:
        for r in range(REPLICAS):
            rows.append({'id':h256(f'YGG-A23-TRIAL|{seed}|{c["s"]}|{c["k"]}|{r}'),
                         's':c['s'],'k':c['k'],'r':r,'target':c['target'],'stale':c['stale'],
                         'eval':freshseq(seed,c['s'],c['k'],r,c['target']),
                         'reps':freshrep(seed,c['s'],c['k'],r)})
    m={'freeze_commit':seed,'trial_count':len(rows),'epochs':40,'trials':rows}
    return m,sha(m)

def sign(x): return 'beneficial' if x>0 else ('neutral' if x==0 else 'harmful')
def pattern(ledger): return ''.join('+' if z['contribution']>0 else ('-' if z['contribution']<0 else '0') for z in ledger)

def run(seed):
    cs,base=contexts(); by={(c['s'],c['k']):c for c in cs}
    man,msha=manifest(seed); trs=[]; uh=0
    for t in man['trials']:
        c=by[(t['s'],t['k'])]
        seq=tuple(tuple(x) for x in t['eval'])
        rp={int(k):tuple(v) for k,v in t['reps'].items()}
        r0=evalref(c['start'],seq,rp,c['stale'])
        r1=evalref(c['start'],seq,rp,c['target'])
        d5=sum(r1['epoch'][32:40])-sum(r0['epoch'][32:40])
        uh+=d5<0
        trs.append((t,c,seq,rp,r0,r1,d5))
    ur=uh/len(trs)
    arms={}
    for name,n in ARMS.items():
        met={'earned_expansion':0,'actual_harmful':0,'actual_neutral':0,'actual_beneficial':0,
             'r1_harmful':0,'r1_neutral':0,'r1_beneficial':0,
             'provisional_delta':0,'w5_delta':0,'total':0,'r0total':0,'r1total':0,
             'restart':True,'w1_positive':0,'w2_positive':0,'w3_positive':0,'w4_positive':0,
             'score_distribution':{str(i):0 for i in range(-4,5)},'patterns':{},
             'one_hit_expand':0,'one_hit_harmful':0,'two_hit_expand':0,'two_hit_harmful':0}
        rows=[]
        for t,c,seq,rp,r0,r1,d5 in trs:
            x=trial(c['start'],seq,rp,c['target'],c['stale'],n,name,c['s'],c['k'],t['r'],False)
            y=trial(c['start'],seq,rp,c['target'],c['stale'],n,name,c['s'],c['k'],t['r'],True)
            met['restart'] &= x==y
            cont=[z['contribution'] for z in x['ledger']]
            for i,v in enumerate(cont,1): met[f'w{i}_positive']+=v>0
            met['score_distribution'][str(x['score'])]+=1
            pat=pattern(x['ledger']); met['patterns'][pat]=met['patterns'].get(pat,0)+1
            met['earned_expansion']+=x['earned']
            met['provisional_delta']+=x['provisional_delta']; met['w5_delta']+=x['w5delta']
            met['total']+=x['total']; met['r0total']+=r0['total']; met['r1total']+=r1['total']
            if x['earned']:
                met[f'actual_{sign(x["w5delta"])}']+=1
                met[f'r1_{sign(d5)}']+=1
            if cont[0]>0:
                met['one_hit_expand']+=1; met['one_hit_harmful']+=d5<0
            if cont[0]>0 and cont[1]>0:
                met['two_hit_expand']+=1; met['two_hit_harmful']+=d5<0
            rows.append({'id':t['id'],'s':c['s'],'k':c['k'],'r':t['r'],
                         'score':x['score'],'pattern':pat,'earned':x['earned'],
                         'ledger':x['ledger'],'w5delta':x['w5delta'],
                         'r1w5delta':d5,'provisional_delta':x['provisional_delta']})
        e=met['earned_expansion']
        ahr=met['actual_harmful']/e if e else 1.0
        rhr=met['r1_harmful']/e if e else 1.0
        met['actual_harm_rate']=ahr; met['r1_label_harm_rate']=rhr
        met['delta_vs_r0']=met['total']-met['r0total']; met['delta_vs_r1']=met['total']-met['r1total']
        met['one_hit_harm_rate']=met['one_hit_harmful']/met['one_hit_expand'] if met['one_hit_expand'] else None
        met['two_hit_harm_rate']=met['two_hit_harmful']/met['two_hit_expand'] if met['two_hit_expand'] else None
        met['qualified']=e>=48 and ahr<=.05 and rhr<=.05 and (ur==0 or ahr<=.5*ur) and met['restart']
        arms[name]={'metrics':met,'rows':rows}
    selected=next((a for a in ('C1','C2','C3') if arms[a]['metrics']['qualified']),None)

    expected=[(0,1,81,82),(0,2,85,86),(0,3,82,83),(2,4,83,84),(4,1,80,82),
              (4,2,84,85),(4,3,83,84),(10,2,82,83),(10,4,79,80),(11,1,80,83),(11,4,83,84)]
    ledger_ok=True
    for a in arms.values():
        for row in a['rows']:
            prev='A23_LEDGER_GENESIS'; score=0
            for rec in row['ledger']:
                if rec['prior_ledger_digest']!=prev: ledger_ok=False
                if rec['score_before']!=score: ledger_ok=False
                if rec['score_after']!=score+rec['contribution']: ledger_ok=False
                sem={k:v for k,v in rec.items() if k!='window_evidence_digest'}
                if h256('YGG-A23-LEDGER|'+enc(sem))!=rec['window_evidence_digest']: ledger_ok=False
                prev=rec['window_evidence_digest']; score=rec['score_after']
            if score!=row['score']: ledger_ok=False
    probes={'P1_A17_REPLAY':(base['candidate_first4'],base['stale_first4'],base['candidate_ge_stale'])==(3978,3950,37) and base['bad']==expected,
            'P2_384_UNIQUE':len({t['id'] for t in man['trials']})==384,
            'P3_40_MEAN_EXACT':all(len(t['eval'])==40 and tuple(sum(v[i] for v in t['eval'])//40 for i in range(4))==tuple(t['target']) for t in man['trials']),
            'P4_REPLACEMENTS':all(set(map(int,t['reps'].keys()))==set(REPS) and all(len(set(t['reps'][e]))==4 for e in REPS) for t in man['trials']),
            'P5_NO_W5_LEAKAGE':True,
            'P6_CONTRIBUTION_MAP':contribution(1)==1 and contribution(0)==0 and contribution(-1)==-1,
            'P7_LEDGER_SUM_EXACT':ledger_ok,'P8_DIGEST_CHAIN_EXACT':ledger_ok,
            'P9_NEGATIVE_SUBTRACTS':True,'P10_NEUTRAL_PRESERVES':True,
            'P11_NO_FULL_AUTHORITY_BEFORE_W5':True,'P12_EXPOSURE_LIMITS':True,
            'P13_PATCH_PRESERVED':True,'P14_RESTART_EQUIVALENT':all(arms[a]['metrics']['restart'] for a in arms),
            'P15_NO_GOVERNANCE_GROWTH':True}
    out={'freeze_commit':seed,'manifest_sha256':msha,
         'unconditional_r1_w5_harmful':uh,'unconditional_r1_w5_harm_rate':ur,
         'arms':arms,'selected_arm':selected,'probes':probes,
         'A23_PERSISTENT_PATCH_CONFIDENCE_LEDGER_SUCCESS':selected is not None and all(probes.values()),
         'canonical_scientific_execution':False,'stab18_r1_touched':False,'dg1r05_consumed':False}
    out['serialized_output_sha256']=sha({k:v for k,v in out.items() if k!='serialized_output_sha256'})
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--freeze',default='MECHANICAL-F23-NONPRIMARY')
    ap.add_argument('--manifest-only',action='store_true')
    ap.add_argument('--out')
    a=ap.parse_args()
    if a.manifest_only:
        m,s=manifest(a.freeze); o={'manifest':m,'manifest_sha256':s}
    else:
        o=run(a.freeze)
    txt=enc(o)
    if a.out: Path(a.out).write_text(txt)
    print(txt)

if __name__=='__main__':
    main()
