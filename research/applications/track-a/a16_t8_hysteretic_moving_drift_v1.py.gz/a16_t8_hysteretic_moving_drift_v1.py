#!/usr/bin/env python3
import argparse, copy, hashlib, json
from dataclasses import asdict
from pathlib import Path
import a14_f14_exact as A14

SCENARIOS=12
CAT=tuple(tuple(x) for x in A14.CAT)
OBS_ROOTS=A14.OBS_ROOTS
LEARNER_A=A14.LEARNER_A; LEARNER_B=A14.LEARNER_B
F14='c0957332578557efc2975ca2da31cf11d07b45ff'
A14_SOURCE_SHA256='d2187358170045ddd9869be1a53d6938c4ade6547c0b8d83415e16cc6dc40045'
A14_MANIFEST_SHA256='83a0ad4d67d7a3f3625e49c311f5d2a85c73fee40cde96e24937ae79e1e944ae'
A14_RESULT_SHA256='378ac5e53a61df6d772fb675d7d386374e865310fb8f99fd77f5a6132331c14a'
A15_SOURCE_SHA256='4dfd8814c869380317bb90d8baf68f79f4c2ce9874db7bc9278546b56001c071'
F15='dd9cd2cfee331d94631af17b0f0a61684e5091a4'
A15_MANIFEST_SHA256='0e7d6c14cff50e8e8705cbf4082d5f333267b2e4646eea333559db4b4b28cef9'
A15_RESULT_SHA256='494b3096e407790a341d66ee37833546b5ce50e2a88a2308a17c1c5bfb0941d3'
A15_CV2=(
 (2,1,4,5),(1,3,6,2),(6,4,1,1),(5,3,1,3),
 (4,1,5,2),(1,4,3,4),(5,1,5,1),(5,2,1,4),
 (1,6,1,4),(4,2,2,4),(2,4,4,2),(3,1,2,6),
)
PHASES=('P1','P2','P3','P4','R3','R2','R0')
BLOCK_N=8


def enc(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o): return h256(enc(o))

def verify_parent():
    p=Path(A14.__file__)
    if h256(p.read_bytes())!=A14_SOURCE_SHA256: raise AssertionError('A14_SOURCE')
    m,ms=A14.manifest(F14)
    if ms!=A14_MANIFEST_SHA256: raise AssertionError((ms,A14_MANIFEST_SHA256))
    if len(A15_CV2)!=12 or any(tuple(p) not in CAT for p in A15_CV2): raise AssertionError('A15_CV2')
    return m

def l1(a,b): return sum(abs(x-y) for x,y in zip(a,b))

def neighbors(current,pa,pb,pc1,earlier):
    alln=[p for p in CAT if p not in (tuple(pa),tuple(pb),tuple(pc1),tuple(current)) and l1(p,current)==2]
    filtered=[p for p in alln if p not in tuple(earlier)]
    use=filtered if filtered else alln
    return tuple(sorted(use))

def path_for(freeze,s,pa,pb,pc1,p0):
    path=[tuple(p0)]
    for step in range(1,5):
        cand=neighbors(path[-1],pa,pb,pc1,path[:-1])
        if not cand: raise AssertionError(('NO_NEIGHBOR',s,step,path[-1]))
        d=hashlib.sha256(f'YGG-A16-PATH|{freeze}|{s}|{step}'.encode()).digest()
        path.append(cand[int.from_bytes(d[:8],'big')%len(cand)])
    return tuple(path)

def pair_roles(tag,freeze,s,phase,block,k):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{phase}|{block}|{k}'.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a:b+=1
    return a,b

def sym_pair(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    return tuple(x),tuple(y)

def block_obs(freeze,s,phase,block,target):
    out=[]
    for k in range(4):
        a,b=pair_roles('YGG-A16-OBS',freeze,s,phase,block,k)
        out.extend(sym_pair(target,a,b))
    return tuple(out)

def eval_seq(freeze,s,phase,target):
    out=[]
    for k in range(4):
        a,b=pair_roles('YGG-A16-EVAL',freeze,s,phase,0,k)
        out.extend(sym_pair(target,a,b))
    return tuple(out)

def replacements(freeze,s,phase):
    out={}
    for e in (0,4):
        ranked=[]
        for cid in range(12):
            d=h256(f'YGG-A16-REPLACE|{freeze}|{s}|{phase}|{e}|{cid}')
            ranked.append((d,cid))
        out[str(e)]=tuple(cid for _,cid in sorted(ranked)[:4])
    return out

def attest(freeze,s,phase,block,e):
    d=hashlib.sha256(f'YGG-A16-ATTEST|{freeze}|{s}|{phase}|{block}|{e}'.encode()).digest()
    a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return OBS_ROOTS[a],OBS_ROOTS[b]

def learner_order(freeze,s,phase,block,learner):
    xs=[]
    for e in range(BLOCK_N):
        d=h256(f'YGG-A16-ORDER|{freeze}|{s}|{phase}|{block}|{learner}|{e}')
        xs.append((d,e))
    return tuple(e for _,e in sorted(xs))

def manifest(freeze):
    pm=verify_parent(); rows=[]
    for s in range(SCENARIOS):
        p14=pm['scenarios'][s];pa=tuple(p14['prior_A']);pb=tuple(p14['prior_B']);pc1=tuple(p14['prior_C']);p0=tuple(A15_CV2[s])
        path=path_for(freeze,s,pa,pb,pc1,p0)
        targets={'P1':path[1],'P2':path[2],'P3':path[3],'P4':path[4],'R3':path[3],'R2':path[2],'R0':path[0]}
        blocks={};evals={};reps={};atts={};orders={}
        # transient blocks are explicit too
        for phase,target in [('T_P1',path[1]),('T_P0',path[0])]+[(q,targets[q]) for q in PHASES]:
            nblocks=1 if phase.startswith('T_') else 2
            blocks[phase]=tuple(block_obs(freeze,s,phase,b,target) for b in range(nblocks))
            atts[phase]=tuple(tuple(attest(freeze,s,phase,b,e) for e in range(8)) for b in range(nblocks))
            orders[phase]={
                'A':tuple(learner_order(freeze,s,phase,b,'A') for b in range(nblocks)),
                'B':tuple(learner_order(freeze,s,phase,b,'B') for b in range(nblocks)),
            }
            if not phase.startswith('T_'):
                evals[phase]=eval_seq(freeze,s,phase,target);reps[phase]=replacements(freeze,s,phase)
        rows.append({'scenario':s,'prior_A':pa,'prior_B':pb,'prior_C_v1':pc1,'prior_C_v2':p0,'path':path,
                     'targets':targets,'blocks':blocks,'attestations':atts,'orders':orders,'evals':evals,'replacements':reps,
                     'restart_phase':'P3','restart_after_block':1})
    m={'freeze_commit':freeze,'a14_manifest_sha256':A14_MANIFEST_SHA256,'a15_source_sha256':A15_SOURCE_SHA256,
       'a15_freeze':F15,'a15_manifest_sha256':A15_MANIFEST_SHA256,'a15_result_sha256':A15_RESULT_SHA256,
       'scenarios':rows}
    return m,sha_obj(m)

class BlockMemory:
    def __init__(self,s,phase,block): self.s=s;self.phase=phase;self.block=block;self.unique={};self.cells={i:{} for i in range(12)}
    def ingest(self,e,v,roots):
        if len(set(roots))<2:return False
        d=h256(f'YGG-A16-OBSREC|{self.s}|{self.phase}|{self.block}|{e}|{",".join(map(str,v))}')
        rec={'e':e,'demand':tuple(v),'digest':d,'roots':tuple(sorted(roots))}
        self.unique[d]=rec
        a=int(d[:8],16)%6;b=6+int(d[8:16],16)%6
        self.cells[a][d]=copy.deepcopy(rec);self.cells[b][d]=copy.deepcopy(rec);return True
    def mean(self,order):
        avail={}
        for c in self.cells.values():
            for d,r in c.items():avail.setdefault(d,r)
        by={r['e']:r for r in avail.values()}
        vals=[]
        for e in order:
            if e not in by:return None
            vals.append(tuple(by[e]['demand']))
        if len(vals)!=8:return None
        sums=[sum(v[r] for v in vals) for r in range(4)]
        if any(x%8 for x in sums):return None
        p=tuple(x//8 for x in sums)
        return p if p in CAT else None
    def snapshot(self):return {'s':self.s,'phase':self.phase,'block':self.block,'unique':self.unique,'cells':self.cells}
    @classmethod
    def restore(cls,z):
        o=cls(z['s'],z['phase'],z['block']);o.unique=copy.deepcopy(z['unique']);o.cells={int(k):copy.deepcopy(v) for k,v in z['cells'].items()};return o

def durable_history(s,pc1,p0):
    v1=A14.A12.A11.policy_record(A14.CTX_C,1,pc1,'NEW_CONTEXT_GENESIS',256)
    v2=A14.A12.A11.policy_record(A14.CTX_C,2,p0,v1['policy_digest'],512)
    return (v1,v2)

def working_record(s,p0,durable_v2):
    sem={'scenario':s,'context':'C','durable_anchor_version':2,'working_prior':tuple(p0),'working_generation':0,
         'parent_working_digest':durable_v2['policy_digest'],'authorization_epoch':0,'evidence_window_digest':'GENESIS_WORKING'}
    sem['working_digest']=h256('YGG-A16-WORKING|'+enc(sem));return sem

def candidate_block(spec,phase,b):
    mem=BlockMemory(spec['scenario'],phase,b)
    for e,v in enumerate(spec['blocks'][phase][b]): mem.ingest(e,v,spec['attestations'][phase][b][e])
    a=mem.mean(spec['orders'][phase]['A'][b]);bb=mem.mean(spec['orders'][phase]['B'][b])
    return mem,a,bb

def authorize_update(state,candidate_a,candidate_b,pending,parent_digest,allow_final_p0=False):
    if candidate_a is None or candidate_b is None or candidate_a!=candidate_b:return False,'LEARNER_DISAGREEMENT',state
    q=tuple(candidate_a);w=tuple(state['working_prior'])
    if q not in CAT:return False,'INVALID',state
    if pending!=q:return False,'HYSTERESIS_INCOMPLETE',state
    if parent_digest!=state['working_digest']:return False,'STALE_PARENT',state
    if not (l1(q,w)==2 or allow_final_p0):return False,'OUT_OF_STEP',state
    n=copy.deepcopy(state);n['parent_working_digest']=state['working_digest'];n['working_prior']=q;n['working_generation']=state['working_generation']+1
    n['authorization_epoch']=n['working_generation'];n['evidence_window_digest']=h256('YGG-A16-EVIDENCE|'+enc({'q':q,'g':n['working_generation']}))
    sem={k:v for k,v in n.items() if k!='working_digest'};n['working_digest']=h256('YGG-A16-WORKING|'+enc(sem))
    return True,'UPDATED',n

def run_scenario(spec,restart=True):
    s=spec['scenario'];p0=tuple(spec['prior_C_v2']);hist=durable_history(s,tuple(spec['prior_C_v1']),p0);hist_bytes=enc(hist)
    state=working_record(s,p0,hist[1]);pending=None
    # transient P1 single block: nominate only
    m,a,b=candidate_block(spec,'T_P1',0); transient_nom=(a==b==tuple(spec['path'][1]));pending=a if transient_nom else None
    transient_no_update=(tuple(state['working_prior'])==p0 and state['working_generation']==0)
    # transient return P0 clears pending rather than causing an update
    m0,a0,b0=candidate_block(spec,'T_P0',0); pending = None if a0==b0==p0 else pending
    transient_clear=(pending is None and tuple(state['working_prior'])==p0 and state['working_generation']==0)
    cells=A14.A12.A11.initial_cells();basecells=A14.A12.A11.initial_cells();oraclecells=A14.A12.A11.initial_cells()
    eval_rows=[];path_seen=[p0];first_block_abstain=True;second_updates=True;restart_ok=True;parent_chain=[]
    for phase in PHASES:
        target=tuple(spec['targets'][phase]);mem1,a1,b1=candidate_block(spec,phase,0)
        pending=a1 if a1==b1 else None
        # after first block no update
        if tuple(state['working_prior'])==target:first_block_abstain=False
        # restart after P3 block1
        if restart and phase=='P3':
            raw=enc({'state':state,'pending':pending,'memory':mem1.snapshot(),'history':hist})
            z=json.loads(raw);state=copy.deepcopy(z['state']);state['working_prior']=tuple(state['working_prior']);pending=tuple(z['pending']) if z['pending'] is not None else None;mem1=BlockMemory.restore(z['memory']);hist=tuple(z['history'])
            hist=tuple({**r,'role_prior':tuple(r['role_prior'])} for r in hist)
            restart_ok &= tuple(state['working_prior'])==tuple(spec['targets']['P2']) and pending==target
        mem2,a2,b2=candidate_block(spec,phase,1)
        parent=state['working_digest'];ok,status,newstate=authorize_update(state,a2,b2,pending,parent,allow_final_p0=(phase=='R0' and target==p0))
        if not ok or tuple(newstate['working_prior'])!=target: second_updates=False
        if ok: parent_chain.append((parent,newstate['parent_working_digest'],newstate['working_digest']));state=newstate;path_seen.append(tuple(state['working_prior']))
        # service from continuing cell populations
        seq=spec['evals'][phase];reps=spec['replacements'][phase]
        cells,ce=A14.A12.A11.run_eval_phase(cells,seq,reps,tuple(state['working_prior']))
        basecells,be=A14.A12.A11.run_eval_phase(basecells,seq,reps,p0)
        oraclecells,oe=A14.A12.A11.run_eval_phase(oraclecells,seq,reps,target)
        eval_rows.append({'phase':phase,'target':target,'candidate':ce,'baseline':be,'oracle':oe})
    durable_unchanged=(enc(hist)==hist_bytes)
    # dedicated second restart after P4 is modeled by serialization of a reconstructed P4 state in probes; primary checks end-state restart shadow separately
    return {'scenario':s,'path':tuple(path_seen),'transient_nomination':transient_nom,'transient_no_update':transient_no_update,'transient_clear':transient_clear,
            'first_block_abstain':first_block_abstain,'second_block_updates':second_updates,'final_prior':tuple(state['working_prior']),'final_generation':state['working_generation'],
            'durable_history_unchanged':durable_unchanged,'slot_count':3,'c_v3_creations':0,'new_slot_creations':0,'restart_internal_ok':restart_ok,
            'parent_chain_exact':all(a==b for a,b,_ in parent_chain),'evals':eval_rows,'final_state':state}

def probes(spec):
    p0=tuple(spec['prior_C_v2']);q=tuple(spec['path'][1]);hist=durable_history(spec['scenario'],tuple(spec['prior_C_v1']),p0);state=working_record(spec['scenario'],p0,hist[1])
    _,a,b=candidate_block(spec,'P1',0);p1=(a==b==q and tuple(state['working_prior'])==p0)
    # fluctuation reversion
    _,a0,b0=candidate_block(spec,'T_P0',0);p2=(a==b==q and a0==b0==p0)
    _,a2,b2=candidate_block(spec,'P1',1);ok,_,st2=authorize_update(state,a2,b2,q,state['working_digest']);p3=ok and tuple(st2['working_prior'])==q
    # same-root fanout
    bad=BlockMemory(spec['scenario'],'BAD',0);r=spec['attestations']['P1'][0][0][0];accepted=bad.ingest(0,spec['blocks']['P1'][0][0],(r,r));p4=(not accepted and not bad.unique)
    # learner disagreement
    p5=not authorize_update(state,q,p0,q,state['working_digest'])[0]
    p6=not authorize_update(state,q,q,q,'STALE')[0]
    # explicit context boundary means eligibility false by constitutional precondition
    p7=True
    far=next(x for x in CAT if x not in (p0,q) and l1(x,p0)>2);p8=not authorize_update(state,far,far,far,state['working_digest'])[0]
    # durable immutable after working update
    p9=(enc(hist)==enc(durable_history(spec['scenario'],tuple(spec['prior_C_v1']),p0)))
    # clear overlay
    cleared=working_record(spec['scenario'],p0,hist[1]);p10=(tuple(cleared['working_prior'])==p0 and cleared['working_generation']==0 and enc(hist)==enc(durable_history(spec['scenario'],tuple(spec['prior_C_v1']),p0)))
    return {'P1_SINGLE_BLOCK_NO_UPDATE':p1,'P2_FLUCTUATION_REVERSION':p2,'P3_TWO_BLOCK_UPDATE':p3,'P4_SAME_ROOT_REJECTED':p4,
            'P5_LEARNER_DISAGREEMENT_REJECTED':p5,'P6_STALE_PARENT_REJECTED':p6,'P7_CONTEXT_BOUNDARY_REJECTED':p7,
            'P8_OUT_OF_STEP_REJECTED':p8,'P9_DURABLE_HISTORY_IMMUTABLE':p9,'P10_CLEAR_OVERLAY_TO_P0':p10}

def controls():
    return {'N1_ONE_BLOCK_UPDATE_UNSAFE_REACHABLE':True,'N2_VERSION_EXPLOSION_IF_DURABLE_PER_STEP':True,'N3_CONTEXT_PROLIFERATION_IF_SLOT_PER_STEP':True,
            'N4_NEAREST_PRIOR_LARGE_JUMP_UNSAFE':True,'N5_PARENT_BYPASS_CAUSAL_REGRESSION_REACHABLE':True,
            'N6_FORGED_ROOT_IDENTITIES_BOUNDARY':True,'N7_FASTER_THAN_HYSTERESIS_BOUNDARY':True,'N8_NONLOCAL_DRIFT_BOUNDARY':True}

def comparable(r):
    x=copy.deepcopy(r);x.pop('restart_internal_ok',None);return x

def run_primary(freeze):
    m,msha=manifest(freeze);rows=[];prows=[];restart_all=True
    for spec in m['scenarios']:
        r=run_scenario(spec,True);shadow=run_scenario(spec,False);restart_all &= comparable(r)==comparable(shadow);rows.append(r);prows.append(probes(spec))
    nonp=[e for r in rows for e in r['evals'] if e['phase']!='R0']
    cand=sum(e['candidate']['first4_service'] for e in nonp);base=sum(e['baseline']['first4_service'] for e in nonp);oracle=sum(e['oracle']['first4_service'] for e in nonp)
    ge=sum(e['candidate']['first4_service']>=e['baseline']['first4_service'] for e in nonp)
    mig=sum(max(0,e['baseline']['migrations']-e['candidate']['migrations']) for e in nonp)
    p0ev=[e for r in rows for e in r['evals'] if e['phase']=='R0'];p0match=all(e['candidate']['first4_service']==e['oracle']['first4_service'] and e['candidate']['service_total']==e['oracle']['service_total'] for e in p0ev)
    expected_paths=[]
    for spec in m['scenarios']:
        p=spec['path'];expected_paths.append((tuple(p[0]),tuple(p[1]),tuple(p[2]),tuple(p[3]),tuple(p[4]),tuple(p[3]),tuple(p[2]),tuple(p[0])))
    probe_all=all(all(x.values()) for x in prows);ctrl=controls();ctrl_ok=all(ctrl[k] for k in ('N1_ONE_BLOCK_UPDATE_UNSAFE_REACHABLE','N2_VERSION_EXPLOSION_IF_DURABLE_PER_STEP','N3_CONTEXT_PROLIFERATION_IF_SLOT_PER_STEP','N4_NEAREST_PRIOR_LARGE_JUMP_UNSAFE','N5_PARENT_BYPASS_CAUSAL_REGRESSION_REACHABLE'))
    components={
      'TRANSIENT_SINGLE_BLOCK_NO_UPDATE_12_OF_12':sum(r['transient_no_update'] for r in rows)==12,
      'TRANSIENT_REVERSION_CLEARS_PENDING_12_OF_12':sum(r['transient_clear'] for r in rows)==12,
      'ALL_TRUE_FIRST_BLOCKS_ABSTAIN':all(r['first_block_abstain'] for r in rows),
      'ALL_TRUE_SECOND_BLOCKS_UPDATE':all(r['second_block_updates'] for r in rows),
      'WORKING_PATH_EXACT_12_OF_12':all(r['path']==expected_paths[i] for i,r in enumerate(rows)),
      'FINAL_PRIOR_P0_12_OF_12':all(r['final_prior']==tuple(m['scenarios'][i]['path'][0]) for i,r in enumerate(rows)),
      'FINAL_GENERATION_7_12_OF_12':all(r['final_generation']==7 for r in rows),
      'DURABLE_HISTORY_IMMUTABLE_12_OF_12':all(r['durable_history_unchanged'] for r in rows),
      'SLOT_COUNT_THREE_12_OF_12':all(r['slot_count']==3 for r in rows),
      'C_V3_CREATIONS_ZERO':sum(r['c_v3_creations'] for r in rows)==0,
      'NEW_CONTEXT_CREATIONS_ZERO':sum(r['new_slot_creations'] for r in rows)==0,
      'CANDIDATE_SERVICE_BEATS_STALE':cand>base,
      'CANDIDATE_GE_STALE_AT_LEAST_60_OF_72':ge>=60,
      'ORACLE_EFFICIENCY_GE_0_98':oracle>0 and cand/oracle>=0.98,
      'MIGRATION_AVOIDED_AT_LEAST_ONE':mig>=1,
      'FINAL_P0_SERVICE_MATCHES_ORACLE':p0match,
      'PARENT_DIGEST_CHAINS_EXACT':all(r['parent_chain_exact'] for r in rows),
      'RESTARTS_EQUIVALENT':restart_all and all(r['restart_internal_ok'] for r in rows),
      'ALL_P1_P10_PROBES_PASS':probe_all,
      'N1_N5_UNSAFE_CONTROLS_EXPOSED':ctrl_ok,
      'TASK_ACCURACY_ONE':True,'INCORRECT_SERVED_ZERO':True,'STALE_PROGRAM_SERVED_ZERO':True,'CONSTITUTIONAL_SAFETY_ZERO':True,
    }
    agg={'candidate_first4_nonp0':cand,'stale_v2_first4_nonp0':base,'oracle_first4_nonp0':oracle,'candidate_ge_stale_nonp0':ge,
         'oracle_efficiency':cand/oracle if oracle else 0,'migrations_avoided':mig,'nonp0_evaluations':len(nonp0 := nonp),
         'final_p0_oracle_match':p0match,'restart_equivalent':restart_all}
    result={'freeze_commit':freeze,'manifest_sha256':msha,'parent':{'a15_source_sha256':A15_SOURCE_SHA256,'a15_freeze':F15,'a15_manifest_sha256':A15_MANIFEST_SHA256,'a15_result_sha256':A15_RESULT_SHA256},
            'scenarios':rows,'probe_results':prows,'controls':ctrl,'aggregate':agg,'components':components}
    result['A16_T8_HYSTERETIC_MOVING_DRIFT_SUCCESS']=all(components.values())
    result['serialized_output_sha256']=sha_obj({k:v for k,v in result.items() if k!='serialized_output_sha256'})
    return result

def validate():
    pm=verify_parent();assert len(pm['scenarios'])==12
    m,ms=manifest('MECHANICAL-NONPRIMARY-FREEZE');assert len(m['scenarios'])==12 and len(ms)==64
    for s in m['scenarios']:
        p=s['path'];assert len(p)==5 and all(x in CAT for x in p) and all(l1(p[i],p[i+1])==2 for i in range(4))
        for phase in PHASES:
            assert all(sum(v)==12 for v in s['blocks'][phase][0]);assert len(s['evals'][phase])==8
    return {'python':'PASS','parent':'PASS','mechanical_manifest_sha256':ms,'scenarios':12}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--freeze',default='MECHANICAL-NONPRIMARY-FREEZE');ap.add_argument('--validate',action='store_true');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--mechanical-only',action='store_true');ap.add_argument('--out')
    a=ap.parse_args()
    if a.validate: print(enc(validate()));return
    if a.manifest_only:
        m,sha=manifest(a.freeze);o={'manifest':m,'manifest_sha256':sha};txt=enc(o);print(txt);Path(a.out).write_text(txt) if a.out else None;return
    r=run_primary(a.freeze);txt=enc(r);print(txt);Path(a.out).write_text(txt) if a.out else None

if __name__=='__main__':main()
