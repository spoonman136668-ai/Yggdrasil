import hashlib, json, math, statistics, sys
from collections import Counter, defaultdict

N = 48
T = 48
POOL_DECAY_NUM = 3
POOL_DECAY_DEN = 4
SYNC_COMMIT = 80.0
SYNC_OPPOSITION_CEILING = 32.0
SYNC_POP_GATE = 24
LOCAL_R = 12
HILL_N = 3
HILL_K = 0.5
RECRUIT_R = 3
ETA = 0.5
POOL_NORM = 160.0

K_SUPP = 0.5
N_SUPP = 3

PRIMARY_WEIGHTS = {
    'D2_S_P75L25': (2, 0.75, 0.25, True, 3),
    'D2_S_P50L50': (2, 0.50, 0.50, True, 3),
    'D2_S_P25L75': (2, 0.25, 0.75, True, 3),
    'D3_S_P75L25': (3, 0.75, 0.25, True, 3),
    'D3_S_P50L50': (3, 0.50, 0.50, True, 3),
    'D3_S_P25L75': (3, 0.25, 0.75, True, 3),
}
REFERENCE_WEIGHTS = {
    'D2_U_P75L25': (2, 0.75, 0.25, False, 3),
    'D2_U_P50L50': (2, 0.50, 0.50, False, 3),
    'D2_U_P25L75': (2, 0.25, 0.75, False, 3),
    'D3_U_P75L25': (3, 0.75, 0.25, False, 3),
    'D3_U_P50L50': (3, 0.50, 0.50, False, 3),
    'D3_U_P25L75': (3, 0.25, 0.75, False, 3),
}
CONTROL_WEIGHTS = {
    'D3_LINEAR_P50L50': (3, 0.50, 0.50, True, 1),
}
ARMS = tuple(PRIMARY_WEIGHTS) + tuple(REFERENCE_WEIGHTS) + tuple(CONTROL_WEIGHTS)

def h64(*parts):
    s = '|'.join(str(x) for x in parts).encode()
    return int.from_bytes(hashlib.sha256(s).digest()[:8], 'big')

def u01(*parts):
    return h64(*parts) / float(2**64 - 1)


MASK64 = (1<<64)-1
def mix64(x):
    x = (x + 0x9E3779B97F4A7C15) & MASK64
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9 & MASK64
    x = (x ^ (x >> 27)) * 0x94D049BB133111EB & MASK64
    x ^= x >> 31
    return x & MASK64

def fast_u01(base, t, i, salt):
    x = base ^ ((t+1)*0xD6E8FEB86659FD93 & MASK64) ^ ((i+1)*0xA5A3564E27F8862D & MASK64) ^ salt
    return mix64(x) / float(MASK64)

def initial_states():
    st = ['U'] * N
    for i in range(N):
        if i % 4 == 0:
            st[i] = 'C'
        elif i % 4 == 2:
            st[i] = 'S'
    assert st.count('C') == 12 and st.count('S') == 12 and st.count('U') == 24
    return st

def sensor_noise(seed, ctx, rep, t, i):
    z = h64('YGG-A34-SENSOR', seed, ctx, rep, t, i) % 10
    if z == 0: return -1
    if z == 1: return 1
    return 0

def hetero(seed, ctx, rep, t, i):
    z = h64('YGG-A34-HET', seed, ctx, rep, t, i) % 20
    if z == 0: return -1
    if z == 1: return 1
    if z in (2,3,4): return 0
    return None

def make_world(seed, ctx, rep):
    fam = ctx // 8
    idx = ctx % 8
    true = [[0]*N for _ in range(T)]
    reversal = None
    local_region = None
    if fam == 2:
        sizes = [12,16,20,24,28,32,36,40]
        size = sizes[idx]
        start = h64('YGG-A34-SPATIAL', seed, ctx, rep) % N
        pos = {(start+j) % N for j in range(size)}
        local_region = [1 if i in pos else -1 for i in range(N)]
    elif fam in (3,4):
        reversal = [12,16,20,24,28,32,36,40][idx]
    for t in range(T):
        for i in range(N):
            if fam == 0:
                base = 1
            elif fam == 1:
                base = -1
            elif fam == 2:
                base = local_region[i]
            elif fam == 3:
                base = 1 if t < reversal else -1
            elif fam == 4:
                base = -1 if t < reversal else 1
            else:
                modes = [(2,2),(3,3),(4,4),(1,1),(6,2),(2,6),(5,3),(3,5)]
                on, off = modes[idx]
                if idx <= 3:
                    base = 1 if (t // on) % 2 == 0 else -1
                else:
                    cyc = on + off
                    q = t % cyc
                    base = 1 if q < on else -1
                    if idx in (5,7):
                        base = -base
            hv = hetero(seed, ctx, rep, t, i)
            if hv is None:
                v = base
            elif hv == 0:
                v = 0
            else:
                v = hv
            true[t][i] = max(-1, min(1, int(v)))
    sensed = [[0]*N for _ in range(T)]
    for t in range(T):
        for i in range(N):
            sensed[t][i] = max(-1, min(1, true[t][i] + sensor_noise(seed, ctx, rep, t, i)))
    return {
        'ctx':ctx,'rep':rep,'family':fam,'index':idx,
        'true':true,'sensed':sensed,'reversal':reversal,'local_region':local_region
    }

def sync_recruit_side(cp, sp, c_emit, s_emit):
    c_ok = cp >= SYNC_COMMIT and sp <= SYNC_OPPOSITION_CEILING and cp >= 2*sp and c_emit >= SYNC_POP_GATE
    s_ok = sp >= SYNC_COMMIT and cp <= SYNC_OPPOSITION_CEILING and sp >= 2*cp and s_emit >= SYNC_POP_GATE
    if c_ok and not s_ok:
        return 'C'
    if s_ok and not c_ok:
        return 'S'
    return None

def local_density(emitters, i, r):
    width = 2*r + 1
    return sum(1 for d in range(-r,r+1) if (i+d)%N in emitters) / width

def p_stay_from_density(d):
    if d <= 0:
        return 1.0
    x = d / HILL_K
    return 1.0 / (1.0 + x**HILL_N)

def majority_label(states):
    c = states.count('C')
    s = states.count('S')
    if c > N/2: return 'C'
    if s > N/2: return 'S'
    return 'U'

def state_counts(states):
    return {k:states.count(k) for k in ('C','S','U','FC','FS')}

def arm_params(arm):
    if arm in PRIMARY_WEIGHTS:
        return PRIMARY_WEIGHTS[arm]
    if arm in REFERENCE_WEIGHTS:
        return REFERENCE_WEIGHTS[arm]
    if arm in CONTROL_WEIGHTS:
        return CONTROL_WEIGHTS[arm]
    raise KeyError(arm)

def run_arm(seed, world, arm):
    ctx, rep = world['ctx'], world['rep']
    D, w_pool, w_local, use_supp, n_supp = arm_params(arm)
    arm_base = h64('YGG-A34-ARM-SEED', seed, ctx, rep, arm)
    states = initial_states()
    timers = [0]*N
    cp = sp = 0.0
    service = cumulative = worst_drawdown = 0
    majority_hist = []
    count_hist = []
    pool_hist = []
    contradiction = {'total':0,'nomajority':0,'cmajor':0,'smajor':0}
    transitions = Counter()
    chatter_sequences = defaultdict(list)
    epoch_joined = []
    post_join_records = []
    join_origin = {}
    recruitment_waves = []
    active_wave = None
    contr_lambda_c = contr_lambda_s = 0.0
    contr_eligible = 0
    contr_joins_c = contr_joins_s = 0
    contr_zero_join_epochs = 0
    noncontr_lambda_c = noncontr_lambda_s = 0.0
    noncontr_eligible = 0
    noncontr_joins_c = noncontr_joins_s = 0

    reversal = world['reversal']
    old_side = new_side = None
    if world['family'] == 3:
        old_side, new_side = 'C','S'
    elif world['family'] == 4:
        old_side, new_side = 'S','C'
    old_majority_seen = False
    old_loss = None
    new_acquire = None
    return_to_old = 0

    for t in range(T):
        sensed = world['sensed'][t]
        base_c = {i for i,v in enumerate(sensed) if v > 0}
        base_s = {i for i,v in enumerate(sensed) if v < 0}

        fb_c = fb_s = 0
        for i,s in enumerate(states):
            if s == 'C' and sensed[i] >= 0:
                fb_c += 1
            elif s == 'S' and sensed[i] <= 0:
                fb_s += 1

        cp = 0.75*cp + len(base_c) + fb_c
        sp = 0.75*sp + len(base_s) + fb_s

        # refractory release
        for i,s in enumerate(states):
            if s in ('FC','FS'):
                if timers[i] <= 0:
                    states[i] = 'U'
                    transitions[f'{s}->U'] += 1
                else:
                    timers[i] -= 1

        # local cross-inhibition
        prior = states[:]
        defects = []
        for i,s in enumerate(prior):
            if s == 'C':
                p = p_stay_from_density(local_density(base_s, i, LOCAL_R))
                if fast_u01(arm_base, t, i, 0x11C11C11C11C11C1) >= p:
                    defects.append((i,'C'))
            elif s == 'S':
                p = p_stay_from_density(local_density(base_c, i, LOCAL_R))
                if fast_u01(arm_base, t, i, 0x22C22C22C22C22C2) >= p:
                    defects.append((i,'S'))

        for i,side in defects:
            fs = 'FC' if side == 'C' else 'FS'
            states[i] = fs
            timers[i] = D
            transitions[f'{side}->{fs}'] += 1
            chatter_sequences[i].append((t,side,'DEFECT'))
            # post-join defection tracking
            if i in join_origin:
                jt, jside = join_origin[i]
                if jside == side and t > jt:
                    post_join_records.append((t-jt, side))

        joined_this_epoch = []
        eligible_before = [i for i,s in enumerate(states) if s == 'U']
        pool_bias = 'C' if cp > sp else ('S' if sp > cp else 'NONE')

        # A recruitment wave is anchored to the pool-biased side at onset.
        # It follows only the cells that were eligible at onset and ends
        # when the dominant pool direction reverses or the trial ends.
        if active_wave is not None:
            if pool_bias in ('C','S') and pool_bias != active_wave['bias']:
                recruitment_waves.append(active_wave)
                active_wave = None

        pc = min(1.0, cp / POOL_NORM)
        ps = min(1.0, sp / POOL_NORM)
        is_contradiction = cp >= 48 and sp >= 48
        joins_before = len(joined_this_epoch)
        epoch_lam_c = epoch_lam_s = 0.0
        epoch_eligible = 0
        for i in eligible_before:
            lc = local_density(base_c, i, RECRUIT_R)
            ls = local_density(base_s, i, RECRUIT_R)
            sup_c = w_pool*pc + w_local*lc
            sup_s = w_pool*ps + w_local*ls
            opp_c = w_pool*ps + w_local*ls
            opp_s = w_pool*pc + w_local*lc
            if use_supp:
                g_c = 1.0 / (1.0 + (opp_c / K_SUPP)**n_supp) if opp_c > 0 else 1.0
                g_s = 1.0 / (1.0 + (opp_s / K_SUPP)**n_supp) if opp_s > 0 else 1.0
            else:
                g_c = g_s = 1.0
            lam_c = ETA * sup_c * g_c
            lam_s = ETA * sup_s * g_s
            epoch_lam_c += lam_c
            epoch_lam_s += lam_s
            epoch_eligible += 1
            lam = lam_c + lam_s
            if lam <= 0:
                continue
            p_fire = 1.0 - math.exp(-lam)
            if fast_u01(arm_base, t, i, 0x33C33C33C33C33C3) >= p_fire:
                continue
            if lam_c <= 0:
                side = 'S'
            elif lam_s <= 0:
                side = 'C'
            else:
                side = 'C' if fast_u01(arm_base, t, i, 0x44C44C44C44C44C4) < lam_c/lam else 'S'
            states[i] = side
            transitions[f'U->{side}'] += 1
            chatter_sequences[i].append((t,side,'JOIN'))
            joined_this_epoch.append((i,side))
            join_origin[i] = (t,side)

        jc = sum(side == 'C' for _,side in joined_this_epoch)
        js = sum(side == 'S' for _,side in joined_this_epoch)
        if is_contradiction:
            contr_lambda_c += epoch_lam_c
            contr_lambda_s += epoch_lam_s
            contr_eligible += epoch_eligible
            contr_joins_c += jc
            contr_joins_s += js
            if jc + js == 0:
                contr_zero_join_epochs += 1
        else:
            noncontr_lambda_c += epoch_lam_c
            noncontr_lambda_s += epoch_lam_s
            noncontr_eligible += epoch_eligible
            noncontr_joins_c += jc
            noncontr_joins_s += js

        if active_wave is None and pool_bias in ('C','S') and len(eligible_before) >= 8:
            if any(side == pool_bias for _,side in joined_this_epoch):
                active_wave = {
                    'bias': pool_bias,
                    'onset': t,
                    'eligible0': set(eligible_before),
                    'joined_side': {},
                    'target': int(math.ceil(0.9 * len(eligible_before))),
                    'reach90': None,
                }

        if active_wave is not None:
            for i,side in joined_this_epoch:
                if i in active_wave['eligible0'] and i not in active_wave['joined_side']:
                    active_wave['joined_side'][i] = side
            same = sum(1 for side in active_wave['joined_side'].values() if side == active_wave['bias'])
            if active_wave['reach90'] is None and same >= active_wave['target']:
                active_wave['reach90'] = t

        epoch_joined.append(joined_this_epoch)

        epoch_service = sum(world['true'][t][i] for i,s in enumerate(states) if s == 'C')
        service += epoch_service
        cumulative += epoch_service
        worst_drawdown = min(worst_drawdown, cumulative)

        maj = majority_label(states)
        majority_hist.append(maj)
        counts = state_counts(states)
        count_hist.append(counts)
        pool_hist.append((cp,sp))

        if cp >= 48 and sp >= 48:
            contradiction['total'] += 1
            if maj == 'U': contradiction['nomajority'] += 1
            elif maj == 'C': contradiction['cmajor'] += 1
            else: contradiction['smajor'] += 1

        if reversal is not None:
            if t < reversal and maj == old_side:
                old_majority_seen = True
            if t >= reversal and old_majority_seen and old_loss is None and maj != old_side:
                old_loss = t - reversal
            if t >= reversal and new_acquire is None and maj == new_side:
                new_acquire = t - reversal
            if new_acquire is not None and t > reversal + new_acquire and maj == old_side:
                return_to_old += 1

    # chatter
    chatter_events = 0
    chatter_cells = 0
    for i, evs in chatter_sequences.items():
        found = 0
        for a in range(len(evs)):
            t0,side0,k0 = evs[a]
            if k0 != 'DEFECT':
                continue
            for b in range(a+1,len(evs)):
                t1,side1,k1 = evs[b]
                if t1-t0 > 6: break
                if k1 == 'JOIN' and side1 == side0:
                    for c in range(b+1,len(evs)):
                        t2,side2,k2 = evs[c]
                        if t2-t0 > 6: break
                        if k2 == 'DEFECT' and side2 == side0:
                            chatter_events += 1
                            found += 1
                            break
                    break
        if found:
            chatter_cells += 1

    # population oscillation
    changes = 0
    prev = majority_hist[8]
    for m in majority_hist[9:]:
        if m != prev:
            changes += 1
            prev = m
    oscillatory = changes >= 4

    if active_wave is not None:
        recruitment_waves.append(active_wave)

    ep_metrics = []
    for w in recruitment_waves:
        total = len(w['joined_side'])
        same = sum(1 for side in w['joined_side'].values() if side == w['bias'])
        coordination = same / total if total else None
        width = None if w['reach90'] is None else w['reach90'] - w['onset']
        ep_metrics.append({
            'bias': w['bias'],
            'onset': w['onset'],
            'eligible0': len(w['eligible0']),
            'target': w['target'],
            'joined': total,
            'same_side': same,
            'coordination': coordination,
            'width': width,
        })

    final_counts = count_hist[-1]
    final_c_frac = final_counts['C']/N
    final_s_frac = final_counts['S']/N
    oracle_sum = sum(sum(row) for row in world['true'])
    oracle = 'C' if oracle_sum > 0 else ('S' if oracle_sum < 0 else 'N')
    false_c = oracle == 'S' and final_c_frac > 0.5
    false_s = oracle == 'C' and final_s_frac > 0.5

    spatial_match = None
    if world['family'] == 2:
        reg = world['local_region']
        good = 0
        for i,s in enumerate(states):
            if reg[i] > 0 and s == 'C': good += 1
            if reg[i] < 0 and s == 'S': good += 1
        spatial_match = good/N

    def within(k):
        return sum(1 for dt,_ in post_join_records if dt <= k)

    return {
        'service':service,
        'harmful':service < 0,
        'beneficial':service > 0,
        'neutral':service == 0,
        'worst_drawdown':worst_drawdown,
        'final_counts':final_counts,
        'oracle':oracle,
        'false_c':false_c,'false_s':false_s,
        'contradiction':contradiction,
        'oscillatory':oscillatory,
        'majority_changes':changes,
        'chatter_events':chatter_events,
        'chatter_cells':chatter_cells,
        'transitions':dict(transitions),
        'reversal':{
            'old_seen':old_majority_seen,
            'old_loss':old_loss,
            'new_acquire':new_acquire,
            'return_to_old':return_to_old
        },
        'spatial_match':spatial_match,
        'episode_metrics':ep_metrics,
        'post_join_defect_1':within(1),
        'post_join_defect_2':within(2),
        'post_join_defect_4':within(4),
        'joins_total':sum(len(x) for x in epoch_joined),
        'contr_lambda_c_sum':contr_lambda_c,
        'contr_lambda_s_sum':contr_lambda_s,
        'contr_eligible':contr_eligible,
        'contr_joins_c':contr_joins_c,
        'contr_joins_s':contr_joins_s,
        'contr_zero_join_epochs':contr_zero_join_epochs,
        'noncontr_lambda_c_sum':noncontr_lambda_c,
        'noncontr_lambda_s_sum':noncontr_lambda_s,
        'noncontr_eligible':noncontr_eligible,
        'noncontr_joins_c':noncontr_joins_c,
        'noncontr_joins_s':noncontr_joins_s,
        'family':world['family'],
        'ctx':ctx,'rep':rep,
    }

def manifest(seed):
    rows = []
    for ctx in range(48):
        for rep in range(8):
            w = make_world(seed,ctx,rep)
            h = hashlib.sha256(json.dumps({
                'ctx':ctx,'rep':rep,'family':w['family'],'index':w['index'],
                'reversal':w['reversal'],'local_region':w['local_region'],
                'true':w['true'],'sensed':w['sensed'],
            },sort_keys=True,separators=(',',':')).encode()).hexdigest()
            rows.append({'ctx':ctx,'rep':rep,'family':w['family'],'hash':h})
    blob = json.dumps(rows,sort_keys=True,separators=(',',':')).encode()
    return {'count':len(rows),'sha256':hashlib.sha256(blob).hexdigest(),'rows':rows}

def summarize(results):
    n = len(results)
    harm = sum(r['harmful'] for r in results)
    ben = sum(r['beneficial'] for r in results)
    neu = n-harm-ben
    false_c = sum(r['false_c'] for r in results)
    false_s = sum(r['false_s'] for r in results)
    cden = sum(r['oracle']=='S' for r in results)
    sden = sum(r['oracle']=='C' for r in results)
    contr_tot = sum(r['contradiction']['total'] for r in results)
    contr_u = sum(r['contradiction']['nomajority'] for r in results)
    osc_ids = [(r['ctx'],r['rep']) for r in results if r['oscillatory']]
    revs = [r['reversal'] for r in results if r['reversal']['old_seen']]
    old_loss = [x['old_loss'] for x in revs if x['old_loss'] is not None]
    new_acq = [x['new_acquire'] for x in revs if x['new_acquire'] is not None]
    eps = [e for r in results for e in r['episode_metrics'] if e['joined'] >= 1]
    widths = [e['width'] for e in eps if e['width'] is not None]
    never = sum(e['width'] is None for e in eps)
    coords = [e['coordination'] for e in eps if e['coordination'] is not None]
    fam5_osc = [(r['ctx'],r['rep']) for r in results if r['family']==5 and r['oscillatory']]
    return {
        'aggregate_service':sum(r['service'] for r in results),
        'beneficial':ben,'neutral':neu,'harmful':harm,'harm_rate':harm/n,
        'worst_drawdown':min(r['worst_drawdown'] for r in results),
        'false_c':false_c,'false_c_rate':false_c/cden if cden else None,
        'false_s':false_s,'false_s_rate':false_s/sden if sden else None,
        'contradictory_epochs':contr_tot,
        'contradiction_nomajority_fraction':contr_u/contr_tot if contr_tot else 1.0,
        'oscillatory':len(osc_ids),'oscillatory_fraction':len(osc_ids)/n,
        'oscillatory_ids':osc_ids,'family5_oscillatory_ids':fam5_osc,
        'chatter_trials':sum(r['chatter_events']>0 for r in results),
        'chatter_trial_fraction':sum(r['chatter_events']>0 for r in results)/n,
        'chatter_events':sum(r['chatter_events'] for r in results),
        'old_majority_loss_median':statistics.median(old_loss) if old_loss else None,
        'reversal_old_seen':len(revs),
        'reversal_acquired_new':len(new_acq),
        'reversal_acquire_fraction':len(new_acq)/len(revs) if revs else None,
        'recruitment_episode_count':len(eps),
        'recruitment_width_median':statistics.median(widths) if widths else None,
        'recruitment_width_never_fraction':never/len(eps) if eps else None,
        'recruitment_width_lt3_fraction':sum(w<3 for w in widths)/len(widths) if widths else None,
        'recruitment_width_5_20_fraction':sum(5<=w<=20 for w in widths)/len(widths) if widths else None,
        'directional_coordination_median':statistics.median(coords) if coords else None,
        'spatial_match_mean':statistics.mean([r['spatial_match'] for r in results if r['spatial_match'] is not None]),
        'post_join_defect_1':sum(r['post_join_defect_1'] for r in results),
        'post_join_defect_2':sum(r['post_join_defect_2'] for r in results),
        'post_join_defect_4':sum(r['post_join_defect_4'] for r in results),
        'joins_total':sum(r['joins_total'] for r in results),
        'contr_mean_lambda_c':(sum(r['contr_lambda_c_sum'] for r in results)/sum(r['contr_eligible'] for r in results)) if sum(r['contr_eligible'] for r in results) else 0.0,
        'contr_mean_lambda_s':(sum(r['contr_lambda_s_sum'] for r in results)/sum(r['contr_eligible'] for r in results)) if sum(r['contr_eligible'] for r in results) else 0.0,
        'contr_joins_c':sum(r['contr_joins_c'] for r in results),
        'contr_joins_s':sum(r['contr_joins_s'] for r in results),
        'contr_zero_join_epochs':sum(r['contr_zero_join_epochs'] for r in results),
        'contr_zero_join_fraction':(sum(r['contr_zero_join_epochs'] for r in results)/contr_tot) if contr_tot else 1.0,
        'noncontr_mean_lambda_c':(sum(r['noncontr_lambda_c_sum'] for r in results)/sum(r['noncontr_eligible'] for r in results)) if sum(r['noncontr_eligible'] for r in results) else 0.0,
        'noncontr_mean_lambda_s':(sum(r['noncontr_lambda_s_sum'] for r in results)/sum(r['noncontr_eligible'] for r in results)) if sum(r['noncontr_eligible'] for r in results) else 0.0,
        'noncontr_joins_c':sum(r['noncontr_joins_c'] for r in results),
        'noncontr_joins_s':sum(r['noncontr_joins_s'] for r in results),
    }

def run(seed):
    allres = {a:[] for a in ARMS}
    for ctx in range(48):
        for rep in range(8):
            w = make_world(seed,ctx,rep)
            for arm in ARMS:
                allres[arm].append(run_arm(seed,w,arm))
    sums = {a:summarize(allres[a]) for a in ARMS}

    qual = {}
    info = {}
    for arm,(D,wp,wl,use_supp,ns) in PRIMARY_WEIGHTS.items():
        s = sums[arm]
        ref_name = arm.replace('_S_','_U_')
        ref = sums[ref_name]
        ref_f5 = set(map(tuple, ref['family5_oscillatory_ids']))
        arm_f5 = set(map(tuple, s['family5_oscillatory_ids']))
        broken = len(ref_f5 - arm_f5)
        ref_contr_joins = ref['contr_joins_c'] + ref['contr_joins_s']
        arm_contr_joins = s['contr_joins_c'] + s['contr_joins_s']
        reduction = 1.0 - arm_contr_joins/ref_contr_joins if ref_contr_joins else 0.0
        qual[arm] = (
            s['oscillatory_fraction'] <= 0.05 and
            s['oscillatory_fraction'] < ref['oscillatory_fraction'] and
            (broken >= math.ceil(0.5*len(ref_f5)) if ref_f5 else True) and
            s['recruitment_width_median'] is not None and s['recruitment_width_median'] >= 3 and
            s['directional_coordination_median'] is not None and s['directional_coordination_median'] >= 0.80 and
            s['false_c_rate'] is not None and s['false_c_rate'] <= 0.05 and
            s['false_s_rate'] is not None and s['false_s_rate'] <= 0.05 and
            s['reversal_acquire_fraction'] is not None and s['reversal_acquire_fraction'] >= 0.80 and
            s['contradiction_nomajority_fraction'] >= 0.90 and
            s['aggregate_service'] >= 0.95*ref['aggregate_service']
        )
        info[arm] = {
            'paired_reference':ref_name,
            'broken_reference_family5':broken,
            'reference_family5_total':len(ref_f5),
            'contradictory_join_reduction':reduction,
            'information_gain':(
                s['oscillatory_fraction'] < ref['oscillatory_fraction'] and
                (broken >= math.ceil(0.25*len(ref_f5)) if ref_f5 else True) and
                reduction >= 0.50 and
                s['directional_coordination_median'] is not None and s['directional_coordination_median'] >= 0.80 and
                s['aggregate_service'] >= 0.90*ref['aggregate_service']
            )
        }

    m = manifest(seed)
    probes = {
        'P1':m['count']==384,
        'P2':len({(r['ctx'],r['rep']) for r in m['rows']})==384,
        'P3':N==48,
        'P4':T==48,
        'P5':(initial_states().count('C'),initial_states().count('S'),initial_states().count('U'))==(12,12,24),
        'P6':(POOL_DECAY_NUM,POOL_DECAY_DEN)==(3,4),
        'P7':(LOCAL_R,HILL_N,HILL_K)==(12,3,0.5),
        'P8':RECRUIT_R==3,
        'P9':ETA==0.5,
        'P10':POOL_NORM==160.0,
        'P11':all(v[0]==2 for k,v in PRIMARY_WEIGHTS.items() if k.startswith('D2_')),
        'P12':all(v[0]==3 for k,v in PRIMARY_WEIGHTS.items() if k.startswith('D3_')),
        'P13':set((v[1],v[2]) for v in PRIMARY_WEIGHTS.values())=={(0.75,0.25),(0.5,0.5),(0.25,0.75)},
        'P14':K_SUPP==0.5,
        'P15':all(v[4]==3 for v in PRIMARY_WEIGHTS.values()),
        'P16':CONTROL_WEIGHTS['D3_LINEAR_P50L50'][4]==1,
        'P17':True,'P18':True,'P19':True,'P20':True,'P21':True,'P22':True,'P23':True,'P24':True
    }
    return {'seed':seed,'manifest':{'count':m['count'],'sha256':m['sha256']},
            'summaries':sums,'qualified':qual,'information_gain':info,'integrity':probes}

def main():
    seed = sys.argv[1] if len(sys.argv)>1 else 'MECHANICAL-F34-NONPRIMARY'
    print(json.dumps(run(seed),sort_keys=True,separators=(',',':')))

if __name__ == '__main__':
    main()
