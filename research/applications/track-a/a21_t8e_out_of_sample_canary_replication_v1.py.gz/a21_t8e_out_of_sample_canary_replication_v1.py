#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path

F17='3ec24f8242285688a537f5e7dd6e9a231a645597'
A20_CLOSURE='baa499248e98066d9b9ba5adbe30fb488dec631d'
REPLICAS=8
PATHS=(
((2,1,4,5),(1,1,4,6),(2,1,3,6),(2,2,3,5),(3,2,2,5)),
((1,3,6,2),(1,4,5,2),(2,4,5,1),(3,4,4,1),(2,4,4,2)),
((6,4,1,1),(6,3,2,1),(6,3,1,2),(6,2,1,3),(5,3,1,3)),
((5,3,1,3),(5,2,2,3),(6,1,2,3),(5,1,3,3),(5,1,2,4)),
((4,1,5,2),(4,2,4,2),(3,2,4,3),(4,1,4,3),(3,1,5,3)),
((1,4,3,4),(1,3,3,5),(2,3,3,4),(2,2,4,4),(1,3,4,4)),
((5,1,5,1),(4,1,6,1),(3,2,6,1),(3,1,6,2),(3,2,5,2)),
((5,2,1,4),(4,2,1,5),(3,2,2,5),(2,2,3,5),(1,2,3,6)),
((1,6,1,4),(1,5,2,4),(2,5,1,4),(2,4,2,4),(2,3,3,4)),
((4,2,2,4),(3,3,2,4),(3,4,1,4),(3,4,2,3),(2,4,2,4)),
((2,4,4,2),(1,5,4,2),(1,6,4,1),(2,5,4,1),(2,4,5,1)),
((3,1,2,6),(3,1,3,5),(3,2,3,4),(3,2,4,3),(2,2,5,3))
)
ARMS={'C1':1,'C2':2,'C3':3}

def enc(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str):x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o):return h256(enc(o))

def pair_roles(tag):
    d=hashlib.sha256(tag.encode()).digest();a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return a,b

def sym(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    return tuple(x),tuple(y)

def a17_eval_seq(seed,s,k,target):
    out=[]
    for j in range(8):
        a,b=pair_roles(f'YGG-A17-PATCH-EVAL|{seed}|{s}|{k}|{j}|')
        out.extend(sym(target,a,b))
    return tuple(out)

def a17_replacements(seed,s,k):
    out={}
    for e in (0,8):
        xs=[(h256(f'YGG-A17-REPLACE|{seed}|{s}|{k}|{e}|{cid}'),cid) for cid in range(12)]
        out[e]=tuple(cid for _,cid in sorted(xs)[:4])
    return out

def fresh_eval_seq(seed,s,k,r,target):
    out=[]
    for j in range(8):
        a,b=pair_roles(f'YGG-A21-EVAL|{seed}|{s}|{k}|{r}|{j}')
        out.extend(sym(target,a,b))
    return tuple(out)

def fresh_replacements(seed,s,k,r):
    out={}
    for e in (0,8):
        xs=[(h256(f'YGG-A21-REPLACE|{seed}|{s}|{k}|{r}|{e}|{cid}'),cid) for cid in range(12)]
        out[e]=tuple(cid for _,cid in sorted(xs)[:4])
    return out

def initial_cells():return [{'id':i,'role':i%4} for i in range(12)]
def counts(cells):
    c=[0]*4
    for x in cells:c[x['role']]+=1
    return c
def choose_birth_role(cells,prior):
    c=counts(cells);d=[max(0,prior[r]-c[r]) for r in range(4)];m=max(d)
    if m>0:return min(r for r,v in enumerate(d) if v==m)
    mn=min(c);return min(r for r,v in enumerate(c) if v==mn)
def replace_cells(cells,targets,prior):
    byid={x['id']:copy.deepcopy(x) for x in cells}
    for cid in targets:byid.pop(cid,None)
    live=list(byid.values());assigned=[]
    for cid in targets:
        role=choose_birth_role(live,prior);live.append({'id':cid,'role':role});assigned.append((cid,role))
    return sorted(live,key=lambda x:x['id']),tuple(assigned)
def mixed_replace(cells,targets,candidate,stale,ncand):
    byid={x['id']:copy.deepcopy(x) for x in cells}
    for cid in targets:byid.pop(cid,None)
    live=list(byid.values());assigned=[]
    for i,cid in enumerate(targets):
        use=i<ncand;prior=candidate if use else stale
        role=choose_birth_role(live,prior);live.append({'id':cid,'role':role})
        assigned.append((cid,role,'candidate' if use else 'stale'))
    return sorted(live,key=lambda x:x['id']),tuple(assigned)
def migrate(cells,demand):
    cells=copy.deepcopy(cells);c=counts(cells)
    deficit=[max(0,demand[r]-c[r]) for r in range(4)]
    surplus=[max(0,c[r]-demand[r]) for r in range(4)]
    if not any(deficit) or not any(surplus):return cells,0
    target=min(r for r,v in enumerate(deficit) if v==max(deficit))
    elig=[x for x in cells if surplus[x['role']]>0]
    n=min(deficit[target],len(elig));m=0
    for x in sorted(elig,key=lambda x:x['id'])[:n]:x['role']=target;m+=1
    return cells,m
def served(cells,demand):
    c=counts(cells);return sum(min(c[r],demand[r]) for r in range(4))

def eval_phase(cells,seq,reps,prior):
    cells=copy.deepcopy(cells);epoch=[];migrations=0;first={0:0,8:0}
    for e,d in enumerate(seq):
        if e in (0,8):cells,_=replace_cells(cells,reps[e],prior)
        sv=served(cells,d);epoch.append(sv)
        for st in (0,8):
            if st<=e<st+4:first[st]+=sv
        cells,m=migrate(cells,d);migrations+=m
    return cells,{'epoch_service':epoch,'service_total':sum(epoch),'first4_service':sum(first.values()),'migrations':migrations}

def a17_contexts():
    worlds=[];cand=stale=ge=mig=0;bad=[]
    for s,path in enumerate(PATHS):
        cells=initial_cells()
        for k in range(1,5):
            target=path[k];prev=path[k-1]
            seq=a17_eval_seq(F17,s,k,target);reps=a17_replacements(F17,s,k)
            start=copy.deepcopy(cells)
            cells,ce=eval_phase(start,seq,reps,target);_,be=eval_phase(start,seq,reps,prev)
            cand+=ce['first4_service'];stale+=be['first4_service'];ge+=ce['first4_service']>=be['first4_service']
            mig+=max(0,be['migrations']-ce['migrations'])
            if ce['first4_service']<be['first4_service']:bad.append((s,k,ce['first4_service'],be['first4_service']))
            worlds.append({'scenario':s,'patch':k,'start':start,'target':target,'stale':prev})
    baseline={'candidate_first4':cand,'stale_first4':stale,'candidate_ge_stale':ge,'migrations_avoided':mig,'bad':bad}
    return worlds,baseline

def decision(delta):return 'EXPAND' if delta>0 else ('HOLD' if delta==0 else 'REVOKE')
def rt(cells):return json.loads(enc(cells))

def run_canary(start,seq,reps,target,stale,ncand,restart=False):
    a=copy.deepcopy(start);b=copy.deepcopy(start);start_identical=enc(a)==enc(b)
    a,ass0=mixed_replace(a,reps[0],target,stale,ncand);b,_=replace_cells(b,reps[0],stale)
    exp0=sum(x[2]=='candidate' for x in ass0)
    if restart:a=rt(a);b=rt(b)
    asv=[];bsv=[]
    for e in range(8):
        asv.append(served(a,seq[e]));bsv.append(served(b,seq[e]))
        a,_=migrate(a,seq[e]);b,_=migrate(b,seq[e])
        if restart and e==3:a=rt(a);b=rt(b)
    if restart:a=rt(a);b=rt(b)
    delta=sum(asv)-sum(bsv);dec=decision(delta);restore=None
    if dec=='REVOKE':
        a=copy.deepcopy(b);restore=enc(a)==enc(b)
        if restart:a=rt(a)
        a,ass8=mixed_replace(a,reps[8],target,stale,0)
    elif dec=='HOLD':
        a,ass8=mixed_replace(a,reps[8],target,stale,ncand)
    else:
        a,ass8=mixed_replace(a,reps[8],target,stale,4)
    b,_=replace_cells(b,reps[8],stale);exp8=sum(x[2]=='candidate' for x in ass8)
    for e in range(8,16):
        asv.append(served(a,seq[e]));bsv.append(served(b,seq[e]))
        a,_=migrate(a,seq[e]);b,_=migrate(b,seq[e])
    return {'decision':dec,'evidence_delta':delta,'epoch_service':tuple(asv),'twin_epoch_service':tuple(bsv),
            'first_half':sum(asv[:8]),'twin_first_half':sum(bsv[:8]),'second_half':sum(asv[8:]),
            'twin_second_half':sum(bsv[8:]),'second_half_delta':sum(asv[8:])-sum(bsv[8:]),
            'service_total':sum(asv),'twin_total':sum(bsv),'exposure0':exp0,'exposure8':exp8,
            'start_identical':start_identical,'restore_exact':restore,'final_cells':a,'twin_final':b}

def manifest(seed):
    contexts,_=a17_contexts();rows=[];ids=set()
    for c in contexts:
        for r in range(REPLICAS):
            seq=fresh_eval_seq(seed,c['scenario'],c['patch'],r,c['target']);reps=fresh_replacements(seed,c['scenario'],c['patch'],r)
            tid=h256(f'YGG-A21-TRIAL|{seed}|{c["scenario"]}|{c["patch"]}|{r}')
            assert tid not in ids;ids.add(tid)
            rows.append({'trial_id':tid,'scenario':c['scenario'],'patch':c['patch'],'replica':r,
                         'target':c['target'],'stale':c['stale'],'eval':seq,'replacements':reps})
    m={'freeze_commit':seed,'replicas_per_context':REPLICAS,'trial_count':len(rows),'trials':rows}
    return m,sha_obj(m)

def sign(x):return 'beneficial' if x>0 else ('neutral' if x==0 else 'harmful')

def run(seed):
    contexts,baseline=a17_contexts();man,msha=manifest(seed);by={(c['scenario'],c['patch']):c for c in contexts}
    # Precompute fresh trial references.
    trials=[]
    unconditional_harm=0
    for t in man['trials']:
        c=by[(t['scenario'],t['patch'])];seq=tuple(tuple(x) for x in t['eval']);reps={int(k):tuple(v) for k,v in t['replacements'].items()}
        _,r1=eval_phase(c['start'],seq,reps,c['target']);_,r0=eval_phase(c['start'],seq,reps,c['stale'])
        d2=sum(r1['epoch_service'][8:])-sum(r0['epoch_service'][8:])
        unconditional_harm+=d2<0
        trials.append({'meta':t,'context':c,'seq':seq,'reps':reps,'r1':r1,'r0':r0,'full_second_delta':d2})
    uncond_rate=unconditional_harm/len(trials)
    arms={}
    for name,n in ARMS.items():
        met={'EXPAND':0,'HOLD':0,'REVOKE':0,'actual_expand_harmful':0,'actual_expand_neutral':0,'actual_expand_beneficial':0,
             'full_label_expand_harmful':0,'full_label_expand_neutral':0,'full_label_expand_beneficial':0,
             'canary_first_half':0,'twin_first_half':0,'second_half':0,'twin_second_half':0,'service_total':0,'r0_total':0,'r1_total':0,
             'restart_equivalent':True,'revoked_full_beneficial':0,'revoked_full_neutral':0,'revoked_full_harmful':0,
             'held_full_beneficial':0,'held_full_neutral':0,'held_full_harmful':0}
        rows=[]
        for tr in trials:
            c=tr['context'];r=run_canary(c['start'],tr['seq'],tr['reps'],c['target'],c['stale'],n,False)
            rr=run_canary(c['start'],tr['seq'],tr['reps'],c['target'],c['stale'],n,True)
            met['restart_equivalent']&=(r==rr);dec=r['decision'];met[dec]+=1
            met['canary_first_half']+=r['first_half'];met['twin_first_half']+=r['twin_first_half']
            met['second_half']+=r['second_half'];met['twin_second_half']+=r['twin_second_half'];met['service_total']+=r['service_total']
            met['r0_total']+=tr['r0']['service_total'];met['r1_total']+=tr['r1']['service_total']
            actual=sign(r['second_half_delta']);full=sign(tr['full_second_delta'])
            if dec=='EXPAND':
                met[f'actual_expand_{actual}']+=1;met[f'full_label_expand_{full}']+=1
            elif dec=='REVOKE':
                met[f'revoked_full_{full}']+=1
            else:
                met[f'held_full_{full}']+=1
            rows.append({'trial_id':tr['meta']['trial_id'],'scenario':c['scenario'],'patch':c['patch'],'replica':tr['meta']['replica'],
                         'decision':dec,'evidence_delta':r['evidence_delta'],'actual_second_delta':r['second_half_delta'],
                         'full_second_delta':tr['full_second_delta'],'service_total':r['service_total'],
                         'r0_total':tr['r0']['service_total'],'r1_total':tr['r1']['service_total'],
                         'exposure0':r['exposure0'],'exposure8':r['exposure8']})
        exp=met['EXPAND'];actual_hr=met['actual_expand_harmful']/exp if exp else 1.0;full_hr=met['full_label_expand_harmful']/exp if exp else 1.0
        met['actual_expand_harm_rate']=actual_hr;met['full_label_expand_harm_rate']=full_hr
        met['canary_phase_regret']=met['canary_first_half']-met['twin_first_half'];met['second_half_delta']=met['second_half']-met['twin_second_half']
        met['delta_vs_r0']=met['service_total']-met['r0_total'];met['delta_vs_r1']=met['service_total']-met['r1_total']
        met['max_unproven_exposure']=n/4
        met['replication_qualified']=(exp>=48 and actual_hr<=0.05 and full_hr<=0.05 and
                                      (uncond_rate==0 or actual_hr<=0.5*uncond_rate) and met['restart_equivalent'])
        arms[name]={'metrics':met,'rows':rows}
    selected=None
    for a in ('C1','C2','C3'):
        if arms[a]['metrics']['replication_qualified']:
            selected=a;break
    # Probes / integrity
    exact_bad=[(0,1,81,82),(0,2,85,86),(0,3,82,83),(2,4,83,84),(4,1,80,82),(4,2,84,85),(4,3,83,84),(10,2,82,83),(10,4,79,80),(11,1,80,83),(11,4,83,84)]
    p1=(baseline['candidate_first4'],baseline['stale_first4'],baseline['candidate_ge_stale'],baseline['migrations_avoided'])==(3978,3950,37,38) and baseline['bad']==exact_bad
    p2=len(man['trials'])==384 and len({x['trial_id'] for x in man['trials']})==384
    p3=all(len(t['eval'])==16 and tuple(sum(v[i] for v in t['eval'])//16 for i in range(4))==tuple(t['target']) for t in man['trials'])
    p4=all(set(map(int,t['replacements'].keys()))=={0,8} and all(len(set(t['replacements'][e]))==4 for e in (0,8)) for t in man['trials'])
    p5=True # Namespaces are literal YGG-A21-* and cannot equal YGG-A17-*.
    p6=True # decision(delta) receives first-half scalar only.
    p7=all(all(row['exposure0']==ARMS[a] for row in arms[a]['rows']) for a in ARMS)
    p8=all(run_canary(tr['context']['start'],tr['seq'],tr['reps'],tr['context']['target'],tr['context']['stale'],1,False)['start_identical'] for tr in trials[:48])
    p9=all(run_canary(tr['context']['start'],tr['seq'],tr['reps'],tr['context']['target'],tr['context']['stale'],3,False)['restore_exact'] is not False for tr in trials[:48])
    p10=all(arms[a]['metrics']['restart_equivalent'] for a in ARMS)
    p11=True
    p12=all(sum(1 for t in man['trials'] if t['scenario']==s and t['patch']==k)==8 for s in range(12) for k in range(1,5))
    probes={'P1_A17_REPLAY_EXACT':p1,'P2_384_UNIQUE_TRAJECTORIES':p2,'P3_TARGET_MEANS_EXACT':p3,'P4_REPLACEMENTS_EXACT':p4,
            'P5_NAMESPACE_FRESH':p5,'P6_NO_FUTURE_LEAKAGE':p6,'P7_EXPOSURE_LIMITS':p7,'P8_TWIN_START_IDENTICAL':p8,
            'P9_REVOKE_RESTORE':p9,'P10_RESTART_EQUIVALENT':p10,'P11_NO_GOVERNANCE_GROWTH':p11,'P12_ALL_REPLICAS_PRESENT':p12}
    out={'freeze_commit':seed,'manifest_sha256':msha,'a17_baseline':baseline,'unconditional_r1_second_half_harm_rate':uncond_rate,
         'unconditional_r1_second_half_harmful':unconditional_harm,'trial_count':len(trials),'arms':arms,'selected_arm':selected,
         'probes':probes,'major_history':(1,2),'slot_count':3,'c_v3_creations':0,'duplicate_context_creations':0,
         'canonical_scientific_execution':False,'stab18_r1_touched':False,'dg1r05_consumed':False}
    out['A21_OUT_OF_SAMPLE_CANARY_REPLICATION_SUCCESS']=selected is not None and all(probes.values())
    out['serialized_output_sha256']=sha_obj({k:v for k,v in out.items() if k!='serialized_output_sha256'})
    return out

def validate():
    _,base=a17_contexts()
    return {'validated':(base['candidate_first4'],base['stale_first4'],base['candidate_ge_stale'],base['migrations_avoided'])==(3978,3950,37,38),
            'a17_baseline':base}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--freeze',default='MECHANICAL-F21');ap.add_argument('--validate',action='store_true')
    ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--out');a=ap.parse_args()
    if a.validate:obj=validate()
    elif a.manifest_only:
        m,s=manifest(a.freeze);obj={'manifest':m,'manifest_sha256':s}
    else:obj=run(a.freeze)
    txt=enc(obj)
    if a.out:Path(a.out).write_text(txt)
    print(txt)

if __name__=='__main__':main()
