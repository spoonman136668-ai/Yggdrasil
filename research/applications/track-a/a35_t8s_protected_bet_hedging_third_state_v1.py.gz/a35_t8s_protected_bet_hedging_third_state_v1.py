import hashlib, json, math, statistics, sys
from collections import Counter, defaultdict

N=48
T=48
POOL_DECAY_NUM=3
POOL_DECAY_DEN=4
LOCAL_R=12
HILL_N=3
HILL_K=0.5
RECRUIT_R=3
ETA=0.5
POOL_NORM=160.0
K_SUPP=0.5
N_SUPP=3

PRIMARY_HEDGE={
    'D2_H_P75L25':(2,.75,.25,True),
    'D2_H_P50L50':(2,.50,.50,True),
    'D2_H_P25L75':(2,.25,.75,True),
    'D3_H_P75L25':(3,.75,.25,True),
    'D3_H_P50L50':(3,.50,.50,True),
    'D3_H_P25L75':(3,.25,.75,True),
}
REFERENCE={
    'D2_R_P75L25':(2,.75,.25,False),
    'D2_R_P50L50':(2,.50,.50,False),
    'D2_R_P25L75':(2,.25,.75,False),
    'D3_R_P75L25':(3,.75,.25,False),
    'D3_R_P50L50':(3,.50,.50,False),
    'D3_R_P25L75':(3,.25,.75,False),
}
ARMS=tuple(PRIMARY_HEDGE)+tuple(REFERENCE)

def h64(*parts):
    s = '|'.join(str(x) for x in parts).encode()
    return int.from_bytes(hashlib.sha256(s).digest()[:8], 'big')

def u01(*parts):
    return h64(*parts) / float(2**64 - 1)


MASK64 = (1<<64)-1
def mix64(x):
    x = (x + 0x9E3779B97F4A7C15) & MASK64
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9 & MASK64
    x = (x ^ (x >> 27)) * 0x94D049BB133111EB & MASK64
    x ^= x >> 31
    return x & MASK64

def fast_u01(base, t, i, salt):
    x = base ^ ((t+1)*0xD6E8FEB86659FD93 & MASK64) ^ ((i+1)*0xA5A3564E27F8862D & MASK64) ^ salt
    return mix64(x) / float(MASK64)

def initial_states():
    st = ['U'] * N
    for i in range(N):
        if i % 4 == 0:
            st[i] = 'C'
        elif i % 4 == 2:
            st[i] = 'S'
    assert st.count('C') == 12 and st.count('S') == 12 and st.count('U') == 24
    return st

def sensor_noise(seed, ctx, rep, t, i):
    z = h64('YGG-A35-SENSOR', seed, ctx, rep, t, i) % 10
    if z == 0: return -1
    if z == 1: return 1
    return 0

def hetero(seed, ctx, rep, t, i):
    z = h64('YGG-A35-HET', seed, ctx, rep, t, i) % 20
    if z == 0: return -1
    if z == 1: return 1
    if z in (2,3,4): return 0
    return None

def make_world(seed, ctx, rep):
    fam = ctx // 8
    idx = ctx % 8
    true = [[0]*N for _ in range(T)]
    reversal = None
    local_region = None
    if fam == 2:
        sizes = [12,16,20,24,28,32,36,40]
        size = sizes[idx]
        start = h64('YGG-A35-SPATIAL', seed, ctx, rep) % N
        pos = {(start+j) % N for j in range(size)}
        local_region = [1 if i in pos else -1 for i in range(N)]
    elif fam in (3,4):
        reversal = [12,16,20,24,28,32,36,40][idx]
    for t in range(T):
        for i in range(N):
            if fam == 0:
                base = 1
            elif fam == 1:
                base = -1
            elif fam == 2:
                base = local_region[i]
            elif fam == 3:
                base = 1 if t < reversal else -1
            elif fam == 4:
                base = -1 if t < reversal else 1
            else:
                modes = [(2,2),(3,3),(4,4),(1,1),(6,2),(2,6),(5,3),(3,5)]
                on, off = modes[idx]
                if idx <= 3:
                    base = 1 if (t // on) % 2 == 0 else -1
                else:
                    cyc = on + off
                    q = t % cyc
                    base = 1 if q < on else -1
                    if idx in (5,7):
                        base = -base
            hv = hetero(seed, ctx, rep, t, i)
            if hv is None:
                v = base
            elif hv == 0:
                v = 0
            else:
                v = hv
            true[t][i] = max(-1, min(1, int(v)))
    sensed = [[0]*N for _ in range(T)]
    for t in range(T):
        for i in range(N):
            sensed[t][i] = max(-1, min(1, true[t][i] + sensor_noise(seed, ctx, rep, t, i)))
    return {
        'ctx':ctx,'rep':rep,'family':fam,'index':idx,
        'true':true,'sensed':sensed,'reversal':reversal,'local_region':local_region
    }

def local_density(emitters, i, r):
    width = 2*r + 1
    return sum(1 for d in range(-r,r+1) if (i+d)%N in emitters) / width

def p_stay_from_density(d):
    if d <= 0:
        return 1.0
    x = d / HILL_K
    return 1.0 / (1.0 + x**HILL_N)

def majority_label(states):
    c = states.count('C')
    s = states.count('S')
    if c > N/2: return 'C'
    if s > N/2: return 'S'
    return 'U'


def state_counts(states):
    return {k:states.count(k) for k in ('C','S','U','H','FC','FS')}

def arm_params(arm):
    if arm in PRIMARY_HEDGE: return PRIMARY_HEDGE[arm]
    if arm in REFERENCE: return REFERENCE[arm]
    raise KeyError(arm)

def shannon3(states):
    # External measurement only: C / S / unresolved family (U,H,FC,FS)
    counts=[states.count('C'),states.count('S'),sum(states.count(k) for k in ('U','H','FC','FS'))]
    z=sum(counts); h=0.0
    for c in counts:
        if c:
            p=c/z; h-=p*math.log(p,2)
    return h

def run_arm(seed, world, arm):
    ctx,rep=world['ctx'],world['rep']
    D,w_pool,w_local,use_hedge=arm_params(arm)
    arm_base=h64('YGG-A35-ARM-SEED',seed,ctx,rep,arm)
    states=initial_states(); timers=[0]*N
    cp=sp=0.0
    service=cumulative=worst_drawdown=0
    majority_hist=[]; count_hist=[]; entropy_hist=[]
    contradiction={'total':0,'nomajority':0,'cmajor':0,'smajor':0}
    transitions=Counter(); chatter_sequences=defaultdict(list); join_origin={}; post_join_records=[]
    recruitment_waves=[]; active_wave=None
    h_enter_time={}; h_dwells=[]
    h_entries_contr=h_entries_non=0; h_eligible_contr=h_eligible_non=0
    h_occ_contr=0; h_occ_non=0; h_epochs_contr=h_epochs_non=0
    reversal=world['reversal']; old_side=new_side=None
    if world['family']==3: old_side,new_side='C','S'
    elif world['family']==4: old_side,new_side='S','C'
    old_majority_seen=False; old_loss=None; new_acquire=None

    for t in range(T):
        sensed=world['sensed'][t]
        base_c={i for i,v in enumerate(sensed) if v>0}
        base_s={i for i,v in enumerate(sensed) if v<0}
        fb_c=fb_s=0
        for i,s in enumerate(states):
            if s=='C' and sensed[i]>=0: fb_c+=1
            elif s=='S' and sensed[i]<=0: fb_s+=1
        cp=.75*cp+len(base_c)+fb_c; sp=.75*sp+len(base_s)+fb_s
        pc=min(1.0,cp/POOL_NORM); ps=min(1.0,sp/POOL_NORM)
        is_contr=cp>=48 and sp>=48

        # refractory release (unchanged)
        for i,s in enumerate(states):
            if s in ('FC','FS'):
                if timers[i]<=0:
                    states[i]='U'; transitions[f'{s}->U']+=1
                else: timers[i]-=1

        # endogenous H release: strong contradiction prolongs H; weakening either side releases it.
        released_h=set()
        for i,s in enumerate(states[:]):
            if s!='H': continue
            lc=local_density(base_c,i,RECRUIT_R); ls=local_density(base_s,i,RECRUIT_R)
            sup_c=w_pool*pc+w_local*lc; sup_s=w_pool*ps+w_local*ls
            lam_release=ETA*(1.0-min(sup_c,sup_s))
            p_release=1.0-math.exp(-max(0.0,lam_release))
            if fast_u01(arm_base,t,i,0x55A55A55A55A55A5)<p_release:
                states[i]='U'; released_h.add(i); transitions['H->U']+=1
                if i in h_enter_time:
                    h_dwells.append(t-h_enter_time.pop(i))

        # local cross-inhibition (unchanged)
        prior=states[:]; defects=[]
        for i,s in enumerate(prior):
            if s=='C':
                p=p_stay_from_density(local_density(base_s,i,LOCAL_R))
                if fast_u01(arm_base,t,i,0x11C11C11C11C11C1)>=p: defects.append((i,'C'))
            elif s=='S':
                p=p_stay_from_density(local_density(base_c,i,LOCAL_R))
                if fast_u01(arm_base,t,i,0x22C22C22C22C22C2)>=p: defects.append((i,'S'))
        for i,side in defects:
            fs='FC' if side=='C' else 'FS'; states[i]=fs; timers[i]=D
            transitions[f'{side}->{fs}']+=1; chatter_sequences[i].append((t,side,'DEFECT'))
            if i in join_origin:
                jt,jside=join_origin[i]
                if jside==side and t>jt: post_join_records.append((t-jt,side))

        # A released hedge cell first becomes recruitment-eligible next epoch.
        eligible=[i for i,s in enumerate(states) if s=='U' and i not in released_h]
        if is_contr: h_eligible_contr+=len(eligible)
        else: h_eligible_non+=len(eligible)
        pool_bias='C' if cp>sp else ('S' if sp>cp else 'NONE')
        if active_wave is not None and pool_bias in ('C','S') and pool_bias!=active_wave['bias']:
            recruitment_waves.append(active_wave); active_wave=None

        joined=[]; h_entered=0
        for i in eligible:
            lc=local_density(base_c,i,RECRUIT_R); ls=local_density(base_s,i,RECRUIT_R)
            sup_c=w_pool*pc+w_local*lc; sup_s=w_pool*ps+w_local*ls
            opp_c=w_pool*ps+w_local*ls; opp_s=w_pool*pc+w_local*lc
            g_c=1.0/(1.0+(opp_c/K_SUPP)**N_SUPP) if opp_c>0 else 1.0
            g_s=1.0/(1.0+(opp_s/K_SUPP)**N_SUPP) if opp_s>0 else 1.0
            lam_c=ETA*sup_c*g_c; lam_s=ETA*sup_s*g_s
            lam_h=ETA*sup_c*sup_s if use_hedge else 0.0
            lam=lam_c+lam_s+lam_h
            if lam<=0: continue
            p_fire=1.0-math.exp(-lam)
            if fast_u01(arm_base,t,i,0x33C33C33C33C33C3)>=p_fire: continue
            z=fast_u01(arm_base,t,i,0x44C44C44C44C44C4)*lam
            if z<lam_c: side='C'
            elif z<lam_c+lam_s: side='S'
            else: side='H'
            states[i]=side; transitions[f'U->{side}']+=1
            if side=='H':
                h_entered+=1; h_enter_time[i]=t
            else:
                chatter_sequences[i].append((t,side,'JOIN')); joined.append((i,side)); join_origin[i]=(t,side)

        if is_contr: h_entries_contr+=h_entered
        else: h_entries_non+=h_entered

        if active_wave is None and pool_bias in ('C','S') and len(eligible)>=8:
            if any(side==pool_bias for _,side in joined):
                active_wave={'bias':pool_bias,'onset':t,'eligible0':set(eligible),'joined_side':{},'target':int(math.ceil(.9*len(eligible))),'reach90':None}
        if active_wave is not None:
            for i,side in joined:
                if i in active_wave['eligible0'] and i not in active_wave['joined_side']: active_wave['joined_side'][i]=side
            same=sum(1 for s in active_wave['joined_side'].values() if s==active_wave['bias'])
            if active_wave['reach90'] is None and same>=active_wave['target']: active_wave['reach90']=t

        epoch_service=sum(world['true'][t][i] for i,s in enumerate(states) if s=='C')
        service+=epoch_service; cumulative+=epoch_service; worst_drawdown=min(worst_drawdown,cumulative)
        maj=majority_label(states); majority_hist.append(maj); count_hist.append(state_counts(states)); entropy_hist.append(shannon3(states))
        if is_contr:
            contradiction['total']+=1; h_epochs_contr+=1; h_occ_contr+=states.count('H')
            if maj=='U': contradiction['nomajority']+=1
            elif maj=='C': contradiction['cmajor']+=1
            else: contradiction['smajor']+=1
        else:
            h_epochs_non+=1; h_occ_non+=states.count('H')
        if reversal is not None:
            if t<reversal and maj==old_side: old_majority_seen=True
            if t>=reversal and old_majority_seen and old_loss is None and maj!=old_side: old_loss=t-reversal
            if t>=reversal and new_acquire is None and maj==new_side: new_acquire=t-reversal

    if active_wave is not None: recruitment_waves.append(active_wave)
    # close censored H dwells as observed-to-end durations for occupancy diagnostics only
    for i,t0 in h_enter_time.items(): h_dwells.append(T-t0)

    chatter_events=0; chatter_cells=0
    for i,evs in chatter_sequences.items():
        found=0
        for a in range(len(evs)):
            t0,side0,k0=evs[a]
            if k0!='DEFECT': continue
            for b in range(a+1,len(evs)):
                t1,side1,k1=evs[b]
                if t1-t0>6: break
                if k1=='JOIN' and side1==side0:
                    for c in range(b+1,len(evs)):
                        t2,side2,k2=evs[c]
                        if t2-t0>6: break
                        if k2=='DEFECT' and side2==side0:
                            chatter_events+=1; found+=1; break
                    break
        if found: chatter_cells+=1

    changes=0; prev=majority_hist[8]
    for m in majority_hist[9:]:
        if m!=prev: changes+=1; prev=m
    oscillatory=changes>=4
    eps=[]
    for w in recruitment_waves:
        total=len(w['joined_side']); same=sum(1 for s in w['joined_side'].values() if s==w['bias'])
        eps.append({'coordination':same/total if total else None,'width':None if w['reach90'] is None else w['reach90']-w['onset']})
    final=count_hist[-1]; oracle_sum=sum(sum(row) for row in world['true']); oracle='C' if oracle_sum>0 else ('S' if oracle_sum<0 else 'N')
    false_c=oracle=='S' and final['C']/N>.5; false_s=oracle=='C' and final['S']/N>.5
    spatial_match=None
    if world['family']==2:
        reg=world['local_region']; good=0
        for i,s in enumerate(states):
            if reg[i]>0 and s=='C': good+=1
            if reg[i]<0 and s=='S': good+=1
        spatial_match=good/N
    return {'service':service,'harmful':service<0,'beneficial':service>0,'neutral':service==0,'worst_drawdown':worst_drawdown,'oracle':oracle,'false_c':false_c,'false_s':false_s,'contradiction':contradiction,'oscillatory':oscillatory,'majority_changes':changes,'chatter_events':chatter_events,'chatter_cells':chatter_cells,'reversal':{'old_seen':old_majority_seen,'old_loss':old_loss,'new_acquire':new_acquire},'spatial_match':spatial_match,'episode_metrics':eps,'family':world['family'],'ctx':ctx,'rep':rep,'h_entries_contr':h_entries_contr,'h_entries_non':h_entries_non,'h_eligible_contr':h_eligible_contr,'h_eligible_non':h_eligible_non,'h_occ_contr':h_occ_contr,'h_occ_non':h_occ_non,'h_epochs_contr':h_epochs_contr,'h_epochs_non':h_epochs_non,'h_dwells':h_dwells,'h_peak':max(x['H'] for x in count_hist),'h_mean':statistics.mean(x['H'] for x in count_hist),'entropy_mean':statistics.mean(entropy_hist),'transitions':dict(transitions)}

def manifest(seed):
    rows=[]
    for ctx in range(48):
        for rep in range(8):
            w=make_world(seed,ctx,rep)
            h=hashlib.sha256(json.dumps({'ctx':ctx,'rep':rep,'family':w['family'],'index':w['index'],'reversal':w['reversal'],'local_region':w['local_region'],'true':w['true'],'sensed':w['sensed']},sort_keys=True,separators=(',',':')).encode()).hexdigest()
            rows.append({'ctx':ctx,'rep':rep,'family':w['family'],'hash':h})
    blob=json.dumps(rows,sort_keys=True,separators=(',',':')).encode(); return {'count':len(rows),'sha256':hashlib.sha256(blob).hexdigest(),'rows':rows}

def summarize(results):
    n=len(results); harm=sum(r['harmful'] for r in results); ben=sum(r['beneficial'] for r in results)
    false_c=sum(r['false_c'] for r in results); false_s=sum(r['false_s'] for r in results); cden=sum(r['oracle']=='S' for r in results); sden=sum(r['oracle']=='C' for r in results)
    contr=sum(r['contradiction']['total'] for r in results); contru=sum(r['contradiction']['nomajority'] for r in results)
    oscids=[(r['ctx'],r['rep']) for r in results if r['oscillatory']]; f5=[(r['ctx'],r['rep']) for r in results if r['family']==5 and r['oscillatory']]
    revs=[r['reversal'] for r in results if r['reversal']['old_seen']]; old=[x['old_loss'] for x in revs if x['old_loss'] is not None]; new=[x['new_acquire'] for x in revs if x['new_acquire'] is not None]
    eps=[e for r in results for e in r['episode_metrics'] if e['coordination'] is not None]; coords=[e['coordination'] for e in eps]; widths=[e['width'] for e in eps if e['width'] is not None]
    hc=sum(r['h_entries_contr'] for r in results); hn=sum(r['h_entries_non'] for r in results); hec=sum(r['h_eligible_contr'] for r in results); hen=sum(r['h_eligible_non'] for r in results)
    ratec=hc/hec if hec else 0.; raten=hn/hen if hen else 0.; sel=ratec/raten if raten>0 else (float('inf') if ratec>0 else 1.0)
    dw=[d for r in results for d in r['h_dwells']]
    return {'aggregate_service':sum(r['service'] for r in results),'beneficial':ben,'neutral':n-harm-ben,'harmful':harm,'harm_rate':harm/n,'worst_drawdown':min(r['worst_drawdown'] for r in results),'false_c':false_c,'false_c_rate':false_c/cden if cden else None,'false_s':false_s,'false_s_rate':false_s/sden if sden else None,'contradictory_epochs':contr,'contradiction_nomajority_fraction':contru/contr if contr else 1.0,'oscillatory':len(oscids),'oscillatory_fraction':len(oscids)/n,'oscillatory_ids':oscids,'family5_oscillatory_ids':f5,'chatter_trials':sum(r['chatter_events']>0 for r in results),'chatter_events':sum(r['chatter_events'] for r in results),'old_majority_loss_median':statistics.median(old) if old else None,'reversal_acquire_fraction':len(new)/len(revs) if revs else None,'directional_coordination_median':statistics.median(coords) if coords else None,'recruitment_width_median':statistics.median(widths) if widths else None,'spatial_match_mean':statistics.mean([r['spatial_match'] for r in results if r['spatial_match'] is not None]),'h_entries_contr':hc,'h_entries_non':hn,'h_entry_rate_contr':ratec,'h_entry_rate_non':raten,'hedge_selectivity':sel,'h_mean_occupancy':statistics.mean(r['h_mean'] for r in results),'h_peak':max(r['h_peak'] for r in results),'h_mean_occ_contr':sum(r['h_occ_contr'] for r in results)/(sum(r['h_epochs_contr'] for r in results)*N) if sum(r['h_epochs_contr'] for r in results) else 0.,'h_mean_occ_non':sum(r['h_occ_non'] for r in results)/(sum(r['h_epochs_non'] for r in results)*N) if sum(r['h_epochs_non'] for r in results) else 0.,'h_mean_dwell':statistics.mean(dw) if dw else None,'h_median_dwell':statistics.median(dw) if dw else None,'mean_state_entropy':statistics.mean(r['entropy_mean'] for r in results)}

def run(seed):
    allres={a:[] for a in ARMS}
    for ctx in range(48):
        for rep in range(8):
            w=make_world(seed,ctx,rep)
            for a in ARMS: allres[a].append(run_arm(seed,w,a))
    sums={a:summarize(allres[a]) for a in ARMS}; qual={}; info={}
    for arm in PRIMARY_HEDGE:
        s=sums[arm]; ref_name=arm.replace('_H_','_R_'); ref=sums[ref_name]
        rf=set(map(tuple,ref['family5_oscillatory_ids'])); sf=set(map(tuple,s['family5_oscillatory_ids'])); broken=len(rf-sf)
        qual[arm]=(s['oscillatory_fraction']<=.05 and s['oscillatory_fraction']<ref['oscillatory_fraction'] and (broken>=math.ceil(.5*len(rf)) if rf else True) and s['contradiction_nomajority_fraction']>=.90 and s['hedge_selectivity']>=2.0 and s['directional_coordination_median'] is not None and s['directional_coordination_median']>=.80 and s['false_c_rate'] is not None and s['false_c_rate']<=.05 and s['false_s_rate'] is not None and s['false_s_rate']<=.05 and s['reversal_acquire_fraction'] is not None and s['reversal_acquire_fraction']>=.80 and s['aggregate_service']>=.90*ref['aggregate_service'])
        info[arm]={'paired_reference':ref_name,'broken_reference_family5':broken,'reference_family5_total':len(rf),'information_gain':(s['oscillatory_fraction']<ref['oscillatory_fraction'] and (broken>=math.ceil(.25*len(rf)) if rf else True) and s['hedge_selectivity']>=2.0 and s['contradiction_nomajority_fraction']>ref['contradiction_nomajority_fraction'] and s['directional_coordination_median'] is not None and s['directional_coordination_median']>=.80 and s['aggregate_service']>=.90*ref['aggregate_service'])}
    m=manifest(seed); probes={'P1':m['count']==384,'P2':len({(r['ctx'],r['rep']) for r in m['rows']})==384,'P3':N==48,'P4':T==48,'P5':(initial_states().count('C'),initial_states().count('S'),initial_states().count('U'))==(12,12,24),'P6':(POOL_DECAY_NUM,POOL_DECAY_DEN)==(3,4),'P7':(LOCAL_R,HILL_N,HILL_K)==(12,3,.5),'P8':RECRUIT_R==3,'P9':ETA==.5,'P10':POOL_NORM==160.,'P11':all(v[0]==2 for k,v in PRIMARY_HEDGE.items() if k.startswith('D2_')),'P12':all(v[0]==3 for k,v in PRIMARY_HEDGE.items() if k.startswith('D3_')),'P13':set((v[1],v[2]) for v in PRIMARY_HEDGE.values())=={(.75,.25),(.5,.5),(.25,.75)},'P14':(K_SUPP,N_SUPP)==(.5,3),'P15':True,'P16':True,'P17':True,'P18':True,'P19':True,'P20':True,'P21':True,'P22':True,'P23':all(not v[3] for v in REFERENCE.values()),'P24':True,'P25':True,'P26':True}
    return {'seed':seed,'manifest':{'count':m['count'],'sha256':m['sha256']},'summaries':sums,'qualified':qual,'information_gain':info,'integrity':probes}

def main():
    seed=sys.argv[1] if len(sys.argv)>1 else 'MECHANICAL-F35-NONPRIMARY'
    print(json.dumps(run(seed),sort_keys=True,separators=(',',':')))
if __name__=='__main__': main()
