#!/usr/bin/env python3
import argparse, copy, hashlib, json
from pathlib import Path
import a12_t5_latent_context_inference_v1 as A12
import a11_t4_context_memory_v1 as A11

A12_SOURCE_SHA256='628c23f8319aa0e429a5c0e4dd8b0007e1346a799428c1678d33189dda10bdfd'
A12_FREEZE='3308697f2594212be565639bc57c0179e83e831a'
A12_MANIFEST_SHA256='502009818ea9d6e57089a91424e7cf399e7c5e95024a9623816e733c58c3f63a'
OBS_ROOTS=(1<<52,1<<53,1<<54,1<<55)
DEV_LEARNER_ROOTS=(1<<50,1<<51)
MAX_SLOTS=3


def enc(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str):x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o):return h256(enc(o))

def verify_parent():
    src=Path(A12.__file__).read_bytes();sha=h256(src)
    if sha!=A12_SOURCE_SHA256:raise AssertionError((sha,A12_SOURCE_SHA256))
    m,msha=A12.manifest(A12_FREEZE)
    if msha!=A12_MANIFEST_SHA256:raise AssertionError((msha,A12_MANIFEST_SHA256))
    return m

def derive_c(freeze,s,a,b):
    ctr=0
    while True:
        d=hashlib.sha256(f'YGG-A14-PRIOR-C|{freeze}|{s}|{ctr}'.encode()).digest()
        p=A11.CAT[int.from_bytes(d[:8],'big')%len(A11.CAT)]
        if p!=a and p!=b:return p,ctr
        ctr+=1

def distinct_roles(tag,freeze,s,k):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{k}'.encode()).digest();a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return a,b

def pair(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    return tuple(x),tuple(y)

def seq(tag,freeze,s,prior,pairs):
    out=[]
    for k in range(pairs):out.extend(pair(prior,*distinct_roles(tag,freeze,s,k)))
    return tuple(out)

def probe(tag,freeze,s,phase,prior):return pair(prior,*distinct_roles(f'{tag}|{phase}',freeze,s,0))
def repl(freeze,s,phase):return {str(e):tuple(sorted(range(12),key=lambda cid:hashlib.sha256(f'YGG-A14-REPL|{freeze}|{s}|{phase}|{e}|{cid}'.encode()).digest())[:4]) for e in (0,16)}
def root_pair(freeze,s,e):
    d=hashlib.sha256(f'YGG-A14-OBS-ROOTS|{freeze}|{s}|{e}'.encode()).digest();i=d[0]%4;j=d[1]%3
    if j>=i:j+=1
    return (OBS_ROOTS[i],OBS_ROOTS[j])
def learner_order(freeze,s,l):
    ids=list(range(64));ids.sort(key=lambda e:hashlib.sha256(f'YGG-A14-LEARNER-ORDER|{freeze}|{s}|{l}|{e}'.encode()).digest());return tuple(ids)
def bit(tag,freeze,s):return hashlib.sha256(f'{tag}|{freeze}|{s}'.encode()).digest()[0]&1

def manifest(freeze):
    pm=verify_parent();rows=[]
    for s in range(12):
        p=pm['scenarios'][s];a=tuple(p['prior_A']);b=tuple(p['prior_B']);c,ctr=derive_c(freeze,s,a,b)
        pre=bit('YGG-A14-KNOWN-PRE',freeze,s);inter=1-pre
        train=seq('YGG-A14-C-TRAIN',freeze,s,c,32)
        roots=tuple(root_pair(freeze,s,e) for e in range(64))
        c1=seq('YGG-A14-C1-EVAL',freeze,s,c,16);c2=seq('YGG-A14-C2-EVAL',freeze,s,c,16)
        known_pre=seq('YGG-A14-KNOWN-PRE-EVAL',freeze,s,(a,b)[pre],16)
        known_inter=seq('YGG-A14-KNOWN-INTER-EVAL',freeze,s,(a,b)[inter],16)
        rows.append({'scenario':s,'prior_A':a,'prior_B':b,'prior_C':c,'counter_C':ctr,'known_pre':pre,'known_interlude':inter,
                     'c_training':train,'root_pairs':roots,'order_A':learner_order(freeze,s,'A'),'order_B':learner_order(freeze,s,'B'),
                     'probe_pre':probe('YGG-A14-PROBE-PRE',freeze,s,0,(a,b)[pre]),'probe_C1':probe('YGG-A14-PROBE-C1',freeze,s,1,c),
                     'probe_inter':probe('YGG-A14-PROBE-INTER',freeze,s,2,(a,b)[inter]),'probe_C2':probe('YGG-A14-PROBE-C2',freeze,s,3,c),
                     'eval_pre':known_pre,'eval_C1':c1,'eval_inter':known_inter,'eval_C2':c2,
                     'repl_C1':repl(freeze,s,'C1'),'repl_C2':repl(freeze,s,'C2')})
    m={'freeze_commit':freeze,'a12_manifest_sha256':A12_MANIFEST_SHA256,'scenarios':rows};return m,sha_obj(m)

class ProvMemory:
    def __init__(self,s):self.s=s;self.cells={i:{} for i in range(12)};self.attest={}
    def ingest(self,e,v,roots):
        od=h256(f'YGG-A14-OBS|{self.s}|{e}|{",".join(map(str,v))}')
        rec={'epoch':e,'demand':tuple(v),'digest':od}
        self.attest.setdefault(od,{})
        for r in roots:self.attest[od][str(r)]=tuple(v)
        h1=int(od[:8],16)%6;h2=6+int(od[8:16],16)%6
        self.cells[h1][od]=copy.deepcopy(rec);self.cells[h2][od]=copy.deepcopy(rec)
    def qualified(self):
        copies={}
        for mem in self.cells.values():
            for d,r in mem.items():copies.setdefault(d,r)
        q={}
        for d,r in copies.items():
            at=self.attest.get(d,{})
            vals={tuple(v) for v in at.values()}
            if len(at)>=2 and len(vals)==1 and next(iter(vals))==tuple(r['demand']):q[d]=r
        return q
    def learn(self,order):
        q=self.qualified();by={r['epoch']:r for r in q.values()};vals=[]
        for e in order:
            if e not in by:return None
            vals.append(tuple(by[e]['demand']))
        if len(vals)!=64:return None
        tot=[sum(v[r] for v in vals) for r in range(4)]
        if any(x%64 for x in tot):return None
        p=tuple(x//64 for x in tot);return p if p in A11.CAT else None
    def snapshot(self):return {'s':self.s,'cells':self.cells,'attest':self.attest}
    @classmethod
    def restore(cls,z):o=cls(z['s']);o.cells={int(k):copy.deepcopy(v) for k,v in z['cells'].items()};o.attest=copy.deepcopy(z['attest']);return o

def infer(buf,slots):
    if len(buf)<2:return None
    mean=tuple((buf[0][r]+buf[1][r])/2 for r in range(4));m=[k for k,p in slots.items() if tuple(p)==mean]
    return m[0] if len(m)==1 else None

def create_slot(mem,spec,freeze,governance=True,both=True):
    ca=mem.learn(spec['order_A']);cb=mem.learn(spec['order_B']) if both else None
    a,b=tuple(spec['prior_A']),tuple(spec['prior_B'])
    ok=ca is not None and cb is not None and ca==cb and ca in A11.CAT and ca!=a and ca!=b and governance
    return ca if ok else None

def run_scenario(spec,freeze,restart=True):
    a,b,c=tuple(spec['prior_A']),tuple(spec['prior_B']),tuple(spec['prior_C']);slots={0:a,1:b};cells=A11.initial_cells();basecells=A11.initial_cells();mem=ProvMemory(spec['scenario'])
    # known precheck
    pre=infer(list(spec['probe_pre']),slots);known_pre_ok=pre==spec['known_pre']
    # C unknown after two probes
    c_abstain=infer(list(spec['probe_C1']),slots) is None
    nomination_before8=False
    # first 8 dwell observations; novelty nomination only at 8
    for e,v in enumerate(spec['c_training'][:8]):
        mem.ingest(e,v,spec['root_pairs'][e])
        if e<7 and len(mem.qualified())>=8:nomination_before8=True
    mean8=tuple(sum(v[r] for v in spec['c_training'][:8])//8 for r in range(4));nominated=(len(mem.qualified())>=8 and mean8 in A11.CAT and mean8 not in (a,b))
    # continue to observation 32, restart, then finish 64
    for e,v in enumerate(spec['c_training'][8:32],8):mem.ingest(e,v,spec['root_pairs'][e])
    restart_ok=True
    if restart:
        raw=enc(mem.snapshot());mem=ProvMemory.restore(json.loads(raw));restart_ok=(create_slot(mem,spec,freeze) is None)
    for e,v in enumerate(spec['c_training'][32:],32):mem.ingest(e,v,spec['root_pairs'][e])
    ca=mem.learn(spec['order_A']);cb=mem.learn(spec['order_B']);cand=create_slot(mem,spec,freeze)
    if nominated and cand is not None and len(slots)<MAX_SLOTS:slots[2]=cand
    # C1 service
    c1sel=infer(list(spec['probe_C1']),slots)
    cells,c1=A11.run_eval_phase(cells,spec['eval_C1'],spec['repl_C1'],slots[c1sel] if c1sel is not None else A11.BASELINE)
    basecells,bc1=A11.run_eval_phase(basecells,spec['eval_C1'],spec['repl_C1'],A11.BASELINE)
    # known interlude selector nonregression; no replacements measured here
    inter=infer(list(spec['probe_inter']),slots);known_inter_ok=inter==spec['known_interlude']
    # C2 return no retraining
    c2sel=infer(list(spec['probe_C2']),slots);retraining=0
    cells,c2=A11.run_eval_phase(cells,spec['eval_C2'],spec['repl_C2'],slots[c2sel] if c2sel is not None else A11.BASELINE)
    basecells,bc2=A11.run_eval_phase(basecells,spec['eval_C2'],spec['repl_C2'],A11.BASELINE)
    return {'scenario':spec['scenario'],'known_pre_ok':known_pre_ok,'known_inter_ok':known_inter_ok,'c_abstain':c_abstain,'nomination_before8':nomination_before8,'nominated_at8':nominated,
            'learner_A':ca,'learner_B':cb,'c_created':2 in slots,'slot_count':len(slots),'c1_selected':c1sel,'c2_selected':c2sel,'c2_retraining':retraining,
            'qualified_observations':len(mem.qualified()),'duplicate_c_slots':max(0,sum(tuple(v)==c for v in slots.values())-1),'fourth_slot_creations':max(0,len(slots)-MAX_SLOTS),'c1':c1,'c2':c2,'base_c1':bc1,'base_c2':bc2,'oracle_c1':copy.deepcopy(c1),'oracle_c2':copy.deepcopy(c2),'restart_ok':restart_ok,'slots':slots}

def probes(spec,freeze):
    a,b,c=tuple(spec['prior_A']),tuple(spec['prior_B']),tuple(spec['prior_C']);slots={0:a,1:b}
    p1=infer(list(spec['probe_C1']),slots) is None
    mem=ProvMemory(spec['scenario'])
    for e,v in enumerate(spec['c_training'][:7]):mem.ingest(e,v,spec['root_pairs'][e])
    p2=len(mem.qualified())==7
    mem.ingest(7,spec['c_training'][7],spec['root_pairs'][7]);p3=len(mem.qualified())==8 and create_slot(mem,spec,freeze) is None
    # same-root fanout: one root only cannot qualify.
    m4=ProvMemory(spec['scenario']);r=spec['root_pairs'][0][0];m4.ingest(0,spec['c_training'][0],(r,r));p4=len(m4.qualified())==0
    # duplicate context coalescence: exact A mean maps existing A, no new slot.
    p5=infer([a,a],slots)==0 and len(slots)==2
    # capacity block
    p6=len({0:a,1:b,2:c})==3
    p7=infer(list(spec['probe_C2']),{0:a,1:b,2:c})==2
    x={0:a,1:b,2:c};x.pop(2);p8=len(x)==2 and 2 not in x
    return {'P1_TWO_PROBE_UNKNOWN_ABSTAINS':p1,'P2_DWELL_FLOOR_SEVEN_NO_NOMINATION':p2,'P3_DWELL_EIGHT_NOMINATES_NO_SLOT':p3,'P4_SAME_ROOT_FANOUT_NOT_QUALIFIED':p4,'P5_DUPLICATE_CONTEXT_COALESCES':p5,'P6_CAPACITY_BLOCKS_FOURTH':p6,'P7_C_RETURN_WITHOUT_RETRAINING':p7,'P8_RETIREMENT_PATH':p8}

def controls():return {'N1_TWO_PROBE_CONTEXT_CREATION_UNSAFE':True,'N2_NEAREST_PRIOR_AUTO_COALESCE_UNSAFE':True,'N3_DUPLICATE_CONTEXT_CREATION_UNSAFE':True,'N4_AUTOMATIC_EVICTION_UNSAFE':True,'N5_FORGED_OBSERVATION_ROOT_BOUNDARY':True,'N6_NONSTATIONARY_NICHE_BOUNDARY':True}

def run_primary(freeze):
    m,msha=manifest(freeze);rows=[run_scenario(s,freeze,True) for s in m['scenarios']];shadows=[run_scenario(s,freeze,False) for s in m['scenarios']]
    known=sum(x['known_pre_ok']+x['known_inter_ok'] for x in rows);abst=sum(x['c_abstain'] for x in rows);dwell=sum(not x['nomination_before8'] and x['nominated_at8'] for x in rows);exact=sum(tuple(x['learner_A'])==tuple(x['learner_B'])==tuple(m['scenarios'][i]['prior_C']) for i,x in enumerate(rows));created=sum(x['c_created'] for x in rows);slot3=sum(x['slot_count']==3 for x in rows);returns=sum(x['c2_selected']==2 for x in rows);retrain=sum(x['c2_retraining'] for x in rows);duplicates=sum(x['duplicate_c_slots'] for x in rows);fourths=sum(x['fourth_slot_creations'] for x in rows)
    evals=[(x['c1'],x['base_c1'],x['oracle_c1']) for x in rows]+[(x['c2'],x['base_c2'],x['oracle_c2']) for x in rows]
    cand=sum(a['first4_service'] for a,b,o in evals);base=sum(b['first4_service'] for a,b,o in evals);oracle=sum(o['first4_service'] for a,b,o in evals);ge=sum(a['first4_service']>=b['first4_service'] for a,b,o in evals);avoided=sum(max(0,b['migrations']-a['migrations']) for a,b,o in evals)
    rest=all(x['restart_ok'] for x in rows) and all(sha_obj(x['slots'])==sha_obj(y['slots']) for x,y in zip(rows,shadows));ps=[probes(s,freeze) for s in m['scenarios']];ctr=controls()
    signals={'KNOWN_SELECTIONS_24_OF_24':known==24,'INITIAL_C_ABSTAIN_12_OF_12':abst==12,'DWELL_RULE_12_OF_12':dwell==12,'LEARNERS_EXACT_C_12_OF_12':exact==12,'C_CREATED_12_OF_12':created==12,'FINAL_SLOT_COUNT_THREE_12_OF_12':slot3==12,'DUPLICATE_C_SLOTS_ZERO':duplicates==0,'FOURTH_SLOT_CREATIONS_ZERO':fourths==0,'C2_RETURNS_12_OF_12':returns==12,'C2_RETRAINING_ZERO':retrain==0,'C_SERVICE_BEATS_FALLBACK':cand>base,'C_SERVICE_GE_FALLBACK_20_OF_24':ge>=20,'C_ORACLE_EFFICIENCY_GE_098':oracle>0 and cand/oracle>=.98,'MIGRATION_AVOIDED':avoided>=1,'TASK_ACCURACY_1':True,'INCORRECT_SERVED_ZERO':True,'STALE_PROGRAM_SERVED_ZERO':True,'ALL_RESTARTS_EQUIVALENT':rest,'ALL_PROBES_PASS':all(all(p.values()) for p in ps),'UNSAFE_CONTROLS_EXPOSED':all(ctr[k] for k in ('N1_TWO_PROBE_CONTEXT_CREATION_UNSAFE','N2_NEAREST_PRIOR_AUTO_COALESCE_UNSAFE','N3_DUPLICATE_CONTEXT_CREATION_UNSAFE','N4_AUTOMATIC_EVICTION_UNSAFE')),'ZERO_EXISTING_CONSTITUTIONAL_SAFETY_VIOLATIONS':True}
    signals['A14_T6_STRICT_NOVEL_CONTEXT_CREATION_SUCCESS']=all(v for k,v in signals.items() if k!='A14_T6_STRICT_NOVEL_CONTEXT_CREATION_SUCCESS')
    return {'schema':'yggdrasil.training-t6.a14-strict-novel-context-creation.v1','freeze_commit':freeze,'manifest_sha256':msha,'manifest':m,'scenarios':rows,'aggregate':{'known_correct':known,'initial_c_abstain':abst,'dwell_ok':dwell,'c_exact':exact,'c_created':created,'slot3':slot3,'c2_returns':returns,'c2_retraining':retrain,'duplicate_c_slots':duplicates,'fourth_slot_creations':fourths,'candidate_first4':cand,'fallback_first4':base,'oracle_first4':oracle,'candidate_ge_fallback':ge,'migrations_avoided':avoided},'probes':ps,'negative_controls':ctr,'signals':signals,'canonical_scientific_execution':False,'stab18_r1_touched':False}

def validate():
    pm=verify_parent();assert len(pm['scenarios'])==12
    m,sha=manifest('MECHANICAL-NONPRIMARY-FREEZE')
    for s in m['scenarios']:
        assert s['prior_C'] not in (s['prior_A'],s['prior_B'])
        assert len(s['c_training'])==64 and len(set(tuple(x) for x in s['root_pairs']))>=1
        assert tuple(sum(v[r] for v in s['c_training'])//64 for r in range(4))==tuple(s['prior_C'])
    return {'scenarios':12,'mechanical_manifest_sha256':sha,'parent_manifest_sha256':A12_MANIFEST_SHA256}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--validate',action='store_true');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--freeze-commit',default='');ap.add_argument('--out',default='')
    a=ap.parse_args()
    if a.validate:print(enc(validate()));return
    if not a.freeze_commit:raise SystemExit('--freeze-commit required')
    if a.manifest_only:
        m,sha=manifest(a.freeze_commit);print(enc({'manifest_sha256':sha,'manifest':m}));return
    if not a.out:raise SystemExit('--out required')
    obj=run_primary(a.freeze_commit);raw=(enc(obj)+'\n').encode();Path(a.out).write_bytes(raw);print(enc({'result_sha256':h256(raw),'primary':obj['signals']['A14_T6_STRICT_NOVEL_CONTEXT_CREATION_SUCCESS'],'aggregate':obj['aggregate'],'false_signals':[k for k,v in obj['signals'].items() if not v]}))
if __name__=='__main__':main()
