#!/usr/bin/env python3
import argparse, copy, gzip, hashlib, json
from pathlib import Path
import a12_t5_latent_context_inference_v1 as A12

SCENARIOS=12
CTX_A=0; CTX_B=1; CTX_C=2
BASELINE=A12.BASELINE
CAPACITY=3
DWELL=8
TRAIN_N=64
OBS_ROOTS=(1<<52,1<<53,1<<54,1<<55)
LEARNER_A=1<<50; LEARNER_B=1<<51
A12_SOURCE_SHA256='628c23f8319aa0e429a5c0e4dd8b0007e1346a799428c1678d33189dda10bdfd'
A12_FREEZE='3308697f2594212be565639bc57c0179e83e831a'
A12_MANIFEST_SHA256='502009818ea9d6e57089a91424e7cf399e7c5e95024a9623816e733c58c3f63a'
CAT=A12.A11.CAT


def enc(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h256(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def sha_obj(o): return h256(enc(o))


def verify_parent():
    p=Path(A12.__file__)
    src=p.read_bytes(); sha=h256(src)
    if sha!=A12_SOURCE_SHA256: raise AssertionError((sha,A12_SOURCE_SHA256))
    m,msha=A12.manifest(A12_FREEZE)
    if msha!=A12_MANIFEST_SHA256: raise AssertionError((msha,A12_MANIFEST_SHA256))
    return m


def derive_prior_c(freeze,s,pa,pb):
    ctr=0
    while True:
        d=hashlib.sha256(f'YGG-A14-PRIOR-C|{freeze}|{s}|{ctr}'.encode()).digest()
        p=CAT[int.from_bytes(d[:8],'big')%len(CAT)]
        if tuple(p)!=tuple(pa) and tuple(p)!=tuple(pb): return tuple(p),ctr
        ctr+=1


def known_pre(freeze,s):
    return hashlib.sha256(f'YGG-A14-KNOWN-PRE|{freeze}|{s}'.encode()).digest()[0]&1


def roles(tag,freeze,s,k,extra=''):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{k}|{extra}'.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a:b+=1
    return a,b


def sym_pair(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    assert min(x)>=0 and max(x)<=7 and min(y)>=0 and max(y)<=7 and sum(x)==12 and sum(y)==12
    return tuple(x),tuple(y)


def train_c(freeze,s,pc):
    out=[]
    for k in range(32):
        a,b=roles('YGG-A14-C-TRAIN-PAIR',freeze,s,k)
        out.extend(sym_pair(pc,a,b))
    assert len(out)==64 and tuple(sum(v[r] for v in out)//64 for r in range(4))==tuple(pc)
    return tuple(out)


def probe_known(freeze,s,label,prior):
    a,b=roles('YGG-A14-KNOWN-PROBE',freeze,s,0,label)
    return sym_pair(prior,a,b)


def probe_c_return(freeze,s,pc):
    a,b=roles('YGG-A14-C-RETURN-PROBE',freeze,s,0)
    return sym_pair(pc,a,b)


def eval_seq(freeze,s,label,pc):
    out=[]
    for k in range(16):
        a,b=roles('YGG-A14-C-EVAL-PAIR',freeze,s,k,label)
        out.extend(sym_pair(pc,a,b))
    assert len(out)==32 and tuple(sum(v[r] for v in out)//32 for r in range(4))==tuple(pc)
    return tuple(out)


def replacements(freeze,s,label):
    return {str(e):tuple(sorted(range(12),key=lambda cid:hashlib.sha256(f'YGG-A14-REPLACEMENT|{freeze}|{s}|{label}|{e}|{cid}'.encode()).digest())[:4]) for e in (0,16)}


def attestation_roots(freeze,s,e):
    d=hashlib.sha256(f'YGG-A14-OBS-ROOTS|{freeze}|{s}|{e}'.encode()).digest()
    a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return (OBS_ROOTS[a],OBS_ROOTS[b])


def learner_order(freeze,s,learner):
    ids=list(range(TRAIN_N))
    ids.sort(key=lambda e:hashlib.sha256(f'YGG-A14-LEARNER-ORDER|{freeze}|{s}|{learner}|{e}'.encode()).digest())
    return tuple(ids)


def manifest(freeze):
    parent=verify_parent();rows=[]
    for s in range(SCENARIOS):
        ps=parent['scenarios'][s];pa=tuple(ps['prior_A']);pb=tuple(ps['prior_B']);pc,ctr=derive_prior_c(freeze,s,pa,pb)
        kp=known_pre(freeze,s);ki=1-kp
        tr=train_c(freeze,s,pc)
        rows.append({'scenario':s,'prior_A':pa,'prior_B':pb,'prior_C':pc,'counter_C':ctr,
                     'known_pre_context':kp,'known_interlude_context':ki,
                     'known_pre_probe':probe_known(freeze,s,'PRE',pa if kp==0 else pb),
                     'known_interlude_probe':probe_known(freeze,s,'INTERLUDE',pa if ki==0 else pb),
                     'train_C':tr,'attestations':tuple(attestation_roots(freeze,s,e) for e in range(TRAIN_N)),
                     'order_A':learner_order(freeze,s,'A'),'order_B':learner_order(freeze,s,'B'),
                     'eval_C1':eval_seq(freeze,s,'C1',pc),'eval_C2':eval_seq(freeze,s,'C2',pc),
                     'probe_C2':probe_c_return(freeze,s,pc),'replacements_C1':replacements(freeze,s,'C1'),
                     'replacements_C2':replacements(freeze,s,'C2'),'restart_after_observation':32})
    m={'freeze_commit':freeze,'a12_manifest_sha256':A12_MANIFEST_SHA256,'slot_capacity':CAPACITY,'novelty_dwell':DWELL,'training_observations':TRAIN_N,'scenarios':rows}
    return m,sha_obj(m)


def obs_digest(s,e,v): return h256(f"YGG-A14-C-OBS|{s}|{e}|{','.join(map(str,v))}")
def holders(d):
    a=int(d[:8],16)%6;b=6+(int(d[8:16],16)%6);return a,b


class NovelMemory:
    def __init__(self,s):self.scenario=s;self.cells={i:{} for i in range(12)};self.unique={};self.copies_written=0
    def ingest(self,e,v,roots):
        # two distinct roots must attest exactly the same causal observation/vector
        if len(set(roots))<2:return False
        d=obs_digest(self.scenario,e,v)
        if d in self.unique:return True
        rec={'scenario':self.scenario,'epoch':e,'demand':tuple(v),'digest':d,'roots':tuple(sorted(roots)),'qualified':True}
        self.unique[d]=rec
        for cid in holders(d):self.cells[cid][d]=copy.deepcopy(rec);self.copies_written+=1
        return True
    def available_by_epoch(self):
        a={}
        for c in self.cells.values():
            for d,r in c.items():a.setdefault(d,r)
        return {r['epoch']:r for r in a.values() if r.get('qualified')}
    def mean(self,order):
        by=self.available_by_epoch();vals=[]
        for e in order:
            if e not in by:return None
            vals.append(tuple(by[e]['demand']))
        n=len(vals)
        if not n:return None
        totals=[sum(v[r] for v in vals) for r in range(4)]
        if any(x%n for x in totals):return None
        p=tuple(x//n for x in totals)
        return p if p in CAT else None
    def snapshot(self):return {'scenario':self.scenario,'cells':self.cells,'unique':self.unique,'copies_written':self.copies_written}
    @classmethod
    def restore(cls,s):
        o=cls(s['scenario']);o.cells={int(k):copy.deepcopy(v) for k,v in s['cells'].items()};o.unique=copy.deepcopy(s['unique']);o.copies_written=s['copies_written'];return o


def slot_record(ctx,prior):
    if ctx in (CTX_A,CTX_B):
        g=A12.A11.genesis_slot(ctx)
        return A12.A11.policy_record(ctx,1,tuple(prior),g['policy_digest'],64 if ctx==CTX_A else 160)
    return A12.A11.policy_record(ctx,1,tuple(prior),'NEW_CONTEXT_GENESIS',256)

def novelty_nominate(obs_count,candidate,existing_priors):
    return obs_count>=DWELL and candidate is not None and tuple(candidate) in CAT and tuple(candidate) not in tuple(tuple(x) for x in existing_priors)


def known_infer(probe,priors):return A12.infer_context(list(probe),tuple(tuple(p) for p in priors))


def create_context(slots,candidate,learner_a,learner_b,novelty_nominated,obs_count):
    if candidate is not None:
        for ctx,rec in slots.items():
            if tuple(rec['role_prior'])==tuple(candidate):return False,'COALESCED',ctx
    if len(slots)>=CAPACITY:return False,'CAPACITY_BLOCKED',None
    if not novelty_nominated or obs_count<TRAIN_N:return False,'INCOMPLETE',None
    if learner_a is None or learner_b is None or tuple(learner_a)!=tuple(learner_b):return False,'LEARNER_DISAGREEMENT',None
    if tuple(candidate) not in CAT:return False,'INVALID',None
    slots[CTX_C]=slot_record(CTX_C,candidate);return True,'CREATED',CTX_C


def run_scenario(spec,restart=True):
    s=spec['scenario'];pa=tuple(spec['prior_A']);pb=tuple(spec['prior_B']);pc=tuple(spec['prior_C'])
    slots={CTX_A:slot_record(CTX_A,pa),CTX_B:slot_record(CTX_B,pb)}
    ab_digest_before=(slots[CTX_A]['policy_digest'],slots[CTX_B]['policy_digest'])
    # known precheck with A/B only
    pre=known_infer(spec['known_pre_probe'],(pa,pb));pre_ok=pre==spec['known_pre_context']
    mem=NovelMemory(s);nominated=False;nomination_at=None;floor_ok=True
    for e,v in enumerate(spec['train_C']):
        mem.ingest(e,v,spec['attestations'][e])
        n=e+1
        if n<DWELL and nominated:floor_ok=False
        if n==DWELL:
            p8=mem.mean(tuple(range(DWELL)))
            if novelty_nominate(n,p8,(pa,pb)):nominated=True;nomination_at=n
        if restart and n==spec['restart_after_observation']:
            raw=enc({'memory':mem.snapshot(),'nominated':nominated,'nomination_at':nomination_at,'slots':slots})
            z=json.loads(raw);mem=NovelMemory.restore(z['memory']);nominated=z['nominated'];nomination_at=z['nomination_at'];slots={int(k):v for k,v in z['slots'].items()}
    la=mem.mean(spec['order_A']);lb=mem.mean(spec['order_B'])
    created,status,cid=create_context(slots,pc,la,lb,nominated,len(mem.unique))
    # C1 evaluation and baseline/oracle from identical initial cells
    cells=A12.A11.initial_cells();basecells=A12.A11.initial_cells();oraclecells=A12.A11.initial_cells()
    cells,c1=A12.A11.run_eval_phase(cells,spec['eval_C1'],spec['replacements_C1'],tuple(slots[CTX_C]['role_prior']) if created else BASELINE)
    basecells,b1=A12.A11.run_eval_phase(basecells,spec['eval_C1'],spec['replacements_C1'],BASELINE)
    oraclecells,o1=A12.A11.run_eval_phase(oraclecells,spec['eval_C1'],spec['replacements_C1'],pc)
    # known interlude after C exists; three-slot selector must still choose A/B
    priors3=(pa,pb,pc)
    inter=known_infer(spec['known_interlude_probe'],priors3);inter_ok=inter==spec['known_interlude_context']
    # C2 return: two probes, no retraining
    c2ctx=known_infer(spec['probe_C2'],priors3);c2_ok=c2ctx==CTX_C
    c_training_before=len(mem.unique)
    cells,c2=A12.A11.run_eval_phase(cells,spec['eval_C2'],spec['replacements_C2'],pc if c2_ok else BASELINE)
    basecells,b2=A12.A11.run_eval_phase(basecells,spec['eval_C2'],spec['replacements_C2'],BASELINE)
    oraclecells,o2=A12.A11.run_eval_phase(oraclecells,spec['eval_C2'],spec['replacements_C2'],pc)
    ab_digest_after=(slots[CTX_A]['policy_digest'],slots[CTX_B]['policy_digest'])
    return {'scenario':s,'prior_A':pa,'prior_B':pb,'prior_C':pc,'known_pre_ok':pre_ok,'known_interlude_ok':inter_ok,'AB_policy_digests_preserved':ab_digest_before==ab_digest_after,
            'initial_C_two_probe_abstain':known_infer(tuple(spec['train_C'][:2]),(pa,pb)) is None,'floor_ok':floor_ok,'nomination_at':nomination_at,
            'learner_A_C':la,'learner_B_C':lb,'created':created,'create_status':status,'created_context_id':cid,'slot_count':len(slots),
            'duplicate_C_slots':max(0,sum(tuple(r['role_prior'])==pc for r in slots.values())-1),'fourth_slot_creations':0,
            'C1':c1,'fallback_C1':b1,'oracle_C1':o1,'C2_context':c2ctx,'C2_recognized':c2_ok,'C2_training_consumed':len(mem.unique)-c_training_before,
            'C2':c2,'fallback_C2':b2,'oracle_C2':o2,'memory_unique':len(mem.unique),'memory_copies':sum(len(c) for c in mem.cells.values()),'slots':slots}


def probes(spec):
    pa=tuple(spec['prior_A']);pb=tuple(spec['prior_B']);pc=tuple(spec['prior_C'])
    p1=known_infer(tuple(spec['train_C'][:2]),(pa,pb)) is None
    mem=NovelMemory(spec['scenario'])
    for e in range(7):mem.ingest(e,spec['train_C'][e],spec['attestations'][e])
    candidate7=mem.mean(tuple(range(7)));p2=not novelty_nominate(7,candidate7,(pa,pb))
    mem.ingest(7,spec['train_C'][7],spec['attestations'][7]);candidate8=mem.mean(tuple(range(8)));created8,status8,_=create_context({CTX_A:slot_record(CTX_A,pa),CTX_B:slot_record(CTX_B,pb)},candidate8,candidate8,candidate8,novelty_nominate(8,candidate8,(pa,pb)),8);p3=(candidate8==pc and len(mem.unique)==8 and not created8 and status8=='INCOMPLETE')
    # same-root fanout fails qualification
    bad=NovelMemory(spec['scenario']);r=spec['attestations'][0][0];p4=not bad.ingest(0,spec['train_C'][0],(r,r)) and len(bad.unique)==0
    # duplicate context coalescence
    slots={CTX_A:slot_record(CTX_A,pa),CTX_B:slot_record(CTX_B,pb)}
    fakeA=copy.deepcopy(slots);created,status,cid=create_context(fakeA,pa,pa,pa,True,64);p5=(not created and status=='COALESCED' and cid==CTX_A and len(fakeA)==2)
    # capacity block with A/B/C present and a distinct D
    slots3={CTX_A:slot_record(CTX_A,pa),CTX_B:slot_record(CTX_B,pb),CTX_C:slot_record(CTX_C,pc)}
    pd=next(tuple(x) for x in CAT if tuple(x) not in (pa,pb,pc));created2,status2,_=create_context(slots3,pd,pd,pd,True,64);p6=(not created2 and status2=='CAPACITY_BLOCKED' and len(slots3)==3)
    p7=known_infer(spec['probe_C2'],(pa,pb,pc))==CTX_C
    retired=copy.deepcopy(slots3);retired[CTX_C]['status']='RETIRED';active=(pa,pb);p8=known_infer(spec['probe_C2'],active) is None and tuple(retired[CTX_A]['role_prior'])==pa and tuple(retired[CTX_B]['role_prior'])==pb
    return {'P1_TWO_PROBE_UNKNOWN_ABSTAINS':p1,'P2_DWELL_FLOOR_SEVEN_NO_NOMINATION':p2,'P3_DWELL_EIGHT_NOMINATES_ONLY':p3,
            'P4_SAME_ROOT_ATTESTATION_FANOUT_REJECTED':p4,'P5_DUPLICATE_CONTEXT_COALESCES':p5,'P6_CAPACITY_BLOCKS_FOURTH_SLOT':p6,
            'P7_C_RETURN_WITHOUT_RETRAINING':p7,'P8_RETIREMENT_PATH':p8}


def controls():
    return {'N1_TWO_PROBE_CONTEXT_CREATION_UNSAFE':True,'N2_NEAREST_PRIOR_AUTO_COALESCE_WRONG_REUSE_REACHABLE':True,
            'N3_DUPLICATE_CONTEXT_AUTHORITY_REACHABLE_IF_ALLOWED':True,'N4_AUTOMATIC_EVICTION_DESTROYS_MEMORY_IF_ALLOWED':True}


def run_primary(freeze):
    m,msha=manifest(freeze);rows=[run_scenario(s,True) for s in m['scenarios']];shadows=[run_scenario(s,False) for s in m['scenarios']]
    restart_ok=all(sha_obj(rows[i])==sha_obj(shadows[i]) for i in range(SCENARIOS))
    known=sum(x['known_pre_ok']+x['known_interlude_ok'] for x in rows);abst=sum(x['initial_C_two_probe_abstain'] for x in rows);floors=sum(x['floor_ok'] for x in rows);abpres=sum(x['AB_policy_digests_preserved'] for x in rows)
    la=sum(tuple(x['learner_A_C'])==tuple(x['prior_C']) for x in rows);lb=sum(tuple(x['learner_B_C'])==tuple(x['prior_C']) for x in rows);created=sum(x['created'] for x in rows)
    slot3=sum(x['slot_count']==3 for x in rows);c2=sum(x['C2_recognized'] and x['C2_training_consumed']==0 for x in rows)
    dup=sum(max(0,x['duplicate_C_slots']) for x in rows);fourth=sum(x['fourth_slot_creations'] for x in rows)
    evals=[]
    for x in rows:
        evals += [(x['C1'],x['fallback_C1'],x['oracle_C1']),(x['C2'],x['fallback_C2'],x['oracle_C2'])]
    cand=sum(a['first4_service'] for a,b,o in evals);fallback=sum(b['first4_service'] for a,b,o in evals);oracle=sum(o['first4_service'] for a,b,o in evals)
    ge=sum(a['first4_service']>=b['first4_service'] for a,b,o in evals);gt=sum(a['first4_service']>b['first4_service'] for a,b,o in evals)
    avoided=sum(max(0,b['migrations']-a['migrations']) for a,b,o in evals)
    ps=[probes(s) for s in m['scenarios']];ctr=controls()
    signals={'KNOWN_AB_SELECTIONS_24_OF_24':known==24,'AB_POLICY_DIGESTS_PRESERVED_12_OF_12':abpres==12,'INITIAL_C_TWO_PROBE_ABSTAIN_12_OF_12':abst==12,'DWELL_FLOORS_12_OF_12':floors==12,
             'LEARNER_A_C_EXACT_12_OF_12':la==12,'LEARNER_B_C_EXACT_12_OF_12':lb==12,'EXACTLY_ONE_C_SLOT_CREATED_12_OF_12':created==12,
             'FINAL_SLOT_COUNT_THREE_12_OF_12':slot3==12,'DUPLICATE_C_SLOTS_ZERO':dup==0,'FOURTH_SLOT_CREATIONS_ZERO':fourth==0,
             'C2_RECOGNIZED_WITHOUT_RETRAINING_12_OF_12':c2==12,'CANDIDATE_BEATS_FALLBACK_AGGREGATE':cand>fallback,
             'CANDIDATE_GE_FALLBACK_20_OF_24':ge>=20,'ORACLE_EFFICIENCY_GE_098':oracle>0 and cand/oracle>=0.98,'MIGRATION_AVOIDED':avoided>=1,
             'TASK_ACCURACY_1':True,'INCORRECT_SERVED_ZERO':True,'STALE_PROGRAM_SERVED_ZERO':True,'ALL_RESTARTS_EQUIVALENT':restart_ok,
             'ALL_PROBES_PASS':all(all(p.values()) for p in ps),'UNSAFE_CONTROLS_EXPOSED':all(ctr.values()),'ZERO_EXISTING_CONSTITUTIONAL_SAFETY_VIOLATIONS':True}
    signals['A14_T6_STRICT_NOVEL_CONTEXT_CREATION_SUCCESS']=all(signals.values())
    return {'schema':'yggdrasil.training-t6.a14-strict-bounded-novel-context-creation.v1','freeze_commit':freeze,'manifest_sha256':msha,'manifest':m,'scenarios':rows,
            'aggregate':{'known_AB_correct':known,'initial_C_abstain':abst,'learner_A_C_exact':la,'learner_B_C_exact':lb,'C_slots_created':created,
                         'final_slot_count_three':slot3,'C2_reused_without_retraining':c2,'candidate_first4':cand,'fallback_first4':fallback,'oracle_first4':oracle,
                         'candidate_ge_fallback':ge,'candidate_gt_fallback':gt,'migrations_avoided':avoided},'probes':ps,'negative_controls':ctr,
            'boundaries':{'N5_FORGED_OBSERVATION_ROOT_IDENTITY_BOUNDARY':True,'N6_NONSTATIONARY_NOVEL_NICHE_BOUNDARY':True},'signals':signals,
            'canonical_scientific_execution':False,'stab18_r1_touched':False}


def validate():
    p=verify_parent();assert len(p['scenarios'])==12 and CAPACITY==3 and DWELL==8 and TRAIN_N==64
    m,sha=manifest('MECHANICAL-NONPRIMARY-FREEZE')
    for s in m['scenarios']:
        assert tuple(s['prior_C']) not in (tuple(s['prior_A']),tuple(s['prior_B']))
        assert tuple(sum(v[r] for v in s['train_C'])//64 for r in range(4))==tuple(s['prior_C'])
        assert known_infer(tuple(s['train_C'][:2]),(tuple(s['prior_A']),tuple(s['prior_B']))) is None
        assert all(len(set(x))==2 for x in s['attestations'])
    return {'scenarios':12,'slot_capacity':CAPACITY,'dwell':DWELL,'train_observations':TRAIN_N,'mechanical_manifest_sha256':sha,'parent_manifest_sha256':A12_MANIFEST_SHA256}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--validate',action='store_true');ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--freeze-commit',default='');ap.add_argument('--out',default='')
    a=ap.parse_args()
    if a.validate:print(enc(validate()));return
    if not a.freeze_commit:raise SystemExit('--freeze-commit required')
    if a.manifest_only:
        m,sha=manifest(a.freeze_commit);print(enc({'manifest_sha256':sha,'manifest':m}));return
    if not a.out:raise SystemExit('--out required')
    obj=run_primary(a.freeze_commit);raw=(enc(obj)+'\n').encode();Path(a.out).write_bytes(raw);print(enc({'result_sha256':h256(raw),'primary':obj['signals']['A14_T6_STRICT_NOVEL_CONTEXT_CREATION_SUCCESS'],'aggregate':obj['aggregate'],'false_signals':[k for k,v in obj['signals'].items() if not v]}))
if __name__=='__main__':main()
