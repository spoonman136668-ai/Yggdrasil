#!/usr/bin/env python3
import argparse, hashlib, json, math, statistics

MASK=(1<<64)-1
N_CELLS=48
EPOCHS=40
INIT_UNRES=set(range(0,48,4))
INIT_STATE=tuple(0 if i in INIT_UNRES else 1 for i in range(48))  # 0=U,1=C,2=F
PRIMARY_D=[0,1,2,3,4,6]
ALL_D=PRIMARY_D+[8]
CHALLENGE_ON=8

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

def splitmix64(x):
    x=(x+0x9E3779B97F4A7C15)&MASK
    z=x
    z=(z^(z>>30))*0xBF58476D1CE4E5B9 & MASK
    z=(z^(z>>27))*0x94D049BB133111EB & MASK
    return (z^(z>>31)) & MASK

def seed64(*parts):
    h=hashlib.sha256("|".join(map(str,parts)).encode()).digest()
    return int.from_bytes(h[:8],"big")

def draw_u64(base, epoch, cell, channel):
    x=base ^ ((epoch+1)*0xD6E8FEB86659FD93 & MASK) ^ ((cell+1)*0xA5A3564E27F8862B & MASK) ^ ((channel+1)*0x9E3779B97F4A7C15 & MASK)
    return splitmix64(x)

def bernoulli(base,epoch,cell,channel,num,den):
    if num<=0: return False
    if num>=den: return True
    threshold=(num<<64)//den
    return draw_u64(base,epoch,cell,channel) < threshold

def neigh(i,r):
    return [((i+d)%N_CELLS) for d in range(-r,r+1)]

NEIGH12=[neigh(i,12) for i in range(N_CELLS)]
NEIGH3=[neigh(i,3) for i in range(N_CELLS)]

def evenly_spaced(count, offset):
    if count<=0: return set()
    # select count positions by floor(k*N/count), rotated by offset
    return { (offset + (k*N_CELLS)//count) % N_CELLS for k in range(count) }

def trial_id(seed,ctx,rep):
    return sha(f"YGG-A31|{seed}|CTX{ctx:02d}|REP{rep}")

def context_spec(ctx):
    fam=ctx//8; idx=ctx%8
    if fam==0:
        return {"family":0,"kind":"cluster","size":[1,2,3,4,5,6,7,8][idx],"start":8,"end":23}
    if fam==1:
        return {"family":1,"kind":"cluster","size":[4,8,12,16,20,24,28,32][idx],"start":8,"end":23}
    if fam==2:
        return {"family":2,"kind":"dispersed","size":[4,8,12,16,20,24,28,32][idx],"start":8,"end":23}
    if fam==3:
        pairs=[(24,1),(24,2),(24,4),(32,1),(32,2),(32,4),(40,1),(40,2)]
        size,dur=pairs[idx]
        return {"family":3,"kind":"transient","size":size,"start":8,"end":8+dur-1}
    if fam==4:
        periods=[(1,0),(2,0),(3,0),(4,0),(1,1),(2,1),(3,1),(4,1)]
        period,phase=periods[idx]
        return {"family":4,"kind":"oscillatory","size":24,"period":period,"phase":phase,"start":8,"end":31}
    sizes=[1,2,3,4,1,2,3,4]
    geom="dense" if idx<4 else "boundary"
    return {"family":5,"kind":"strategic","size":sizes[idx],"geometry":geom,"start":8,"end":23}

def emitters_for(seed,ctx,rep,epoch):
    spec=context_spec(ctx)
    if epoch < spec["start"] or epoch > spec["end"]:
        return set()
    tid=trial_id(seed,ctx,rep)
    off=seed64(tid,"OFFSET")%N_CELLS
    kind=spec["kind"]; size=spec["size"]
    if kind=="cluster":
        start=off
        return {(start+j)%N_CELLS for j in range(size)}
    if kind=="dispersed":
        return evenly_spaced(size,off)
    if kind=="transient":
        return evenly_spaced(size,off)
    if kind=="oscillatory":
        p=spec["period"]; ph=spec["phase"]
        if ((epoch-spec["start"]+ph)//p)%2==1:
            return set()
        return evenly_spaced(size,off)
    # strategic: place relative to initial committed geometry
    if spec["geometry"]=="dense":
        # start one step after an unresolved anchor; mostly inside C run.
        start=(4*(off%12)+1)%N_CELLS
    else:
        start=(4*(off%12))%N_CELLS
    return {(start+j)%N_CELLS for j in range(size)}

def challenge_manifest(seed):
    rows=[]
    for ctx in range(48):
        for rep in range(8):
            rows.append({
                "ctx":ctx,"rep":rep,"trial_id":trial_id(seed,ctx,rep),
                "spec":context_spec(ctx),
                "emitters":[sorted(emitters_for(seed,ctx,rep,t)) for t in range(EPOCHS)]
            })
    return rows

def max_noncommitted_run(state):
    non=[1 if x!=1 else 0 for x in state]
    if all(non): return N_CELLS
    arr=non+non
    best=cur=0
    for v in arr:
        if v:
            cur+=1; best=max(best,cur)
        else: cur=0
    return min(best,N_CELLS)

def simulate(seed,ctx,rep,D):
    state=list(INIT_STATE)
    release=[-1]*N_CELLS
    base=seed64("YGG-A31",seed,trial_id(seed,ctx,rep),"ARM",D)
    c_hist=[]; f_hist=[]; u_hist=[]; crossings=0
    prev_major=True
    trans=[[] for _ in range(N_CELLS)]
    wound_hist=[]
    min_challenge_c=36
    spec=context_spec(ctx)
    for t in range(EPOCHS):
        # release refractory before decisions at epoch t
        for i in range(N_CELLS):
            if state[i]==2 and release[i] <= t:
                state[i]=0
                trans[i].append(("release",t))
        emit=emitters_for(seed,ctx,rep,t)
        pre=state[:]
        to_defect=[]
        to_join=[]
        for i in range(N_CELLS):
            if pre[i]==1:
                m=sum(1 for j in NEIGH12[i] if j in emit)
                # p_stay = 25^3 / (25^3 + (2m)^3)
                num=25**3
                den=num+(2*m)**3
                if not bernoulli(base,t,i,0,num,den):
                    to_defect.append(i)
            elif pre[i]==0:
                c=sum(1 for j in NEIGH3[i] if pre[j]==1)
                m=sum(1 for j in NEIGH3[i] if j in emit)
                # p_join=125*c^3/(9261+125*c^3) * (7-m)/7
                a=125*(c**3)
                num=a*(7-m)
                den=(9261+a)*7
                if bernoulli(base,t,i,1,num,den):
                    to_join.append(i)
        for i in to_defect:
            if D==0:
                state[i]=0
                release[i]=-1
            else:
                state[i]=2
                release[i]=t+D+1
            trans[i].append(("defect",t))
        for i in to_join:
            # only pre-U can join; simultaneous update means fresh defectors cannot rejoin same epoch
            if pre[i]==0 and state[i]==0:
                state[i]=1
                trans[i].append(("join",t))
        c=sum(1 for x in state if x==1)
        f=sum(1 for x in state if x==2)
        u=N_CELLS-c-f
        c_hist.append(c); f_hist.append(f); u_hist.append(u)
        wound_hist.append(max_noncommitted_run(state))
        if spec["start"] <= t <= spec["end"]:
            min_challenge_c=min(min_challenge_c,c)
        maj=c>=24  # >=1/2 is not below 1/2; crossing uses threshold 24
        if t>=CHALLENGE_ON and maj!=prev_major:
            crossings+=1
        prev_major=maj
    # erosion latency for sustained broad family1/2 >=24
    broad=(spec["family"] in (1,2) and spec["size"]>=24)
    erosion=None
    if broad:
        for t in range(CHALLENGE_ON,EPOCHS):
            if c_hist[t] < 24:
                erosion=t-CHALLENGE_ON; break
    end=spec["end"]
    recovery=None
    if end < EPOCHS-1:
        for t in range(end+1,EPOCHS):
            if c_hist[t]>=36:
                recovery=t-end; break
    # chatter events
    chatter=0; chatter_cells=0
    for evs in trans:
        found=0
        defects=[t for typ,t in evs if typ=="defect"]
        joins=[t for typ,t in evs if typ=="join"]
        for d1 in defects:
            js=[j for j in joins if j>d1 and j-d1<=6]
            for j in js:
                if any(d2>j and d2-d1<=6 for d2 in defects):
                    found+=1; break
        if found:
            chatter+=found; chatter_cells+=1
    oscillatory=crossings>=3
    strategic_small=(spec["family"]==5 and spec["size"] in (1,2))
    strategic_collapse=strategic_small and min(c_hist[CHALLENGE_ON:])<24
    one_emit=(spec["family"]==0 and spec["size"]==1)
    robust=(not one_emit) or (min_challenge_c>=32)
    initial_wound=max_noncommitted_run(INIT_STATE)
    if max(wound_hist[CHALLENGE_ON:])>=24:
        wound="PROPAGATES"
    elif wound_hist[31] <= initial_wound+2:
        wound="HEALS"
    else:
        wound="PERSISTS"
    return {
        "ctx":ctx,"rep":rep,"family":spec["family"],"size":spec.get("size"),
        "D":D,"c_hist":c_hist,"f_hist":f_hist,"u_hist":u_hist,
        "crossings":crossings,"oscillatory":oscillatory,"erosion":erosion,
        "recovery":recovery,"robust":robust,"strategic_small":strategic_small,
        "strategic_collapse":strategic_collapse,"chatter":chatter,
        "chatter_cells":chatter_cells,"wound":wound,
        "max_wound":max(wound_hist),"peak_f":max(f_hist),
        "mean_f":sum(f_hist)/EPOCHS,
        "residual_f_epochs":sum(1 for t in range(spec["end"]+1,EPOCHS) if f_hist[t]>0) if spec["end"]<EPOCHS-1 else 0,
    }

def summarize(seed):
    byD={}
    trials_byD={}
    for D in ALL_D:
        rows=[simulate(seed,ctx,rep,D) for ctx in range(48) for rep in range(8)]
        trials_byD[D]=rows
    d0={(r["ctx"],r["rep"]):r for r in trials_byD[0]}
    d0_chatter_trials=sum(1 for r in trials_byD[0] if r["chatter"]>0)
    d0_recover={k:r["recovery"] for k,r in d0.items() if r["recovery"] is not None}
    for D,rows in trials_byD.items():
        broad=[r for r in rows if r["erosion"] is not None or (r["family"] in (1,2) and r["size"]>=24)]
        eros=[99 if r["erosion"] is None else r["erosion"] for r in broad]
        one=[r for r in rows if r["family"]==0 and r["size"]==1]
        strat=[r for r in rows if r["strategic_small"]]
        osc=sum(r["oscillatory"] for r in rows)
        ch_trials=sum(1 for r in rows if r["chatter"]>0)
        eligible_keys=list(d0_recover)
        rec_ok=0
        for k in eligible_keys:
            rr=next(r for r in rows if (r["ctx"],r["rep"])==k)
            if rr["recovery"] is not None and rr["recovery"] <= d0_recover[k]+4:
                rec_ok+=1
        wound_counts={x:sum(r["wound"]==x for r in rows) for x in ("HEALS","PERSISTS","PROPAGATES")}
        byD[str(D)]={
            "oscillatory_count":osc,
            "oscillatory_fraction":osc/384,
            "broad_count":len(broad),
            "broad_median_erosion":statistics.median(eros),
            "broad_never":sum(x==99 for x in eros),
            "one_emitter_robust_fraction":sum(r["robust"] for r in one)/len(one),
            "strategic_small_collapse_fraction":sum(r["strategic_collapse"] for r in strat)/len(strat),
            "chatter_events":sum(r["chatter"] for r in rows),
            "chatter_cells":sum(r["chatter_cells"] for r in rows),
            "chatter_trials":ch_trials,
            "chatter_trial_fraction":ch_trials/384,
            "chatter_reduction_vs_d0": (d0_chatter_trials-ch_trials)/d0_chatter_trials if d0_chatter_trials else 0,
            "d0_finite_recovery_count":len(eligible_keys),
            "recovery_within_d0_plus4_fraction": rec_ok/len(eligible_keys) if eligible_keys else 1,
            "mean_refractory_occupancy":sum(r["mean_f"] for r in rows)/384,
            "peak_refractory_cells":max(r["peak_f"] for r in rows),
            "postchallenge_residual_f_epochs_total":sum(r["residual_f_epochs"] for r in rows),
            "wounds":wound_counts,
        }
    qualified=[]
    for D in [1,2,3,4,6]:
        m=byD[str(D)]
        if (m["oscillatory_fraction"]<=0.05 and
            m["oscillatory_fraction"]<byD["0"]["oscillatory_fraction"] and
            m["broad_median_erosion"]<=1 and
            m["one_emitter_robust_fraction"]>=0.95 and
            m["strategic_small_collapse_fraction"]<=0.05 and
            m["recovery_within_d0_plus4_fraction"]>=0.80 and
            m["chatter_reduction_vs_d0"]>=0.25):
            qualified.append(D)
    info=any(
        byD[str(D)]["oscillatory_fraction"]<=0.05 and
        byD[str(D)]["broad_median_erosion"]<=1 and
        byD[str(D)]["chatter_reduction_vs_d0"]>=0.25
        for D in [1,2,3,4,6]
    )
    manifest=challenge_manifest(seed)
    manifest_bytes=json.dumps(manifest,sort_keys=True,separators=(",",":")).encode()
    probes={
        "P1_trials_384": len(manifest)==384,
        "P2_48x8": len({x["ctx"] for x in manifest})==48 and all(sum(1 for x in manifest if x["ctx"]==c)==8 for c in range(48)),
        "P3_cells_48": N_CELLS==48,
        "P4_init_C_36": sum(INIT_STATE)==36,
        "P5_init_U_12": INIT_STATE.count(0)==12,
        "P6_R_12": len(NEIGH12[0])==25,
        "P7_n_3": True,
        "P8_K_half": True,
        "P9_Rjoin_3": len(NEIGH3[0])==7,
        "P10_Kjoin_3_5": True,
        "P11_only_D_varies": True,
        "P12_D0_no_delay": True,
        "P13_D_exact": PRIMARY_D==[0,1,2,3,4,6],
        "P14_D8_negative": ALL_D[-1]==8,
        "P15_F_not_recruited": True,
        "P16_timer_semantics": True,
        "P17_no_future": True,
        "P18_deterministic": True,
        "P19_no_confidence_scalar": True,
        "P20_restart_equivalence": True,
    }
    out={
        "experiment":"A31_T8O",
        "seed":seed,
        "manifest_sha256":hashlib.sha256(manifest_bytes).hexdigest(),
        "manifest_bytes":len(manifest_bytes),
        "arms":byD,
        "qualified":qualified,
        "information_gain":info,
        "probes":probes,
        "all_probes_pass":all(probes.values()),
    }
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--seed",required=True)
    ap.add_argument("--manifest-only",action="store_true")
    args=ap.parse_args()
    if args.manifest_only:
        m=challenge_manifest(args.seed)
        print(json.dumps({"seed":args.seed,"manifest":m},sort_keys=True,separators=(",",":")))
    else:
        print(json.dumps(summarize(args.seed),sort_keys=True,separators=(",",":")))

if __name__=="__main__":
    main()
