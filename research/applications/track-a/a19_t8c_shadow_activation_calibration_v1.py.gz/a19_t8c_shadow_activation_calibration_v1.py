#!/usr/bin/env python3
import argparse, copy, hashlib, itertools, json
from dataclasses import dataclass

BASELINE=(3,3,3,3)
CTX_A=0
CTX_B=1
PHASES=6
A11_FREEZE='77874019c9f8cc8716873161f920e249a07ec4fa'
A11_MANIFEST_SHA='b0e00f29d36637a1365ab2407678aacf232ac4f4cf05d387f68af975a5b4bedd'
A12_FREEZE='3308697f2594212be565639bc57c0179e83e831a'
A12_MANIFEST_SHA='502009818ea9d6e57089a91424e7cf399e7c5e95024a9623816e733c58c3f63a'
F14='c0957332578557efc2975ca2da31cf11d07b45ff'
OBS_ROOTS=(1<<52,1<<53,1<<54,1<<55)
F17='3ec24f8242285688a537f5e7dd6e9a231a645597'
A15_CV2=((2,1,4,5),(1,3,6,2),(6,4,1,1),(5,3,1,3),(4,1,5,2),(1,4,3,4),(5,1,5,1),(5,2,1,4),(1,6,1,4),(4,2,2,4),(2,4,4,2),(3,1,2,6))
SHADOW_EVAL_A=1<<48
SHADOW_EVAL_B=1<<49

@dataclass
class Cell:
    id:int
    role:int

def enc(o):
    return json.dumps(o, sort_keys=True, separators=(",",":"), ensure_ascii=False)

def h256(x):
    if isinstance(x, str):
        x = x.encode()
    return hashlib.sha256(x).hexdigest()

def sha_obj(o):
    return h256(enc(o))

def prior_catalog():
    out=[]
    for a in range(1,7):
        for b in range(1,7):
            for c in range(1,7):
                d=12-a-b-c
                if 1<=d<=6:
                    p=(a,b,c,d)
                    if max(p)-min(p)>=2:
                        out.append(p)
    return tuple(sorted(set(out)))

CAT=prior_catalog()
assert len(CAT)==124

def a11_derive_prior(freeze,s,ctx,avoid=None):
    ctr=0
    while True:
        d=hashlib.sha256(f"YGG-A11-PRIOR|{freeze}|{s}|{ctx}|{ctr}".encode()).digest()
        p=CAT[int.from_bytes(d[:8],"big")%len(CAT)]
        if p!=avoid: return p,ctr
        ctr+=1

def a11_pair_roles(tag,freeze,s,phase,k):
    d=hashlib.sha256(f"{tag}|{freeze}|{s}|{phase}|{k}".encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a: b+=1
    return a,b

def a11_zero_mean_sequence(tag,freeze,s,phase,prior,pairs):
    out=[]
    for k in range(pairs):
        a,b=a11_pair_roles(tag,freeze,s,phase,k)
        v1=list(prior); v2=list(prior)
        v1[a]+=1; v1[b]-=1; v2[a]-=1; v2[b]+=1
        assert min(v1)>=0 and max(v1)<=7 and sum(v1)==12
        assert min(v2)>=0 and max(v2)<=7 and sum(v2)==12
        out += [tuple(v1),tuple(v2)]
    mean=tuple(sum(v[r] for v in out)//len(out) for r in range(4))
    assert mean==tuple(prior)
    return tuple(out)

def a11_replacement_targets(freeze,s,phase,episode):
    ids=list(range(12))
    ids.sort(key=lambda cid:hashlib.sha256(f"YGG-A11-REPLACEMENT|{freeze}|{s}|{phase}|{episode}|{cid}".encode()).digest())
    return tuple(ids[:4])

def a11_learner_order(freeze,s,ctx,learner):
    ids=list(range(64))
    ids.sort(key=lambda e:hashlib.sha256(f"YGG-A11-LEARNER-ORDER|{freeze}|{s}|{ctx}|{learner}|{e}".encode()).digest())
    return tuple(ids)

def a11_manifest(freeze):
    rows=[]
    for s in range(12):
        pa,ca=a11_derive_prior(freeze,s,CTX_A,None)
        pb,cb=a11_derive_prior(freeze,s,CTX_B,pa)
        train_a=a11_zero_mean_sequence("YGG-A11-TRAIN-PAIR",freeze,s,"A",pa,32)
        train_b=a11_zero_mean_sequence("YGG-A11-TRAIN-PAIR",freeze,s,"B",pb,32)
        eval_a1=a11_zero_mean_sequence("YGG-A11-EVAL-PAIR",freeze,s,"A1",pa,16)
        eval_b=a11_zero_mean_sequence("YGG-A11-EVAL-PAIR",freeze,s,"B",pb,16)
        eval_a2=a11_zero_mean_sequence("YGG-A11-EVAL-PAIR",freeze,s,"A2",pa,16)
        reps={ph:{str(e):a11_replacement_targets(freeze,s,ph,e) for e in (0,16)} for ph in ("A1","B","A2")}
        rows.append({"scenario":s,"prior_A":pa,"prior_B":pb,"counter_A":ca,"counter_B":cb,
                     "train_A":train_a,"train_B":train_b,"eval_A1":eval_a1,"eval_B":eval_b,"eval_A2":eval_a2,
                     "order_A_A":a11_learner_order(freeze,s,"A","A"),"order_A_B":a11_learner_order(freeze,s,"A","B"),
                     "order_B_A":a11_learner_order(freeze,s,"B","A"),"order_B_B":a11_learner_order(freeze,s,"B","B"),
                     "replacements":reps})
    m={"freeze_commit":freeze,"scenarios":rows}
    return m,sha_obj(m)

def a12_context_sequence(freeze,s):
    ctr=0
    while True:
        d=hashlib.sha256(f'YGG-A12-HIDDEN-CONTEXTS|{freeze}|{s}|{ctr}'.encode()).digest()
        seq=tuple((d[i]>>0)&1 for i in range(PHASES))
        switches=sum(seq[i]!=seq[i-1] for i in range(1,PHASES))
        if 0 in seq and 1 in seq and switches>=3:return seq,ctr
        ctr+=1

def a12_distinct_roles(tag,freeze,s,q,k=0):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{q}|{k}'.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a:b+=1
    return a,b

def a12_sym_pair(prior,a,b):
    v1=list(prior); v2=list(prior)
    v1[a]+=1;v1[b]-=1;v2[a]-=1;v2[b]+=1
    assert min(v1)>=0 and max(v1)<=7 and min(v2)>=0 and max(v2)<=7
    return tuple(v1),tuple(v2)

def a12_phase_probe(freeze,s,q,prior):
    a,b=a12_distinct_roles('YGG-A12-CONTEXT-PROBE',freeze,s,q)
    return a12_sym_pair(prior,a,b)

def a12_service_seq(freeze,s,q,prior):
    out=[]
    for k in range(8):
        a,b=a12_distinct_roles('YGG-A12-SERVICE-PAIR',freeze,s,q,k)
        out.extend(a12_sym_pair(prior,a,b))
    assert tuple(sum(v[r] for v in out)//16 for r in range(4))==tuple(prior)
    return tuple(out)

def a12_replacements(freeze,s,q):
    return {str(e):tuple(sorted(range(12),key=lambda cid:hashlib.sha256(f'YGG-A12-REPLACEMENT|{freeze}|{s}|{q}|{e}|{cid}'.encode()).digest())[:4]) for e in (0,8)}

def a12_restart_phase(freeze,s):
    d=hashlib.sha256(f'YGG-A12-RESTART-PHASE|{freeze}|{s}'.encode()).digest()
    return d[0]%PHASES

def a12_manifest(freeze):
    parent,_=a11_manifest(A11_FREEZE)
    rows=[]
    for s in range(12):
        p=parent['scenarios'][s]
        priors=(tuple(p['prior_A']),tuple(p['prior_B']))
        seq,ctr=a12_context_sequence(freeze,s)
        phases=[]
        for q,c in enumerate(seq):
            prior=priors[c]
            phases.append({'phase':q,'hidden_context':c,'probe':a12_phase_probe(freeze,s,q,prior),
                           'service':a12_service_seq(freeze,s,q,prior),'replacements':a12_replacements(freeze,s,q)})
        rows.append({'scenario':s,'prior_A':priors[0],'prior_B':priors[1],'hidden_contexts':seq,
                     'sequence_counter':ctr,'restart_phase':a12_restart_phase(freeze,s),'phases':phases})
    m={'freeze_commit':freeze,'a11_manifest_sha256':A11_MANIFEST_SHA,'scenarios':rows}
    return m,sha_obj(m)

def a14_derive_prior_c(freeze,s,pa,pb):
    ctr=0
    while True:
        d=hashlib.sha256(f'YGG-A14-PRIOR-C|{freeze}|{s}|{ctr}'.encode()).digest()
        p=CAT[int.from_bytes(d[:8],'big')%len(CAT)]
        if tuple(p)!=tuple(pa) and tuple(p)!=tuple(pb): return tuple(p),ctr
        ctr+=1

def a14_known_pre(freeze,s):
    return hashlib.sha256(f'YGG-A14-KNOWN-PRE|{freeze}|{s}'.encode()).digest()[0]&1

def a14_roles(tag,freeze,s,k,extra=''):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{k}|{extra}'.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a:b+=1
    return a,b

def a14_sym_pair(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    assert min(x)>=0 and max(x)<=7 and min(y)>=0 and max(y)<=7 and sum(x)==12 and sum(y)==12
    return tuple(x),tuple(y)

def a14_train_c(freeze,s,pc):
    out=[]
    for k in range(32):
        a,b=a14_roles('YGG-A14-C-TRAIN-PAIR',freeze,s,k)
        out.extend(a14_sym_pair(pc,a,b))
    assert len(out)==64 and tuple(sum(v[r] for v in out)//64 for r in range(4))==tuple(pc)
    return tuple(out)

def a14_probe_known(freeze,s,label,prior):
    a,b=a14_roles('YGG-A14-KNOWN-PROBE',freeze,s,0,label)
    return a14_sym_pair(prior,a,b)

def a14_probe_c_return(freeze,s,pc):
    a,b=a14_roles('YGG-A14-C-RETURN-PROBE',freeze,s,0)
    return a14_sym_pair(pc,a,b)

def a14_eval_seq(freeze,s,label,pc):
    out=[]
    for k in range(16):
        a,b=a14_roles('YGG-A14-C-EVAL-PAIR',freeze,s,k,label)
        out.extend(a14_sym_pair(pc,a,b))
    assert len(out)==32 and tuple(sum(v[r] for v in out)//32 for r in range(4))==tuple(pc)
    return tuple(out)

def a14_replacements(freeze,s,label):
    return {str(e):tuple(sorted(range(12),key=lambda cid:hashlib.sha256(f'YGG-A14-REPLACEMENT|{freeze}|{s}|{label}|{e}|{cid}'.encode()).digest())[:4]) for e in (0,16)}

def a14_attestation_roots(freeze,s,e):
    d=hashlib.sha256(f'YGG-A14-OBS-ROOTS|{freeze}|{s}|{e}'.encode()).digest()
    a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return (OBS_ROOTS[a],OBS_ROOTS[b])

def a14_learner_order(freeze,s,learner):
    ids=list(range(64))
    ids.sort(key=lambda e:hashlib.sha256(f'YGG-A14-LEARNER-ORDER|{freeze}|{s}|{learner}|{e}'.encode()).digest())
    return tuple(ids)

def a14_manifest(freeze):
    parent,_=a12_manifest(A12_FREEZE);rows=[]
    for s in range(12):
        ps=parent['scenarios'][s];pa=tuple(ps['prior_A']);pb=tuple(ps['prior_B']);pc,ctr=a14_derive_prior_c(freeze,s,pa,pb)
        kp=a14_known_pre(freeze,s);ki=1-kp
        tr=a14_train_c(freeze,s,pc)
        rows.append({'scenario':s,'prior_A':pa,'prior_B':pb,'prior_C':pc,'counter_C':ctr,
                     'known_pre_context':kp,'known_interlude_context':ki,
                     'known_pre_probe':a14_probe_known(freeze,s,'PRE',pa if kp==0 else pb),
                     'known_interlude_probe':a14_probe_known(freeze,s,'INTERLUDE',pa if ki==0 else pb),
                     'train_C':tr,'attestations':tuple(a14_attestation_roots(freeze,s,e) for e in range(64)),
                     'order_A':a14_learner_order(freeze,s,'A'),'order_B':a14_learner_order(freeze,s,'B'),
                     'eval_C1':a14_eval_seq(freeze,s,'C1',pc),'eval_C2':a14_eval_seq(freeze,s,'C2',pc),
                     'probe_C2':a14_probe_c_return(freeze,s,pc),'replacements_C1':a14_replacements(freeze,s,'C1'),
                     'replacements_C2':a14_replacements(freeze,s,'C2'),'restart_after_observation':32})
    m={'freeze_commit':freeze,'a12_manifest_sha256':A12_MANIFEST_SHA,'slot_capacity':3,'novelty_dwell':8,'training_observations':64,'scenarios':rows}
    return m,sha_obj(m)

def l1(a,b): return sum(abs(x-y) for x,y in zip(a,b))

def delta(a,b): return tuple(x-y for x,y in zip(a,b))

def valid_delta(d): return sorted(d)==[-1,0,0,1] and sum(abs(x) for x in d)==2

def a17_neighbors(current,pa,pb,pc1,earlier):
    xs=[p for p in CAT if p not in (tuple(pa),tuple(pb),tuple(pc1),tuple(current)) and p not in tuple(earlier) and l1(p,current)==2]
    return tuple(sorted(xs))

def a17_path_for(freeze,s,pa,pb,pc1,p0):
    p=[tuple(p0)]
    for k in range(1,5):
        xs=a17_neighbors(p[-1],pa,pb,pc1,p[:-1])
        d=hashlib.sha256(f'YGG-A17-PATCH-TARGET|{freeze}|{s}|{k}'.encode()).digest()
        p.append(xs[int.from_bytes(d[:8],'big')%len(xs)])
    return tuple(p)

def a17_roles(tag,freeze,s,k,j,extra=''):
    d=hashlib.sha256(f'{tag}|{freeze}|{s}|{k}|{j}|{extra}'.encode()).digest()
    a=d[0]%4;b=d[1]%3
    if b>=a:b+=1
    return a,b

def a17_sym(prior,a,b):
    x=list(prior);y=list(prior);x[a]+=1;x[b]-=1;y[a]-=1;y[b]+=1
    return tuple(x),tuple(y)

def a17_eval_seq(freeze,s,k,target):
    out=[]
    for j in range(8):
        a,b=a17_roles('YGG-A17-PATCH-EVAL',freeze,s,k,j);out.extend(a17_sym(target,a,b))
    return tuple(out)

def a17_replacements(freeze,s,k):
    out={}
    for e in (0,8):
        xs=[(h256(f'YGG-A17-REPLACE|{freeze}|{s}|{k}|{e}|{cid}'),cid) for cid in range(12)]
        out[str(e)]=tuple(cid for _,cid in sorted(xs)[:4])
    return out

def a17_manifest(freeze):
    pm,_=a14_manifest(F14);rows=[]
    for s in range(12):
        a=pm['scenarios'][s];pa=tuple(a['prior_A']);pb=tuple(a['prior_B']);pc1=tuple(a['prior_C']);p0=tuple(A15_CV2[s])
        path=a17_path_for(freeze,s,pa,pb,pc1,p0)
        patches=[]
        for k in range(1,5):
            target=path[k]
            patches.append({'patch':k,'from':path[k-1],'target':target,'delta':delta(target,path[k-1]),
                            'eval':a17_eval_seq(freeze,s,k,target),'replacements':a17_replacements(freeze,s,k)})
        rows.append({'scenario':s,'prior_A':pa,'prior_B':pb,'prior_C_v1':pc1,'base_C_v2':p0,'path':path,'patches':patches})
    # not full manifest; diagnostic fields sufficient
    return rows

def initial_cells(): return [Cell(i,i%4) for i in range(12)]

def counts(cells):
    c=[0]*4
    for x in cells: c[x.role]+=1
    return c

def choose_birth_role(cells,prior):
    c=counts(cells); deficit=[max(0,prior[r]-c[r]) for r in range(4)]
    m=max(deficit)
    if m>0:return min(r for r,v in enumerate(deficit) if v==m)
    mn=min(c); return min(r for r,v in enumerate(c) if v==mn)

def replace_cells(cells,targets,prior):
    cells=copy.deepcopy(cells); assigned=[]
    byid={c.id:c for c in cells}
    for cid in targets: byid.pop(cid,None)
    live=list(byid.values())
    for cid in targets:
        role=choose_birth_role(live,prior);live.append(Cell(cid,role));assigned.append((cid,role))
    return sorted(live,key=lambda x:x.id),tuple(assigned)

def migrate_one_step(cells,demand):
    cells=copy.deepcopy(cells);c=counts(cells)
    deficit=[max(0,demand[r]-c[r]) for r in range(4)]
    surplus=[max(0,c[r]-demand[r]) for r in range(4)]
    if not any(deficit) or not any(surplus): return cells,0
    target=min(r for r,v in enumerate(deficit) if v==max(deficit))
    elig=[x for x in cells if surplus[x.role]>0]
    n=min(deficit[target],len(elig));moved=0
    for x in sorted(elig,key=lambda x:x.id)[:n]:
        x.role=target;moved+=1
    return cells,moved

def served(cells,demand):
    c=counts(cells)
    return sum(min(c[r],demand[r]) for r in range(4))

def eval_phase(cells,seq,reps,prior, trace=False):
    cells=copy.deepcopy(cells);total=0;migrations=0;first={}; tr=[]
    for e,d in enumerate(seq):
        if e in (0,8):
            cells,a=replace_cells(cells,reps[str(e)],prior);first[e]=0
        sv=served(cells,d); total += sv
        for st in (0,8):
            if st<=e<st+4: first[st]+=sv
        before=copy.deepcopy(cells)
        cells,m=migrate_one_step(cells,d);migrations += m
        if trace:
            tr.append({"e":e,"demand":tuple(d),"service":sv,"pre_migrate_counts":tuple(counts(before)),
                       "post_migrate_counts":tuple(counts(cells)),"migrations":m})
    out={'service_total':total,'first4_service':sum(first.values()),'migrations':migrations}
    return cells,out,tr

def replay_a17():
    all_eval=[]
    for spec in rows:
        cells=initial_cells()
        for ps in spec["patches"]:
            start=copy.deepcopy(cells)
            target=tuple(ps["target"]); prev=tuple(ps["from"])
            cells, ce, ctr = eval_phase(start, ps["eval"], ps["replacements"], target, trace=True)
            _, be, btr = eval_phase(start, ps["eval"], ps["replacements"], prev, trace=True)
            _, oe, otr = eval_phase(start, ps["eval"], ps["replacements"], target, trace=True)
            all_eval.append({"scenario":spec["scenario"],"patch":ps["patch"],"candidate":ce,"stale":be,"oracle":oe,
                             "candidate_trace":ctr,"stale_trace":btr,"start":start,"spec":ps,
                             "target":target,"previous":prev})
    cand=sum(e["candidate"]["first4_service"] for e in all_eval)
    stale=sum(e["stale"]["first4_service"] for e in all_eval)
    oracle=sum(e["oracle"]["first4_service"] for e in all_eval)
    ge=sum(e["candidate"]["first4_service"]>=e["stale"]["first4_service"] for e in all_eval)
    mig=sum(max(0,e["stale"]["migrations"]-e["candidate"]["migrations"]) for e in all_eval)
    bad=[(e["scenario"],e["patch"],e["candidate"]["first4_service"],e["stale"]["first4_service"]) for e in all_eval if e["candidate"]["first4_service"]<e["stale"]["first4_service"]]
    return all_eval, (cand,stale,oracle,ge,mig), bad

def a19_shadow_roles(freeze,s,k,j):
    d=hashlib.sha256(f'YGG-A19-SHADOW-OBS|{freeze}|{s}|{k}|{j}'.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a:b+=1
    return a,b

def a19_shadow_obs(freeze,s,k,target):
    out=[]
    for j in range(2):
        a,b=a19_shadow_roles(freeze,s,k,j)
        out.extend(a17_sym(target,a,b))
    assert len(out)==4
    assert tuple(sum(v[r] for v in out)//4 for r in range(4))==tuple(target)
    return tuple(out)

def a19_shadow_attest(freeze,s,k,e):
    d=hashlib.sha256(f'YGG-A19-SHADOW-ATTEST|{freeze}|{s}|{k}|{e}'.encode()).digest()
    a=d[0]%4; b=d[1]%3
    if b>=a:b+=1
    return OBS_ROOTS[a],OBS_ROOTS[b]

def a19_geometry_order(freeze,s,k,root):
    combos=list(itertools.combinations(range(12),4))
    combos.sort(key=lambda combo: h256(f"YGG-A19-EVALUATOR-ORDER|{freeze}|{s}|{k}|{root}|{','.join(map(str,combo))}"))
    return combos

def a19_replacement_order(freeze,s,k,combo):
    return tuple(sorted(combo,key=lambda cid:h256(f'YGG-A19-SHADOW-REPLACE-ORDER|{freeze}|{s}|{k}|{cid}')))

def score_single_replacement(start, demands, target_ids, prior):
    roles=[c.role for c in start]
    for cid in target_ids:
        roles[cid]=None
    for cid in target_ids:
        live=[r for r in roles if r is not None]
        c=[live.count(r) for r in range(4)]
        deficit=[max(0,prior[r]-c[r]) for r in range(4)]
        m=max(deficit)
        if m>0:
            role=min(r for r,v in enumerate(deficit) if v==m)
        else:
            mn=min(c);role=min(r for r,v in enumerate(c) if v==mn)
        roles[cid]=role
    svc=0
    for demand in demands:
        c=[roles.count(r) for r in range(4)]
        svc += sum(min(c[r],demand[r]) for r in range(4))
        deficit=[max(0,demand[r]-c[r]) for r in range(4)]
        surplus=[max(0,c[r]-demand[r]) for r in range(4)]
        if any(deficit) and any(surplus):
            target=min(r for r,v in enumerate(deficit) if v==max(deficit))
            elig=[cid for cid,role in enumerate(roles) if surplus[role]>0]
            n=min(deficit[target],len(elig))
            for cid in sorted(elig)[:n]:
                roles[cid]=target
    return svc

def a19_shadow_summary(freeze,s,k,start,target,prev,root):
    obs=a19_shadow_obs(freeze,s,k,target)
    deltas=[]
    for combo in a19_geometry_order(freeze,s,k,root):
        order=a19_replacement_order(freeze,s,k,combo)
        cs=score_single_replacement(start,obs,order,target)
        ss=score_single_replacement(start,obs,order,prev)
        deltas.append(cs-ss)
    # order-independent exact summary
    sd=sorted(deltas)
    hist={str(x):sd.count(x) for x in sorted(set(sd))}
    return {
        "minimum":min(sd),"maximum":max(sd),
        "sum":sum(sd),"count":len(sd),
        "mean_num":sum(sd),"mean_den":len(sd),
        "median":sd[len(sd)//2],
        "frac_ge_num":sum(x>=0 for x in sd),"frac_ge_den":len(sd),
        "frac_gt_num":sum(x>0 for x in sd),"frac_gt_den":len(sd),
        "histogram":hist
    }

def gate_decision(summary,arm):
    mean_pos=summary["mean_num"]>0
    if arm=="G1":
        return summary["minimum"]>=0 and mean_pos
    if arm=="G2":
        return summary["frac_ge_num"]*4 >= summary["frac_ge_den"]*3 and mean_pos
    if arm=="G3":
        return mean_pos
    raise ValueError(arm)

def a19_runs(freeze):
    # exact A17 replay, collecting each patch's fixed pre-eval state and candidate/stale heldout scores
    exact_evs, agg, bad = replay_a17()
    assert agg==(3978,3950,3978,37,38)
    results=[]
    for e in exact_evs:
        s=e["scenario"]; k=e["patch"]; start=e["start"]; target=e["target"]; prev=e["previous"]
        atts=tuple(a19_shadow_attest(freeze,s,k,i) for i in range(4))
        assert all(len(set(x))==2 for x in atts)
        sa=a19_shadow_summary(freeze,s,k,start,target,prev,SHADOW_EVAL_A)
        sb=a19_shadow_summary(freeze,s,k,start,target,prev,SHADOW_EVAL_B)
        assert sa==sb
        cand_first=e["candidate"]["first4_service"]; stale_first=e["stale"]["first4_service"]
        cand_full=sum(x["service"] for x in e["candidate_trace"]); stale_full=sum(x["service"] for x in e["stale_trace"])
        row={
            "scenario":s,"patch":k,
            "shadow_observations":a19_shadow_obs(freeze,s,k,target),
            "shadow_attestations":atts,
            "shadow":sa,
            "heldout_candidate_first4":cand_first,"heldout_stale_first4":stale_first,
            "heldout_first4_delta":cand_first-stale_first,
            "heldout_candidate_full16":cand_full,"heldout_stale_full16":stale_full,
            "heldout_full16_delta":cand_full-stale_full,
        }
        row["decisions"]={a:gate_decision(sa,a) for a in ("G1","G2","G3")}
        results.append(row)
    arms={}
    strict_pos=sum(r["heldout_first4_delta"]>0 for r in results)
    for arm in ("G1","G2","G3"):
        activated=[r for r in results if r["decisions"][arm]]
        dormant=[r for r in results if not r["decisions"][arm]]
        harmful=sum(r["heldout_first4_delta"]<0 for r in activated)
        beneficial=sum(r["heldout_first4_delta"]>0 for r in activated)
        neutral=sum(r["heldout_first4_delta"]==0 for r in activated)
        missed=sum(r["heldout_first4_delta"]>0 for r in dormant)
        avoided=sum(r["heldout_first4_delta"]<0 for r in dormant)
        gf=sum(r["heldout_candidate_first4"] if r["decisions"][arm] else r["heldout_stale_first4"] for r in results)
        gfull=sum(r["heldout_candidate_full16"] if r["decisions"][arm] else r["heldout_stale_full16"] for r in results)
        sf=sum(r["heldout_stale_first4"] for r in results)
        sfull=sum(r["heldout_stale_full16"] for r in results)
        af=sum(r["heldout_candidate_first4"] for r in results)
        afull=sum(r["heldout_candidate_full16"] for r in results)
        arms[arm]={
            "activated":len(activated),"dormant":len(dormant),
            "harmful_activations":harmful,"beneficial_activations":beneficial,"neutral_activations":neutral,
            "missed_beneficial":missed,"avoided_harmful":avoided,
            "first4_service":gf,"full16_service":gfull,
            "first4_vs_stale":gf-sf,"full16_vs_stale":gfull-sfull,
            "first4_vs_always_patch":gf-af,"full16_vs_always_patch":gfull-afull,
            "precision_num":beneficial,"precision_den":len(activated),
            "recall_num":beneficial,"recall_den":strict_pos
        }
    # bins by shadow noninferior fraction, first4 heldout sign
    bins={"[0,.25)":[], "[.25,.50)":[], "[.50,.75)":[], "[.75,1)":[], "1.00":[]}
    for r in results:
        f=r["shadow"]["frac_ge_num"]/r["shadow"]["frac_ge_den"]
        key="1.00" if f==1 else "[.75,1)" if f>=.75 else "[.50,.75)" if f>=.5 else "[.25,.50)" if f>=.25 else "[0,.25)"
        bins[key].append(r["heldout_first4_delta"])
    cal={}
    for k,vals in bins.items():
        cal[k]={"count":len(vals),"harmful":sum(v<0 for v in vals),"beneficial":sum(v>0 for v in vals),"neutral":sum(v==0 for v in vals),
                "mean_heldout_delta":sum(vals)/len(vals) if vals else None}
    return {"freeze":freeze,"arms":arms,"calibration":cal,"rows":results}


rows=a17_manifest(F17)


def validate_fixed_lineage():
    _,s11=a11_manifest(A11_FREEZE)
    _,s12=a12_manifest(A12_FREEZE)
    _,s14=a14_manifest(F14)
    assert s11==A11_MANIFEST_SHA
    assert s12==A12_MANIFEST_SHA
    assert s14=='83a0ad4d67d7a3f3625e49c311f5d2a85c73fee40cde96e24937ae79e1e944ae'
    _,agg,bad=replay_a17()
    assert agg==(3978,3950,3978,37,38)
    assert bad==[(0,1,81,82),(0,2,85,86),(0,3,82,83),(2,4,83,84),(4,1,80,82),(4,2,84,85),(4,3,83,84),(10,2,82,83),(10,4,79,80),(11,1,80,83),(11,4,83,84)]
    return {'a11':s11,'a12':s12,'a14':s14,'a17_aggregate':agg,'a17_bad':bad}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--freeze',required=True)
    ap.add_argument('--validate',action='store_true')
    ap.add_argument('--out')
    a=ap.parse_args()
    v=validate_fixed_lineage()
    if a.validate:
        txt=enc(v)
    else:
        r=a19_runs(a.freeze)
        r['lineage_validation']=v
        r['serialized_output_sha256']=sha_obj(r)
        txt=enc(r)
    if a.out:
        open(a.out,'w',encoding='utf-8').write(txt)
    print(txt)

if __name__=='__main__':
    main()
