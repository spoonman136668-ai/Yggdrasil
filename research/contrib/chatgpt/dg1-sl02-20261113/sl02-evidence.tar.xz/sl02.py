"""SL02 synthetic source-only wake/sleep falsification.

Never fit evaluator-only transitions, phase labels, or imagined dream transitions.
Run as Python 3.12+ standard library. Frozen source preregistration is in prereg.json.
"""
from __future__ import annotations

import hashlib
import json
import random
import time
from itertools import combinations

ACTIONS = 4
STATES = 16
FULL = (1 << 40) - 1
TRIPLES = tuple(combinations(range(4), 3))
SCHEMA = 'ygg.dg1-sl02.context-recovery.v1'
SEEDS = {
    'ABA': tuple(range(94001, 94009)),
    'stationary_majority': tuple(range(94009, 94017)),
    'unfamiliar_cubic': tuple(range(94017, 94025)),
}
ARMS = ('sleep_repair', 'native_no_sleep', 'conventional_online', 'online_replay_control')


def valid(s, a=None):
    if type(s) is not int or not 0 <= s < STATES:
        raise ValueError('SL02_INVALID_STATE')
    if a is not None and (type(a) is not int or not 0 <= a < ACTIONS):
        raise ValueError('SL02_INVALID_ACTION')


def effect(s, rule):
    valid(s)
    if type(rule) is not int or not 0 <= rule < 40:
        raise ValueError('SL02_INVALID_RULE')
    if rule < 32:
        return ((s & (rule >> 1)).bit_count() % 2) ^ (rule & 1)
    return (int(sum((s >> i) & 1 for i in TRIPLES[(rule - 32)//2]) >= 2)
            ^ (rule & 1))


def survivor(mask, state, changed):
    return sum(1 << r for r in range(40) if (mask >> r) & 1 and effect(state, r) == changed)


def predicts(mask, state, action):
    valid(state, action)
    outcomes = {effect(state, r) for r in range(40) if mask & (1 << r)}
    if len(outcomes) != 1:
        return None
    return state ^ (next(iter(outcomes)) << action)


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('ascii')


class Physics:
    def __init__(self, seed, group):
        if group not in SEEDS or seed not in SEEDS[group]:
            raise ValueError('SL02_WORLD_NOT_REGISTERED')
        self.seed, self.group = seed, group
        self.sign, self.slope = [], []
        for action in range(4):
            rng = random.Random(seed * 101 + action * 31)
            self.sign.append(rng.randrange(2))
            self.slope.append(rng.randrange(2))
        self.causal, self.flips = 0, 0

    def evaluator_truth(self, s, a, step):
        valid(s, a)
        if type(step) is not int or not 0 <= step < 48:
            raise ValueError('SL02_BAD_STEP')
        left, right, own = (s >> ((a + 1) % 4)) & 1, (s >> ((a + 2) % 4)) & 1, (s >> a) & 1
        if self.group == 'stationary_majority':
            changed = int(left + right + own >= 2)
        elif self.group == 'unfamiliar_cubic':
            changed = int(s == 15)
        else:
            changed = left ^ right ^ (own & self.slope[a])
        changed ^= self.sign[a]
        if self.group == 'ABA' and 17 <= step < 33:
            changed ^= 1
        return s ^ (changed << a)

    def charge_causal(self, s, a, step):
        nxt = self.evaluator_truth(s, a, step)
        self.causal += 1
        return nxt

    def charge_flip(self, s, bit):
        valid(s, bit)
        self.flips += 1
        return s ^ (1 << bit)


class NativeBanks:
    """Online two-context causal version-space. No world or phase input."""
    def __init__(self, archive=True):
        self.banks = [[FULL] * 4]
        self.active = 0
        self.unresolved = False
        self.log = []
        self.archive = archive
        self.switches = 0
        self.rejections = 0
        self.observations = 0
        self.repairs = 0

    def observe(self, s, a, nxt):
        valid(s, a); valid(nxt)
        if nxt not in (s, s ^ (1 << a)):
            raise ValueError('SL02_NONLOCAL_PHYSICS')
        changed = int(s != nxt)
        preferred = survivor(self.banks[self.active][a], s, changed)
        if preferred:
            self.banks[self.active][a] = preferred
            self.unresolved = False
        else:
            other = next((i for i, bank in enumerate(self.banks)
                          if i != self.active and survivor(bank[a], s, changed)), None)
            if other is not None:
                self.active = other
                self.banks[other][a] = survivor(self.banks[other][a], s, changed)
                self.switches += 1
                self.unresolved = False
            elif len(self.banks) < 2:
                self.banks.append([FULL] * 4)
                self.active = 1
                self.banks[1][a] = survivor(FULL, s, changed)
                self.unresolved = False
                self.switches += 1
            else:
                self.unresolved = True
                self.rejections += 1
        if self.archive:
            self.log.append([s, a, nxt])
            self.log = self.log[-32:]
        self.observations += 1

    def predict(self, s, a):
        valid(s, a)
        if self.unresolved:
            return None
        return predicts(self.banks[self.active][a], s, a)

    def sleep(self):
        """Regenerate banks using physical episodes and bounded label-blind replay.

        Observations may be assigned to two programs by predicted likelihood.
        We allow only rule-filtering; no synthetic values are fitted.
        """
        if not self.log:
            return
        masks = [bank[:] for bank in self.banks]
        # Candidate segmentation starts from currently remembered version spaces.
        for _ in range(2):
            buckets = [[], []]
            last = self.active
            for state, action, nxt in self.log:
                changed = int(state != nxt)
                likelihood = []
                for idx in range(2):
                    mask = masks[idx][action] if idx < len(masks) else FULL
                    survivors = survivor(mask, state, changed).bit_count()
                    likelihood.append((survivors / max(mask.bit_count(), 1), idx))
                best = max(range(2), key=lambda idx: (likelihood[idx][0], idx == last, -idx))
                buckets[best].append([state, action, nxt])
                last = best
            refined = [[FULL] * 4, [FULL] * 4]
            # Conflicting samples inside a bucket abstain from a learned update.
            for idx, events in enumerate(buckets):
                for state, action, nxt in events:
                    updated = survivor(refined[idx][action], state, int(state != nxt))
                    if updated:
                        refined[idx][action] = updated
            masks = refined
        # Avoid accepting a structurally empty context bank as evidence.
        if not any(buckets[1]):
            masks = [masks[0]]
        old = self.banks
        self.banks = masks
        # Recent physical evidence chooses context; not the evaluator or phase.
        scores = []
        for idx, bank in enumerate(self.banks):
            n = 0
            for state, action, nxt in self.log[-4:]:
                if predicts(bank[action], state, action) == nxt:
                    n += 1
            scores.append(n)
        self.active = max(range(len(scores)), key=lambda idx: (scores[idx], idx == self.active, -idx))
        self.unresolved = scores[self.active] == 0
        self.repairs += int(old != self.banks)

    def snapshot(self):
        payload = dict(schema=SCHEMA, banks=self.banks, active=self.active,
                       unresolved=self.unresolved, log=self.log, archive=self.archive,
                       switches=self.switches, rejections=self.rejections,
                       observations=self.observations, repairs=self.repairs)
        envelope = {'payload': payload, 'sha256': hashlib.sha256(encode(payload)).hexdigest()}
        raw = encode(envelope)
        if len(raw) > 8192:
            raise ValueError('SL02_SNAPSHOT_LIMIT')
        return raw

    @classmethod
    def restore(cls, raw):
        try:
            if type(raw) is not bytes or not 0 < len(raw) <= 8192:
                raise ValueError('BAD_CHECKPOINT_TYPE')
            envelope = json.loads(raw)
            if type(envelope) is not dict or set(envelope) != {'payload', 'sha256'}:
                raise ValueError('BAD_ENVELOPE')
            p = envelope['payload']
            need = {'schema','banks','active','unresolved','log','archive','switches',
                    'rejections','observations','repairs'}
            if (type(p) is not dict or set(p) != need or p['schema'] != SCHEMA
                or hashlib.sha256(encode(p)).hexdigest() != envelope['sha256']):
                raise ValueError('BAD_HASH_OR_SCHEMA')
            if (type(p['banks']) is not list or not 1 <= len(p['banks']) <= 2 or
                any(type(bank) is not list or len(bank) != 4 or
                    any(type(mask) is not int or not 0 < mask <= FULL for mask in bank)
                    for bank in p['banks'])):
                raise ValueError('BAD_BANKS')
            if type(p['active']) is not int or not 0 <= p['active'] < len(p['banks']):
                raise ValueError('BAD_ACTIVE')
            if type(p['archive']) is not bool or type(p['unresolved']) is not bool:
                raise ValueError('BAD_FLAGS')
            if type(p['log']) is not list or len(p['log']) > 32:
                raise ValueError('BAD_LOG')
            for e in p['log']:
                if type(e) is not list or len(e) != 3:
                    raise ValueError('BAD_EVENT')
                s, a, nxt = e
                valid(s, a); valid(nxt)
                if nxt not in (s, s ^ (1 << a)):
                    raise ValueError('BAD_CAUSAL_EVENT')
            for k in ('switches','rejections','observations','repairs'):
                if type(p[k]) is not int or not 0 <= p[k] <= 48:
                    raise ValueError('BAD_COUNTER')
            obj = cls(archive=p['archive'])
            for k in need - {'schema'}:
                setattr(obj, k, p[k])
            if obj.snapshot() != raw:
                raise ValueError('NONCANONICAL')
            return obj
        except (TypeError, ValueError, KeyError, UnicodeError, OverflowError) as exc:
            raise ValueError('SL02_CHECKPOINT_REJECTED') from exc


class ConventionalContext:
    """Independent conventional two-context, rule-mask baseline with same data/size."""
    def __init__(self):
        self.states = [[FULL] * 4]
        self.selected = 0
        self.mismatch = False
        self.log = []
        self.observations = 0

    def observe(self, state, action, nxt):
        valid(state, action); valid(nxt)
        if nxt not in (state, state ^ (1 << action)):
            raise ValueError('NONCAUSAL_OBS')
        y = int(state != nxt)
        options = [i for i, row in enumerate(self.states)
                   if survivor(row[action], state, y)]
        if self.selected in options:
            target = self.selected
        elif options:
            target = options[0]
        elif len(self.states) < 2:
            self.states.append([FULL] * 4)
            target = 1
        else:
            target = None
        self.mismatch = target is None
        if target is not None:
            self.selected = target
            self.states[target][action] = survivor(self.states[target][action], state, y)
        self.log.append([state, action, nxt])
        self.log = self.log[-32:]
        self.observations += 1

    def predict(self, state, action):
        valid(state, action)
        return None if self.mismatch else predicts(self.states[self.selected][action], state, action)

    def snapshot(self):
        return encode({'states': self.states, 'selected': self.selected,
                       'mismatch': self.mismatch, 'log': self.log,
                       'observations': self.observations})


def audit(model, world, step, seen):
    res = {'correct':0, 'wrong_confident':0, 'abstained':0,
           'unseen_correct':0,'unseen_wrong_confident':0,'unseen_abstained':0}
    for s in range(16):
        for a in range(4):
            pred = model.predict(s, a)
            truth = world.evaluator_truth(s, a, step)
            bucket = ('abstained' if pred is None else
                      'correct' if pred == truth else 'wrong_confident')
            res[bucket] += 1
            if (s, a) not in seen:
                res['unseen_' + bucket] += 1
    return res


def one_world(seed, group):
    world = Physics(seed, group)
    models = {'sleep_repair': NativeBanks(), 'native_no_sleep': NativeBanks(),
              'conventional_online': ConventionalContext(),
              'online_replay_control': NativeBanks()}
    state = seed % 16
    seen = set()
    ledger = []
    flips = 0
    prequential = {name:{phase:{'correct':0,'wrong_confident':0,'abstained':0}
                        for phase in ('A1','B','A2')} for name in models}
    audits = {name:{} for name in models}
    work_ns = {name:0 for name in models}
    for step in range(48):
        phase = ('B' if group == 'ABA' and 17 <= step < 33 else
                 'A1' if step < 17 else 'A2')
        s = state
        if step % 7 == 6 and flips < 8:
            action = (step//7 + seed) % 4
            state = world.charge_flip(s, action)
            flips += 1
            ledger.append([step, s, 'flip', action, state])
        else:
            action = (step + seed) % 4
            state = world.charge_causal(s, action, step)
            ledger.append([step, s, 'causal', action, state])
            seen.add((s, action))
            for name, model in models.items():
                t0 = time.perf_counter_ns()
                before = model.predict(s, action)
                bucket = ('abstained' if before is None else
                          'correct' if before == state else 'wrong_confident')
                prequential[name][phase][bucket] += 1
                model.observe(s, action, state)
                work_ns[name] += time.perf_counter_ns() - t0
        if (step + 1) % 8 == 0:
            # The replay control performs the identical computation with
            # identical episodes, showing whether timing alone adds benefit.
            for name in ('sleep_repair','online_replay_control'):
                t0 = time.perf_counter_ns()
                models[name].sleep()
                work_ns[name] += time.perf_counter_ns() - t0
        if step + 1 in (16,32,48):
            for name, model in models.items():
                audits[name][str(step+1)] = audit(model, world, step, seen)
    assert world.causal + world.flips == 48 and world.flips <= 8
    snapshots = {}
    for name, model in models.items():
        raw = model.snapshot()
        if name != 'conventional_online':
            assert NativeBanks.restore(raw).snapshot() == raw
        snapshots[name] = {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    return {
        'seed':seed, 'group':group, 'charged_actions':48,
        'charged_causal':world.causal, 'charged_flips':world.flips,
        'physical_trace_sha256':hashlib.sha256(encode(ledger)).hexdigest(),
        'physical_trace':ledger, 'distinct_seen_pairs':len(seen),
        'prequential':prequential, 'audits':audits,
        'snapshots':snapshots, 'model_work_ns':work_ns,
        'replays':{name:getattr(models[name], 'repairs', None) for name in models},
    }


def run():
    start = time.perf_counter_ns()
    worlds = [one_world(seed, name) for name,seeds in SEEDS.items() for seed in seeds]
    counts = ('correct','wrong_confident','abstained',
              'unseen_correct','unseen_wrong_confident','unseen_abstained')
    aggregate = {group:{arm:{k:sum(w['audits'][arm]['48'][k] for w in worlds
                                       if w['group'] == group) for k in counts}
                        for arm in ARMS} for group in SEEDS}
    best_online = {g:max(('native_no_sleep','conventional_online'),
                         key=lambda a:(aggregate[g][a]['correct'],
                                       -aggregate[g][a]['wrong_confident'])) for g in SEEDS}
    sleep = aggregate['ABA']['sleep_repair']
    ctrl = aggregate['ABA'][best_online['ABA']]
    st = aggregate['stationary_majority']
    ood = aggregate['unfamiliar_cubic']
    primary = (sleep['correct'] - ctrl['correct'] >= 24 and
               sleep['unseen_correct'] - ctrl['unseen_correct'] >= 16 and
               sleep['wrong_confident'] - ctrl['wrong_confident'] <= 8 and
               st['sleep_repair']['correct'] >= st[best_online['stationary_majority']]['correct']-8 and
               ood['sleep_repair']['wrong_confident'] <= 8)
    return dict(schema='ygg.dg1-sl02.prospective-dev.v1',
                frozen_protocol='research/contrib/chatgpt/dg1-sl02-20261113/prereg.json',
                classification=('DEV_SIGNAL_NOT_SCIENCE' if primary else
                                'MIXED_DEV' if sleep['correct'] > ctrl['correct'] else 'NEGATIVE_DEV'),
                primary_pass=primary,
                scientific_acceptance='UNVERIFIED',
                native_superior_to_conventional=(
                    sleep['correct'] > aggregate['ABA']['conventional_online']['correct'] and
                    sleep['wrong_confident'] <= aggregate['ABA']['conventional_online']['wrong_confident']),
                sleep_ties_online_replay_control=all(aggregate[g]['sleep_repair'] ==
                   aggregate[g]['online_replay_control'] for g in SEEDS),
                best_online_by_cohort=best_online, aggregate_final=aggregate,
                charged_actions_all_arms=24*48,
                same_observations_for_all_arms=True,
                equal_total_compute=False,
                elapsed_whole_process_ns=time.perf_counter_ns()-start,
                worlds=worlds)

if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True, indent=2))
