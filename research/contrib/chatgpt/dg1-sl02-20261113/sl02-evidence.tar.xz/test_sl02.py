import unittest
from sl02 import NativeBanks, ConventionalContext, Physics, one_world, run, effect, SEEDS, survivor

class SL02Tests(unittest.TestCase):
    def test_rule_family_and_causal_action_guards(self):
        self.assertEqual(effect(0,0),0)
        self.assertEqual(effect(0,1),1)
        self.assertNotEqual(survivor((1<<0)|(1<<1), 0, 0), 0)
        m = NativeBanks()
        for e in [(-1,0,0),(0,4,0),(0,0,17),(0,0,2)]:
            with self.assertRaises(ValueError): m.observe(*e)
    def test_no_hidden_phases_or_evaluator_update(self):
        m = NativeBanks()
        before = m.snapshot()
        w = Physics(94001,'ABA')
        for s in range(16):
            for a in range(4):
                w.evaluator_truth(s,a,20)
        self.assertEqual(before, m.snapshot())
        self.assertEqual((w.causal,w.flips),(0,0))
        with self.assertRaises(TypeError): m.observe(0,0,0,hidden_phase=0)
    def test_sleep_only_real_observations_and_cold_tamper(self):
        m = NativeBanks()
        m.sleep()
        self.assertEqual(m.observations,0)
        m.observe(0,0,0)
        m.sleep()
        self.assertEqual(m.observations,1)
        raw = m.snapshot()
        self.assertEqual(NativeBanks.restore(raw).snapshot(),raw)
        for bad in [raw[:-1],raw+b'x',bytearray(raw)]:
            with self.assertRaises(ValueError): NativeBanks.restore(bad)
    def test_trajectory_charged_shared_budget_and_replay_identity(self):
        for seed,group in [(94001,'ABA'),(94009,'stationary_majority'),(94017,'unfamiliar_cubic')]:
            w=one_world(seed,group)
            self.assertEqual(w['charged_actions'],48)
            self.assertLessEqual(w['charged_flips'],8)
            self.assertEqual(w['charged_causal']+w['charged_flips'],48)
            self.assertEqual(w['audits']['sleep_repair'],w['audits']['online_replay_control'])
            for a in w['snapshots'].values(): self.assertLessEqual(a['bytes'],8192)
    def test_frozen_cohorts_and_independent_controls(self):
        self.assertEqual([len(x) for x in SEEDS.values()],[8,8,8])
        self.assertEqual(len(set().union(*map(set,SEEDS.values()))),24)
        self.assertIsInstance(ConventionalContext(),ConventionalContext)
        r=run()
        self.assertEqual(r['charged_actions_all_arms'],1152)
        self.assertEqual(len(r['worlds']),24)
        self.assertTrue(r['sleep_ties_online_replay_control'])
        self.assertEqual(r['scientific_acceptance'],'UNVERIFIED')
if __name__=='__main__': unittest.main()
