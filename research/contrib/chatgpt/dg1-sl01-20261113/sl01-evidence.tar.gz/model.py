"""SL01: source-only bounded wake/sleep causal rule compression.

Offline 'sleep' reads only physical experience and cannot access audit truth.
All arms use the same fixed 40-rule grammar; no claim of novel rule discovery.
"""
import hashlib
import json
import random
from itertools import combinations

FULL = (1 << 40) - 1
TRIPLES = tuple(combinations(range(4), 3))
SCHEMA = "ygg.dg1-sl01.sleep-memory.v1"

def effect(state, rule):
    if not (type(state) is int and 0 <= state < 16 and type(rule) is int and 0 <= rule < 40):
        raise ValueError("INVALID_RULE_OR_STATE")
    if rule < 32:
        return ((state & (rule >> 1)).bit_count() & 1) ^ (rule & 1)
    return int(sum((state >> i) & 1 for i in TRIPLES[(rule - 32)//2]) >= 2) ^ (rule & 1)

def next_state(state, action, rule):
    if type(action) is not int or not 0 <= action < 4:
        raise ValueError("INVALID_ACTION")
    return state ^ (effect(state, rule) << action)

def filter_mask(mask, state, result, action):
    observed = (state ^ result) >> action
    return sum((1 << k) for k in range(40) if mask & (1 << k) and effect(state, k) == observed)

def infer(mask, state, action):
    outcomes = {effect(state, k) for k in range(40) if mask & (1 << k)}
    return next_state(state, action, next(iter(outcomes))) if len(outcomes) == 1 else None

def experience(seed, ctx):
    rng = random.Random(seed * 97 + ctx * 100003)
    rules = [rng.randrange(40) for _ in range(4)]
    pairs = [(state, action) for action in range(4) for state in range(16)]
    # exactly four distinct observations per action
    chosen = []
    for action in range(4):
        states = rng.sample(range(16), 4)
        chosen.extend((s, action) for s in states)
    return rules, [(state, action, next_state(state, action, rules[action]))
                   for state, action in chosen]

class MaskBank:
    def __init__(self):
        self.masks = [FULL] * 4
        self.observations = 0

    def learn(self, entry):
        s, a, after = entry
        if type(s) is not int or not 0 <= s < 16 or type(a) is not int or not 0 <= a < 4:
            raise ValueError("INVALID_PHYSICAL_EVENT")
        if after not in (s, s ^ (1 << a)):
            raise ValueError("NONLOCAL_PHYSICAL_EVENT")
        revised = filter_mask(self.masks[a], s, after, a)
        if not revised:
            raise ValueError("INCONSISTENT_WITH_FROZEN_RULE_FAMILY")
        self.masks[a] = revised
        self.observations += 1

    def predict(self, state, action):
        return infer(self.masks[action], state, action)

    def snapshot(self):
        body = {"schema": SCHEMA, "masks": self.masks, "observations": self.observations}
        plain = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
        return json.dumps({"body": body, "sha256": hashlib.sha256(plain).hexdigest()},
                          sort_keys=True, separators=(",", ":")).encode()

    @classmethod
    def restore(cls, raw):
        try:
            if type(raw) is not bytes or len(raw) > 4096:
                raise ValueError("BAD_CHECKPOINT")
            packet = json.loads(raw)
            body = packet["body"]
            digest = hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            if set(packet) != {"body", "sha256"} or packet["sha256"] != digest:
                raise ValueError("BAD_CHECKPOINT")
            if set(body) != {"schema", "masks", "observations"} or body["schema"] != SCHEMA:
                raise ValueError("BAD_CHECKPOINT")
            if (type(body["masks"]) is not list or len(body["masks"]) != 4
                    or any(type(m) is not int or not 0 < m <= FULL for m in body["masks"])
                    or type(body["observations"]) is not int or not 0 <= body["observations"] <= 32):
                raise ValueError("BAD_CHECKPOINT")
            output = cls()
            output.masks = body["masks"][:]
            output.observations = body["observations"]
            if output.snapshot() != raw:
                raise ValueError("NONCANONICAL_CHECKPOINT")
            return output
        except (KeyError, TypeError, UnicodeError, OverflowError, ValueError) as exc:
            raise ValueError("BAD_CHECKPOINT") from exc

def audit(predict, rules, seen):
    out = {"correct": 0, "wrong_confident": 0, "abstained": 0,
           "unseen_correct": 0, "unseen_wrong_confident": 0, "unseen_abstained": 0}
    for s in range(16):
        for a in range(4):
            got = predict(s, a)
            truth = next_state(s, a, rules[a])
            key = "abstained" if got is None else "correct" if got == truth else "wrong_confident"
            out[key] += 1
            if (s, a) not in seen:
                out["unseen_" + key] += 1
    return out

def one_world(seed):
    rules_a, events_a = experience(seed, 0)
    rules_b, events_b = experience(seed, 1)
    bank_online_a = MaskBank()
    bank_online_b = MaskBank()
    for event in events_a:
        bank_online_a.learn(event)
    for event in events_b:
        bank_online_b.learn(event)

    # Sleep: preserve episodes while awake, consolidate to parameter masks when offline.
    sleep_a, sleep_b = MaskBank(), MaskBank()
    for event in events_a:
        sleep_a.learn(event)
    for event in events_b:
        sleep_b.learn(event)
    # Consolidation happens only after the complete wake experience;
    # two banks are stored for cold retrieval with no evaluator feedback.
    cold_a = MaskBank.restore(sleep_a.snapshot())
    cold_b = MaskBank.restore(sleep_b.snapshot())

    # A conventional batch version-space controller implements the same rule family.
    conventional_a = MaskBank()
    for event in sorted(events_a):
        conventional_a.learn(event)

    # Dream ablation: predictions from a frozen model must never create evidence.
    dream_a = MaskBank.restore(sleep_a.snapshot())
    for state in range(16):
        for action in range(4):
            _ = dream_a.predict(state, action)
    assert dream_a.snapshot() == sleep_a.snapshot()

    # Bounded 16-entry factual FIFO memory; cannot generalize outside witnessed pairs.
    fifo = {(s, a): after for s, a, after in events_a}
    seen = {(s, a) for s, a, _ in events_a}
    result = {
        "seed": seed, "charged_actions": len(events_a) + len(events_b),
        "offline_simulator_queries": 0,
        "first_context_audit": {
            "episodic_fifo": audit(lambda s, a: fifo.get((s, a)), rules_a, seen),
            "online_native_version_space": audit(bank_online_a.predict, rules_a, seen),
            "sleep_native_compression": audit(cold_a.predict, rules_a, seen),
            "conventional_batch_compression": audit(conventional_a.predict, rules_a, seen),
            "sleep_dream_ablation": audit(dream_a.predict, rules_a, seen)},
        "second_context_audit": audit(cold_b.predict, rules_b, {(s, a) for s, a, _ in events_b}),
        "cold_restore_identical": cold_a.snapshot() == sleep_a.snapshot(),
        "cold_snapshot_bytes": len(sleep_a.snapshot()),
        "trace_sha256": hashlib.sha256(json.dumps([events_a, events_b], separators=(",", ":")).encode()).hexdigest(),
        "rule_support_A": [x.bit_count() for x in cold_a.masks],
    }
    return result

def run():
    worlds = [one_world(seed) for seed in range(93001, 93009)]
    arms = worlds[0]["first_context_audit"]
    agg = {arm: {k: sum(w["first_context_audit"][arm][k] for w in worlds)
                 for k in worlds[0]["first_context_audit"][arm]}
           for arm in arms}
    native = agg["sleep_native_compression"]
    fifo = agg["episodic_fifo"]
    conventional = agg["conventional_batch_compression"]
    passed = (native["unseen_correct"] - fifo["unseen_correct"] >= 16
              and native["unseen_wrong_confident"] == 0
              and native["correct"] >= 16)
    return {"schema": "ygg.dg1-sl01.prospective-dev.v1",
            "classification": "DEV_SIGNAL_NOT_SCIENCE" if passed else "NEGATIVE_DEV",
            "primary_pass": passed,
            "scientific_acceptance": "UNVERIFIED",
            "native_superior_to_conventional": (
                native["correct"] > conventional["correct"] and
                native["wrong_confident"] <= conventional["wrong_confident"]),
            "all_same_physical_events": True, "same_total_compute": False,
            "aggregate_first_A": agg, "worlds": worlds}

if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
