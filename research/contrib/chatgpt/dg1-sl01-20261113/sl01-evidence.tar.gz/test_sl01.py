import unittest
from model import MaskBank, effect, experience, one_world, run

class SleepResearchTests(unittest.TestCase):
    def test_rules_and_physical_budget(self):
        self.assertEqual(effect(0, 0), 0)
        self.assertEqual(effect(0, 1), 1)
        for seed in range(93001, 93009):
            _, events = experience(seed, 0)
            self.assertEqual(len(events), 16)
            self.assertEqual(len({(s,a) for s,a,_ in events}), 16)
    def test_cold_snapshot_and_corruption(self):
        m = MaskBank()
        m.learn((0,0,0))
        raw = m.snapshot()
        self.assertEqual(MaskBank.restore(raw).snapshot(), raw)
        for bad in (raw[:-1], raw+b"x", bytes([raw[0]^1])+raw[1:], bytearray(raw)):
            with self.assertRaises(ValueError):
                MaskBank.restore(bad)
    def test_no_audit_learning_or_dream_data(self):
        w = one_world(93001)
        self.assertEqual(w["charged_actions"], 32)
        self.assertEqual(w["offline_simulator_queries"], 0)
        self.assertTrue(w["cold_restore_identical"])
        self.assertLess(w["cold_snapshot_bytes"], 4096)
        self.assertEqual(w["first_context_audit"]["sleep_native_compression"],
                         w["first_context_audit"]["sleep_dream_ablation"])
        self.assertEqual(w["first_context_audit"]["sleep_native_compression"],
                         w["first_context_audit"]["online_native_version_space"])
    def test_independent_conventional_tie_explicit(self):
        res = run()
        self.assertFalse(res["native_superior_to_conventional"])
        self.assertEqual(res["scientific_acceptance"], "UNVERIFIED")
if __name__ == "__main__":
    unittest.main()
