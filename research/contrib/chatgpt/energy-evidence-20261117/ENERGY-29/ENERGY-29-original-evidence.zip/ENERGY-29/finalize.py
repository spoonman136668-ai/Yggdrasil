#!/usr/bin/env python3
"""Assemble reproducible local report and source custody before GitHub archival."""
from pathlib import Path
import hashlib, json, platform, sys, zipfile
import numpy, scipy, sklearn
P=Path(__file__).resolve().parent
j=json.loads((P/'scored.json').read_text());a=json.loads((P/'audit_result.json').read_text());q=json.loads((P/'qualification.json').read_text());replay=json.loads((P/'replay_result.json').read_text());freeze=json.loads((P/'freeze.json').read_text())
assert a['status']=='PASS' and q['development_classification']=='DEVELOPMENT_NO_GO' and replay['semantic_identity']
assert hashlib.sha256((P/'experiment.py').read_bytes()).hexdigest()==freeze['source_sha256']
assert hashlib.sha256((P/'protocol.json').read_bytes()).hexdigest()==freeze['protocol_sha256']
s=j['summary']['strata']
def correct(family,noise,arm):return s[f'{family}/noise{noise}']['correct'][arm]
def pct(n):return f'{100*n/1920:.2f}%'
R=f'''# ENERGY-29 — Constructive Boolean causal hypotheses beyond fixed rule templates

**Date:** 2026-11-18. **Frozen outcome: DEVELOPMENT_NO_GO.** **Scientific pass: false.** **Deployment: NONE.**

## Research question and relevance

ENERGY-28 showed that a finite hypothesis-birth rule can outperform a prior 40-template family, but its new causal relationships were still selected from the experimenter's XOR3+AND2 grammar. ENERGY-29 instead constructs Boolean causal rule hypotheses as sparse algebraic-normal-form (ANF) expressions from a generic 41-feature basis (all monomials of degrees 1, 2 and 3 over six public intervention bits). It can combine up to three distinct monomials, with an optional output complement, producing **23,044 signed Boolean programs**. No source target is presented as an identity/label to the learner.

This is a **bounded general-purpose compositional hypothesis space**, not unconstrained causal concept invention or native Yggdrasil code. It is mathematically a version-space Bayes/energy-equivalent estimator, **not a distinctive performance benefit of energy inference**. Native CKAD's existing retained context learner, exactly marginalized planner and controlled scientific first-use were not modified or executed.

## Prospective frozen protocol

- Six binary public intervention variables, **64 possible interventions** per world. Exactly **24 witnessed action-consequence observations** used for learning, **24 disjoint held-out interventions** for scoring and **16 unused**. For each primary seed, the split is independently SHA-ordered and **the same across all laws**, preventing hidden-rule-dependent intervention selection.
- Source families: **old** signed three-bit parity optionally corrected by an AND of two remaining bits (160 known templates); **novel_in_basis** new three-term generic polynomial expressions including cubic and quadratic factors, deliberately excluded from those 160 templates; **outside_basis** degree-four interactions or majority-of-five, absent from the 23,044-rule hypothesis bank.
- **Four new primary seeds 2399, 2411, 2423, 2441**, 20 independently generated laws per source family and seed, training corruption of zero or exactly two observed labels, **480 independently fitted cases** and **11,520 held binary outcomes per learning arm**. Separate non-scored smoke seed 7001.
- **Same public evidence for every learner arm**. Structural-birth arm initially uses the old exact Bayesian bank; it admits all 23,044 compositional candidates if the old bank's minimum mismatch reaches at least 2 in the first 12 observations or at least 3 in all 24. Model receives no source law labels, hidden values or held outcomes; only the 24 intervention/outcome pairs.
- **Strong controls:** fully fitted exact Bayesian complete ANF version space, fully fitted old-template Bayesian bank, conventional degree-three polynomial kernel ridge, trained depth-six CART and trained 31-tree ExtraTrees forest, plus hard single-hypothesis MAP ablation. No arm gets more observed data or action capacity. Bayesian rule posterior and normalized classical energy are mathematically equivalent.
- Prespecified development GO requires clean novel >=90%, noisy novel >=80%, >=20 percentage-point novel gain over old and >=3 points over strongest conventional control in **each** noise group, within 2 points of full exact ANF control, and familiar knowledge degradation <=0pp without corruption and <=2pp with corruption. **All conditions mandatory.** Outside-basis scores describe representational limits only.

**Freeze seals:** `experiment.py` SHA-256 `{freeze['source_sha256']}`; `protocol.json` SHA-256 `{freeze['protocol_sha256']}`; smoke SHA-256 `{freeze['smoke_sha256']}`. Frozen **before** any primary scoring; code, cohort, priors and development thresholds unchanged after the score. Scoring may be rerun semantically with timing excluded. The auditor had only serialization corrections after scoring (retained failure record).

## Primary held-out results

Each row contains **80 fitted worlds ×24 disjoint held interventions =1,920 predictions per arm**.

| World family | Training flips | Old fixed Bayes | Constructed ANF birth | Complete exact ANF Bayes | Strongest conventional (forest) | Novel births |
|---|---:|---:|---:|---:|---:|---:|
| Familiar old | 0/24 | {correct('old',0,'old_bayes')}/1920 | {correct('old',0,'constructive')}/1920 | {correct('old',0,'full_anf_bayes')}/1920 | {correct('old',0,'conventional_forest')}/1920 | {s['old/noise0']['births']}/80 |
| Familiar old | 2/24 | {correct('old',2,'old_bayes')}/1920 | {correct('old',2,'constructive')}/1920 | {correct('old',2,'full_anf_bayes')}/1920 | {correct('old',2,'conventional_forest')}/1920 | {s['old/noise2']['births']}/80 |
| New function within expanded basis | 0/24 | {correct('novel_in_basis',0,'old_bayes')}/1920 | **{correct('novel_in_basis',0,'constructive')}/1920 ({pct(correct('novel_in_basis',0,'constructive'))})** | {correct('novel_in_basis',0,'full_anf_bayes')}/1920 | {correct('novel_in_basis',0,'conventional_forest')}/1920 | {s['novel_in_basis/noise0']['births']}/80 |
| New function within expanded basis | 2/24 | {correct('novel_in_basis',2,'old_bayes')}/1920 | **{correct('novel_in_basis',2,'constructive')}/1920 ({pct(correct('novel_in_basis',2,'constructive'))})** | {correct('novel_in_basis',2,'full_anf_bayes')}/1920 | {correct('novel_in_basis',2,'conventional_forest')}/1920 | {s['novel_in_basis/noise2']['births']}/80 |
| Outside even expanded basis | 0/24 | {correct('outside_basis',0,'old_bayes')}/1920 | {correct('outside_basis',0,'constructive')}/1920 | {correct('outside_basis',0,'full_anf_bayes')}/1920 | {correct('outside_basis',0,'conventional_forest')}/1920 | {s['outside_basis/noise0']['births']}/80 |
| Outside even expanded basis | 2/24 | {correct('outside_basis',2,'old_bayes')}/1920 | {correct('outside_basis',2,'constructive')}/1920 | {correct('outside_basis',2,'full_anf_bayes')}/1920 | {correct('outside_basis',2,'conventional_forest')}/1920 | {s['outside_basis/noise2']['births']}/80 |

**Positive bounded signal:** constructed ANF rules gained **{correct('novel_in_basis',0,'constructive')-correct('novel_in_basis',0,'old_bayes')}/1920 (+{100*(correct('novel_in_basis',0,'constructive')-correct('novel_in_basis',0,'old_bayes'))/1920:.2f} percentage points)** over fixed old templates for clean novel laws and **{correct('novel_in_basis',2,'constructive')-correct('novel_in_basis',2,'old_bayes')}/1920 (+{100*(correct('novel_in_basis',2,'constructive')-correct('novel_in_basis',2,'old_bayes'))/1920:.2f} points)** for corrupted novel laws. Compared to the strongest conventional forest, improvements were **+{100*(correct('novel_in_basis',0,'constructive')-correct('novel_in_basis',0,'conventional_forest'))/1920:.2f}** and **+{100*(correct('novel_in_basis',2,'constructive')-correct('novel_in_basis',2,'conventional_forest'))/1920:.2f}** points. Birth occurred in 79/80 clean and 80/80 noisy novel cases, but perfect rule identification is not established.

**Disqualifying weaknesses:** novel clean accuracy **{pct(correct('novel_in_basis',0,'constructive'))}** misses the >=90% frozen target; novel noisy accuracy **{pct(correct('novel_in_basis',2,'constructive'))}** misses >=80%. Familiar clean retention of the original bank was exact; familiar **noisy** cases triggered erroneous expansion in **12/80** worlds and lost **{correct('old',2,'old_bayes')-correct('old',2,'constructive')}/1920 = {100*(correct('old',2,'old_bayes')-correct('old',2,'constructive'))/1920:.2f} percentage points** versus the unchanged old-Bayes control, breaching the <=2pp degradation limit. It is a genuine contradiction-triggering false alarm on the familiar structural family.

**Out-of-basis control:** constructing generic ANF helps on higher-degree truths even though their exact functions are **not in the 23,044-model bank**. These are extrapolations, not recovered exact laws. No claim of open-ended conceptual discovery, causal retention after session transitions, or general intelligence. The negative is that even a broad version space has a formal representation boundary.

## Audited evidence and numerical caveats

Independent source/reconstruction audit **PASS**; it does **not import the scorer**. It independently regenerates truth masks, SHA-ordered interventions, corruption positions, old/constructed Bayes predictions, all three conventional fits, and every 480-case held result, including 7 arms ×24 held outputs. In **48 stratified cases ×24 held** it additionally checks the complete ANF posterior prediction using exact unbounded Python integers rather than floating-point likelihood sums. Summary:

- **{a['individual_predictions_independently_verified']:,}** individual arm predictions independently recalculated; **{a['causal_outcomes_independently_reconstructed']:,}** held causal truths reconstructed; **{a['exact_big_integer_held_posterior_votes_verified']:,}** exact-integer votes; **{a['structural_invariants_checked']:,}** designated source/structure invariants. The aggregate is **{a['total_assertion_bearing_checks']:,} checked values/invariants**, not 103,872 distinct unit-test functions. The conventional tree/forest auditor retrains the **same third-party sklearn implementations**, so this is an independent evidence rebuild but not an independent forest algorithm implementation.
- The independent augmented least-squares polynomial regression reproduced the scorer's kernel solution classifications on all held examples. **{a['numeric_ridge_near_zero_held_margins']}** held ridge margins were numerically near zero (<1e-8); their exact sign may depend on environment and tie conventions. The audit matched this specific environment and thus cannot claim cross-platform bitwise reproducibility for those ties.
- The **first auditor execution failed only when serializing NumPy `int64` counters**; a second console-summary serialization issue was corrected in the auditor alone. `AUDIT-FIRST-FAILURE.md` preserves both. No frozen source, primary score, cohort or threshold changed.
- Fresh complete scoring-process semantic replay reproduced **all 480 case records and summary aggregates** byte-for-byte when wall timings are excluded; canonical SHA-256 **`{replay['canonical_semantic_sha256']}`**. Original scoring wall **{replay['original_wall_seconds']:.3f}s**, replay wall **{replay['replay_wall_seconds']:.3f}s** on local CPU. Those times include **all arms** and do not measure a relative learned-model speedup. Full native H200/Windows qualification was not executed.

## Frozen decisions and implications

| Gate | Result |
|---|---|
'''
for k,v in q['gates'].items():R+=f'| {k} | {"PASS" if v else "FAIL"} |\n'
R+='''
**ENGINEERING:** frozen source and primary scoring, independent local audit, and semantic replay PASS. No accepted-source Yggdrasil full regression, Linux/Windows parity or original first-use was performed. GitHub archive must be verified separately before claiming remote evidence custody.

**SCIENTIFIC:** **DEVELOPMENT_NO_GO**, strong in-family construction improvement but missed absolute thresholds and familiar-noisy retention. Full exact ANF Bayes reaches virtually the same novel accuracy; the normalized energy viewpoint is equivalent, not a new model or special intelligence gain. Avoid retuning this scored cohort. Future work would need genuinely new modalities/actions and native CKAD competing-hypothesis integration only after independently qualified prospective science.

**DEPLOYMENT:** NONE. Existing Yggdrasil native learner / CKAD PR #1207, Wingless, Hybrid, FORGE owner and their respective research loops remain untouched. No controller, scheduler, new PR, protected scientific first-use, or merge.
'''
(P/'REPORT.md').write_text(R,encoding='utf-8')
environment={'schema':'energy29.local-environment.v1','python':sys.version,'python_version':platform.python_version(),'platform':platform.platform(),'numpy':numpy.__version__,'scipy':scipy.__version__,'scikit_learn':sklearn.__version__,'source_sha256':freeze['source_sha256'],'full_regression':'NOT_EXECUTED','gpu':'NOT_EXECUTED','scientific_first_use':'NOT_EXECUTED'}
(P/'environment.json').write_text(json.dumps(environment,indent=2,sort_keys=True)+'\n')
files=['REPORT.md','experiment.py','protocol.json','freeze.json','make_freeze.py','smoke.json','scored.json','primary_stdout.json','independent_audit.py','audit_result.json','AUDIT-FIRST-FAILURE.md','qualification.json','replay-scored.json','replay_stdout.json','replay_result.json','environment.json','finalize.py']
manifest={'schema':'energy29.byte-custody-manifest.v1','classification':'DEVELOPMENT_NO_GO','source_sha256':freeze['source_sha256'],'protocol_sha256':freeze['protocol_sha256'],'scored_sha256':replay['original_scored_sha256'],'members':[{'filename':name,'bytes':(P/name).stat().st_size,'sha256':hashlib.sha256((P/name).read_bytes()).hexdigest()} for name in files]}
(P/'MANIFEST.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
files+=['MANIFEST.json']
archive=P/'ENERGY-29-original-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in files:
        contents=(P/name).read_bytes()
        info=zipfile.ZipInfo(f'ENERGY-29/{name}',date_time=(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100644<<16)
        z.writestr(info,contents,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive,'r') as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)
    for row in manifest['members']:
        assert hashlib.sha256(z.read('ENERGY-29/'+row['filename'])).hexdigest()==row['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'report_bytes':(P/'REPORT.md').stat().st_size,'status':'PASS_LOCAL_CUSTODY'},indent=2))
