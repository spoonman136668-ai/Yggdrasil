#!/usr/bin/env python3
"""Create pre-score immutable preregistration and source receipts, once."""
import hashlib,json,platform
from pathlib import Path
p=Path(__file__).resolve().parent
source=p/'experiment.py'
smoke=p/'smoke.json'
protocol={
  'schema':'yggdrasil.energy29.bounded-boolean-rule-invention.prereg.v1',
  'date':'2026-11-18','name':'ENERGY-29',
  'objective':'Test whether generic algebraic-normal-form sparse causal hypothesis construction discovers functional relations beyond an explicitly pre-listed XOR3+AND2 grammar from witnessed interventions; falsify its generality on functions requiring higher-order/more numerous terms.',
  'source_and_scope':'Fully synthetic and disjoint from ENERGY-28. Source-side law IDs/labels; learner only sees public 6-bit intervention vectors and their observed binary consequences. No real-world first use, native Yggdrasil training, or active loop changes.',
  'source_design':{
    'n_action_bits':6,'action_space':64,'training_interventions':24,'held_interventions':24,'unused':16,
    'source_family':['old existing XOR3 with optional AND2 correction','novel three sparse ANF monomials each degree<=3, including cubic & quadratic term and not equal to any old law','outside sparse ANF target: degree4 interaction or majority5'],
    'source_worlds_per_family_per_seed':20,'seeds':[2399,2411,2423,2441],
    'noise_corrupted_training_labels':[0,2],
    'held_noise':0,'held_update_count':0,'smoke_seed':7001,
    'source_hashing':'SHA-256 fixed seed-only disjoint split; noise positions source-side SHA-256; source law IDs never supplied to learner; same revealed actions and labels for all models',
    'total_scored_cases':480,'held_per_arm':11520
  },
  'hypotheses':{
    'original_prior_bank':160,'new_generic_algebraic_terms':'41 all degree1..3 square-free monomials in six intervention bits',
    'composed_program_space':'all Boolean XOR sums of at most three distinct monomial factors plus optional complement sign; 23,044 functions, constructed from basis rather than pre-listed grammar families',
    'prior_tier_masses':[0.01,0.12,0.27,0.60],
    'assumed_training_label_flip_probability':0.25,
    'candidate_birth':'generate broad ANF hypothesis space after minimum mismatch >=2 among old bank after first 12 witnessed interventions or >=3 after 24; otherwise use old bank',
    'posterior_decision':'exact finite hypothesis likelihood weighted marginal (>0.5, tie to 0); normalized energy encoding is mathematically equivalent, NOT an energy-specific improvement'
  },
  'controls':[
    'Fully fitted original 160-rule Bayes under same evidence',
    'Fully fitted complete 23,044-structure ANF Bayesian posterior (strongest same-family exact control)',
    'Fully fitted degree<=3 polynomial kernel ridge with L2 penalty 1.0, same inputs',
    'Fully trained conventional depth-6 CART decision tree',
    'Fully trained 31-tree ExtraTrees forest (depth<=6, same public evidence)',
    'MAP hard winner ablation of the selected hypothesis bank',
    'Outside-basis new causal functions as a negative control of finite representation'
  ],
  'success_criteria_development_all_required':{
    'novel_in_basis_clean_accuracy_at_least':0.90,
    'novel_in_basis_noisy_accuracy_at_least':0.80,
    'novel_in_basis_gain_over_old_each_noise_at_least_pp':20,
    'novel_in_basis_gain_over_strongest_conventional_each_noise_at_least_pp':3,
    'novel_in_basis_gap_below_complete_anf_each_noise_at_most_pp':2,
    'familiar_noiseless_prediction_loss_vs_old_at_most_pp':0,
    'familiar_corrupted_prediction_loss_vs_old_at_most_pp':2,
    'no_unfounded_outside_basis_generalization_claim':True,
    'no_claim_of_energy_specific_gain_from_equivalent_bayes':True
  },
  'negative_controls':[
    'Source construction must make all in-basis truth masks outside original 160 old masks',
    'Outside-basis source function must be absent from both old and constructed bank',
    'Same public evidence and held truth for every arm, no held training',
    'Exhaustively recompute source truth and training corruption with separately implemented audit',
    'Check original snapshots, signatures, all 480 rows and 7 prediction arms independently',
    'Use exact integer posterior cross-check for stratified case subset to catch floating near-ties',
    'Fresh scored semantic replay with timing fields excluded',
    'No post-score changes to seeds, algorithms or thresholds; retain any errors as provenance'
  ],
  'budget':{'primary_wall_seconds':120,'audit_wall_seconds':90,'paid_apis':0,'protected_first_use':0,'original_source_actions':0},
  'qualification':'development only; no native learned model, no native full dual-platform final regression, no scientific first-use, no promotion',
  'deployment':'NONE','scientific_pass':False,
  'repo':'spoonman136668-ai/Yggdrasil',
  'native_pr_1207_head_at_freeze':'08fbe556d7ac134d3662f7003af5bc4430013ac1',
  'research_archive_pr':1210,
  'parent_energy28_archive_sha':'0ae3d547c9e37e6168fbd77ff547bc4338041f43'
}
(p/'protocol.json').write_text(json.dumps(protocol,sort_keys=True,indent=2)+'\n')
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
freeze={'schema':'energy29.frozen-source-before-scoring.v1','source_sha256':sha(source),'protocol_sha256':sha(p/'protocol.json'),'smoke_sha256':sha(smoke),'smoke_seed_only':7001,'scored_seeds':[2399,2411,2423,2441],'frozen_per_case_noise':[0,2],'freeze_created_without_scored_file':not (p/'scored.json').exists(),'notes':'Protocol, code and smoke results sealed before evaluation. No primary result used to choose source, features, priors, thresholds or seeds.'}
if not freeze['freeze_created_without_scored_file']:raise RuntimeError('Refuse to freeze after scoring')
(p/'freeze.json').write_text(json.dumps(freeze,sort_keys=True,indent=2)+'\n')
print(json.dumps(freeze,indent=2))
