#!/usr/bin/env python3
"""ENERGY-46 external synthetic continual causal factor learning. NO native model use.
Freeze source and preregistration on separate GitHub commits BEFORE primary seeds.
"""
import argparse,copy,hashlib,json,itertools,time,warnings
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet,Ridge
from sklearn.ensemble import RandomForestRegressor

SEEDS=(8909,8923,8933); SMOKE=99863; FAMILIES=('parity2','parity3','mixed'); IDS=(0,1,2,3)
GRAMMAR=[('p',v) for n in (1,2,3) for v in itertools.combinations(range(12),n)] + [('a',v) for v in itertools.combinations(range(12),2)]
K=len(GRAMMAR);assert K==364
ARMS=('replay_gated','unconditional_replay','hybrid_validation','stagewise_omp4','omp_structural_memory','omp_full7','elasticnet','ridge','forest','no_repair','shuffled_gate')
MATCHED=('hybrid_validation','stagewise_omp4','omp_structural_memory','omp_full7','elasticnet','ridge','forest')

def rng(*parts):
    seed=int.from_bytes(hashlib.sha256(('ENERGY46-v1|'+ '|'.join(map(str,parts))).encode()).digest()[:8],'big')
    return np.random.default_rng(seed)

def phi(x):
    x=np.asarray(x,dtype=np.int8); n=len(x); y=np.empty((n,K),dtype=np.float64)
    for j,(kind,idx) in enumerate(GRAMMAR):
        z=x[:,idx]
        if kind=='p':y[:,j]=1-2*np.bitwise_xor.reduce(z,axis=1)
        else:y[:,j]=2*np.all(z==1,axis=1).astype(np.float64)-1
    return y

def make_world(seed,idx,family):
    key=f'{seed}:{idx}:{family}';g=rng(key,'truth')
    if family=='parity2':pool=[i for i,(kind,sup) in enumerate(GRAMMAR) if kind=='p' and len(sup)==2 and max(sup)<10]
    elif family=='parity3':pool=[i for i,(kind,sup) in enumerate(GRAMMAR) if kind=='p' and len(sup)==3 and max(sup)<10]
    else:pool=[i for i,(kind,sup) in enumerate(GRAMMAR) if max(sup)<10 and len(sup)>=2]
    ids=[int(t) for t in g.choice(pool,5,replace=False)];weights=[float((1 if g.random()<.5 else -1)*g.uniform(.85,1.15)) for _ in range(5)]
    changed=idx!=3
    if not changed:ids[4]=ids[3];weights[4]=weights[3]
    out={'seed':seed,'idx':idx,'family':family,'case':key,'truth':ids,'weights':weights,'changed':changed,'parts':{}}
    for part,stage,count in [('old_train',0,96),('new_train',1,96),('old_held',0,128),('new_held',1,128),('cold_held',1,128)]:
        h=rng(key,part,'x');x=h.integers(0,2,size=(count,12),dtype=np.int8)
        if part!='cold_held':
            cue0=(x[:,0] if stage==0 else 1-x[:,0]);cue1=x[:,1] if stage==0 else x[:,2]
            x[:,10]=np.bitwise_xor(cue0,(h.random(count)<.08).astype(np.int8))
            x[:,11]=np.bitwise_xor(cue1,(h.random(count)<.08).astype(np.int8))
        true=phi(x)[:,ids];w=np.asarray(weights)
        y=true[:,:3]@w[:3]+true[:,3+stage]*w[3+stage]+rng(key,part,'noise').normal(0,.3,count)
        out['parts'][part]={'x':x,'y':y,'stage':stage}
    return out

def omp(A,y,n):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        model=OrthogonalMatchingPursuit(n_nonzero_coefs=n,fit_intercept=False).fit(A,y)
    ids=np.flatnonzero(np.abs(model.coef_)>1e-8)
    return ids.astype(int).tolist(),np.asarray(model.coef_[ids],dtype=float)

def fit(A,y,ids,r=.02):
    Z=A[:,ids]
    return np.linalg.solve(Z.T@Z+r*np.eye(len(ids)),Z.T@y)

def replace(A,y,oldids,split=72,gate=True,shuffle=False):
    # Selection and trigger use *only new TRAIN observations*. The last 24 of
    # those 96 training cases are a decision subset, not any held evaluation.
    if shuffle:y=rng('sham',tuple(oldids),float(np.sum(y))).permutation(y)
    T=A[:split];yy=y[:split];current=fit(T,yy,oldids)
    baseline=float(np.mean((A[split:,oldids]@current-y[split:])**2))
    residual=yy-T[:,oldids]@current
    correlations=np.abs(T.T@residual)/np.maximum(np.linalg.norm(T,axis=0),1e-9)
    correlations[oldids]=-np.inf
    top=np.argsort(-correlations,kind='stable')[:24]
    best=(float('inf'),(10**9,10**9),[],[])
    for drop in oldids:
        keep=[j for j in oldids if j!=drop]
        for add in top:
            ids=keep+[int(add)];coef=fit(T,yy,ids)
            err=float(np.mean((A[split:,ids]@coef-y[split:])**2))
            sig=(int(drop),int(add))
            if (err,sig)<(best[0],best[1]):best=(err,sig,ids,coef)
    improvement=baseline-best[0];trigger=bool(improvement>=.12) if gate else True
    ids=best[2] if trigger else oldids
    return {'trigger':trigger,'drop':int(best[1][0]),'add':int(best[1][1]),'ids':list(map(int,ids)),
            'coef':fit(A,y,ids).tolist(),'improvement':float(improvement),'validation_base':baseline,'validation_replace':best[0]}

def context(A0,A1):
    x0=np.column_stack([A0,np.zeros_like(A0)]);x1=np.column_stack([np.zeros_like(A1),A1]);return np.vstack([x0,x1])

def predict_model(sel,A,stage):
    if stage==0:return A[:,sel['old_ids']]@sel['old_coef']
    return A[:,sel['new_ids']]@sel['new_coef']

def case_score(seed,idx,family):
    w=make_world(seed,idx,family);p=w['parts'];a0=phi(p['old_train']['x']);a1=phi(p['new_train']['x']);y0=p['old_train']['y'];y1=p['new_train']['y'];
    st=time.perf_counter();oi,ow=omp(a0,y0,4);old_fit=time.perf_counter()-st
    st=time.perf_counter();gat=replace(a1,y1,oi);tg=time.perf_counter()-st
    st=time.perf_counter();unc=replace(a1,y1,oi,gate=False);tu=time.perf_counter()-st
    st=time.perf_counter();sham=replace(a1,y1,oi,shuffle=True);tsh=time.perf_counter()-st
    st=time.perf_counter();ni,nw=omp(a1,y1,4);tn=time.perf_counter()-st
    st=time.perf_counter();D=context(a0,a1);Y=np.r_[y0,y1];di,dw=omp(D,Y,7);tm=time.perf_counter()-st
    st=time.perf_counter();D2=np.vstack([np.c_[a0,np.zeros_like(a0)],np.c_[np.zeros_like(a1),a1]]);full_ids,full_w=omp(D2,Y,7);tf=time.perf_counter()-st
    st=time.perf_counter();en=ElasticNet(alpha=.025,l1_ratio=.85,max_iter=5000,tol=1e-5,random_state=0).fit(D,Y);te=time.perf_counter()-st
    st=time.perf_counter();rg=Ridge(alpha=40).fit(D,Y);tr=time.perf_counter()-st
    st=time.perf_counter();forest=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=seed+idx).fit(np.r_[np.c_[p['old_train']['x'],np.zeros(96)],np.c_[p['new_train']['x'],np.ones(96)]],Y);tfr=time.perf_counter()-st
    # Old predictions retain the independently qualified frozen OMP4 support,
    # and reapply the 96 witnessed old consequences exactly; no new-stage
    # gradients may modify this old context head. A matched hybrid-validation
    # control chooses stagewise vs cumulative model
    # by the final 24 new-TRAIN labels, no contradiction-specific support edits.
    aa=np.zeros_like(a1);newD=np.c_[aa,a1]
    valmem=float(np.mean((newD[-24:,di]@dw-y1[-24:])**2))
    valstage=float(np.mean((a1[-24:,ni]@nw-y1[-24:])**2))
    use_stage=bool(valstage+.01<valmem)
    times={'replay_gated':old_fit+tm+tg,'unconditional_replay':old_fit+tm+tu,'hybrid_validation':old_fit+tm+tn,
           'stagewise_omp4':old_fit+tn,'omp_structural_memory':old_fit+tm,'omp_full7':tf,'elasticnet':te,'ridge':tr,'forest':tfr,'no_repair':old_fit,'shuffled_gate':old_fit+tm+tsh}
    scores={arm:{} for arm in ARMS}
    def pc(arm,A,X,stage):
        old=A[:,oi]@ow
        mem=np.c_[A,np.zeros_like(A)][:,di]@dw if stage==0 else np.c_[np.zeros_like(A),A][:,di]@dw
        if arm=='replay_gated':return old if stage==0 else (A[:,gat['ids']]@gat['coef'] if gat['trigger'] else A[:,oi]@fit(a1,y1,oi))
        if arm=='unconditional_replay':return old if stage==0 else A[:,unc['ids']]@unc['coef']
        if arm=='hybrid_validation':return old if stage==0 else (A[:,ni]@nw if use_stage else mem)
        if arm=='stagewise_omp4':return old if stage==0 else A[:,ni]@nw
        if arm=='omp_structural_memory':return mem
        if arm=='omp_full7':return (np.c_[A,np.zeros_like(A)] if stage==0 else np.c_[np.zeros_like(A),A])[:,full_ids]@full_w
        if arm=='elasticnet':return en.predict(np.c_[A,np.zeros_like(A)] if stage==0 else np.c_[np.zeros_like(A),A])
        if arm=='ridge':return rg.predict(np.c_[A,np.zeros_like(A)] if stage==0 else np.c_[np.zeros_like(A),A])
        if arm=='forest':return forest.predict(np.c_[X,np.full(len(X),stage)])
        if arm=='shuffled_gate':return old if stage==0 else (A[:,sham['ids']]@sham['coef'] if sham['trigger'] else A[:,oi]@fit(a1,y1,oi))
        return old
    for arm in ARMS:
        st=time.perf_counter()
        for field in ('old_held','new_held','cold_held'):
            v=p[field];a=phi(v['x']);s=v['stage'];pred=pc(arm,a,v['x'],s)
            scores[arm][field]=float(np.mean((pred-v['y'])**2))
        scores[arm]['fit_s']=float(times[arm]);scores[arm]['pred_s']=float(time.perf_counter()-st)
    scores['replay_gated'].update(trigger=gat['trigger'],drop=gat['drop'],add=gat['add'],candidate_new_ids=gat['ids'],candidate_new_weights=gat['coef'],old_ids=oi,old_weights=ow.tolist(),old_replay_ids=di,old_replay_weights=dw.tolist(),improvement=gat['improvement'],old_before=scores['no_repair']['old_held'],true_support_correct=bool(gat['trigger'] and gat['drop']==w['truth'][3] and gat['add']==w['truth'][4]) if w['changed'] else bool(not gat['trigger']))
    scores['hybrid_validation'].update(use_stage=use_stage,validation_mem=valmem,validation_stage=valstage)
    return {'seed':seed,'idx':idx,'family':family,'changed':w['changed'],'true_factors':w['truth'],'true_weights':w['weights'],'scores':scores}

def summarize(rows,seeds):
    agg={arm:{key:float(np.mean([r['scores'][arm][key] for r in rows])) for key in ('old_held','new_held','cold_held')}|{key:float(sum(r['scores'][arm][key] for r in rows)) for key in ('fit_s','pred_s')} for arm in ARMS}
    c=agg['replay_gated'];bestcold=min(agg[a]['cold_held'] for a in MATCHED);bestold=min(agg[a]['old_held'] for a in MATCHED)
    changes=[r for r in rows if r['changed']];stable=[r for r in rows if not r['changed']]
    exact=sum(r['scores']['replay_gated']['true_support_correct'] for r in changes)/len(changes)
    nochange=sum(r['scores']['replay_gated']['true_support_correct'] for r in stable)/len(stable)
    perseed={}
    for s in seeds:
        rr=[r for r in rows if r['seed']==s];perseed[str(s)]={'candidate':float(np.mean([r['scores']['replay_gated']['cold_held'] for r in rr])), 'best_conventional':float(min(np.mean([r['scores'][a]['cold_held'] for r in rr]) for a in MATCHED))}
    seedwins=sum(v['candidate']<v['best_conventional'] for v in perseed.values())
    gates={
    'cold_vs_best_10pct':c['cold_held']<=.9*bestcold,
    'cold_vs_matched_hybrid_5pct':c['cold_held']<=.95*agg['hybrid_validation']['cold_held'],
    'old_vs_best_1pct':c['old_held']<=1.01*bestold,
    'old_replay_retention_1pct':c['old_held']<=1.01*agg['no_repair']['old_held'],
    'changed_correct_support_70pct':exact>=.7,
    'nochange_false_edit_at_most_10pct':nochange>=.9,
    'sham_new_20pct':c['new_held']<=.8*agg['shuffled_gate']['new_held'],
    'seed_wins_2of3':seedwins>=2 if len(seeds)==3 else False,
    'time_at_most_3x_memory':c['fit_s']+c['pred_s']<=3*(agg['omp_structural_memory']['fit_s']+agg['omp_structural_memory']['pred_s'])}
    dec={'gates':gates,'passes':sum(gates.values()),'fails':len(gates)-sum(gates.values()),'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO','seedwins':seedwins,'perseed':perseed,'best_conventional_cold':bestcold,'best_conventional_old':bestold,'changed_exact':exact,'nochange_correct':nochange}
    return agg,dec

def canonical(rec):
    z=copy.deepcopy(rec);z.pop('wall_s',None)
    for r in z['cases']:
        for a in r['scores'].values():a.pop('fit_s',None);a.pop('pred_s',None)
    for a in z['aggregate'].values():a.pop('fit_s',None);a.pop('pred_s',None)
    z['decision'].pop('classification',None);z['decision'].pop('passes',None);z['decision'].pop('fails',None);z['decision']['gates'].pop('time_at_most_3x_memory',None)
    return json.dumps(z,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def run(seeds,ids,mode):
    st=time.perf_counter();rows=[case_score(s,i,f) for s in seeds for i in ids for f in FAMILIES];agg,dec=summarize(rows,seeds)
    return {'schema':'energy46.primary.v1','mode':mode,'seeds':list(seeds),'ids':list(ids),'families':list(FAMILIES),'cases':rows,'aggregate':agg,'decision':dec,'wall_s':time.perf_counter()-st}

def main():
    q=argparse.ArgumentParser();q.add_argument('--smoke',action='store_true');q.add_argument('--primary',action='store_true');q.add_argument('--out',required=True);a=q.parse_args()
    if a.smoke==a.primary:raise SystemExit('Specify --smoke XOR --primary')
    out=run((SMOKE,) if a.smoke else SEEDS,(0,3) if a.smoke else IDS,'smoke' if a.smoke else 'primary')
    Path(a.out).write_text(json.dumps(out,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'worlds':len(out['cases']),'decision':out['decision'],'aggregate':out['aggregate'],'semantic_sha256':hashlib.sha256(canonical(out)).hexdigest()}))
if __name__=='__main__':main()
