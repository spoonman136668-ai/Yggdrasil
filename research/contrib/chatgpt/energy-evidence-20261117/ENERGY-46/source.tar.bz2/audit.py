#!/usr/bin/env python3
"""Independent ENERGY-46 scorer/auditor: no import from experiment.py.
Reconstructs all source worlds and refits all fitted arms from raw actions.
NumPy and sklearn library internals are shared; never assert library-independence.
"""
import argparse,hashlib,itertools,json,warnings
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,Ridge,ElasticNet
from sklearn.ensemble import RandomForestRegressor

MODELS=('replay_gated','unconditional_replay','hybrid_validation','stagewise_omp4','omp_structural_memory','omp_full7','elasticnet','ridge','forest','no_repair','shuffled_gate')
G=[('p',bits) for size in (1,2,3) for bits in itertools.combinations(range(12),size)]
G.extend([('a',bits) for bits in itertools.combinations(range(12),2)])
N=len(G); assert N==364

def local_rng(*values):
    key='ENERGY46-v1|'+'|'.join(str(v) for v in values)
    return np.random.Generator(np.random.PCG64(int.from_bytes(hashlib.sha256(key.encode()).digest()[:8],'big')))

def features(x):
    m=np.zeros((len(x),364),dtype='float64')
    for k,(typ,support) in enumerate(G):
        if typ=='a':m[:,k]=np.where(np.sum(x[:,support],axis=1)==2,1.,-1.)
        else:m[:,k]=(-1.)**np.sum(x[:,support],axis=1)
    return m

def reworld(seed,idx,fam):
    key=f'{seed}:{idx}:{fam}';r=local_rng(key,'truth')
    pool=[i for i,(kind,support) in enumerate(G) if max(support)<10 and ((fam=='parity2' and kind=='p' and len(support)==2) or (fam=='parity3' and kind=='p' and len(support)==3) or (fam=='mixed' and len(support)>=2))]
    ids=[int(i) for i in r.choice(pool,5,replace=False)]
    ws=[float((1 if r.random()<.5 else -1)*r.uniform(.85,1.15)) for _ in range(5)]
    if idx==3:ids[4]=ids[3];ws[4]=ws[3]
    outputs={}
    for label,stage,n in (('old_train',0,96),('new_train',1,96),('old_held',0,128),('new_held',1,128),('cold_held',1,128)):
        a=local_rng(key,label,'x');x=a.integers(0,2,size=(n,12),dtype=np.int8)
        if label!='cold_held':
            t0=x[:,0] if stage==0 else 1-x[:,0]
            t1=x[:,1] if stage==0 else x[:,2]
            x[:,10]=np.logical_xor(t0,a.random(n)<.08)
            x[:,11]=np.logical_xor(t1,a.random(n)<.08)
        basis=features(x)[:,ids]
        y=basis[:,:3]@np.asarray(ws[:3])+basis[:,3+stage]*ws[3+stage]+local_rng(key,label,'noise').normal(0,.3,n)
        outputs[label]=(x,y)
    return {'ids':ids,'weights':ws,'parts':outputs}

def subset_fit(A,y,n):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore');model=OrthogonalMatchingPursuit(n_nonzero_coefs=n,fit_intercept=False)
        model.fit(A,y)
    s=np.where(abs(model.coef_)>1e-8)[0]
    return list(map(int,s)),np.asarray(model.coef_[s],dtype=float)

def weighted_fit(A,y,cols):
    m=A[:,cols];return np.linalg.solve(m.T@m+.02*np.eye(len(cols)),m.T@y)

def structural_edit(A,y,baseline,forced=False,negative=False):
    if negative:y=local_rng('sham',tuple(baseline),float(np.sum(y))).permutation(y)
    first=A[:72];targets=y[:72];c=weighted_fit(first,targets,baseline)
    first_error=np.mean((A[72:,baseline]@c-y[72:])**2)
    residual=targets-first[:,baseline]@c
    value=np.abs(first.T@residual)/np.maximum(np.linalg.norm(first,axis=0),1e-9)
    value[baseline]=-np.inf
    shortlisted=np.argsort(-value,kind='stable')[:24]
    selection=None
    for obsolete in baseline:
        left=[n for n in baseline if n!=obsolete]
        for proposal in shortlisted:
            keep=left+[int(proposal)];beta=weighted_fit(first,targets,keep)
            risk=float(np.mean((A[72:,keep]@beta-y[72:])**2))
            key=(risk,(int(obsolete),int(proposal)))
            if selection is None or key<selection[0]:selection=(key,keep)
    risk,edge=selection[0];trigger=bool(first_error-risk>=.12) or forced
    active=selection[1] if trigger else baseline
    return {'trigger':trigger,'drop':edge[0],'add':edge[1],'ids':active,'weights':weighted_fit(A,y,active),'improvement':float(first_error-risk)}

def close(a,b,why):
    if not np.isclose(a,b,rtol=2e-7,atol=2e-9):raise AssertionError(f'{why}: {a} vs {b}')

def main():
    p=argparse.ArgumentParser();p.add_argument('file');p.add_argument('--out',required=True);opts=p.parse_args()
    src=json.loads(Path(opts.file).read_text());checks=0;rowcounts={a:0 for a in MODELS}
    for row in src['cases']:
        seed=int(row['seed']);idx=int(row['idx']);fam=row['family'];w=reworld(seed,idx,fam);part=w['parts']
        assert row['true_factors']==w['ids'] and row['changed']==(idx!=3);checks+=6
        for a,b in zip(row['true_weights'],w['weights']):close(a,b,'weights');checks+=1
        old_x,old_y=part['old_train'];new_x,new_y=part['new_train'];M0=features(old_x);M1=features(new_x)
        oi,ow=subset_fit(M0,old_y,4);assert row['scores']['replay_gated']['old_ids']==oi;checks+=len(oi)
        for a,b in zip(row['scores']['replay_gated']['old_weights'],ow):close(a,b,'old coefficients');checks+=1
        edit=structural_edit(M1,new_y,oi);raw=row['scores']['replay_gated']
        for k in ('drop','add','trigger'):
            assert raw[k]==edit[k],(k,seed,idx,fam);checks+=1
        assert raw['candidate_new_ids']==edit['ids'];checks+=len(edit['ids'])
        for v,t in zip(raw['candidate_new_weights'],edit['weights']):close(v,t,'edited weight');checks+=1
        forced=structural_edit(M1,new_y,oi,forced=True)
        wrong=structural_edit(M1,new_y,oi,negative=True)
        ni,nw=subset_fit(M1,new_y,4)
        D=np.vstack([np.hstack([M0,np.zeros_like(M0)]),np.hstack([np.zeros_like(M1),M1])]);Y=np.r_[old_y,new_y]
        mi,mw=subset_fit(D,Y,7);fi,fw=subset_fit(D,Y,7)
        elastic=ElasticNet(alpha=.025,l1_ratio=.85,max_iter=5000,tol=1e-5,random_state=0).fit(D,Y)
        ridge=Ridge(alpha=40).fit(D,Y)
        forest=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=seed+idx).fit(np.r_[np.c_[old_x,np.zeros(96)],np.c_[new_x,np.ones(96)]],Y)
        new_design=np.c_[np.zeros_like(M1),M1]
        use_stage=bool(np.mean((M1[-24:,ni]@nw-new_y[-24:])**2)+.01<np.mean((new_design[-24:,mi]@mw-new_y[-24:])**2))
        assert row['scores']['hybrid_validation']['use_stage']==use_stage;checks+=1
        for env in ('old_held','new_held','cold_held'):
            x,y=part[env];stage=0 if env=='old_held' else 1;M=features(x)
            old=M[:,oi]@ow
            gated=M[:,edit['ids']]@edit['weights'] if edit['trigger'] else M[:,oi]@weighted_fit(M1,new_y,oi)
            oldval=np.c_[M,np.zeros_like(M)][:,mi]@mw if stage==0 else np.c_[np.zeros_like(M),M][:,mi]@mw
            fullval=np.c_[M,np.zeros_like(M)][:,fi]@fw if stage==0 else np.c_[np.zeros_like(M),M][:,fi]@fw
            newval=M[:,ni]@nw
            permval=M[:,wrong['ids']]@wrong['weights'] if wrong['trigger'] else M[:,oi]@weighted_fit(M1,new_y,oi)
            preds={
            'replay_gated':old if stage==0 else gated,
            'unconditional_replay':old if stage==0 else M[:,forced['ids']]@forced['weights'],
            'hybrid_validation':old if stage==0 else (newval if use_stage else oldval),
            'stagewise_omp4':old if stage==0 else newval,
            'omp_structural_memory':oldval,
            'omp_full7':fullval,
            'elasticnet':elastic.predict(np.c_[M,np.zeros_like(M)] if stage==0 else np.c_[np.zeros_like(M),M]),
            'ridge':ridge.predict(np.c_[M,np.zeros_like(M)] if stage==0 else np.c_[np.zeros_like(M),M]),
            'forest':forest.predict(np.c_[x,np.full(len(x),stage)]),
            'no_repair':old,
            'shuffled_gate':old if stage==0 else permval}
            for name,val in preds.items():
                v=float(np.mean((val-y)**2));close(v,row['scores'][name][env],f'{seed}/{idx}/{fam}:{name}:{env}');checks+=len(val);rowcounts[name]+=1
    # independent score and gate reaggregation (timings excluded)
    for arm in MODELS:
        for key in ('old_held','new_held','cold_held'):
            a=float(np.mean([c['scores'][arm][key] for c in src['cases']]));close(a,src['aggregate'][arm][key],f'agg-{arm}-{key}');checks+=1
    passg=src['decision']['gates'];assert len(passg)==9
    assert src['decision']['passes']==sum(passg.values()) and src['decision']['fails']==9-sum(passg.values());checks+=2
    assert src['mode'] in ('smoke','primary')
    receipt={'schema':'energy46.audit.v1','status':'PASS','checks':checks,'cases':len(src['cases']),'arms':list(MODELS),'third_party_backends_shared':['numpy','scikit-learn'],'independent_source_generator':True,'independent_all_arm_refit':True,'independent_all_held_predictions':True,'limitation':'Shared NumPy RNG and scikit-learn implementation; software is not independently qualified native Yggdrasil.'}
    Path(opts.out).write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
