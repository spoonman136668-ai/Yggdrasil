#!/usr/bin/env python3
"""ENERGY-41: learned structural reliability transfer to unseen causal graphs.

External synthetic development only. Training demonstrations contain fully observed
latent binary assignments. Evaluation receives ONLY noisy graph constraints, not
latent labels or withheld relational probes. Same data/solver for all arms.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from sklearn.linear_model import LogisticRegression

VERSION = 'energy41-v1'
SEEDS = (8407,8423,8431)
SMOKE_SEED = 99741
TRAIN_FAMILIES = ('erdos','modular')
TEST_FAMILIES = ('erdos','modular','lattice')
GROUP_NOISE = (0.06,0.16,0.44)
ARMS = ('structured_energy','bayes','logistic','uniform','shuffled_energy','oracle')
STARTS=8
SWEEPS=24
PROBES=40


def digest(*key):
    return hashlib.sha256('/'.join(map(str,(VERSION,*key))).encode('ascii')).digest()

def getseed(*key):
    return int.from_bytes(digest(*key)[:8], 'big')

def random(key):
    return np.random.default_rng(getseed(*key))

def norm(w):
    a=np.clip(np.asarray(w,dtype=float),0.05,8.)
    return np.round(3*a/a.sum(),10).tolist()

def edge_group(i,j,n):
    dist=min(j-i,n-(j-i))
    return 0 if dist==1 else (1 if dist<=4 else 2)

def generate(seed,family,n,world,mode):
    started=time.perf_counter()
    ring={tuple(sorted((i,(i+1)%n))) for i in range(n)}
    choices=[]
    for i in range(n):
        for j in range(i+1,n):
            if (i,j) in ring: continue
            if family=='erdos': priority=0
            elif family=='modular': priority=int(i//8!=j//8)
            elif family=='lattice': priority=int(min(j-i,n-(j-i))>4)
            else:raise ValueError(family)
            choices.append((priority,digest('rank',seed,mode,family,n,world,i,j),i,j))
    choices.sort()
    pairs=sorted(ring|{(i,j) for _,_,i,j in choices[:2*n]})
    truth=random(('truth',seed,mode,family,n,world)).integers(0,2,size=n,dtype=np.int8).tolist()
    truth[0]=0  # fixes gauge for audit; relational accuracy is gauge invariant
    edges=[]
    for i,j in pairs:
        g=edge_group(i,j,n)
        bad=int(getseed('noise',seed,mode,family,n,world,i,j)%1000000 < int(GROUP_NOISE[g]*1000000))
        obs=truth[i]^truth[j]^bad
        edges.append([i,j,int(obs),g])
    assert len(edges)==3*n
    return {'seed':seed,'mode':mode,'family':family,'n':n,'world':world,'edges':edges,'truth':truth,
            'generation_s':time.perf_counter()-started}

def train_cases(seed):
    return [generate(seed,f,20,w,'train') for f in TRAIN_FAMILIES for w in range(8)]

def test_cases(seed):
    return ([generate(seed,f,20,w,'old') for f in TRAIN_FAMILIES for w in range(2)]+
            [generate(seed,f,n,w,'novel') for f in TEST_FAMILIES for n in (36,52) for w in range(2)])

def violations(edge,truth):
    i,j,obs,g=edge
    return int((truth[i]^truth[j])!=obs)

def group_training_errors(cases,shuffle=False):
    bad=np.zeros(3,dtype=float);good=np.zeros(3,dtype=float)
    for c in cases:
        labels=[e[3] for e in c['edges']]
        if shuffle:
            random(('group-shuffle',c['seed'],c['family'],c['n'],c['world'])).shuffle(labels)
        for e,g in zip(c['edges'],labels):
            if violations(e,c['truth']):bad[g]+=1
            else:good[g]+=1
    return good,bad

def fit_bayes(cases):
    good,bad=group_training_errors(cases)
    return norm(np.log((good+1)/(bad+1)))

def fit_logistic(cases):
    good,bad=group_training_errors(cases)
    X=np.repeat(np.eye(3), (good+bad).astype(int),axis=0)
    yy=np.concatenate([np.r_[np.ones(int(g)),np.zeros(int(b))] for g,b in zip(good,bad)])
    # Arrange aligned X exactly in that per-class order.
    model=LogisticRegression(fit_intercept=False,C=1,max_iter=1000,tol=1e-9,solver='lbfgs')
    model.fit(X,yy)
    return norm(model.coef_[0])

def structured_examples(cases,shuffle=False):
    """d_g = violations after one vertex intervention - truth violations."""
    rows=[]
    for c in cases:
        n=c['n'];x=c['truth'];edges=c['edges']
        groups=[e[3] for e in edges]
        if shuffle:
            random(('group-shuffle',c['seed'],c['family'],c['n'],c['world'])).shuffle(groups)
        for v in range(n):
            d=np.zeros(3)
            for e,g in zip(edges,groups):
                if e[0]!=v and e[1]!=v:continue
                # toggling one endpoint always toggles satisfaction
                d[g]+=1 if violations(e,x) else -1
            rows.append(d)
    return np.array(rows)

def fit_structured(cases,shuffle=False):
    d=structured_examples(cases,shuffle)
    w=np.ones(3,dtype=float)
    # Fixed 96-epoch structured max-margin projected gradient. No primary tuning.
    for _ in range(96):
        margin=d@w
        active=margin<2.0
        grad=np.mean(d[active],axis=0) if active.any() else np.zeros(3)
        w=w+0.06*(grad-0.01*(w-1))
        w=np.clip(w,0.05,8.)
        w=np.asarray(norm(w))
    return w.tolist()

def fit_all(cases):
    out={};times={}
    for name in ARMS:
        t=time.perf_counter()
        if name=='structured_energy':v=fit_structured(cases)
        elif name=='shuffled_energy':v=fit_structured(cases,True)
        elif name=='bayes':v=fit_bayes(cases)
        elif name=='logistic':v=fit_logistic(cases)
        elif name=='uniform':v=norm([1,1,1])
        elif name=='oracle':v=norm(np.log((1-np.array(GROUP_NOISE))/np.array(GROUP_NOISE)))
        else:raise AssertionError(name)
        out[name]=v;times[name]=time.perf_counter()-t
    return out,times

def weighted_cost(edges,bits,w):
    return sum(float(w[g]) for i,j,b,g in edges if (int(bits[i])^int(bits[j]))!=b)

def solve(edges,n,weights,seed,family,world,mode):
    t0=time.perf_counter()
    rng=random(('inference',seed,mode,family,n,world))
    states=rng.choice(np.array([-1,1],dtype=np.int8),size=(STARTS,n)).astype(np.int32)
    J=np.zeros((n,n),dtype=float)
    for i,j,p,g in edges:
        J[i,j]=J[j,i]=float(weights[g])*(1-2*p)
    def costs(ss):
        bits=ss<0
        out=np.zeros(len(ss))
        for i,j,p,g in edges:out+=float(weights[g])*((bits[:,i]^bits[:,j])!=bool(p))
        return out
    current=costs(states);best=float(current.min());bits=(states[int(current.argmin())]<0).astype(np.int8).tolist()
    for sweep in range(SWEEPS):
        for j in rng.permutation(n):
            delta=states[:,j]*(states@J[:,j])
            mask=delta<-1e-10
            states[mask,j]*=-1
            current[mask]+=delta[mask]
            k=int(current.argmin())
            if float(current[k])<best-1e-8:
                best=float(current[k]);bits=(states[k]<0).astype(np.int8).tolist()
        if (sweep+1)%8==0 and sweep+1<SWEEPS:
            for row in range(STARTS):
                chosen=rng.choice(n,size=max(1,n//10),replace=False)
                states[row,chosen]*=-1
            current=costs(states)
    assert abs(weighted_cost(edges,bits,weights)-best)<1e-6
    return {'bits_hex':bytes(bits).hex(),'weighted_energy':round(best,10),
            'duration_s':time.perf_counter()-t0,'attempted_flips':STARTS*SWEEPS*n}

def holdout_pairs(c):
    n=c['n'];edge_set={(i,j) for i,j,_,_ in c['edges']}
    pool=sorted(((digest('probe',c['seed'],c['mode'],c['family'],n,c['world'],i,j),i,j)
                 for i in range(n) for j in range(i+1,n) if (i,j) not in edge_set))
    return [[i,j] for _,i,j in pool[:PROBES]]

def score(bits_hex,pairs,truth):
    bits=list(bytes.fromhex(bits_hex))
    assert len(bits)==len(truth)
    return sum((bits[i]^bits[j])==(truth[i]^truth[j]) for i,j in pairs)

def cohort(seed):
    t0=time.perf_counter()
    tr=train_cases(seed);ev=test_cases(seed)
    weights,fit_seconds=fit_all(tr)
    scored=[]
    for c in ev:
        pairs=holdout_pairs(c)
        results={}
        for arm in ARMS:
            pred=solve(c['edges'],c['n'],weights[arm],c['seed'],c['family'],c['world'],c['mode'])
            pred['correct']=int(score(pred['bits_hex'],pairs,c['truth']))
            results[arm]=pred
        scored.append({'seed':c['seed'],'mode':c['mode'],'family':c['family'],
                       'n':c['n'],'world':c['world'],'edges':c['edges'],
                       'truth_hex':bytes(c['truth']).hex(),'probe_pairs':pairs,
                       'generation_s':c['generation_s'],'arms':results})
    return {'seed':seed,'train':tr,'train_graph_generation_s':sum(z['generation_s'] for z in tr),
            'weights':weights,'fit_seconds':fit_seconds,'test':scored,
            'cohort_wall_s':time.perf_counter()-t0}

def aggregate(cohorts):
    metrics={a:{'old_correct':0,'novel_correct':0,'lattice_correct':0,'n52_correct':0,'train_fit_s':0,'test_solve_s':0} for a in ARMS}
    timings={a:0 for a in ARMS}
    per_seed=[]
    for c in cohorts:
        byseed={a:0 for a in ARMS}
        for a in ARMS:metrics[a]['train_fit_s']+=c['fit_seconds'][a]
        for w in c['test']:
            for a in ARMS:
                z=w['arms'][a]; k='old_correct' if w['mode']=='old' else 'novel_correct'
                metrics[a][k]+=z['correct']
                if w['mode']=='novel':
                    byseed[a]+=z['correct']
                    if w['family']=='lattice':metrics[a]['lattice_correct']+=z['correct']
                    if w['n']==52:metrics[a]['n52_correct']+=z['correct']
                metrics[a]['test_solve_s']+=z['duration_s']
                timings[a]+=z['duration_s']+w['generation_s']
        for a in ARMS:
            timings[a]+=c['train_graph_generation_s']+c['fit_seconds'][a]
        per_seed.append({'seed':c['seed'],'novel_correct':byseed})
    novel=36*PROBES;old=12*PROBES;lattice=12*PROBES;large=18*PROBES
    cand=metrics['structured_energy'];controls=('bayes','logistic','uniform','shuffled_energy')
    best_novel=max(metrics[a]['novel_correct'] for a in controls)
    best_old=max(metrics[a]['old_correct'] for a in controls)
    seed_margins=[row['novel_correct']['structured_energy']-max(row['novel_correct'][a] for a in controls) for row in per_seed]
    gates={
      'novel_vs_best_information_matched_2pp':(cand['novel_correct']-best_novel)/novel>=.02,
      'novel_vs_uniform_3pp':(cand['novel_correct']-metrics['uniform']['novel_correct'])/novel>=.03,
      'old_retention_at_most_1pp_loss':(best_old-cand['old_correct'])/old<=.01,
      'group_shuffled_negative_5pp':(cand['novel_correct']-metrics['shuffled_energy']['novel_correct'])/novel>=.05,
      'unseen_family_vs_bayes_1pp':(cand['lattice_correct']-metrics['bayes']['lattice_correct'])/lattice>=.01,
      'n52_vs_bayes_1pp':(cand['n52_correct']-metrics['bayes']['n52_correct'])/large>=.01,
      'seed_stability_two_of_three':sum(x>0 for x in seed_margins)>=2,
      'end_to_end_value_per_second_1point2x_bayes':
        cand['novel_correct']/timings['structured_energy']>=1.2*metrics['bayes']['novel_correct']/timings['bayes'],
    }
    return {'scores':metrics,'denominators':{'novel':novel,'old':old,'lattice':lattice,'n52':large},
            'seed_novel_margins_vs_strongest':seed_margins,'per_seed':per_seed,
            'policy_generation_fit_inference_s':timings,'gates':gates,
            'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO'}

def run(smoke):
    start=time.perf_counter()
    seeds=[SMOKE_SEED] if smoke else list(SEEDS)
    cohorts=[cohort(seed) for seed in seeds]
    summary=aggregate(cohorts) if not smoke else {'smoke':True,'test_worlds':len(cohorts[0]['test'])}
    return {'schema':'yggdrasil.energy41.score.v1','mode':'smoke' if smoke else 'primary',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seeds':seeds,'train_graphs_per_seed':16,'test_graphs_per_seed':16,
            'cohorts':cohorts,'summary':summary,'wall_s':time.perf_counter()-start,
            'scientific_pass':False,'native_model_changed':False,'deployment':'NONE'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--smoke',action='store_true');p.add_argument('--out',required=True)
    args=p.parse_args();r=run(args.smoke)
    Path(args.out).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'mode':r['mode'],'summary':r['summary'],'elapsed_s':r['wall_s']},indent=2,sort_keys=True))
if __name__=='__main__':main()
