#!/usr/bin/env python3
"""Independent re-generation and numerical refit audit for ENERGY-58.
Never imports experiment.py. Uses same public NumPy/sklearn numerical backends.
"""
import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,Ridge,ElasticNet
from sklearn.kernel_ridge import KernelRidge
FAMS=('persistent','edge_reversal','novel_triple')
ARMS=('cumulative_invariants','separate_relations','rehearsal_ridge','shared_all','full_elasticnet','rbf_kernel','no_update','shuffled_new')
N=84; H=64
PAIRS=list(itertools.combinations(range(12),2))
ALL4=[tuple(z) for degree in range(1,5) for z in itertools.combinations(range(12),degree)]
EDGES=list(itertools.combinations(range(4),2))

def reconstruct(seed,idx,family):
    gen=np.random.default_rng(np.random.SeedSequence([5801,int(seed),int(idx),FAMS.index(family)]))
    roles=list(map(int,gen.permutation(10)))
    a=(gen.choice([-1.,1.],size=8)*gen.uniform([.9,.9,.9,.9,.55,.55,.45,.65],[1.35,1.35,1.35,1.35,.85,.85,.8,.9])).tolist()
    labels=['old','middle','new','old','middle','new','cold'];amount=[N,N,N,H,H,H,H]
    keys=list(map(int,gen.permutation(1024)[:sum(amount)]));bits=((np.array(keys)[:,None]>>np.arange(10))&1).astype(np.int8)
    obs=np.concatenate((bits,np.zeros((len(bits),2),dtype=np.int8)),axis=1)
    spans={};start=0
    for j,(stage,count) in enumerate(zip(labels,amount)):
        hi=start+count;spans[('train_' if j<3 else 'held_')+stage]=[start,hi]
        for i in range(start,hi):
            if stage=='old':c=(int(bits[i,roles[0]]),int(bits[i,roles[4]]))
            elif stage=='middle':c=(1-int(bits[i,roles[0]]),int(bits[i,roles[4]]))
            elif stage=='new':c=(int(bits[i,roles[0]]),1-int(bits[i,roles[4]]))
            else:c=tuple(map(int,gen.integers(0,2,size=2)))
            for k in range(2):obs[i,10+k]=int(c[k] if stage=='cold' or gen.random()>.08 else 1-c[k])
        start=hi
    spins=2*obs-1
    primitive=np.asarray([spins[:,roles[j*2]]*spins[:,roles[j*2+1]] for j in range(4)])
    b0,b1,b2,b3=primitive
    base=np.asarray(a[:4])@primitive
    rel=(b0*b1,b2*b3,b0*b2,b1*b3)
    yy=np.zeros(len(keys));start=0
    for stage,count in zip(labels,amount):
        hi=start+count
        coefficient={'old':[a[4],a[5],a[6],0.], 'middle':[a[4],a[5],0.,a[7]],
                     'new':[a[4],a[5],0.,a[7]],'cold':[a[4],a[5],0.,a[7]]}[stage].copy()
        if family=='edge_reversal' and stage in ('new','cold'):coefficient[0]*=-1
        effects=sum(coefficient[j]*rel[j][start:hi] for j in range(4))
        if family=='novel_triple' and stage in ('new','cold'):effects=effects+.7*(b0*b1*b2)[start:hi]
        yy[start:hi]=base[start:hi]+effects+gen.normal(0,.2,count)
        start=hi
    return {'seed':int(seed),'id':int(idx),'family':family,'roles':roles,'amplitudes':a,'keys':keys,'x':obs.tolist(),'y':yy.tolist(),'spans':spans}

def phi(x,combs):
    s=2*np.asarray(x,dtype=np.int8)-1
    return np.array([np.prod(s[:,list(c)],axis=1) for c in combs],float).T

def join(stage_features,targets,shared):
    sizes=list(map(len,stage_features));total=sum(sizes)
    columns=[];names=[]
    for j in range(10):
        if j>=4 and j-4 in shared:
            columns.append(np.concatenate([block[:,j] for block in stage_features]));names.append((j,-1))
        else:
            for t,block in enumerate(stage_features):
                column=np.zeros(total);lo=sum(sizes[:t]);column[lo:lo+sizes[t]]=block[:,j]
                columns.append(column);names.append((j,t))
    for t,block in enumerate(stage_features):
        intercept=np.zeros(total);lo=sum(sizes[:t]);intercept[lo:lo+sizes[t]]=1
        columns.append(intercept)
    coef=Ridge(alpha=.4,fit_intercept=False,solver='svd').fit(np.array(columns).T,np.concatenate(targets)).coef_
    last=np.zeros(10)
    for val,(j,t) in zip(coef[:-len(sizes)],names):
        if t==-1 or t==len(sizes)-1:last[j]=val
    return last,coef[-1]

def replay(w):
    x=np.asarray(w['x'],np.int8);y=np.asarray(w['y'],float)
    trains=[slice(*w['spans']['train_'+a]) for a in ('old','middle','new')]
    held=[slice(*w['spans']['held_'+a]) for a in ('old','middle','new','cold')]
    p=phi(x,PAIRS)
    old_omp=OrthogonalMatchingPursuit(n_nonzero_coefs=4).fit(p[trains[0]],y[trains[0]])
    chosen=np.flatnonzero(np.abs(old_omp.coef_)>1e-9).tolist()
    if len(chosen)!=4:raise ValueError('support count')
    b=p[:,chosen]
    r=np.column_stack([b]+[b[:,a]*b[:,b_] for a,b_ in EDGES])
    fit=[Ridge(alpha=.4,fit_intercept=True,solver='svd').fit(r[sel],y[sel]) for sel in trains]
    coeff=np.asarray([a.coef_[4:] for a in fit]);stable=[]
    for j in range(6):
        values=coeff[:,j]
        if np.min(np.abs(values))>=.18 and np.all(np.sign(values)==np.sign(values[0])) and max(values)-min(values)<=.35: stable.append(j)
    cs,cb=join([r[s] for s in trains],[y[s] for s in trains],stable)
    us,ub=join([r[s] for s in trains],[y[s] for s in trains],list(range(6)))
    rs,rb=join([r[s] for s in trains],[y[s] for s in trains],[])
    oldpred=fit[0].predict(r[held[0]]);midpred=fit[1].predict(r[held[1]])
    pre={}
    pre['cumulative_invariants']=[oldpred,midpred,r[held[2]]@cs+cb,r[held[3]]@cs+cb]
    pre['separate_relations']=[oldpred,midpred,fit[2].predict(r[held[2]]),fit[2].predict(r[held[3]])]
    pre['rehearsal_ridge']=[oldpred,midpred,r[held[2]]@rs+rb,r[held[3]]@rs+rb]
    pre['shared_all']=[oldpred,midpred,r[held[2]]@us+ub,r[held[3]]@us+ub]
    pre['no_update']=[oldpred,midpred,fit[1].predict(r[held[2]]),fit[1].predict(r[held[3]])]
    rng=np.random.default_rng(np.random.SeedSequence([5807,w['seed'],w['id'],FAMS.index(w['family'])]))
    negative=Ridge(alpha=.4,solver='svd').fit(r[trains[2]],rng.permutation(y[trains[2]]))
    pre['shuffled_new']=[oldpred,midpred,negative.predict(r[held[2]]),negative.predict(r[held[3]])]
    wide=phi(x,ALL4)
    for name,fac,z in [
        ('full_elasticnet',lambda:ElasticNet(alpha=.04,l1_ratio=.82,max_iter=1400,tol=.0005),wide),
        ('rbf_kernel',lambda:KernelRidge(alpha=.15,kernel='rbf',gamma=.3),x.astype(float))]:
        m=[fac().fit(z[s],y[s]) for s in trains]
        pre[name]=[mm.predict(z[hh]) for mm,hh in zip([m[0],m[1],m[2],m[2]],held)]
    checkpoint={'old':{'coef':fit[0].coef_.tolist(),'intercept':float(fit[0].intercept_)},
                'middle':{'coef':fit[1].coef_.tolist(),'intercept':float(fit[1].intercept_)},
                'new':{'coef':fit[2].coef_.tolist(),'intercept':float(fit[2].intercept_)},
                'cumulative':{'coef':cs.tolist(),'intercept':float(cb)},
                'selected_pairs':[list(PAIRS[i]) for i in chosen], 'invariant_edges':stable,'version':1}
    enc=json.dumps(checkpoint,sort_keys=True,separators=(',',':')).encode()
    return pre,checkpoint,hashlib.sha256(enc).hexdigest()

def audit(doc):
    failures=[];count=0;eps=5e-9
    for case in doc['cases']:
        w=case['world'];expected=reconstruct(w['seed'],w['id'],w['family'])
        for key,value in expected.items():
            if key in ('y','amplitudes'):
                if not np.allclose(value,w[key],atol=1e-12,rtol=0):failures.append(f'generator mismatch {key}')
                count+=len(value)
            else:
                if value!=w[key]:failures.append(f'generator mismatch {key}')
                count+=1
        if len(set(w['keys']))!=len(w['keys']):failures.append('duplicate action assignment')
        count+=1
        predicted,checkpoint,digest=replay(expected)
        # Compare independently refitted float coefficients numerically, not by float text bytes:
        stored=case['info']['checkpoint']
        if (checkpoint['selected_pairs']!=stored['selected_pairs'] or checkpoint['invariant_edges']!=stored['invariant_edges']
            or checkpoint['version']!=stored['version']):failures.append('checkpoint structure unequal')
        for stage in ('old','middle','new','cumulative'):
            if not np.allclose(checkpoint[stage]['coef'],stored[stage]['coef'],atol=eps,rtol=0) or abs(checkpoint[stage]['intercept']-stored[stage]['intercept'])>eps:
                failures.append('checkpoint numeric disagreement '+stage)
        encoded=json.dumps(stored,sort_keys=True,separators=(',',':')).encode()
        if hashlib.sha256(encoded).hexdigest()!=case['info']['checkpoint_sha256']:failures.append('checkpoint hash unequal')
        if case['info']['checkpoint_bytes']!=len(encoded):failures.append('byte count')
        count+=3
        if not case['info']['restart_exact']:failures.append('restart witness FALSE')
        count+=1
        for arm in ARMS:
            for idx,dom in enumerate(('old','middle','new','cold')):
                obtained=np.asarray(case['predictions'][arm][idx]);want=np.asarray(predicted[arm][idx]);
                if obtained.shape!=want.shape or not np.allclose(obtained,want,atol=eps,rtol=0):failures.append(f'{w["seed"]}/{w["id"]}/{arm}/{dom} pred')
                count+=len(want)
                truth=np.asarray(expected['y'][slice(*expected['spans']['held_'+dom])]);mse=np.mean((want-truth)**2)
                if abs(float(mse)-case['metrics'][arm][dom])>eps:failures.append(f'{arm} {dom} MSE')
                count+=1
    for arm in ARMS:
        for dom in ('old','middle','new','cold'):
            value=float(np.mean([z['metrics'][arm][dom] for z in doc['cases']]))
            if abs(value-doc['aggregate'][arm][dom])>eps:failures.append(f'{arm} aggregate')
            count+=1
        for seed in doc['seeds']:
            value=float(np.mean([z['metrics'][arm]['cold'] for z in doc['cases'] if z['world']['seed']==seed]))
            if abs(value-doc['per_seed'][str(seed)][arm])>eps:failures.append(f'{arm} seed')
            count+=1
        for family in doc['families']:
            value=float(np.mean([z['metrics'][arm]['cold'] for z in doc['cases'] if z['world']['family']==family]))
            if abs(value-doc['per_family'][family][arm])>eps:failures.append(f'{arm} family')
            count+=1
    return {'id':'ENERGY-58','audit':'independent_generator_and_full_refit','status':'PASS' if not failures else 'FAIL','checks':count,'errors':failures[:20],
            'error_count':len(failures),'cases':len(doc['cases']),'shared_numerical_backend':'numpy and scikit-learn',
            'imports_scorer':False}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('score');ap.add_argument('--out',required=True);a=ap.parse_args()
    doc=json.loads(Path(a.score).read_text());res=audit(doc);Path(a.out).write_text(json.dumps(res,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:res[k] for k in ('status','checks','error_count','cases')}));raise SystemExit(0 if res['status']=='PASS' else 2)
