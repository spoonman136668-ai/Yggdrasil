#!/usr/bin/env python3
"""Fresh-process, standard-library-only readout of serialized ENERGY-58 checkpoint.
Input has model plus observation actions only; never reads eval labels.
"""
import argparse,json
from pathlib import Path

def evaluate(checkpoint,actions):
    terms=checkpoint['selected_pairs']
    out={}
    for stage in ('old','middle','new','cold'):
        weights=checkpoint['cumulative' if stage in ('new','cold') else stage]
        result=[]
        for x in actions[stage]:
            b=[(1 if sum(1-x[j] for j in indices)%2==0 else -1) for indices in terms]
            r=b+[b[i]*b[j] for i in range(4) for j in range(i+1,4)]
            result.append(float(weights['intercept']+sum(w*t for w,t in zip(weights['coef'],r))))
        out[stage]=result
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');a=ap.parse_args()
    inp=json.loads(Path(a.input).read_text());result=evaluate(inp['checkpoint'],inp['actions']);Path(a.output).write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n')
