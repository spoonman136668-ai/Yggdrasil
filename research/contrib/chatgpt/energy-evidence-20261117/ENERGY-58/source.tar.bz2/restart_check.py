#!/usr/bin/env python3
"""Across-process restored historical causal readout check. Does not import scorer."""
import argparse,hashlib,json,subprocess,sys,tempfile,time
from pathlib import Path
import numpy as np

def verify(doc):
    failures=[];records=[];elapsed=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='energy58-cold-start-') as tmp:
        work=Path(tmp)
        for i,case in enumerate(doc['cases']):
            raw=case['world'];xx=raw['x'];sp=raw['spans'];actions={k:xx[slice(*sp['held_'+k])] for k in ('old','middle','new','cold')}
            inp={'checkpoint':case['info']['checkpoint'],'actions':actions}
            (work/'in.json').write_text(json.dumps(inp,sort_keys=True,separators=(',',':'))+'\n')
            run=subprocess.run([sys.executable,'-I',str(Path(__file__).with_name('restore.py')),str(work/'in.json'),str(work/'out.json')],capture_output=True,text=True,timeout=12)
            if run.returncode!=0:failures.append(f'{i} process exit {run.returncode}');continue
            loaded=json.loads((work/'out.json').read_text());mx=0.;checks=0
            for j,k in enumerate(('old','middle','new','cold')):
                wanted=np.asarray(case['predictions']['cumulative_invariants'][j]);got=np.asarray(loaded[k]);
                if len(got)!=len(wanted):failures.append(f'{i} length {k}');continue
                err=float(np.max(np.abs(got-wanted)));mx=max(mx,err);checks+=len(got)
                if err>1e-11:failures.append(f'{i} {k} error {err}')
            records.append({'case':i,'seed':raw['seed'],'id':raw['id'],'family':raw['family'],'max_error':mx,'checked':checks,'checkpoint_sha256':case['info']['checkpoint_sha256'],
                            'readout_sha256':hashlib.sha256(json.dumps(loaded,sort_keys=True,separators=(',',':')).encode()).hexdigest()})
    return {'id':'ENERGY-58','mode':'one_fresh_python_process_per_world_standard_library_readout','status':'PASS' if not failures and len(records)==len(doc['cases']) else 'FAIL',
            'failures':failures[:20],'processes':len(records),'readouts':sum(r['checked'] for r in records),'max_error':max((r['max_error'] for r in records),default=None),'records':records,'elapsed_seconds':time.perf_counter()-elapsed}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('scored');ap.add_argument('--out',required=True);a=ap.parse_args()
    r=verify(json.loads(Path(a.scored).read_text()));Path(a.out).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps({k:r[k] for k in ('status','processes','readouts','max_error')}));raise SystemExit(0 if r['status']=='PASS' else 2)
