#!/usr/bin/env python3
"""ENERGY-58 external synthetic three-episode cumulative relation retention study.
No Yggdrasil native model or accepted state is accessed or mutated.
"""
import argparse, hashlib, itertools, json, time
from functools import lru_cache
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge, OrthogonalMatchingPursuit, ElasticNet
from sklearn.kernel_ridge import KernelRidge

FAMILIES=('persistent','edge_reversal','novel_triple')
ARMS=('cumulative_invariants','separate_relations','rehearsal_ridge','shared_all','full_elasticnet','rbf_kernel','no_update','shuffled_new')
N=84; H=64
@lru_cache(None)
def terms(order): return tuple(c for k in range(1,order+1) for c in itertools.combinations(range(12),k))
def spin(x): return 2*np.asarray(x,dtype=np.int8)-1
def feat(x,combs):
    s=spin(x); return np.column_stack([np.prod(s[:,c],axis=1) for c in combs]).astype(float)
def world(seed,ident,family):
    rng=np.random.default_rng(np.random.SeedSequence([5801,seed,ident,FAMILIES.index(family)]))
    roles=rng.permutation(10).tolist()
    amplitudes=(rng.choice([-1.,1.],8)*rng.uniform([.9,.9,.9,.9,.55,.55,.45,.65],[1.35,1.35,1.35,1.35,.85,.85,.8,.9])).tolist()
    stages=('old','middle','new','old','middle','new','cold'); lengths=(N,N,N,H,H,H,H)
    n=sum(lengths); keys=rng.permutation(1024)[:n].astype(int)
    x=((keys[:,None]>>np.arange(10))&1).astype(np.int8)
    observed=np.column_stack((x,np.zeros((n,2),dtype=np.int8)))
    spans={};start=0
    for tag,count in zip(stages,lengths):
        stop=start+count;spans[('train_' if start<3*N else 'held_')+tag]=[start,stop]
        for i in range(start,stop):
            if tag=='old': cue=[int(x[i,roles[0]]),int(x[i,roles[4]])]
            elif tag=='middle':cue=[1-int(x[i,roles[0]]),int(x[i,roles[4]])]
            elif tag=='new':cue=[int(x[i,roles[0]]),1-int(x[i,roles[4]])]
            else:cue=list(map(int,rng.integers(0,2,2)))
            for j,val in enumerate(cue):observed[i,10+j]=val if tag=='cold' or rng.random()>.08 else 1-val
        start=stop
    s=spin(observed)
    primitive=np.column_stack([s[:,roles[2*j]]*s[:,roles[2*j+1]] for j in range(4)])
    a,b,c,d=[primitive[:,j] for j in range(4)]
    base=primitive@np.asarray(amplitudes[:4]);q1=a*b;q2=c*d;q3=a*c;q4=b*d;triple=a*b*c
    y=np.zeros(n);start=0
    for tag,count in zip(stages,lengths):
        stop=start+count
        coeff={ 'old': [amplitudes[4],amplitudes[5],amplitudes[6],0.],
                'middle':[amplitudes[4],amplitudes[5],0.,amplitudes[7]],
                'new':[amplitudes[4],amplitudes[5],0.,amplitudes[7]],
                'cold':[amplitudes[4],amplitudes[5],0.,amplitudes[7]]}[tag].copy()
        if family=='edge_reversal' and tag in ('new','cold'): coeff[0]*=-1
        relation=sum(v*z[start:stop] for v,z in zip(coeff,(q1,q2,q3,q4)))
        if family=='novel_triple' and tag in ('new','cold'):relation=relation+.7*triple[start:stop]
        y[start:stop]=base[start:stop]+relation+rng.normal(0,.20,count);start=stop
    return {'seed':seed,'id':ident,'family':family,'roles':roles,'amplitudes':amplitudes,'keys':keys.tolist(),'x':observed.tolist(),'y':y.tolist(),'spans':spans}

def ridge(z,y,alpha=.4):return Ridge(alpha=alpha,fit_intercept=True,solver='svd').fit(z,y)
def model_repr(m):return {'coef':m.coef_.tolist(),'intercept':float(m.intercept_)}
def predict_repr(m,z):return z@np.asarray(m['coef'])+m['intercept']
def select(x,y):
    basis=terms(2)[12:];m=OrthogonalMatchingPursuit(n_nonzero_coefs=4).fit(feat(x,basis),y)
    ids=np.flatnonzero(np.abs(m.coef_)>1e-9).tolist()
    if len(ids)!=4:raise RuntimeError('failed to recover 4 old primitive slots')
    return [basis[i] for i in ids]
def relation(x,chosen):
    b=feat(x,chosen);return np.column_stack((b,*[b[:,i]*b[:,j] for i,j in itertools.combinations(range(4),2)]))

def joint_invariants(stages,truth,shared):
    # Stage-independent coefficients for selected invariant pair relations; stage-specific others.
    sizes=[len(a) for a in stages]; n=sum(sizes);cols=[];labels=[]
    for i in range(10):
        if i>=4 and i-4 in shared:
            cols.append(np.concatenate([z[:,i] for z in stages]));labels.append((i,'shared'))
        else:
            for st,z in enumerate(stages):
                col=np.zeros(n);start=sum(sizes[:st]);col[start:start+len(z)]=z[:,i]
                cols.append(col);labels.append((i,st))
    for st,z in enumerate(stages):
        col=np.zeros(n);start=sum(sizes[:st]);col[start:start+len(z)]=1.
        cols.append(col)
    beta=Ridge(alpha=.4,fit_intercept=False,solver='svd').fit(np.column_stack(cols),np.concatenate(truth)).coef_
    new=np.zeros(10)
    for v,(j,st) in zip(beta[:-len(stages)],labels):
        if st=='shared' or st==len(stages)-1:new[j]=v
    return {'coef':new.tolist(),'intercept':float(beta[-1])}

def refit(w):
    x=np.asarray(w['x'],np.int8);y=np.asarray(w['y'],float);sp=w['spans']
    tr=[slice(*sp['train_'+z]) for z in ('old','middle','new')]
    te=[slice(*sp['held_'+z]) for z in ('old','middle','new','cold')]
    chosen=select(x[tr[0]],y[tr[0]]);r=relation(x,chosen)
    mdl=[ridge(r[s],y[s]) for s in tr]
    # Three sequential updates; old and middle stored readouts fixed at time of learning.
    old=model_repr(mdl[0]);mid=model_repr(mdl[1]);new=model_repr(mdl[2]);
    coefficients=np.asarray([m.coef_[4:] for m in mdl]);
    invariant=[k for k in range(6) if min(abs(v) for v in coefficients[:,k])>=.18 and
               all(np.sign(v)==np.sign(coefficients[0,k]) for v in coefficients[:,k]) and
               max(coefficients[:,k])-min(coefficients[:,k])<=.35]
    cumulative=joint_invariants([r[s] for s in tr],[y[s] for s in tr],invariant)
    # An explicitly conventional rehearsal control with same relational features and all stages,\
    # selecting a new-context head via stage-specific regression, without invariance heuristic.
    rehearsal=joint_invariants([r[s] for s in tr],[y[s] for s in tr],[])
    unconditional=joint_invariants([r[s] for s in tr],[y[s] for s in tr],list(range(6)))
    shuffle_rng=np.random.default_rng(np.random.SeedSequence([5807,w['seed'],w['id'],FAMILIES.index(w['family'])]))
    shuffled=model_repr(ridge(r[tr[2]],shuffle_rng.permutation(y[tr[2]])))
    candidates={
      'cumulative_invariants':(old,mid,cumulative),
      'separate_relations':(old,mid,new),
      'rehearsal_ridge':(old,mid,rehearsal),
      'shared_all':(old,mid,unconditional),
      'no_update':(old,mid,mid),
      'shuffled_new':(old,mid,shuffled),
    }
    timing={};pred={}
    for name,(p0,p1,p2) in candidates.items():
        pred[name]=[predict_repr(p,z).tolist() for p,z in zip((p0,p1,p2,p2),(r[s] for s in te))]
    # Full-feature strong controls. All get exactly identical 252 labeled observations.
    f4=feat(x,terms(4));trains=[(f4[s],y[s]) for s in tr]
    for name,fac,features in (
        ('full_elasticnet',lambda:ElasticNet(alpha=.04,l1_ratio=.82,max_iter=1400,tol=.0005),f4),
        ('rbf_kernel',lambda:KernelRidge(alpha=.15,kernel='rbf',gamma=.3),x.astype(float))):
        start=time.perf_counter();mm=[fac().fit(features[s],y[s]) for s in tr]
        pred[name]=[m.predict(features[s]).tolist() for m,s in zip((mm[0],mm[1],mm[2],mm[2]),te)]
        timing[name]=time.perf_counter()-start
    # Serialize the entire checkpoint from source models and reconstruct every held prediction.
    # Only training-derived representations, no generator truth or evaluation values included.
    checkpoint={'old':old,'middle':mid,'new':new,'cumulative':cumulative,'selected_pairs':[list(c) for c in chosen],
                'invariant_edges':invariant,'version':1}
    encoded=json.dumps(checkpoint,sort_keys=True,separators=(',',':'))
    restored=json.loads(encoded)
    restored_r=relation(x,tuple(tuple(z) for z in restored['selected_pairs']))
    restored_pred=[predict_repr(restored['old'],restored_r[te[0]]).tolist(),
                   predict_repr(restored['middle'],restored_r[te[1]]).tolist(),
                   predict_repr(restored['cumulative'],restored_r[te[2]]).tolist(),
                   predict_repr(restored['cumulative'],restored_r[te[3]]).tolist()]
    if any(not np.array_equal(np.asarray(a),np.asarray(b)) for a,b in zip(restored_pred,pred['cumulative_invariants'])):raise RuntimeError('cold restart output drift')
    return pred,{'checkpoint':checkpoint,'checkpoint_sha256':hashlib.sha256(encoded.encode()).hexdigest(),
                 'restart_exact':True,'checkpoint_bytes':len(encoded),'timing_controls':timing}

def evaluate(seeds,ids=(0,1,2,3),families=FAMILIES):
    cases=[];t0=time.perf_counter()
    for seed in seeds:
      for fam in families:
       for idx in ids:
        w=world(seed,idx,fam);p,info=refit(w);actual=np.asarray(w['y'],float);metrics={}
        for name in ARMS:
            metrics[name]={dom:float(np.mean((np.asarray(p[name][i])-actual[slice(*w['spans']['held_'+dom])])**2)) for i,dom in enumerate(('old','middle','new','cold'))}
        cases.append({'world':w,'predictions':p,'info':info,'metrics':metrics})
    mean=lambda arm,dom,subset:float(np.mean([z['metrics'][arm][dom] for z in subset]))
    agg={name:{dom:mean(name,dom,cases) for dom in ('old','middle','new','cold')} for name in ARMS}
    per_seed={str(seed):{name:mean(name,'cold',[z for z in cases if z['world']['seed']==seed]) for name in ARMS} for seed in seeds}
    per_family={fam:{name:mean(name,'cold',[z for z in cases if z['world']['family']==fam]) for name in ARMS} for fam in families}
    checkpoint_equal=all(z['info']['restart_exact'] for z in cases)
    return {'id':'ENERGY-58','dataset':'E58:three-episode-synthetic-v1','seeds':list(seeds),'ids':list(ids),'families':list(families),'cases':cases,'aggregate':agg,'per_seed':per_seed,'per_family':per_family,'restart_exact':checkpoint_equal,'elapsed_total_seconds':time.perf_counter()-t0}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',nargs='+',type=int,required=True);ap.add_argument('--ids',nargs='+',type=int,default=[0,1,2,3]);ap.add_argument('--out',required=True);a=ap.parse_args()
    result=evaluate(a.seeds,a.ids);Path(a.out).write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps({'cases':len(result['cases']),'cold_mse':{k:round(v['cold'],6) for k,v in result['aggregate'].items()},'seconds':result['elapsed_total_seconds']}))
