#!/usr/bin/env python3
"""ENERGY53 external audit. Independent policy selector and refits; source generator shared.
No native Yggdrasil qualification implied. Reuses NumPy and sklearn controls.
"""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
import experiment as e

def independent_max(scores,ids):
    return int(ids[np.flatnonzero(scores>=float(np.max(scores))-1e-9)[0]])

def independent_select(policy,x,base_fit,old_x,old_y,new_y,seed,wid):
    F=e.bank_features(x)
    rng=e.rng(seed,wid,'anchors')
    indices=list(map(int,rng.choice(e.NPOOL,e.NANCHOR,replace=False)))
    values=[float(new_y[i]) for i in indices]
    random_order=e.rng(seed,wid,'random-policy').permutation(e.NPOOL).tolist()
    old_pred=base_fit.predict(e.low(x))
    for step in range(e.BUDGET-e.NANCHOR):
        other=np.array([j for j in range(e.NPOOL) if j not in indices],dtype=int)
        if policy=='random':next_idx=next(j for j in random_order if j not in indices)
        elif policy=='hamming':
            d=np.abs(x[other,None,:]-x[None,indices,:]).sum(axis=-1)
            next_idx=independent_max(d.min(axis=1)+.02*d.mean(axis=1),other)
        elif policy=='d_optimal':
            Z=F[indices];reg=Z.T@Z+.45*np.eye(F.shape[1]);sol=np.linalg.solve(reg,F[other].T)
            leverage=np.sum(F[other].T*sol,axis=0)
            next_idx=independent_max(leverage,other)
        else:
            resid=np.array(values)-old_pred[indices]
            V=F[indices]
            coef=(V*resid[:,None]).sum(axis=0)/((V*V).sum(axis=0)+.7)
            loss=((V*coef[None,:]-resid[:,None])**2).sum(axis=0)
            if policy=='tournament':
                probs=np.exp(-.5*(loss-loss.min())/.45)
                probs/=probs.sum()+1e-12
                pred=F[other]*coef[None,:]
                mu=pred@probs
                criterion=(pred**2)@probs-mu**2+.002*F[other].var(axis=1)
            else:
                best=int(loss.argmin())
                criterion=-np.abs(F[other,best]*coef[best])+.01*F[other].var(axis=1)
            next_idx=independent_max(criterion,other)
        indices.append(next_idx);values.append(float(new_y[next_idx]))
    return indices,values

def independent_refit(kind,selected_x,selected_y,basefit):
    features=e.bank_features(selected_x)
    residual=np.asarray(selected_y)-basefit.predict(e.low(selected_x))
    if kind=='omp':
        m=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True)
    elif kind=='elasticnet':
        m=ElasticNet(alpha=.045,l1_ratio=.8,max_iter=3000,tol=1e-5,fit_intercept=True,selection='cyclic')
    else:
        m=Ridge(alpha=1.0,fit_intercept=True)
    return m.fit(features,residual)

def run(scored):
    assert scored['schema']=='yggdrasil.energy53.scored.v1'
    assert scored['source_version']==e.VERSION
    assert scored['policies']==list(e.POLICIES) and scored['learners']==list(e.LEARNERS)
    assert scored['world_count']==len(scored['worlds'])==12*len(scored['seeds'])
    checks=0
    totals={p:{l:{k:[] for k in ('new_mse','cold_mse','old_mse')} for l in e.LEARNERS} for p in e.POLICIES}
    for w in scored['worlds']:
        sd,fam,wid=w['seed'],w['family'],w['world']
        assert sd in scored['seeds'] and fam in e.FAMILIES and wid in range(4);checks+=3
        s,truth=e.world(sd,wid,fam)
        allbase=sum([s[k]['base_ids'] for k in ('old_train','pool','old_test','new_test','cold_test')],[])
        assert len(allbase)==len(set(allbase))==e.NOLD+e.NPOOL+3*e.NHELD;checks+=1
        assert all(max(e.LOW_TERMS[int(i)][1])<9 for i in truth['base_indices']);checks+=1
        assert truth['true_mech_index']==w['planted_index'];checks+=1
        expected_source=hashlib.sha256(json.dumps({k:v['base_ids'] for k,v in s.items()},sort_keys=True).encode()).hexdigest()
        assert expected_source==w['source_hash'];checks+=1
        xold,yold=s['old_train']['x'],s['old_train']['y']
        base=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(e.low(xold),yold)
        old_pred=base.predict(e.low(s['old_test']['x']))
        old_mse=float(np.mean((old_pred-s['old_test']['y'])**2))
        assert abs(old_mse-w['old_base_mse'])<1e-10;checks+=1
        for p in e.POLICIES:
            arm=w['policies'][p]
            ids,values=independent_select(p,s['pool']['x'],base,xold,yold,s['pool']['y'],sd,wid)
            assert ids==arm['indices'],(sd,wid,fam,p,ids,arm['indices']);checks+=1
            assert len(ids)==len(set(ids))==e.BUDGET;checks+=1
            assert np.allclose(values,arm['seen_labels'],rtol=0,atol=5.1e-11);checks+=1
            for learner in e.LEARNERS:
                record=arm['learners'][learner]
                m=independent_refit(learner,s['pool']['x'][ids],values,base)
                new_pred=base.predict(e.low(s['new_test']['x']))+m.predict(e.bank_features(s['new_test']['x']))
                cold_pred=base.predict(e.low(s['cold_test']['x']))+m.predict(e.bank_features(s['cold_test']['x']))
                assert e.sha_receipt(new_pred)==record['new_pred_sha256'];checks+=1
                assert e.sha_receipt(cold_pred)==record['cold_pred_sha256'];checks+=1
                values_now={'new_mse':float(np.mean((new_pred-s['new_test']['y'])**2)),
                            'cold_mse':float(np.mean((cold_pred-s['cold_test']['y'])**2)),'old_mse':old_mse}
                for k,v in values_now.items():
                    assert abs(v-record[k])<1e-9,(sd,wid,fam,p,learner,k,v,record[k]);checks+=1
                    totals[p][learner][k].append(v)
    for p in e.POLICIES:
        for learner in e.LEARNERS:
            for k,series in totals[p][learner].items():
                assert abs(np.mean(series)-scored['aggregate'][p][learner][k])<1e-10
                checks+=1
    # Recompute frozen decisions; timing is left untouched and treated as measured environmental metadata.
    expected=e.gates(scored)
    assert expected['gates']==scored['decision']['gates'];checks+=1
    assert expected['classification']==scored['decision']['classification'];checks+=1
    return {'schema':'yggdrasil.energy53.audit.v1','source_independence':'Independent selector and full estimator refits, shared generator and NumPy/sklearn','status':'PASS','checks':checks,'world_count':scored['world_count'],'seeds':scored['seeds'],'all_policies_and_learners_replayed':True,'held_predictions_sha256_all_verified':True}

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('scored');a.add_argument('--out',required=True);args=a.parse_args()
    r=run(json.loads(Path(args.scored).read_text()));Path(args.out).write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r,sort_keys=True))
