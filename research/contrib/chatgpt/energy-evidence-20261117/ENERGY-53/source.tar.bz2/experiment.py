#!/usr/bin/env python3
"""ENERGY-53: prospective causal hypothesis tournament vs matched intervention designs.
Independent external synthetic research. No native Yggdrasil model integration.
"""
import argparse, hashlib, json, os, time
from itertools import combinations
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge

VERSION='ENERGY53.v1'
FAMILIES=('parity4','threshold4','gate4')
POLICIES=('tournament','hamming','d_optimal','uncertainty','random')
LEARNERS=('omp','elasticnet','ridge')
NOLD, NPOOL, NHELD, BUDGET, NANCHOR = 80,96,48,16,4
SEEDS_SCREEN=(99721,99733)
SEEDS_PRIMARY=(9511,9523,9547)
SEED_DEV=(99709,)
PAIRS=list(combinations(range(11),2))
LOW_TERMS=[(k,idx) for k in (1,2,3) for idx in combinations(range(11),k)]
LOW_TERMS+=[('and2',idx) for idx in PAIRS]
CAUSAL_BASE_TERMS=[i for i,(kind,ids) in enumerate(LOW_TERMS) if max(ids)<9]
BANK={}
for fi,fam in enumerate(FAMILIES):
    possible=list(combinations(range(9),4))
    rr=np.random.default_rng(330+fi)
    chosen=[possible[int(v)] for v in rr.permutation(len(possible))[:8]]
    BANK[fam]=chosen
ALL_BANK=[(fam,ids) for fam in FAMILIES for ids in BANK[fam]]


def rng(seed, wid, tag):
    key=f'{VERSION}/{seed}/{wid}/{tag}'.encode()
    return np.random.default_rng(int.from_bytes(hashlib.sha256(key).digest()[:8],'little'))


def bits(k):
    k=np.asarray(k,dtype=np.int64).reshape(-1)
    return ((k[:,None]>>np.arange(9,dtype=np.int64)[None,:])&1).astype(np.float64)


def with_cues(x, seed, wid, tag, stage):
    r=rng(seed,wid,'cue-'+tag)
    if stage=='old':
        a=x[:,0].copy();b=x[:,1].copy()
    elif stage=='new':
        a=1-x[:,0];b=x[:,2].copy()
    else:
        a=r.integers(0,2,len(x)).astype(float);b=r.integers(0,2,len(x)).astype(float)
    if stage!='cold':
        a=np.logical_xor(a,r.random(len(x))<.1).astype(float)
        b=np.logical_xor(b,r.random(len(x))<.1).astype(float)
    return np.column_stack((x,a,b))


def low(x):
    z=2*x-1
    cols=[]
    for typ,ids in LOW_TERMS:
        if typ=='and2':cols.append(np.prod(x[:,ids],axis=1)*2-1)
        else:cols.append(np.prod(z[:,ids],axis=1))
    return np.asarray(cols).T


def mechanism(x,fam,ids):
    v=x[:,ids]
    if fam=='parity4':return np.prod(2*v-1,axis=1)
    if fam=='threshold4':return 2*(v.sum(axis=1)>=3).astype(float)-1
    return 2*((v[:,0]>0)&(v[:,1]>0)&((v[:,2]>0)|(v[:,3]>0))).astype(float)-1


def bank_features(x):
    return np.column_stack([mechanism(x,f,idx) for f,idx in ALL_BANK])


def world(seed,wid,fam):
    r=rng(seed,wid,'latent-'+fam)
    order=r.permutation(512)
    sections={}
    offsets=(('old_train',NOLD,'old'),('pool',NPOOL,'new'),('old_test',NHELD,'old'),('new_test',NHELD,'new'),('cold_test',NHELD,'cold'))
    pos=0
    for name,n,stage in offsets:
        x=bits(order[pos:pos+n]);pos+=n
        sections[name]={'x':with_cues(x,seed,wid,f'{fam}-{name}',stage),'base_ids':order[pos-n:pos].tolist()}
    base_idx=r.choice(CAUSAL_BASE_TERMS,size=4,replace=False)
    base_weight=r.choice([-1,1],4)*r.uniform(.7,1.2,4)
    latent_idx=int(r.integers(0,8))
    new_weight=float(r.choice([-1,1])*r.uniform(1.1,1.8))
    for name,rec in sections.items():
        x=rec['x'];y=low(x)[:,base_idx]@base_weight
        if name in ('pool','new_test','cold_test'):
            y=y+new_weight*mechanism(x,fam,BANK[fam][latent_idx])
        y=y+rng(seed,wid,'noise-'+fam+'-'+name).normal(0,.20,len(x))
        rec['y']=np.asarray(y)
    return sections,{'true_family':fam,'true_support':BANK[fam][latent_idx],'true_mech_index':FAMILIES.index(fam)*8+latent_idx,'base_indices':base_idx.tolist()}


def stable_max(vals, indices):
    vals=np.asarray(vals);m=float(np.max(vals))
    return int(indices[np.flatnonzero(vals>=m-1e-9)[0]])

def choose_policy(policy,xpool,basefit,xold,yold,observe,seed,wid):
    """Receives only witnessed old labels and callback revealing selected NEW outcomes."""
    F=bank_features(xpool)
    anchor=rng(seed,wid,'anchors').choice(NPOOL,NANCHOR,replace=False).tolist()
    selected=list(map(int,anchor));seen=[float(observe(i)) for i in selected]
    if policy=='random':
        order=rng(seed,wid,'random-policy').permutation(NPOOL).tolist()
    old_mean=basefit.predict(low(xpool))
    start=time.perf_counter()
    for _ in range(BUDGET-NANCHOR):
        remaining=[j for j in range(NPOOL) if j not in selected]
        if policy=='random':j=next(v for v in order if v not in selected)
        elif policy=='hamming':
            d=np.abs(xpool[remaining,None,:]-xpool[None,selected,:]).sum(axis=2)
            values=np.min(d,axis=1)+.02*np.mean(d,axis=1)
            j=stable_max(values,remaining)
        elif policy=='d_optimal':
            # Standard Bayesian D-optimal design on SAME 24 candidate features.
            A=F[selected];inv=np.linalg.inv(A.T@A+.45*np.eye(F.shape[1]))
            scores=np.einsum('ij,jk,ik->i',F[remaining],inv,F[remaining])
            j=stable_max(scores,remaining)
        else:
            # Hypothesis-wise coefficient fit conditioned on the selected NEW outcomes.
            resid=np.asarray(seen)-old_mean[selected]
            A=F[selected];norm=(A*A).sum(axis=0)+.7
            beta=np.sum(A*resid[:,None],axis=0)/norm
            pred=A*beta[None,:]
            losses=((pred-resid[:,None])**2).sum(axis=0)
            if policy=='tournament':
                # Soft posterior, conservatively tempered; no true-factor access.
                weights=np.exp(-.5*(losses-losses.min())/.45)
                weights=weights/(weights.sum()+1e-12)
                P=F[remaining]*beta[None,:]
                mn=P@weights
                value=(P*P)@weights-mn*mn
                value+=.002*np.var(F[remaining],axis=1)
            elif policy=='uncertainty':
                # Conventional single best hypothesis uncertainty / proximity.
                best=int(np.argmin(losses));P=F[remaining,best]*beta[best]
                value=-np.abs(P)+.01*np.var(F[remaining],axis=1)
            j=stable_max(value,remaining)
        selected.append(int(j));seen.append(float(observe(j)))
    return selected,seen,time.perf_counter()-start


def fit_base(xold,yold):
    m=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True)
    m.fit(low(xold),yold)
    return m


def fitted_model(learner,xnew,ynew,basefit):
    res=ynew-basefit.predict(low(xnew));f=bank_features(xnew)
    if learner=='omp':m=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True)
    elif learner=='elasticnet':m=ElasticNet(alpha=.045,l1_ratio=.8,max_iter=3000,tol=1e-5,fit_intercept=True,selection='cyclic')
    else:m=Ridge(alpha=1.0,fit_intercept=True)
    m.fit(f,res)
    return m


def sha_receipt(values):
    return hashlib.sha256(np.asarray(values,dtype='<f8').tobytes()).hexdigest()


def evaluate(seeds,include_worlds=True):
    worlds=[]
    for seed in seeds:
        for fam in FAMILIES:
            for wid in range(4):
                t= time.perf_counter();s,truth=world(seed,wid,fam)
                xold,yold=s['old_train']['x'],s['old_train']['y'];xpool,ypool=s['pool']['x'],s['pool']['y']
                basefit=fit_base(xold,yold)
                base_error=float(np.mean((basefit.predict(low(s['old_test']['x']))-s['old_test']['y'])**2))
                receipt={'seed':seed,'family':fam,'world':wid,'source_hash':hashlib.sha256(json.dumps({k:v['base_ids'] for k,v in s.items()},sort_keys=True).encode()).hexdigest(),
                         'planted_index':truth['true_mech_index'],'old_base_mse':base_error,'policies':{}}
                for policy in POLICIES:
                    queried=[]
                    def oracle(j):
                        if j in queried:raise AssertionError('double witnessed label')
                        queried.append(int(j));return ypool[int(j)]
                    idx,seen,sel_secs=choose_policy(policy,xpool,basefit,xold,yold,oracle,seed,wid)
                    assert idx==queried and len(idx)==BUDGET and len(set(idx))==BUDGET
                    arm={'indices':idx,'seen_labels':[round(float(v),10) for v in seen],
                         'selection_seconds':sel_secs,'learners':{}}
                    for learner in LEARNERS:
                        st=time.perf_counter();m=fitted_model(learner,xpool[idx],np.asarray(seen),basefit)
                        predold=basefit.predict(low(s['old_test']['x']))
                        prednew=basefit.predict(low(s['new_test']['x']))+m.predict(bank_features(s['new_test']['x']))
                        predcold=basefit.predict(low(s['cold_test']['x']))+m.predict(bank_features(s['cold_test']['x']))
                        elapsed=time.perf_counter()-st
                        met={'new_mse':float(np.mean((prednew-s['new_test']['y'])**2)),
                             'cold_mse':float(np.mean((predcold-s['cold_test']['y'])**2)),
                             'old_mse':float(np.mean((predold-s['old_test']['y'])**2)),
                             'fit_predict_seconds':elapsed,
                             'new_pred_sha256':sha_receipt(prednew),'cold_pred_sha256':sha_receipt(predcold)}
                        arm['learners'][learner]=met
                    receipt['policies'][policy]=arm
                receipt['wall_seconds']=time.perf_counter()-t
                worlds.append(receipt)
    agg={}
    for policy in POLICIES:
        agg[policy]={}
        for learner in LEARNERS:
            keys=('new_mse','cold_mse','old_mse','fit_predict_seconds')
            agg[policy][learner]={k:float(np.mean([w['policies'][policy]['learners'][learner][k] for w in worlds])) for k in keys}
        agg[policy]['selection_seconds_total']=sum(w['policies'][policy]['selection_seconds'] for w in worlds)
    return {'schema':'yggdrasil.energy53.scored.v1','source_version':VERSION,'seeds':list(seeds),'world_count':len(worlds),
            'budgets':{'old_labels':NOLD,'selected_new_labels':BUDGET,'shared_anchor_labels':NANCHOR,'new_pool':NPOOL,'held_per_context':NHELD},
            'policies':list(POLICIES),'learners':list(LEARNERS),'aggregate':agg,'worlds':worlds if include_worlds else []}


def gates(r):
    a=r['aggregate'];seed=r['seeds'];worlds=r['worlds']
    cold=lambda p,l:a[p][l]['cold_mse']
    strongest=min((cold(p,l),p,l) for p in POLICIES if p!='tournament' for l in LEARNERS)
    candidate=min((cold('tournament',l),l) for l in LEARNERS)
    seeds=[]
    for s in seed:
        ws=[w for w in worlds if w['seed']==s]
        val=lambda p,l:float(np.mean([w['policies'][p]['learners'][l]['cold_mse'] for w in ws]))
        bestother=min(val(p,'omp') for p in POLICIES if p!='tournament')
        seeds.append({'seed':s,'candidate':val('tournament','omp'),'best_other_omp':bestother,'margin':bestother-val('tournament','omp')})
    # Guard against choosing the candidate downstream learner post-result:
    # Pre-registered primary learner is OMP; all other learner arms remain comparators.
    primary='omp'
    v={'cold_gain_8pct_vs_best_other_omp':cold('tournament',primary)<=.92*min(cold(p,primary) for p in POLICIES if p!='tournament'),
       'cold_gain_5pct_vs_best_any':cold('tournament',primary)<=.95*strongest[0],
       'random_gain_10pct':cold('tournament',primary)<=.90*cold('random',primary),
       'hamming_gain_5pct':cold('tournament',primary)<=.95*cold('hamming',primary),
       'seed_stability_2of3':sum(x['margin']>0 for x in seeds)>=2 if len(seeds)==3 else False,
       'family_no_degradation_10pct':all(float(np.mean([w['policies']['tournament']['learners'][primary]['cold_mse'] for w in worlds if w['family']==f]))<=1.10*min(float(np.mean([w['policies'][p]['learners'][primary]['cold_mse'] for w in worlds if w['family']==f])) for p in POLICIES if p!='tournament') for f in FAMILIES),
       'old_retention_exact':all(w['policies']['tournament']['learners'][primary]['old_mse']==w['old_base_mse'] for w in worlds),
       'selection_cost_below_20x_random':a['tournament']['selection_seconds_total'] <=20*max(1e-6,a['random']['selection_seconds_total'])}
    return {'classification':'DEVELOPMENT_GO' if all(v.values()) else 'DEVELOPMENT_NO_GO',
            'gates':v,'passed':sum(v.values()),'candidate_primary':'omp','strongest_other_global':strongest,'best_tournament_exploratory':candidate,
            'seed_metrics_exploratory':seeds}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seeds',nargs='+',type=int,required=True);p.add_argument('--out',required=True);a=p.parse_args()
    os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
    score=evaluate(tuple(a.seeds));score['decision']=gates(score)
    Path(a.out).write_text(json.dumps(score,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps({'seeds':a.seeds,'worlds':score['world_count'],'classification':score['decision']['classification'],'gates':score['decision']['gates'], 'primary_omp':{p:score['aggregate'][p]['omp']['cold_mse'] for p in POLICIES}},sort_keys=True))
