"""ENERGY-55: causal-intervention paired-feature representation; external synthetic only.

The script deliberately exposes no hidden bit identities to any fitted method.
"""
import argparse, hashlib, json, os, time, platform
from collections import defaultdict
from itertools import combinations
import numpy as np
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.feature_selection import mutual_info_regression
from sklearn.linear_model import ElasticNet

FAMILIES=('parity4','threshold4','conditional4')
ARMS=('paired_rbf','paired_abs_rbf','mi_rbf','tree_rank_rbf','lasso_rbf','random6_rbf','raw12_rbf','raw12_cv_rbf','raw12_trees','sham_paired_rbf')
SEED_SMOKE=(99983,99989)
SEED_PRIMARY=(9811,9827,9839)
CAUSAL_COUNT=6
N_BITS=12
OBS_OLD=96
OBS_NEW=48
HELD=96


def rng(*keys):
    return np.random.default_rng(int.from_bytes(hashlib.sha256('|'.join(map(str,('E55:v1',)+keys)).encode()).digest()[:8],'big'))

def signs(X,ids):
    return 1.-2.*(np.sum(X[:,ids],axis=1)%2)

def majority(X,ids,thresh):
    return np.where(np.sum(X[:,ids],axis=1)>=thresh,1.,-1.)

def hidden_value(X,causal,family,stage):
    c=causal
    if family=='parity4':
        z=1.15*signs(X,c[:4])+.95*signs(X,c[2:6])
        d=.85*signs(X,[c[0],c[4],c[5]]) if stage==0 else -.85*signs(X,[c[1],c[3],c[5]])
    elif family=='threshold4':
        z=1.15*majority(X,c[:4],3)+.95*majority(X,c[2:6],2)
        d=.85*signs(X,[c[0],c[4],c[5]]) if stage==0 else -.85*signs(X,[c[1],c[3],c[5]])
    else:
        z=1.15*np.where(X[:,c[0]]==1,signs(X,[c[1],c[2],c[3]]),majority(X,[c[3],c[4],c[5]],2))
        z+=.95*majority(X,[c[0],c[2],c[4]],2)
        d=.85*signs(X,[c[1],c[3],c[5]]) if stage==0 else -.85*signs(X,[c[2],c[4],c[5]])
    return z+d


def make_world(seed,world_id,family):
    g=rng(seed,world_id,family,'truth')
    causal=g.choice(N_BITS,CAUSAL_COUNT,replace=False).astype(int).tolist()
    nuisance=[j for j in range(N_BITS) if j not in causal]
    cue=g.choice(nuisance,2,replace=False).astype(int).tolist()
    return causal,cue


def sample_actions(seed,world_id,family,tag,n,causal,cue,stage,paired=False):
    g=rng(seed,world_id,family,tag,'actions')
    if paired:
        # Precisely three controlled 2-outcome pairs per observed bit.
        if n!=72: raise ValueError('paired design must use 72 actions')
        X=[]
        for bit in range(N_BITS):
            for _ in range(3):
                base=g.integers(0,2,size=N_BITS,dtype=np.int8)
                for k,c in enumerate(cue):
                    ref=[causal[0],causal[3]][k]
                    base[c]=base[ref]^int(g.random()<.10)
                flipped=base.copy();flipped[bit]^=1
                X.extend((base,flipped))
        return np.asarray(X,dtype=np.int8)
    X=g.integers(0,2,size=(n,N_BITS),dtype=np.int8)
    if stage!=2:
        for k,c in enumerate(cue):
            ref=([causal[0],causal[3]] if stage==0 else [causal[1],causal[4]])[k]
            inv=bool(stage==1 and k==1)
            X[:,c]=X[:,ref] ^ int(inv) ^ (g.random(n)<.1).astype(np.int8)
    return X


def make_data(seed,world_id,family):
    c,cue=make_world(seed,world_id,family)
    data={}
    for tag,n,stage,paired in [('old_pair',72,0,True),('old_other',24,0,False),('new_train',48,1,False),('old_test',HELD,0,False),('new_test',HELD,1,False),('cold_test',HELD,2,False)]:
        X=sample_actions(seed,world_id,family,tag,n,c,cue,stage,paired)
        f=hidden_value(X,c,family,0 if stage==0 else 1)
        noise=rng(seed,world_id,family,tag,'noise').normal(0,.20,n)
        data[tag]=(X,(f+noise).astype(float))
    return c,cue,data


def rank_selected(xold,yold,xnew,ynew,seed,world_id,family):
    X=np.vstack((xold,xnew));Y=np.r_[yold,ynew]
    # Causal matched-pair effect power: no access to planted variables.
    paired=yold[:72].reshape(N_BITS,3,2)
    salience=np.mean(np.square(paired[:,:,1]-paired[:,:,0]),axis=1)
    paired_order=np.argsort(-salience,kind='stable')[:CAUSAL_COUNT]
    abs_salience=np.mean(np.abs(paired[:,:,1]-paired[:,:,0]),axis=1)
    paired_abs_order=np.argsort(-abs_salience,kind='stable')[:CAUSAL_COUNT]
    mi=mutual_info_regression(X,Y,discrete_features=True,random_state=0,n_neighbors=3)
    mi_order=np.argsort(-mi,kind='stable')[:CAUSAL_COUNT]
    t=ExtraTreesRegressor(n_estimators=40,max_depth=9,min_samples_leaf=2,random_state=seed%100000+world_id,n_jobs=1)
    t.fit(X,Y)
    tree_order=np.argsort(-t.feature_importances_,kind='stable')[:CAUSAL_COUNT]
    reg=ElasticNet(alpha=.04,l1_ratio=.9,max_iter=2000,tol=1e-5,random_state=0)
    reg.fit(X,Y)
    lasso_order=np.argsort(-np.abs(reg.coef_),kind='stable')[:CAUSAL_COUNT]
    rand=rng(seed,world_id,family,'random_bit_subset').permutation(N_BITS)[:CAUSAL_COUNT]
    sh=rng(seed,world_id,family,'sham_paired').permutation(72)
    bad=yold[:72][sh].reshape(N_BITS,3,2)
    sham_salience=np.mean(np.square(bad[:,:,1]-bad[:,:,0]),axis=1)
    sham_order=np.argsort(-sham_salience,kind='stable')[:CAUSAL_COUNT]
    return {
        'paired_rbf':paired_order,
        'paired_abs_rbf':paired_abs_order,
        'mi_rbf':mi_order,
        'tree_rank_rbf':tree_order,
        'lasso_rbf':lasso_order,
        'random6_rbf':rand,
        'raw12_rbf':np.arange(N_BITS),
        'raw12_cv_rbf':np.arange(N_BITS),
        'raw12_trees':np.arange(N_BITS),
        'sham_paired_rbf':sham_order
    },salience


def fit_predict(arm,selected,data,seed,wid,return_pred=True):
    oX,oy=data['old_pair'];aX,ay=data['old_other'];nx,ny=data['new_train']
    Xold=np.vstack([oX,aX]);Yold=np.r_[oy,ay]
    metrics={}; predictions={};fit_s=0.
    for name,training,truth in [('old',(Xold,Yold),data['old_test']),('new',(nx,ny),data['new_test']),('cold',(nx,ny),data['cold_test'])]:
        train_x,train_y=training;test_x,test_y=truth
        beg=time.perf_counter()
        if arm=='raw12_cv_rbf':
            model=GridSearchCV(KernelRidge(kernel='rbf'),{'alpha':[.05,.2,.8],'gamma':[.12,.3,.6]},cv=KFold(n_splits=3,shuffle=True,random_state=317),scoring='neg_mean_squared_error',n_jobs=1)
        elif arm=='raw12_trees':
            model=ExtraTreesRegressor(n_estimators=96,max_depth=12,min_samples_leaf=2,random_state=seed+wid*31+int(name!='old'),n_jobs=1)
        else:
            model=KernelRidge(alpha=.14,kernel='rbf',gamma=.52)
        model.fit(train_x[:,selected],train_y)
        pred=model.predict(test_x[:,selected])
        fit_s+=time.perf_counter()-beg
        predictions[name]=pred.tolist()
        metrics[name]=float(np.mean((pred-test_y)**2))
    return metrics,predictions,fit_s


def evaluate(seeds):
    cases=[];agg=defaultdict(lambda:defaultdict(list));timer=defaultdict(float)
    for seed in seeds:
        for fam in FAMILIES:
            for wid in range(4):
                causal,cue,data=make_data(seed,wid,fam)
                Xold=np.vstack([data['old_pair'][0],data['old_other'][0]])
                Yold=np.r_[data['old_pair'][1],data['old_other'][1]]
                sel,sal=rank_selected(Xold,Yold,*data['new_train'],seed,wid,fam)
                row={'seed':seed,'family':fam,'world_id':wid,'truth_causal':causal,'nuisance_cues':cue,'selection':{},'results':{},
                     'pair_salience':sal.tolist(),'train_action_hash':hashlib.sha256(np.vstack([Xold,data['new_train'][0]]).tobytes()).hexdigest()}
                for arm in ARMS:
                    metrics,pred,t=fit_predict(arm,sel[arm],data,seed,wid)
                    row['selection'][arm]=[int(v) for v in sel[arm]]
                    row['results'][arm]={'mse':metrics,'predictions':pred,'fit_predict_wall_s':t}
                    for k,v in metrics.items():agg[arm][k].append(v)
                    timer[arm]+=t
                cases.append(row)
    pooled={a:{k:float(np.mean(vals)) for k,vals in m.items()} for a,m in agg.items()}
    return {'schema':'energy55.record.v1','seeds':list(seeds),'worlds':len(cases),'cases':cases,'pooled':pooled,'fit_predict_wall_s':dict(timer),'environment':{'python':platform.python_version(),'numpy':np.__version__}}


def gates(result):
    p=result['pooled'];c=p['paired_rbf'];others=[a for a in ARMS if a not in ('paired_rbf','sham_paired_rbf')]
    best=min(p[a]['cold'] for a in others)
    seedvals=[];familyvals=[]
    for seed in result['seeds']:
        subset=[x for x in result['cases'] if x['seed']==seed]
        cc=np.mean([x['results']['paired_rbf']['mse']['cold'] for x in subset])
        oo=min(np.mean([x['results'][a]['mse']['cold'] for x in subset]) for a in others)
        seedvals.append({'seed':seed,'candidate_cold':float(cc),'best_control_cold':float(oo),'win':bool(cc<oo)})
    for fam in FAMILIES:
        subset=[x for x in result['cases'] if x['family']==fam]
        cc=np.mean([x['results']['paired_rbf']['mse']['cold'] for x in subset])
        oo=min(np.mean([x['results'][a]['mse']['cold'] for x in subset]) for a in others)
        familyvals.append({'family':fam,'candidate_cold':float(cc),'best_control_cold':float(oo),'within_10pct':bool(cc<=1.1*oo)})
    count=sum(len(set(r['selection']['paired_rbf']) & set(r['truth_causal'])) for r in result['cases'])
    total=CAUSAL_COUNT*len(result['cases'])
    # Approximate measured total source-visible overhead via separately measured fixed fitter; raw-tree baseline charged equally training labels.
    ctime=result['fit_predict_wall_s']['paired_rbf']
    ettime=result['fit_predict_wall_s']['raw12_trees']
    checks={
    'cold_gain_10pct_vs_best':bool(c['cold']<=.90*best),
    'causal_bit_recall_90pct':bool(count/total>=.90),
    'cold_gain_10pct_vs_raw_rbf':bool(c['cold']<=.90*p['raw12_rbf']['cold']),
    'cold_gain_20pct_vs_sham':bool(c['cold']<=.8*p['sham_paired_rbf']['cold']),
    'seed_wins_2of3':bool(sum(x['win'] for x in seedvals)>=2),
    'family_no_more_than10pct_worse':bool(all(x['within_10pct'] for x in familyvals)),
    'new_no_more_than5pct_worse':bool(c['new']<=1.05*min(p[a]['new'] for a in others)),
    'old_no_more_than10pct_worse':bool(c['old']<=1.1*min(p[a]['old'] for a in others)),
    'fit_time_below_tree_time':bool(ctime<ettime)
    }
    return {'gates':checks,'passed':sum(checks.values()),'total':len(checks),'causal_bit_recall':count/total,'selected_correct':count,'selected_total':total,'strongest_control_cold':best,'seed_margins':seedvals,'family_margins':familyvals}


def main():
    p=argparse.ArgumentParser();p.add_argument('--seeds',nargs='+',type=int,required=True);p.add_argument('--out',required=True);args=p.parse_args()
    permitted=set(SEED_SMOKE)|set(SEED_PRIMARY)
    if not set(args.seeds)<=permitted:raise ValueError('unfrozen seed')
    r=evaluate(tuple(args.seeds));r['qualification']=gates(r)
    with open(args.out,'w') as f:json.dump(r,f,sort_keys=True,separators=(',',':'));f.write('\n')
    print(json.dumps({'worlds':r['worlds'],'seeds':r['seeds'],'pooled':r['pooled'],'gate_count':r['qualification']['passed']},sort_keys=True))
if __name__=='__main__':main()
