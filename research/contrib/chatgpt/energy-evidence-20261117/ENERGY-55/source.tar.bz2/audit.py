"""Independent scored-record audit. Generator and third-party numerical solvers are shared."""
import argparse,json,hashlib
from collections import defaultdict
import numpy as np
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.model_selection import GridSearchCV,KFold
from sklearn.feature_selection import mutual_info_regression
from sklearn.linear_model import ElasticNet
import experiment as E


def assert_close(x,y,tol=1e-9):
    if not np.allclose(x,y,atol=tol,rtol=tol,equal_nan=False):
        raise AssertionError(f'Numerical mismatch {np.max(np.abs(np.asarray(x)-np.asarray(y)))}')


def audit(path):
    r=json.load(open(path));checks=0;agg=defaultdict(lambda:defaultdict(list))
    assert r['schema']=='energy55.record.v1';assert len(r['cases'])==len(r['seeds'])*12
    keys=[(case['seed'],case['family'],case['world_id']) for case in r['cases']]
    assert len(set(keys))==len(keys)
    for row in r['cases']:
        seed,fam,wid=row['seed'],row['family'],row['world_id']
        causal,cue,data=E.make_data(seed,wid,fam);assert row['truth_causal']==causal and row['nuisance_cues']==cue;checks+=2
        oldX,oldY=data['old_pair'];assert oldX.shape==(72,12)
        for bit in range(12):
            for pair in range(3):
                a,b=oldX[bit*6+pair*2:bit*6+pair*2+2];diff=np.flatnonzero(a!=b)
                assert diff.tolist()==[bit]
                checks+=1
        X=np.vstack([oldX,data['old_other'][0]]);Y=np.r_[oldY,data['old_other'][1]]
        assert row['train_action_hash']==hashlib.sha256(np.vstack([X,data['new_train'][0]]).tobytes()).hexdigest();checks+=1
        t=oldY.reshape(12,3,2)
        sal2=np.mean((t[:,:,1]-t[:,:,0])**2,axis=1)
        sal1=np.mean(np.abs(t[:,:,1]-t[:,:,0]),axis=1)
        assert_close(sal2,row['pair_salience']);checks+=12
        indices={'paired_rbf':np.argsort(-sal2,kind='stable')[:6],
                 'paired_abs_rbf':np.argsort(-sal1,kind='stable')[:6],
                 'random6_rbf':E.rng(seed,wid,fam,'random_bit_subset').permutation(12)[:6],
                 'raw12_rbf':np.arange(12),'raw12_cv_rbf':np.arange(12),'raw12_trees':np.arange(12)}
        xc=np.vstack([X,data['new_train'][0]]);yc=np.r_[Y,data['new_train'][1]]
        mi=mutual_info_regression(xc,yc,discrete_features=True,random_state=0,n_neighbors=3)
        indices['mi_rbf']=np.argsort(-mi,kind='stable')[:6]
        reg=ExtraTreesRegressor(n_estimators=40,max_depth=9,min_samples_leaf=2,random_state=seed%100000+wid,n_jobs=1)
        reg.fit(xc,yc)
        indices['tree_rank_rbf']=np.argsort(-reg.feature_importances_,kind='stable')[:6]
        lasso=ElasticNet(alpha=.04,l1_ratio=.9,max_iter=2000,tol=1e-5,random_state=0)
        lasso.fit(xc,yc)
        indices['lasso_rbf']=np.argsort(-np.abs(lasso.coef_),kind='stable')[:6]
        bad=Y[:72][E.rng(seed,wid,fam,'sham_paired').permutation(72)].reshape(12,3,2)
        indices['sham_paired_rbf']=np.argsort(-np.mean((bad[:,:,1]-bad[:,:,0])**2,axis=1),kind='stable')[:6]
        for arm in E.ARMS:
            ii=indices[arm];assert row['selection'][arm]==ii.tolist();checks+=6
            for mode in ['old','new','cold']:
                if mode=='old':tr_x,tr_y=X,Y;te_x,te_y=data['old_test']
                else:tr_x,tr_y=data['new_train'];te_x,te_y=data['new_test' if mode=='new' else 'cold_test']
                if arm=='raw12_trees':
                    model=ExtraTreesRegressor(n_estimators=96,max_depth=12,min_samples_leaf=2,random_state=seed+wid*31+int(mode!='old'),n_jobs=1)
                elif arm=='raw12_cv_rbf':
                    model=GridSearchCV(KernelRidge(kernel='rbf'),{'alpha':[.05,.2,.8],'gamma':[.12,.3,.6]},cv=KFold(n_splits=3,shuffle=True,random_state=317),scoring='neg_mean_squared_error',n_jobs=1)
                else:model=KernelRidge(alpha=.14,kernel='rbf',gamma=.52)
                model.fit(tr_x[:,ii],tr_y);pred=model.predict(te_x[:,ii]);saved=row['results'][arm]
                assert_close(pred,saved['predictions'][mode]);checks+=len(pred)
                mse=float(np.mean((pred-te_y)**2));assert_close(mse,saved['mse'][mode]);checks+=1
                agg[arm][mode].append(mse)
    for arm in E.ARMS:
        for mode in ['old','new','cold']:
            assert_close(np.mean(agg[arm][mode]),r['pooled'][arm][mode]);checks+=1
    q=E.gates(r)
    assert q['gates']==r['qualification']['gates']
    assert q['passed']==r['qualification']['passed'];checks+=2
    return {'status':'PASS','checks':checks,'audited_worlds':len(r['cases']),'audited_arms':len(E.ARMS),'note':'Independent selection and estimator refit, shared synthetic generator and NumPy/sklearn solvers.'}

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('scored');a.add_argument('--out',required=True);v=a.parse_args()
    result=audit(v.scored)
    with open(v.out,'w') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(result,sort_keys=True))
