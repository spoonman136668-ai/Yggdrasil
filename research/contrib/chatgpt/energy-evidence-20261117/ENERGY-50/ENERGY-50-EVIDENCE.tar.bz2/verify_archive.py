#!/usr/bin/env python3
"""Read-only ENERGY-50 archive verification; runs no model or primary worlds."""
from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
m=json.loads((D/'manifest.json').read_text())
for name,expected in m['sha256'].items():
    got=hashlib.sha256((D/name).read_bytes()).hexdigest()
    assert got==expected,(name,got,expected)
s=json.loads((D/'result.json').read_text())
assert s['classification']=='DEVELOPMENT_SCREEN_NO_GO' and not s['primary_scored']
assert s['primary_seeds_reserved_unconsumed']==[9209,9221,9241]
for n,seed in (('smoke.json',99941),('smoke2.json',99947)):
    x=json.loads((D/n).read_text())
    assert x['seeds']==[seed] and x['case_count']==6
for n in ('smoke_audit.json','smoke2_audit.json'):
    x=json.loads((D/n).read_text());assert x['checks']==943 and x['status']=='PASS'
print('ENERGY50_ARCHIVE_PASS source, 12 full cases, 2 independent audits, replay, unconsumed primary and explicit SCREEN_NO_GO')
