#!/usr/bin/env python3
"""ENERGY-50 independent OOD synthetic intervention-selection qualification.
External researcher-only; does not read/change native Yggdrasil science or model.
Source+auditor and prospective protocol MUST be committed before primary scoring.
"""
import argparse, copy, hashlib, itertools, json, time, warnings
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.kernel_ridge import KernelRidge

PRIMARY=(9209,9221,9241)
SMOKE=(99941,99947)
IDS=(0,1,2,3)
FAMILIES=('high_order_parity','threshold_mod','conditional_gate')
POLICIES=('diverse','random','fixed','committee','dense_disagreement','pair_coverage','shuffled_committee')
LEARNERS=('kernel_ridge','extra_trees','legacy_elasticnet')
SUPPORT=('diverse:kernel_ridge','random:kernel_ridge')
BUDGET=24
FEATURES=[('p',t) for k in (1,2,3) for t in itertools.combinations(range(12),k)]+[('a',t) for t in itertools.combinations(range(12),2)]
assert len(FEATURES)==364


def rng(*args):
    seed=int.from_bytes(hashlib.sha256(('E50:v1|'+'|'.join(map(str,args))).encode()).digest()[:8],'big')
    return np.random.default_rng(seed)


def sha(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def truth_world(seed,idx,family):
    case=f'{seed}:{idx}:{family}'
    g=rng(case,'latent')
    kinds={'high_order_parity':('parity4','parity5'),
           'threshold_mod':('threshold4','majority5','mod3of5'),
           'conditional_gate':('mux5','parity5','mod3of5')}[family]
    specs=[]; seen=set()
    for i in range(5):
        for attempt in range(60):
            kind=kinds[int(g.integers(0,len(kinds)))]
            n=4 if kind in ('parity4','threshold4') else 5
            support=tuple(sorted(int(t) for t in g.choice(10,size=n,replace=False)))
            key=(kind,support)
            if key not in seen:
                seen.add(key);specs.append((kind,support));break
        else:raise RuntimeError('source motif collision')
    weights=[float((-1 if g.random()<.5 else 1)*g.uniform(.8,1.2)) for _ in range(5)]
    changed=idx!=3
    if not changed:specs[4]=specs[3];weights[4]=weights[3]
    return {'case':case,'seed':seed,'idx':idx,'family':family,'changed':changed,'specs':specs,'weights':weights}


def mechanism(X,spec):
    kind,sel=spec; a=np.asarray(X[:,tuple(sel)],dtype=np.int8)
    if kind.startswith('parity'):return 1-2*np.bitwise_xor.reduce(a,axis=1)
    if kind=='threshold4':return 2*(a.sum(axis=1)>=3).astype(float)-1
    if kind=='majority5':return 2*(a.sum(axis=1)>=3).astype(float)-1
    if kind=='mod3of5':return 2*(a.sum(axis=1)%3==0).astype(float)-1
    if kind=='mux5':
        b=np.bitwise_xor.reduce(a[:,1:4],axis=1)
        c=np.logical_and(a[:,1]==1,a[:,4]==1)
        return 2*np.where(a[:,0]==1,b,c).astype(float)-1
    raise ValueError(kind)


def basis(X):
    X=np.asarray(X,dtype=np.int8)
    out=np.empty((len(X),364),dtype=float)
    for j,(kind,support) in enumerate(FEATURES):
        a=X[:,support]
        if kind=='p':out[:,j]=1-2*np.bitwise_xor.reduce(a,axis=1)
        else:out[:,j]=2*np.all(a==1,axis=1).astype(float)-1
    return out


def data(W):
    case=W['case']
    # All 720 action records have different 10-bit causal action assignments.
    # They are a shuffled without-replacement partition of 1024 possible settings.
    g=rng(case,'unique_actions')
    uint=g.permutation(1024)
    counts={'old_train':96,'new_train':48,'pool':192,'old_held':128,'new_held':128,'cold_held':128}
    X={}; labels={}; pos=0
    for tag,n in counts.items():
        keys=uint[pos:pos+n];pos+=n
        b=((keys[:,None]>>np.arange(10,dtype=np.int64))&1).astype(np.int8)
        x=np.zeros((n,12),dtype=np.int8);x[:,:10]=b
        if tag=='cold_held':x[:,10:]=rng(case,tag,'cues').integers(0,2,(n,2),dtype=np.int8)
        else:
            stage=0 if tag.startswith('old_') else 1
            u=rng(case,tag,'cues')
            x[:,10]=np.bitwise_xor(b[:,0] if stage==0 else 1-b[:,0],(u.random(n)<.08).astype(np.int8))
            x[:,11]=np.bitwise_xor(b[:,1] if stage==0 else b[:,2],(u.random(n)<.08).astype(np.int8))
        X[tag]=x
        stage=0 if tag.startswith('old_') else 1
        ids=(0,1,2,3+stage)
        y=np.zeros(n,dtype=float)
        for idx in ids:y+=W['weights'][idx]*mechanism(x,W['specs'][idx])
        y+=rng(case,tag,'noise').normal(0,.3,n)
        labels[tag]=y
    assert len({tuple(x) for a in X.values() for x in a[:,:10]})==720
    return X,labels


def greedy(scores,pool,observed,lam):
    scores=np.asarray(scores,dtype=float)
    assert len(scores)==len(pool)
    rank=scores/max(float(np.max(np.abs(scores))),1e-8)
    dist=np.count_nonzero(pool[:,None,:]!=observed[None,:,:],axis=2).min(axis=1).astype(float)
    selected=[];used=np.zeros(len(pool),dtype=bool)
    for _ in range(BUDGET):
        val=np.where(used,-np.inf,rank+lam*dist/12.)
        i=int(np.argmax(val));selected.append(i);used[i]=True
        dist=np.minimum(dist,np.count_nonzero(pool!=pool[i],axis=1))
    return selected


def committee_score(X,Y,P,case,shuffled=False):
    preds=[]
    # The same non-grammar predictor and identical observations for all selectors.
    for j in range(4):
        ids=rng(case,'committee',j).integers(0,len(Y),len(Y))
        y=Y[ids].copy()
        if shuffled:y=rng(case,'label_shuffle',j).permutation(y)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            model=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22).fit(X[ids],y)
        preds.append(model.predict(P))
    return np.std(np.array(preds),axis=0)


def choose(policy,Xold,Yold,Xnew,Ynew,pool,case):
    t=time.perf_counter()
    if policy=='fixed':sel=list(range(BUDGET))
    elif policy=='random':sel=[int(v) for v in rng(case,'random_selection').choice(len(pool),BUDGET,replace=False)]
    elif policy=='diverse':sel=greedy(np.zeros(len(pool)),pool,Xnew,1.)
    elif policy=='pair_coverage':
        # Greedy coverage of all pairwise 0/1 value patterns in the unlabeled actions.
        pairs=list(itertools.combinations(range(12),2))
        cover=np.zeros((len(pool),len(pairs)*4),dtype=np.int8)
        for j,(a,b) in enumerate(pairs):cover[np.arange(len(pool)),j*4+2*pool[:,a].astype(np.int64)+pool[:,b].astype(np.int64)]=1
        current=np.zeros(cover.shape[1],dtype=bool)
        for x in Xnew:
            for j,(a,b) in enumerate(pairs):current[j*4+2*int(x[a])+int(x[b])]=True
        used=np.zeros(len(pool),dtype=bool);sel=[]
        for _ in range(BUDGET):
            gains=np.sum(cover[:,~current],axis=1).astype(float)
            gains[used]=-np.inf
            pick=int(np.argmax(gains));sel.append(pick);used[pick]=True;current|=cover[pick].astype(bool)
    else:
        if policy=='dense_disagreement':
            o=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22).fit(Xold,Yold)
            n=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22).fit(Xnew,Ynew)
            score=np.abs(o.predict(pool)-n.predict(pool))
        elif policy=='committee':score=committee_score(Xnew,Ynew,pool,case)
        elif policy=='shuffled_committee':score=committee_score(Xnew,Ynew,pool,case,True)
        else:raise ValueError(policy)
        sel=greedy(score,pool,Xnew,.18)
    assert len(set(sel))==BUDGET
    return sel,time.perf_counter()-t


def model_fit_predict(learner,Xo,Yo,Xn,Yn,test,case):
    tt=time.perf_counter()
    if learner=='legacy_elasticnet':
        old=basis(Xo);new=basis(Xn)
        A=np.vstack([np.column_stack([old,np.zeros_like(old)]),np.column_stack([np.zeros_like(new),new])])
        y=np.concatenate([Yo,Yn]);p=[]
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            m=ElasticNet(alpha=.025,l1_ratio=.85,max_iter=4000,tol=1e-5).fit(A,y)
        for tag in ('old_held','new_held','cold_held'):
            z=basis(test[tag]);tval=np.column_stack([z,np.zeros_like(z)]) if tag=='old_held' else np.column_stack([np.zeros_like(z),z]);p.append(m.predict(tval))
    else:
        A=np.vstack([np.column_stack([Xo,np.zeros(len(Xo))]),np.column_stack([Xn,np.ones(len(Xn))])]);y=np.concatenate([Yo,Yn]);p=[]
        if learner=='kernel_ridge':m=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22)
        elif learner=='extra_trees':m=ExtraTreesRegressor(n_estimators=64,max_features=.8,min_samples_leaf=2,n_jobs=1,random_state=int(rng(case,'forest').integers(0,2**31-1)))
        else:raise ValueError(learner)
        m.fit(A,y)
        for tag in ('old_held','new_held','cold_held'):
            x=test[tag];stage=0. if tag=='old_held' else 1.
            p.append(m.predict(np.column_stack([x,np.full(len(x),stage)])))
    return p,time.perf_counter()-tt


def case_result(seed,idx,family):
    W=truth_world(seed,idx,family);c=W['case'];X,Y=data(W)
    picks={};select_s={}
    for p in POLICIES:
        ids,s=choose(p,X['old_train'],Y['old_train'],X['new_train'],Y['new_train'],X['pool'],c)
        picks[p]=ids;select_s[p]=s
    # This is the only stage at which unobserved pool labels become available.
    arms={}
    for p in POLICIES:
        ids=picks[p]
        x=np.vstack([X['new_train'],X['pool'][ids]])
        y=np.concatenate([Y['new_train'],Y['pool'][ids]])
        for learner in LEARNERS:
            pred,sec=model_fit_predict(learner,X['old_train'],Y['old_train'],x,y,X,c)
            rows={}
            for tag,z in zip(('old_held','new_held','cold_held'),pred):
                rows[tag.split('_')[0]+'_mse']=float(np.mean((z-Y[tag])**2))
                rows[tag.split('_')[0]+'_pred_sha256']=hashlib.sha256(np.asarray(z,dtype='<f8').tobytes()).hexdigest()
            rows['fit_predict_seconds']=sec;arms[p+':'+learner]=rows
    return {'case':c,'seed':seed,'idx':idx,'family':family,'changed':W['changed'],
            'latent_sha256':sha({'specs':W['specs'],'weights':W['weights']}),
            'actions_sha256':{tag:hashlib.sha256(X[tag].tobytes()).hexdigest() for tag in X},
            'held_target_sha256':{tag:hashlib.sha256(Y[tag].astype('<f8').tobytes()).hexdigest() for tag in ('old_held','new_held','cold_held')},
            'pool_actions_selected':picks,'selector_seconds':select_s,'arms':arms}


def aggregate(cases):
    names=[p+':'+m for p in POLICIES for m in LEARNERS]
    means={name:{key:float(np.mean([c['arms'][name][key] for c in cases])) for key in ('old_mse','new_mse','cold_mse')}
           for name in names}
    times={name:float(sum(c['selector_seconds'][name.split(':')[0]]+c['arms'][name]['fit_predict_seconds'] for c in cases)) for name in names}
    def m(pol,learner='kernel_ridge',subset=cases):return float(np.mean([c['arms'][pol+':'+learner]['cold_mse'] for c in subset]))
    cmp=means['diverse:kernel_ridge'];rnd=means['random:kernel_ridge'];others=[p for p in POLICIES if p!='diverse']
    best=min(others,key=lambda p:m(p))
    seedm={str(s):{'diverse':m('diverse',subset=[c for c in cases if c['seed']==s]),'random':m('random',subset=[c for c in cases if c['seed']==s]),'best_other':min(m(p,subset=[c for c in cases if c['seed']==s]) for p in others)} for s in sorted(set(c['seed'] for c in cases))}
    familym={f:{'diverse':m('diverse',subset=[c for c in cases if c['family']==f]),'random':m('random',subset=[c for c in cases if c['family']==f])} for f in FAMILIES}
    unchanged=[c for c in cases if not c['changed']];changed=[c for c in cases if c['changed']]
    gates={
      'critical_cold_gain_10pct_random_krr':cmp['cold_mse']<=.90*rnd['cold_mse'],
      'critical_seed_2of3_vs_random':sum(x['diverse']<x['random'] for x in seedm.values())>=2,
      'critical_old_within_2pct_best_krr':cmp['old_mse']<=1.02*min(means[p+':kernel_ridge']['old_mse'] for p in others),
      'critical_nochange_cold_at_most_10pct_random':m('diverse',subset=unchanged)<=1.10*m('random',subset=unchanged),
      'critical_full_policy_runtime_at_most_1point4_random':times['diverse:kernel_ridge']<=1.40*times['random:kernel_ridge'],
      'supporting_cold_gain_3pct_best_other_krr':cmp['cold_mse']<=.97*m(best),
      'supporting_changed_cold_gain_10pct_random_krr':m('diverse',subset=changed)<=.90*m('random',subset=changed),
      'supporting_3of3_ood_families_vs_random':all(v['diverse']<v['random'] for v in familym.values()),
      'supporting_extra_trees_5pct_cold_vs_random':means['diverse:extra_trees']['cold_mse']<=.95*means['random:extra_trees']['cold_mse']
    }
    critical=[k for k in gates if k.startswith('critical_')];supporting=[k for k in gates if k.startswith('supporting_')]
    passed=sum(gates.values())
    classification=('DEVELOPMENT_PROVISIONAL_GO' if all(gates[k] for k in critical) and sum(gates[k] for k in supporting)>=2 else 'DEVELOPMENT_NO_GO')
    return {'models':means,'total_policy_fit_predict_seconds':times,'per_seed':seedm,'per_family':familym,'best_alternative_krr':best,
            'gates':gates,'passed':passed,'total':len(gates),'critical_passed':sum(gates[k] for k in critical),'supporting_passed':sum(gates[k] for k in supporting),
            'classification':classification}


def canonical(record):
    v=copy.deepcopy(record);v.pop('wall_seconds',None)
    for c in v['cases']:
        c.pop('selector_seconds',None)
        for entry in c['arms'].values():entry.pop('fit_predict_seconds',None)
    v['summary'].pop('total_policy_fit_predict_seconds',None)
    v['summary'].pop('gates',None);v['summary'].pop('passed',None);v['summary'].pop('critical_passed',None);v['summary'].pop('supporting_passed',None);v['summary'].pop('classification',None)
    return json.dumps(v,sort_keys=True,separators=(',',':')).encode()


def run(seeds,idxs,mode):
    t=time.perf_counter()
    c=[case_result(s,i,f) for s in seeds for i in idxs for f in FAMILIES]
    return {'schema':'yggdrasil.energy50.v1','mode':mode,'seeds':list(seeds),'ids':list(idxs),'families':list(FAMILIES),'case_count':len(c),'cases':c,
            'summary':aggregate(c),'wall_seconds':time.perf_counter()-t,'native_model_trained':False,'deployment':'NONE'}


if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--mode',required=True,choices=('smoke','smoke2','primary'));a.add_argument('--out',required=True);v=a.parse_args()
    if v.mode=='primary':seeds=PRIMARY;ids=IDS
    else:seeds=(SMOKE[0] if v.mode=='smoke' else SMOKE[1],);ids=(0,3)
    r=run(seeds,ids,v.mode)
    Path(v.out).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'mode':v.mode,'cases':len(r['cases']),'summary':r['summary'],'semantic_sha256':hashlib.sha256(canonical(r)).hexdigest(),'wall_seconds':r['wall_seconds']},sort_keys=True))
