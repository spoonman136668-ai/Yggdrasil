#!/usr/bin/env python3
"""ENERGY-50 independent source-free evaluator. Never imports experiment.py.
Rebuilds latent OOD rules and disjoint action sets from SHA-256 streams;
refits each of the 21 learning arms with identical training labels,
independently checks the policy and predictions, and verifies high-order Fourier
content not representable by the authored <=3-way parity/AND2 grammar.
"""
import argparse, hashlib, itertools, json, time, warnings
from pathlib import Path
import numpy as np
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import ElasticNet

names=('diverse','random','fixed','committee','dense_disagreement','pair_coverage','shuffled_committee')
learners=('kernel_ridge','extra_trees','legacy_elasticnet')
contexts=(('old_train',96,0),('new_train',48,1),('pool',192,1),('old_held',128,0),('new_held',128,1),('cold_held',128,1))
features=tuple((t,sub) for ar in (1,2,3) for sub in itertools.combinations(range(12),ar) for t in ('parity',))+tuple(('and',sub) for sub in itertools.combinations(range(12),2))
assert len(features)==364
checked=0

def eq(actual,wanted,label):
    global checked
    checked+=1
    if isinstance(actual,(float,np.floating)) or isinstance(wanted,(float,np.floating)):
        if not np.isclose(actual,wanted,rtol=3e-9,atol=2e-10):raise AssertionError((label,actual,wanted))
    elif actual!=wanted:raise AssertionError((label,actual,wanted))

def g(*parts):
    payload=('E50:v1|'+'|'.join(map(str,parts))).encode()
    return np.random.default_rng(int.from_bytes(hashlib.sha256(payload).digest()[:8],'big'))

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def hidden(seed,idx,family):
    key=f'{seed}:{idx}:{family}';rr=g(key,'latent')
    allowed={'high_order_parity':('parity4','parity5'), 'threshold_mod':('threshold4','majority5','mod3of5'), 'conditional_gate':('mux5','parity5','mod3of5')}[family]
    pairs=[];used=set()
    while len(pairs)<5:
        typ=allowed[int(rr.integers(len(allowed)))];n=4 if typ in ('parity4','threshold4') else 5
        comb=tuple(sorted(map(int,rr.choice(10,n,replace=False))))
        if (typ,comb) not in used:used.add((typ,comb));pairs.append((typ,comb))
    coef=[float((-1 if rr.random()<.5 else 1)*rr.uniform(.8,1.2)) for _ in range(5)]
    if idx==3:pairs[-1]=pairs[-2];coef[-1]=coef[-2]
    return pairs,coef

def rule(kind,subset,X):
    a=X[:,tuple(subset)].astype(int)
    if kind.startswith('parity'):return np.prod(1-2*a,axis=1)
    if kind in ('threshold4','majority5'):return (2*(np.count_nonzero(a,axis=1)>=3)-1).astype(float)
    if kind=='mod3of5':return (2*(np.sum(a,axis=1)%3==0)-1).astype(float)
    if kind=='mux5':
        y=np.where(a[:,0]!=0, np.bitwise_xor.reduce(a[:,1:4],axis=1),np.logical_and(a[:,1]!=0,a[:,4]!=0))
        return (2*y-1).astype(float)
    raise ValueError(kind)

def check_nontrivial_order(spec):
    typ,cols=spec
    n=len(cols);a=np.array(list(itertools.product((0,1),repeat=n)),dtype=np.int8)
    obj=rule(typ,tuple(range(n)),a)
    high=[]
    for count in range(4,n+1):
        for subset in itertools.combinations(range(n),count):
            high.append(float(np.mean(obj*np.prod(1-2*a[:,subset],axis=1))))
    eq(max(abs(v) for v in high)>1e-8,True,typ+' high-order nonzero')

def construct(seed,idx,family):
    case=f'{seed}:{idx}:{family}';latent,coeff=hidden(seed,idx,family)
    stream=g(case,'unique_actions').permutation(1024)
    X={};Y={};start=0
    for tag,n,stage in contexts:
        key=stream[start:start+n];start+=n
        a=np.array([[(int(v)>>j)&1 for j in range(10)] for v in key],dtype=np.int8)
        mat=np.column_stack((a,np.zeros((n,2),dtype=np.int8)))
        if tag=='cold_held':mat[:,10:]=g(case,tag,'cues').integers(0,2,(n,2),dtype=np.int8)
        else:
            draw=g(case,tag,'cues')
            flip=(draw.random(n)<.08).astype(np.int8)
            mat[:,10]=np.bitwise_xor(a[:,0] if stage==0 else 1-a[:,0],flip)
            mat[:,11]=np.bitwise_xor(a[:,1] if stage==0 else a[:,2],(draw.random(n)<.08).astype(np.int8))
        X[tag]=mat
        effect=sum(float(coeff[i])*rule(latent[i][0],latent[i][1],mat) for i in (0,1,2,3+stage))
        Y[tag]=effect+g(case,tag,'noise').normal(0,.3,n)
    assert len({tuple(x) for val in X.values() for x in val[:,:10]})==720
    return latent,coeff,X,Y

def expand(X):
    xx=np.asarray(X)
    result=np.empty((len(xx),len(features)),float)
    for j,(kind,support) in enumerate(features):
        vals=xx[:,tuple(support)]
        if kind=='parity':result[:,j]=np.prod(1-2*vals.astype(int),axis=1)
        else:result[:,j]=2*np.prod(vals.astype(int),axis=1)-1
    return result

def select_ranking(arr,available,pool,stage,diversity_weight):
    score=np.asarray(arr,dtype=float);score=score/max(float(np.max(np.abs(score))),1e-8)
    d=np.sum(pool[:,None,:]!=stage[None,:,:],axis=2).min(axis=1).astype(float)
    chosen=[];used=np.zeros(len(pool),dtype=bool)
    for _ in range(24):
        val=score+diversity_weight*d/12
        val[used]=-np.inf
        index=int(val.argmax());used[index]=True;chosen.append(index)
        d=np.minimum(d,np.count_nonzero(pool!=pool[index],axis=1))
    return chosen

def ensemble_prediction(X,y,P,case,sham=False):
    result=[]
    for j in range(4):
        ids=g(case,'committee',j).integers(0,len(y),len(y))
        yy=y[ids]
        if sham:yy=g(case,'label_shuffle',j).permutation(yy)
        mod=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22).fit(X[ids],yy)
        result.append(mod.predict(P))
    return np.std(result,axis=0)

def selector(name,case,X,Y):
    P=X['pool'];N=X['new_train'];O=X['old_train']
    if name=='fixed':return list(range(24))
    if name=='random':return list(map(int,g(case,'random_selection').choice(len(P),24,replace=False)))
    if name=='diverse':return select_ranking(np.zeros(len(P)),None,P,N,1.)
    if name=='pair_coverage':
        pairs=list(itertools.combinations(range(12),2));codes=np.empty((len(P),len(pairs)),int)
        for j,(a,b) in enumerate(pairs):codes[:,j]=2*P[:,a].astype(int)+P[:,b].astype(int)
        covered=set()
        for a in N:
            for j,(u,v) in enumerate(pairs):covered.add((j,2*int(a[u])+int(a[v])))
        seen=set();picked=[]
        for _ in range(24):
            gain=[-1 if i in seen else sum((j,int(codes[i,j])) not in covered for j in range(len(pairs))) for i in range(len(P))]
            i=int(np.argmax(gain));picked.append(i);seen.add(i)
            for j in range(len(pairs)):covered.add((j,int(codes[i,j])))
        return picked
    if name=='dense_disagreement':
        a=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22).fit(O,Y['old_train'])
        b=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22).fit(N,Y['new_train'])
        score=np.abs(a.predict(P)-b.predict(P))
    else:
        score=ensemble_prediction(N,Y['new_train'],P,case,name=='shuffled_committee')
    return select_ranking(score,None,P,N,.18)

def fit_eval(learner,case,oldx,oldy,newx,newy,X):
    yt=np.concatenate((oldy,newy))
    if learner=='legacy_elasticnet':
        A=expand(oldx);B=expand(newx)
        design=np.vstack((np.column_stack((A,np.zeros_like(A))),np.column_stack((np.zeros_like(B),B))))
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            mod=ElasticNet(alpha=.025,l1_ratio=.85,max_iter=4000,tol=1e-5).fit(design,yt)
        pred=[]
        for tag in ('old_held','new_held','cold_held'):
            v=expand(X[tag]);data=np.hstack((v,np.zeros_like(v))) if tag=='old_held' else np.hstack((np.zeros_like(v),v))
            pred.append(mod.predict(data))
        return pred
    observed=np.vstack((np.column_stack((oldx,np.zeros(len(oldx)))),np.column_stack((newx,np.ones(len(newx))))))
    if learner=='kernel_ridge':mod=KernelRidge(alpha=1.5,kernel='rbf',gamma=.22)
    else:mod=ExtraTreesRegressor(n_estimators=64,max_features=.8,min_samples_leaf=2,n_jobs=1,random_state=int(g(case,'forest').integers(0,2**31-1)))
    mod.fit(observed,yt)
    return [mod.predict(np.hstack((X[tag],np.full((len(X[tag]),1),float(tag!='old_held'))))) for tag in ('old_held','new_held','cold_held')]

def audit(case_record):
    case=case_record['case'];seed=case_record['seed'];idx=case_record['idx'];family=case_record['family']
    eq(case,f'{seed}:{idx}:{family}','case')
    eq(case_record['changed'],idx!=3,'change flag')
    latent,coef,X,Y=construct(seed,idx,family)
    eq(case_record['latent_sha256'],digest({'specs':latent,'weights':coef}),'latent SHA')
    for spec in latent:check_nontrivial_order(spec)
    for tag in X:eq(case_record['actions_sha256'][tag],hashlib.sha256(X[tag].tobytes()).hexdigest(),tag+' actions')
    for tag in ('old_held','new_held','cold_held'):
        eq(case_record['held_target_sha256'][tag],hashlib.sha256(np.asarray(Y[tag],dtype='<f8').tobytes()).hexdigest(),tag+' labels')
    for pol in names:
        ids=selector(pol,case,X,Y)
        eq(case_record['pool_actions_selected'][pol],ids,pol+' selected')
        eq(len(set(ids)),24,'unique selected')
        newx=np.vstack((X['new_train'],X['pool'][ids]))
        newy=np.hstack((Y['new_train'],Y['pool'][ids]))
        for learner in learners:
            predicted=fit_eval(learner,case,X['old_train'],Y['old_train'],newx,newy,X)
            key=pol+':'+learner
            for i,tag in enumerate(('old','new','cold')):
                row=case_record['arms'][key]
                hashval=hashlib.sha256(np.asarray(predicted[i],dtype='<f8').tobytes()).hexdigest()
                eq(row[tag+'_pred_sha256'],hashval,key+' predicted bytes')
                eq(row[tag+'_mse'],float(np.mean((predicted[i]-Y[tag+'_held'])**2)),key+' MSE')

def run(path):
    global checked
    checked=0
    source=json.loads(Path(path).read_text());assert source['schema']=='yggdrasil.energy50.v1'
    assert source['mode'] in ('smoke','smoke2','primary')
    assert source['families']==['high_order_parity','threshold_mod','conditional_gate']
    if source['mode']=='primary':assert source['seeds']==[9209,9221,9241] and source['ids']==[0,1,2,3]
    else:
        assert source['seeds']==([99941] if source['mode']=='smoke' else [99947]);assert source['ids']==[0,3]
    assert len(source['cases'])==len(source['seeds'])*len(source['ids'])*len(source['families'])
    for entry in source['cases']:audit(entry)
    eq(source['summary']['passed'],sum(source['summary']['gates'].values()),'gates count')
    assert len(source['summary']['gates'])==9
    return {'schema':'yggdrasil.energy50.independent-audit.v1','mode':source['mode'],'status':'PASS',
            'checks':checked,'cases':len(source['cases']),'full_21_arm_refits':True,'source_free':True,
            'all_720_unique_causal_interventions_per_world':True,'verified_hidden_fourier_order_above_three':True,
            'audit_scope':'independently regenerated 36/12 worlds, 7 selector decisions, all 21 downstream model fits and 3x128 predictions; shares sklearn/numpy libraries',
            'native_qualification':'NOT RUN'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('record');parser.add_argument('--out',required=True);opt=parser.parse_args()
    t=time.perf_counter();report=run(opt.record);report['audit_wall_seconds']=time.perf_counter()-t
    Path(opt.out).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,sort_keys=True))
