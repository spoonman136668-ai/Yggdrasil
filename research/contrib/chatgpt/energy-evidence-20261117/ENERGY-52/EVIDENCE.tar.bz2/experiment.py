#!/usr/bin/env python3
"""ENERGY-52: held-out-validation-gated causal correction on fresh high-order worlds.
External synthetic research. Source-free evaluation truth; no native model integration.
"""
import argparse, hashlib, itertools, json, time
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet

SEEDS=(9419,9431,9449)
FAMILIES=('parity45','threshold','conditional_mod')
IDS=range(4)
POLICIES=('gate_energy','ungated_energy','no_adapt','enet_new','omp_new','gate_enet','shuffled_gate','oracle_gate')
POW=np.array([len(x) for d in range(1,6) for x in itertools.combinations(range(12),d)],dtype=int)
SUPPORTS=[c for d in range(1,6) for c in itertools.combinations(range(12),d)]
MASK=np.zeros((12,len(SUPPORTS)),dtype=np.float64)
for j,s in enumerate(SUPPORTS):MASK[list(s),j]=1.
DEG=POW
assert len(SUPPORTS)==1585

def rng(*keys):
    blob=(':'.join(map(str,('E52:v1',)+keys))).encode()
    return np.random.default_rng(int.from_bytes(hashlib.sha256(blob).digest()[:8],'little'))

def feats(bits):
    # Fourier monomials in +/-1 Walsh basis, all 12 observable bits.
    return 1.-2.*((bits.astype(np.float64)@MASK)%2.)

def get_world(seed,fam,wid):
    g=rng('world',seed,fam,wid)
    hidden=[]
    # 3 shared motifs and 2 stage-specific; exact supports concealed from learners
    choices=g.choice(10,size=(5,5),replace=True)
    for k in range(5):
        degree=int(g.integers(4,6)); v=tuple(sorted(g.choice(10,size=degree,replace=False).tolist()))
        coeff=float(g.choice([-1.,1.])*g.uniform(.85,1.25))
        kind='parity' if fam=='parity45' else (('majority' if k%2==0 else 'modulo') if fam=='threshold' else ('conditional' if k%2==0 else 'modulo'))
        hidden.append((kind,v,coeff))
    # 360 causal-assignment-unique interventions, split BEFORE observing any outcome
    perm=rng('assignment',seed,fam,wid).permutation(1024)[:360]
    result={}
    segments=('old_train','new_fit','new_val','old_test','new_test','cold_test')
    spans=[72,48,24,72,72,72]
    pos=0
    for phase,n in zip(segments,spans):
        code=perm[pos:pos+n];pos+=n
        causal=((code[:,None]>>np.arange(10))&1).astype(np.uint8)
        noise_rng=rng('cue',seed,fam,wid,phase)
        observed=np.zeros((n,12),np.uint8);observed[:,:10]=causal
        if phase.startswith('old'):
            observed[:,10]=causal[:,0] ^ (noise_rng.random(n)<.1)
            observed[:,11]=causal[:,1] ^ (noise_rng.random(n)<.1)
        elif phase.startswith('new'):
            observed[:,10]=(1-causal[:,0]) ^ (noise_rng.random(n)<.1)
            observed[:,11]=causal[:,2] ^ (noise_rng.random(n)<.1)
        else:
            observed[:,10:]=noise_rng.integers(0,2,size=(n,2))
        is_old=phase.startswith('old')
        truth=np.zeros(n,dtype=float)
        for idx in ((0,1,2,3) if is_old else (0,1,2,4)):
            kind,s,weight=hidden[idx]
            z=causal[:,list(s)]
            if kind=='parity': m=1.-2.*(np.sum(z,axis=1)%2).astype(float)
            elif kind=='majority':m=2*(np.sum(z,axis=1)>=((len(s)+1)//2))-1
            elif kind=='modulo':m=2*(np.sum(z,axis=1)%3==1)-1
            else:m=2*(np.where(z[:,0]==1,np.sum(z[:,1:])%2==0,np.sum(z[:,1:])>=2))-1
            truth+=weight*m
        y=truth+rng('noise',seed,fam,wid,phase).normal(0,.25,n)
        result[phase]={'x':observed,'y':y,'assignment':code,'truth':truth}
    assert pos==360 and len(set(perm.tolist()))==360
    return result,hidden

def pred_sparse(x, ids, beta, bias):
    return feats(x)[:,ids]@beta+bias if len(ids) else np.full(len(x),bias)

def sparse_fit(x,y,nterms=6,degree_penalty=0.04):
    f=feats(x); residual=y.copy(); selected=[]; bias=float(y.mean()); residual-=bias
    for i in range(nterms):
        norms=np.sqrt((f*f).sum(axis=0)); cov=np.abs(f.T@residual)/np.maximum(norms,1.)/(1+degree_penalty*(DEG-1))
        if selected:cov[selected]=-1
        j=int(np.argmax(cov));selected.append(j)
        mat=np.column_stack((np.ones(len(x)),f[:,selected]))
        reg=np.eye(1+len(selected))*.025;reg[0,0]=0
        coeff=np.linalg.solve(mat.T@mat+reg,mat.T@y)
        residual=y-mat@coeff
    return selected,coeff[1:],float(coeff[0])

def omp_fit(x,y):
    model=OrthogonalMatchingPursuit(n_nonzero_coefs=6,fit_intercept=True)
    model.fit(feats(x),y)
    return model

def enet_fit(x,y):
    model=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=1200,tol=.0005,random_state=0)
    model.fit(feats(x),y)
    return model

def mse(a,b):return float(np.mean((np.asarray(a)-np.asarray(b))**2))

def case(seed,fam,wid,detail=False):
    data,hidden=get_world(seed,fam,wid)
    ox=data['old_train']['x'];oy=data['old_train']['y']
    nx=data['new_fit']['x'];ny=data['new_fit']['y']
    vx=data['new_val']['x'];vy=data['new_val']['y']
    ax=np.vstack((nx,vx)); ay=np.r_[ny,vy]
    sets=['old_test','new_test','cold_test']
    t0=time.perf_counter()
    old_ids,old_beta,old_bias=sparse_fit(ox,oy,6)
    old=lambda x:pred_sparse(x,old_ids,old_beta,old_bias)
    candidate_ids,candidate_beta,candidate_bias=sparse_fit(nx,ny-old(nx),5)
    candidate=lambda x:old(x)+pred_sparse(x,candidate_ids,candidate_beta,candidate_bias)
    gain=mse(old(vx),vy)-mse(candidate(vx),vy)
    margin=.05*mse(old(vx),vy)
    accepted=bool(gain>margin)
    if accepted:
        chosen_ids,chosen_beta,chosen_bias=sparse_fit(ax,ay-old(ax),5)
        predict_energy=lambda x:old(x)+pred_sparse(x,chosen_ids,chosen_beta,chosen_bias)
    else:
        chosen_ids,chosen_beta,chosen_bias=[],np.array([]),0.
        predict_energy=old
    ung_ids,ung_beta,ung_bias=sparse_fit(ax,ay-old(ax),5)
    ungated=lambda x:old(x)+pred_sparse(x,ung_ids,ung_beta,ung_bias)
    sg=rng('shuffle',seed,fam,wid).permutation(len(ay))
    sh_ids,sh_beta,sh_bias=sparse_fit(ax,ay[sg]-old(ax),5)
    shuffled=lambda x:old(x)+pred_sparse(x,sh_ids,sh_beta,sh_bias)
    en=enet_fit(ax,ay)
    enold=enet_fit(ox,oy)
    op=omp_fit(ax,ay)
    opold=omp_fit(ox,oy)
    enval=enet_fit(nx,ny)
    en_gate=bool(mse(enold.predict(feats(vx)),vy)-mse(enval.predict(feats(vx)),vy)>.05*mse(enold.predict(feats(vx)),vy))
    energy_time=time.perf_counter()-t0
    predict={
      'gate_energy':(lambda x:predict_energy(x)),
      'ungated_energy':(lambda x:ungated(x)),
      'no_adapt':(lambda x:old(x)),
      'enet_new':(lambda x:en.predict(feats(x))),
      'omp_new':(lambda x:op.predict(feats(x))),
      'gate_enet':(lambda x:en.predict(feats(x)) if en_gate else enold.predict(feats(x))),
      'shuffled_gate':(lambda x:shuffled(x) if accepted else old(x)),
    }
    measures={}
    predictions={}
    for arm,model in predict.items():
        predictions[arm]={}
        for phase in sets:
            x=data[phase]['x']
            if phase=='old_test':
                yhat=(enold.predict(feats(x)) if arm in ('enet_new','gate_enet') else opold.predict(feats(x)) if arm=='omp_new' else old(x))
            else:yhat=model(x)
            predictions[arm][phase]=np.round(yhat,9).tolist()
        measures[arm]={phase:mse(predictions[arm][phase],data[phase]['y']) for phase in sets}
    rec={'seed':seed,'family':fam,'id':wid,'measures':measures,'energy_gate':accepted,
      'enet_gate':en_gate,'validation_gain':gain,'validation_threshold':margin,
      'selected_old':[int(i) for i in old_ids], 'selected_correction':[int(i) for i in chosen_ids],
      'selected_ungated':[int(i) for i in ung_ids],
      'high_order_true':[list(v) for kind,v,w in hidden if kind=='parity' and len(v)>=4],
      'structural_support_recall':float(sum(tuple(s) in [SUPPORTS[i] for i in set(old_ids+chosen_ids)]
           for kind,s,w in hidden if kind=='parity' and len(s)>=4)/max(1,sum(kind=='parity' and len(s)>=4 for kind,s,w in hidden))),
      'energy_fit_wall_s':energy_time,
      'assignments_sha256':hashlib.sha256(np.r_[tuple(data[k]['assignment'] for k in data)].astype('<i8').tobytes()).hexdigest(),
      'truth_sha256':hashlib.sha256(np.concatenate([data[k]['truth'] for k in data]).astype('<f8').tobytes()).hexdigest()}
    if detail:rec['predictions']=predictions
    return rec

def evaluate(seeds,full=False):
    cases=[]; t0=time.perf_counter()
    for s in seeds:
      for fam in FAMILIES:
        for idx in IDS:
          cases.append(case(s,fam,idx,detail=full))
    aggregate={a:{p:float(np.mean([c['measures'][a][p] for c in cases])) for p in ('old_test','new_test','cold_test')} for a in predict_names()}
    per_seed={str(s):{a:float(np.mean([c['measures'][a]['cold_test'] for c in cases if c['seed']==s])) for a in predict_names()} for s in seeds}
    return {'kind':'ENERGY52-synthetic','seeds':list(seeds),'worlds':len(cases),'cases':cases,
            'aggregate':aggregate,'per_seed':per_seed,'gate_acceptance':sum(c['energy_gate'] for c in cases),
            'enet_gate_acceptance':sum(c['enet_gate'] for c in cases),
            'wall_seconds':time.perf_counter()-t0}

def predict_names():return ('gate_energy','ungated_energy','no_adapt','enet_new','omp_new','gate_enet','shuffled_gate')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--smoke-seed',type=int,default=99991);ap.add_argument('--primary',action='store_true');ap.add_argument('--out',required=True);ap.add_argument('--full',action='store_true')
    args=ap.parse_args();assert args.smoke!=args.primary
    assert not args.smoke or args.smoke_seed in (99991,99997)
    seeds=(args.smoke_seed,) if args.smoke else SEEDS
    r=evaluate(seeds,full=args.full)
    with open(args.out,'w') as f:json.dump(r,f,indent=2,sort_keys=True)
    print(json.dumps({'worlds':r['worlds'],'aggregate':r['aggregate'],'accepted':r['gate_acceptance'],'time_s':r['wall_seconds']},sort_keys=True))
