#!/usr/bin/env python3
"""Read-only independent reproduction of case selection and held-out loss.
It regenerates worlds and refits estimators; shares sklearn and generator by design.
"""
import argparse,hashlib,json,math
import numpy as np
import experiment as e

def checks(path):
    receipt=json.load(open(path)); chk=0; failures=[]
    assert receipt['worlds']==len(receipt['cases']) and receipt['seeds'] in ([99991],[99997],list(e.SEEDS))
    for saved in receipt['cases']:
        s,f,i=saved['seed'],saved['family'],saved['id']
        d,hidden=e.get_world(s,f,i)
        # Verify source disjointness and hashes independently of stored results
        assignments=np.concatenate([d[k]['assignment'] for k in d]); assert len(set(assignments.tolist()))==360
        h=hashlib.sha256(assignments.astype('<i8').tobytes()).hexdigest()
        if saved['assignments_sha256']!=h:failures.append((s,f,i,'hash'))
        chk+=360
        # Refit all models; compare predictions to scorer to machine tolerance.
        replay=e.case(s,f,i,detail=True)
        for arm in e.predict_names():
            for phase in ('old_test','new_test','cold_test'):
                got=np.array(replay['predictions'][arm][phase])
                assert np.isfinite(got).all()
                y=d[phase]['y']
                actual=float(np.mean((got-y)**2))
                if abs(actual-saved['measures'][arm][phase])>1e-7:failures.append((s,f,i,arm,phase,'mse'))
                chk+=len(got)+1
        if replay['energy_gate']!=saved['energy_gate'] or replay['enet_gate']!=saved['enet_gate']:failures.append((s,f,i,'gate'))
        if replay['selected_correction']!=saved['selected_correction']:failures.append((s,f,i,'supports'))
        chk+=2
    if failures:raise AssertionError(failures[:15])
    return {'status':'PASS','checks':chk,'cases':len(receipt['cases']),'source_shared_with_scorer':True,'independent_of_scorer_aggregator':True,'failures':[]}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('--out',required=True)
    a=ap.parse_args();r=checks(a.input)
    with open(a.out,'w') as f:json.dump(r,f,indent=2,sort_keys=True)
    print(json.dumps(r))
