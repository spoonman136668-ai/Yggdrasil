#!/usr/bin/env python3
"""Audit-only ENERGY-52 seed whitelist adapter; does not modify frozen scorer.
The frozen audit's hardcoded accepted-seed check omitted the prospectively frozen
screen list 99973,99979. Set that check's in-memory constant only, verify source
identities, and invoke frozen audit.checks() unchanged for all substantive tests.
"""
import hashlib, json
from pathlib import Path
import experiment as e
import audit
SHA={"experiment.py":"1e80168f86d65e2ccd250e6975ed5df414653f064812007e723109d3178348c9", "audit.py":"1ac95760f049a04ddc745491857ced76404dea9bc45a454170214054ffe8fbe7"}
for name, expected in SHA.items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected,name
inp=Path('prospective_screen.json')
receipt=json.loads(inp.read_text())
assert receipt['seeds']==[99973,99979] and receipt['worlds']==24
assert e.SEEDS==(9419,9431,9449)
e.SEEDS=(99973,99979)  # whitelist only; generator always uses explicit case seeds
out=audit.checks(str(inp))
assert out['checks']==24*(360+7*3*(72+1)+2)
assert out['cases']==24 and out['status']=='PASS'
out['exception']='Frozen audit.py CLI accepted only previous exploratory seed singleton lists and reserved primary seed triple; in-memory whitelist overridden for prospectively frozen [99973,99979]. No changed scorer, case seeds, source files, observations, per-arm predictions or loss checks.'
out['auditor_is_source_independent']=False
out['audit_program_sha256']=SHA['audit.py']
out['scorer_program_sha256']=SHA['experiment.py']
Path('prospective_audit.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,sort_keys=True))
