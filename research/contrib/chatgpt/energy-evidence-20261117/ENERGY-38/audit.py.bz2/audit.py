#!/usr/bin/env python3
"""ENERGY-38 independent source/action/learning refit and freeze audit.

Does not import experiment.py, and checks each held causal effect prediction,
source action partition, selected action set, observed consequence and frozen gate.
"""
import hashlib
from itertools import combinations
import json
import sys
import time
import warnings
from pathlib import Path

import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, Ridge
from sklearn.tree import DecisionTreeClassifier

EXPECTED_SOURCE_SHA = '879be3760bb28d34bacf03f7dc9603556d9adcc58b0f517cdc4c75d5a2418026'
SEEDS=(7807,7829,7841)
FAMILIES=('majority','context_switch','nonlinear_gate')
SELECTORS=('onepass_energy','omp_uncertainty','ridge_leverage','diversity','random')
LEARNERS=('energy','omp12','ridge','tree')
# independently rebuild scalar factor dictionary
ACTION = [[(i >> j) & 1 for j in range(8)] for i in range(256)]
FACTORS = [('parity',c) for d in range(1,5) for c in combinations(range(8),d)] + [('and',c) for c in combinations(range(8),2)]
assert len(FACTORS)==190

def factor(bits,kind,coords):
    if kind=='and':return 2*(bits[coords[0]]&bits[coords[1]])-1
    out=1
    for j in coords:out*=2*bits[j]-1
    return out

FEATURES=np.array([[factor(ACTION[i],kind,c) for kind,c in FACTORS] for i in range(256)],dtype=float)

def digest(*parts):return hashlib.sha256('/'.join(map(str,('energy38-v1',*parts))).encode()).digest()
def choice(*parts,n):return int.from_bytes(digest(*parts)[:8],'big')%n

def ground(seed,world,family):
    order=sorted(range(1,8),key=lambda bit:digest('factororder',seed,world,family,bit))
    a,b,c,d,e,f,g=order
    signs=[1 if choice('sign',seed,world,family,k,n=2) else -1 for k in range(4)]
    def response(bits):
        spin=lambda j:2*bits[j]-1
        if family=='majority':
            v1=spin(a)*spin(b)*spin(c)
            v2=spin(d)*spin(e)
            v3=(2*(bits[f]&bits[g])-1)*spin(0)
            return 1 if signs[0]*v1+signs[1]*v2+signs[2]*v3>0 else -1
        if family=='context_switch':
            return signs[0]*spin(a)*spin(b)*spin(c) if bits[0]==0 else signs[1]*spin(d)*spin(e)*spin(f)
        left=bits[a]^bits[b]^bits[c]
        right=bits[d]&bits[e]
        gated=bits[0]&(bits[f]^bits[g])
        return 1 if left^right^gated else -1
    truth=np.array([response(bits) for bits in ACTION])
    order=sorted(range(128),key=lambda s:digest('suffix',seed,world,family,s))
    old=np.array([2*x for x in order[:48]],dtype=int)
    cand=old+1
    holdold=np.array([2*x for x in order[48:96]],dtype=int)
    holdnew=holdold+1
    def witnessed(a):
        error=int.from_bytes(digest('noise',seed,world,family,int(a))[:8],'big')/2**64<.1
        return int(truth[a])*(-1 if error else 1)
    y=np.array([witnessed(i) for i in old])
    return old,cand,holdold,holdnew,truth,y,witnessed


def select(policy,old,obs,candidates,seed,w,fam):
    x=FEATURES[old];candidate_features=FEATURES[candidates]
    if policy=='onepass_energy':
        gradient=(obs[:,None]*x).mean(axis=0)
        mask=np.zeros_like(gradient)
        take=np.argsort(-np.abs(gradient),kind='stable')[:12]
        mask[take]=gradient[take]
        uncertainty=1/(1+np.abs(candidate_features@mask))
    elif policy=='omp_uncertainty':
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            o=OrthogonalMatchingPursuit(n_nonzero_coefs=12,fit_intercept=True).fit(x,obs)
        uncertainty=1/(1+np.abs(o.predict(candidate_features)))
    elif policy=='ridge_leverage':
        cross=x@candidate_features.T
        solve=np.linalg.solve(x@x.T+8*np.eye(len(x)),cross)
        uncertainty=np.maximum((np.sum(candidate_features**2,axis=1)-np.sum(cross*solve,axis=0))/8,0)
    elif policy=='random':
        order=sorted(range(len(candidates)),key=lambda i:digest('random',seed,w,fam,int(candidates[i])))
        return [int(candidates[i]) for i in order[:12]]
    else:uncertainty=np.zeros(len(candidates))
    chosen=[]
    while len(chosen)!=12:
        remain=[i for i in range(len(candidates)) if i not in chosen]
        if chosen:
            scores=[min((int(candidates[i])^int(candidates[j])).bit_count() for j in chosen)/7 for i in remain]
        else:scores=[0.]*len(remain)
        if policy!='diversity':scores=[v*.05+uncertainty[i] for i,v in zip(remain,scores)]
        chosen.append(remain[int(np.argmax(scores))])
    return [int(candidates[i]) for i in chosen]


def trained(learner,train,obs,held):
    x=FEATURES[train];z=FEATURES[held]
    if learner=='energy':
        coeff=np.zeros(190,dtype=float)
        for step in range(32):
            bad=np.flatnonzero(obs*(x@coeff)<1)
            if len(bad)==0:break
            gradient=(obs[bad,None]*x[bad]).mean(axis=0)
            best=np.argsort(-np.abs(gradient),kind='stable')[:8]
            coeff[best]+=.06*gradient[best]
            keep=np.argsort(-np.abs(coeff),kind='stable')[:12]
            mask=np.zeros(190,dtype=bool);mask[keep]=True
            coeff[~mask]=0
        scores=z@coeff;support=int(np.count_nonzero(coeff))
    elif learner=='omp12':
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            reg=OrthogonalMatchingPursuit(n_nonzero_coefs=12,fit_intercept=True).fit(x,obs)
        scores=reg.predict(z);support=int(np.count_nonzero(reg.coef_))
    elif learner=='ridge':
        reg=Ridge(alpha=3.0).fit(x,obs)
        scores=reg.predict(z);support=int(np.count_nonzero(reg.coef_))
    else:
        reg=DecisionTreeClassifier(max_depth=8,random_state=17).fit(np.array(ACTION)[train],obs)
        scores=reg.predict(np.array(ACTION)[held]);support=int(reg.tree_.node_count)
    return np.where(scores>0,1,-1),support


def audit(path):
    payload=Path(path).read_bytes();score=json.loads(payload);counts=0
    def require(test,label):
        nonlocal counts
        counts+=1
        if not test:raise AssertionError(label)
    require(score['schema']=='yggdrasil.energy38.score.v1','schema')
    require(score['source_sha256']==EXPECTED_SOURCE_SHA,'frozen code')
    if score['mode']=='smoke':seeds=(99311,);instances=range(1)
    else:seeds=SEEDS;instances=range(6)
    require(score['seeds']==list(seeds),'seeds')
    require(score['worlds']==len(seeds)*len(instances)*3,'world count')
    cases={ (c['seed'],c['instance'],c['family']):c for c in score['cases'] }
    require(len(cases)==len(score['cases']),'duplicate source IDs')
    accum={s:{l:{t:0 for t in ('old_correct','new_correct','causal_effect_correct')} for l in LEARNERS} for s in SELECTORS}
    timing={s:{l:0. for l in LEARNERS} for s in SELECTORS}
    false=0;null=0
    per_seed={}
    for seed in seeds:
        per_seed[seed]={s:{l:0 for l in LEARNERS} for s in SELECTORS}
        for instance in instances:
            for family in FAMILIES:
                key=(seed,instance,family)
                require(key in cases,'missing world')
                case=cases[key]
                old,cand,held_old,held_new,truth,y,witnessed=ground(seed,instance,family)
                require(len(set(old)|set(cand)|set(held_old)|set(held_new))==192,'no held overlap')
                effects=truth[held_new]-truth[held_old]
                null+=int(np.sum(effects==0))
                require(case['nonzero_causal_effects']==int(np.count_nonzero(effects)),'true effects')
                held=np.r_[held_old,held_new]
                for selector in SELECTORS:
                    sampled=select(selector,old,y,cand,seed,instance,family)
                    recorded=case['policies'][selector]
                    require(recorded['selected_actions']==sampled,'selected actions')
                    acquired=[witnessed(i) for i in sampled]
                    require(recorded['observed_new']==acquired,'witnessed signs')
                    train=np.r_[old,np.array(sampled,dtype=int)]
                    labels=np.r_[y,np.array(acquired)]
                    for learner in LEARNERS:
                        pred,support=trained(learner,train,labels,held)
                        expected={'old_correct':int(np.sum(pred[:48]==truth[held_old])),
                                  'new_correct':int(np.sum(pred[48:]==truth[held_new])),
                                  'causal_effect_correct':int(np.sum((pred[48:]-pred[:48])==effects))}
                        saved=recorded['arms'][learner]
                        for k,v in expected.items():
                            require(saved[k]==v,('prediction',key,selector,learner,k))
                            accum[selector][learner][k]+=v
                        require(saved['support']==support,('model support',key,selector,learner))
                        require(saved['policy_total_s']>=0,'cost positive')
                        timing[selector][learner]+=saved['policy_total_s']
                        per_seed[seed][selector][learner]+=expected['causal_effect_correct']
                selected=case['policies']['onepass_energy']
                tr=np.r_[old,np.array(selected['selected_actions'],dtype=int)]
                labels=np.r_[y,np.array(selected['observed_new'],dtype=int)]
                random=np.random.default_rng(choice('shuffle',seed,instance,family,n=2**32))
                negative,_=trained('energy',tr,random.permutation(labels),held)
                num=int(np.sum(negative[48:]-negative[:48]==effects))
                require(case['shuffled_energy_effect_correct']==num,'negative score')
                false+=num
    require(accum==score['score'],'aggregate outcomes')
    require(null==score['null_nochange_correct'],'null comparator')
    require(false==score['shuffled_negative_effect_correct'],'negative aggregate')
    require(all(abs(timing[p][m]-score['policy_full_seconds'][p][m])<1e-8 for p in SELECTORS for m in LEARNERS),'policy time sums')
    controls=[(p,m) for p in SELECTORS for m in LEARNERS if (p,m)!=('onepass_energy','energy')]
    cur=accum['onepass_energy']['energy'];n=48*len(cases)
    best=max(accum[p][m]['causal_effect_correct'] for p,m in controls)
    max_new=max(accum[p][m]['new_correct'] for p,m in controls)
    max_old=max(accum[p][m]['old_correct'] for p,m in controls)
    margins=[per_seed[s]['onepass_energy']['energy']-max(per_seed[s][p][m] for p,m in controls) for s in seeds]
    g={
      'causal_effect_advantage':(cur['causal_effect_correct']-max(best,null))/n>=.03,
      'new_context_advantage':(cur['new_correct']-max_new)/n>=.02,
      'old_context_retention':cur['old_correct']>=max_old-.01*n,
      'selector_vs_random':(cur['causal_effect_correct']-accum['random']['energy']['causal_effect_correct'])/n>=.02,
      'seed_stability':sum(v>0 for v in margins)>=2 if score['mode']!='smoke' else False,
      'label_shuffled_negative':(cur['causal_effect_correct']-false)/n>=.05,
      'whole_policy_value_per_cpu':cur['causal_effect_correct']/timing['onepass_energy']['energy']>=1.5*accum['random']['omp12']['causal_effect_correct']/timing['random']['omp12'],
    }
    # Smoke has a fixed one-seed staging exception in original scorer, not science.
    require(g==score['gates'],'frozen gates')
    require(margins==score['per_seed_effect_margins'],'seed margins')
    require(score['classification']==('DEVELOPMENT_GO' if all(g.values()) else 'DEVELOPMENT_NO_GO'),'verdict')
    require(score['native_checkpoint_run'] is False and score['scientific_pass'] is False and score['deployment']=='NONE','boundaries')
    return {'audit':'PASS','checks':counts,'worlds':len(cases),'original_json_sha256':hashlib.sha256(payload).hexdigest(),
            'frozen_source_sha256':EXPECTED_SOURCE_SHA,'scores':accum,'gates':g,'null_effects':null,
            'shuffled_effects':false,'seed_margins':margins,
            'scope':'independent all-world all-selector all-learner refits; conventional sklearn library shared; no native research acceptance'}

if __name__=='__main__':
    p=sys.argv[1] if len(sys.argv)>1 else 'scored.json'
    out=sys.argv[2] if len(sys.argv)>2 else 'audit_result.json'
    start=time.perf_counter()
    r=audit(p)
    r['audit_wall_seconds']=time.perf_counter()-start
    Path(out).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k!='scores'},sort_keys=True,indent=2))
