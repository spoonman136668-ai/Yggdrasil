#!/usr/bin/env python3
"""ENERGY-38: causal intervention EFFECT recovery per full-policy CPU cost.

Isolated synthetic external contributor study. No Yggdrasil native model.
Do not modify this source or its frozen design after preregistration.
"""
import argparse
import hashlib
import itertools
import json
import time
import warnings
from pathlib import Path

import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, Ridge
from sklearn.tree import DecisionTreeClassifier

SEEDS = (7807, 7829, 7841)
FAMILIES = ('majority', 'context_switch', 'nonlinear_gate')
SELECTORS = ('onepass_energy', 'omp_uncertainty', 'ridge_leverage', 'diversity', 'random')
LEARNERS = ('energy', 'omp12', 'ridge', 'tree')
CONTROLS = tuple((p, m) for p in SELECTORS for m in LEARNERS if (p, m) != ('onepass_energy', 'energy'))
BITS = np.array([[(i >> j) & 1 for j in range(8)] for i in range(256)], dtype=np.int8)
SPINS = 2 * BITS - 1
TERMS = []
COLS = []
for degree in range(1, 5):
    for indices in itertools.combinations(range(8), degree):
        TERMS.append(('parity', indices))
        COLS.append(np.prod(SPINS[:, indices], axis=1))
for indices in itertools.combinations(range(8), 2):
    TERMS.append(('and', indices))
    COLS.append(2 * (BITS[:, indices[0]] * BITS[:, indices[1]]) - 1)
PHI = np.asarray(COLS, dtype=np.float64).T
assert PHI.shape == (256, 190)


def h(*args):
    return hashlib.sha256('/'.join(map(str, ('energy38-v1', *args))).encode('utf-8')).digest()


def choose(*parts, n):
    return int.from_bytes(h(*parts)[:8], 'big') % n


def world(seed, instance, family):
    """Deterministic causal response to externally set 8-bit action; hidden evaluator-only."""
    # New primary seeds, 3 non-identical mechanisms; source grammar withheld from learner.
    options = list(range(1, 8))
    picked = sorted(options, key=lambda x: h('factororder', seed, instance, family, x))
    a,b,c,d,e,f,g = picked
    signs = [1 if choose('sign', seed, instance, family, k, n=2) else -1 for k in range(4)]
    spin = 2 * BITS - 1
    if family == 'majority':
        q1 = spin[:,a] * spin[:,b] * spin[:,c]
        q2 = spin[:,d] * spin[:,e]
        q3 = (2 * (BITS[:,f] & BITS[:,g]) - 1) * spin[:,0]
        truth = np.where(signs[0]*q1 + signs[1]*q2 + signs[2]*q3 > 0, 1, -1)
    elif family == 'context_switch':
        old = signs[0] * spin[:,a] * spin[:,b] * spin[:,c]
        new = signs[1] * spin[:,d] * spin[:,e] * spin[:,f]
        truth = np.where(BITS[:,0] == 0, old, new).astype(int)
    else:
        # A nonlinear, compositional threshold with a genuine context-dependent factor.
        left = (BITS[:,a] ^ BITS[:,b] ^ BITS[:,c]).astype(int)
        right = (BITS[:,d] & BITS[:,e]).astype(int)
        gate = BITS[:,0] & (BITS[:,f] ^ BITS[:,g])
        bit = left ^ right ^ gate
        truth = np.where(bit > 0, 1, -1)
    suffixes = sorted(range(128), key=lambda s: h('suffix', seed, instance, family, s))
    train_s = suffixes[:48]
    held_s = suffixes[48:96]
    base = np.array([2*s for s in train_s], dtype=int)
    candidates = np.array([2*s+1 for s in train_s], dtype=int)
    old_held = np.array([2*s for s in held_s], dtype=int)
    new_held = old_held + 1
    assert len(set(base)|set(candidates)|set(old_held)|set(new_held)) == 192
    def noisy(action):
        corrupt = (int.from_bytes(h('noise',seed,instance,family,int(action))[:8], 'big') / 2**64) < .10
        return int(truth[action]) * (-1 if corrupt else 1)
    prior_obs = np.array([noisy(a) for a in base], dtype=int)
    return dict(seed=seed,instance=instance,family=family,truth=truth,base=base,candidates=candidates,
                held_old=old_held,held_new=new_held,prior_obs=prior_obs,noisy=noisy,
                known_effects=int(np.count_nonzero(truth[new_held]-truth[old_held])))


def energy_fit(matrix, observed, passes=32):
    """Sparse contrastive max-margin energy E(y,a)=-y w*phi(a), 12 active couplings."""
    w = np.zeros(matrix.shape[1],dtype=float)
    for _ in range(passes):
        failed = observed * (matrix @ w) < 1
        if not np.any(failed): break
        g = np.mean(observed[failed,None] * matrix[failed], axis=0)
        picked = np.argsort(-np.abs(g),kind='stable')[:8]
        w[picked] += .06 * g[picked]
        keep=np.argsort(-np.abs(w),kind='stable')[:12]
        mask=np.zeros(len(w),dtype=bool)
        mask[keep]=True
        w[~mask] = 0
    return w


def choose_actions(policy, base, y, candidate, seed, instance, family):
    start=time.perf_counter()
    obs=PHI[base]
    targets=PHI[candidate]
    if policy=='onepass_energy':
        # One normalized source gradient only (no model-iterative learning in selector).
        w=(y[:,None] * obs).mean(axis=0)
        top=np.argsort(-np.abs(w),kind='stable')[:12]
        projected=np.zeros_like(w)
        projected[top]=w[top]
        utility=1/(1+np.abs(targets@projected))
    elif policy=='omp_uncertainty':
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            model=OrthogonalMatchingPursuit(n_nonzero_coefs=12,fit_intercept=True).fit(obs,y)
        utility=1/(1+np.abs(model.predict(targets)))
    elif policy=='ridge_leverage':
        # Exact ridge predictive leverage via 48x48 Woodbury, no hidden outcomes.
        alpha=8.0
        kernel=obs@obs.T + alpha*np.eye(len(obs))
        cross=obs@targets.T
        proj=np.linalg.solve(kernel,cross)
        v=(np.sum(targets*targets,axis=1)-np.sum(cross*proj,axis=0))/alpha
        utility=np.maximum(v,0)
    elif policy=='diversity':
        utility=np.zeros(len(candidate))
    else:
        order=sorted(range(len(candidate)), key=lambda j:h('random',seed,instance,family,int(candidate[j])))
        picked=np.asarray([candidate[j] for j in order[:12]],dtype=int)
        return picked,time.perf_counter()-start
    selected=[]
    # Greedy diversity adds at most .05 to the normalized selection score.
    while len(selected)<12:
        available=[j for j in range(len(candidate)) if j not in selected]
        if selected:
            spread=np.array([min(int(bin(int(candidate[j])^int(candidate[k])).count('1')) for k in selected)
                             for j in available],dtype=float)
            spread/=7.0
        else:
            spread=np.zeros(len(available))
        if policy=='diversity':
            # Fixed greedy max-min Hamming, distinct from active model uncertainty.
            vals=spread
        else:
            vals=utility[available]+.05*spread
        best=available[int(np.argmax(vals))]
        selected.append(best)
    return np.asarray([candidate[j] for j in selected],dtype=int),time.perf_counter()-start


def fitted_predictions(learner, train, y, held):
    start=time.perf_counter()
    if learner=='energy':
        w=energy_fit(PHI[train],y)
        score=PHI[held]@w
        support=int(np.count_nonzero(w))
    elif learner=='omp12':
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            model=OrthogonalMatchingPursuit(n_nonzero_coefs=12,fit_intercept=True).fit(PHI[train],y)
        score=model.predict(PHI[held]);support=int(np.count_nonzero(model.coef_))
    elif learner=='ridge':
        model=Ridge(alpha=3.0).fit(PHI[train],y)
        score=model.predict(PHI[held]);support=int(np.count_nonzero(model.coef_))
    else:
        model=DecisionTreeClassifier(max_depth=8,random_state=17).fit(BITS[train],y)
        score=model.predict(BITS[held]);support=int(model.tree_.node_count)
    return np.where(score>0,1,-1),time.perf_counter()-start,support


def one_case(seed,instance,family):
    tstart=time.perf_counter()
    w=world(seed,instance,family)
    source_s=time.perf_counter()-tstart
    hold=np.concatenate([w['held_old'],w['held_new']])
    true_old=w['truth'][w['held_old']]
    true_new=w['truth'][w['held_new']]
    true_effect=true_new-true_old
    data={}
    for policy in SELECTORS:
        selected,ts=choose_actions(policy,w['base'],w['prior_obs'],w['candidates'],seed,instance,family)
        # Source oracle is only queried *after* action selection is frozen.
        queried=np.array([w['noisy'](a) for a in selected],dtype=int)
        training=np.concatenate([w['base'],selected])
        observed=np.concatenate([w['prior_obs'],queried])
        arms={}
        for learner in LEARNERS:
            predicted,tfit,support=fitted_predictions(learner,training,observed,hold)
            pred_old=predicted[:48];pred_new=predicted[48:]
            effect=pred_new-pred_old
            arms[learner]={
                'old_correct':int(np.sum(pred_old==true_old)),
                'new_correct':int(np.sum(pred_new==true_new)),
                'causal_effect_correct':int(np.sum(effect==true_effect)),
                'fit_pred_s':tfit,'support':support,
                'policy_total_s':source_s+ts+tfit,
            }
        data[policy]={'selected_actions':selected.tolist(),
                     'observed_new':queried.tolist(),
                     'selection_s':ts,'arms':arms}
    # Negative: permute *all 60* observed consequences for the primary selector only.
    a=data['onepass_energy']
    tr=np.concatenate([w['base'],np.asarray(a['selected_actions'],dtype=int)])
    observations=np.concatenate([w['prior_obs'],np.asarray(a['observed_new'],dtype=int)])
    rng=np.random.default_rng(choose('shuffle',seed,instance,family,n=2**32))
    wrong=rng.permutation(observations)
    null_pred,dt,_=fitted_predictions('energy',tr,wrong,hold)
    sham=int(np.sum((null_pred[48:]-null_pred[:48])==true_effect))
    return {'seed':seed,'instance':instance,'family':family,
            'nonzero_causal_effects':w['known_effects'],
            'source_s':source_s,'policies':data,'shuffled_energy_effect_correct':sham,
            'shuffled_fit_s':dt}


def aggregate(cases):
    scores={p:{m:{k:sum(c['policies'][p]['arms'][m][k] for c in cases)
                    for k in ('old_correct','new_correct','causal_effect_correct')}
               for m in LEARNERS} for p in SELECTORS}
    times={p:{m:sum(c['policies'][p]['arms'][m]['policy_total_s'] for c in cases)
              for m in LEARNERS} for p in SELECTORS}
    return scores,times


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--smoke',action='store_true')
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    seeds=(99311,) if args.smoke else SEEDS
    instances=range(1) if args.smoke else range(6)
    start=time.perf_counter()
    cases=[one_case(s,w,f) for s in seeds for w in instances for f in FAMILIES]
    score,timing=aggregate(cases)
    n=48*len(cases)
    current=score['onepass_energy']['energy']
    best_other=max(score[p][m]['causal_effect_correct'] for p,m in CONTROLS)
    best_new=max(score[p][m]['new_correct'] for p,m in CONTROLS)
    best_old=max(score[p][m]['old_correct'] for p,m in CONTROLS)
    fixed_null=sum(48-c['nonzero_causal_effects'] for c in cases)
    per_seed=[]
    for s in seeds:
        sc,_=aggregate([c for c in cases if c['seed']==s])
        per_seed.append(sc['onepass_energy']['energy']['causal_effect_correct']-
                        max(sc[p][m]['causal_effect_correct'] for p,m in CONTROLS))
    gates={
      'causal_effect_advantage':(current['causal_effect_correct']-max(best_other,fixed_null))/n>=.03,
      'new_context_advantage':(current['new_correct']-best_new)/n>=.02,
      'old_context_retention':current['old_correct']>=best_old-.01*n,
      'selector_vs_random':(current['causal_effect_correct']-score['random']['energy']['causal_effect_correct'])/n>=.02,
      'seed_stability':sum(x>0 for x in per_seed)>=2,
      'label_shuffled_negative':(current['causal_effect_correct']-sum(c['shuffled_energy_effect_correct'] for c in cases))/n>=.05,
      'whole_policy_value_per_cpu': current['causal_effect_correct']/timing['onepass_energy']['energy'] >=
            1.5*score['random']['omp12']['causal_effect_correct']/timing['random']['omp12'],
    }
    scored={'schema':'yggdrasil.energy38.score.v1','mode':'smoke' if args.smoke else 'primary',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seeds':list(seeds),'worlds':len(cases),'observations_per_world':60,
            'held_intervention_pairs_per_world':48,'total_effect_pairs':n,
            'null_nochange_correct':fixed_null,
            'shuffled_negative_effect_correct':sum(c['shuffled_energy_effect_correct'] for c in cases),
            'score':score,'policy_full_seconds':timing,'per_seed_effect_margins':per_seed,
            'gates':gates,'wall_seconds':time.perf_counter()-start,
            'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO',
            'scientific_pass':False,'native_checkpoint_run':False,'deployment':'NONE',
            'cases':cases}
    Path(args.out).write_text(json.dumps(scored,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in scored.items() if k!='cases'},sort_keys=True,indent=2))

if __name__=='__main__':main()
