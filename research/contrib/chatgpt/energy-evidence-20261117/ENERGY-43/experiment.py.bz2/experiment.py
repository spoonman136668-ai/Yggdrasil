#!/usr/bin/env python3
"""ENERGY-43: native-free research, acquired causal factor grammar (not supplied factors).
Frozen source candidate. Use --smoke for pre-prereg local qualification, --primary only after prereg committed.
"""
import argparse, hashlib, itertools, json, os, platform, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor

N=12; OLD_N=96; NEW_N=96; HOLD_N=128; MAX_SUPPORT=7
FAMILIES=['parity2','parity3','mixed']
PRIMARY_SEEDS=[8617,8629,8651]
SMOKE_SEED=99811

def digest(*values):
    return int.from_bytes(hashlib.sha256(('E43:v1:'+':'.join(map(str,values))).encode()).digest()[:8],'little')

def rng(*values): return np.random.default_rng(digest(*values))

def features():
    grammar=[('P1',p) for p in itertools.combinations(range(N),1)]
    grammar += [('P2',p) for p in itertools.combinations(range(N),2)]
    grammar += [('P3',p) for p in itertools.combinations(range(N),3)]
    grammar += [('A2',p) for p in itertools.combinations(range(N),2)]
    return grammar
GRAMMAR=features(); IDS={z:i for i,z in enumerate(GRAMMAR)}

def basis(x):
    """Grammar only; no support-specific oracle factor list supplied to any learner."""
    signs=(2*x.astype(np.int8)-1).astype(np.float32)
    out=np.empty((len(x),len(GRAMMAR)),dtype=np.float32)
    for i,(typ,sub) in enumerate(GRAMMAR):
        if typ[0]=='P':out[:,i]=np.prod(signs[:,sub],axis=1)
        else:out[:,i]=2*np.all(x[:,sub]>0,axis=1).astype(np.float32)-1
    return out

def sample_actions(seed,case,part,n,env):
    x=rng(seed,case,part).integers(0,2,size=(n,N),dtype=np.int8)
    # Two cues correlate with action variables differently across old, new and cold domains.
    # Underlying law never uses these cues; they are not provided as 'nuisance' to learners.
    g=rng(seed,case,part,'spur')
    if env=='old': x[:,10]=np.bitwise_xor(x[:,0],g.random(n)<0.07);x[:,11]=np.bitwise_xor(x[:,1],g.random(n)<0.07)
    elif env=='new': x[:,10]=np.bitwise_xor(1-x[:,0],g.random(n)<0.07);x[:,11]=np.bitwise_xor(x[:,2],g.random(n)<0.07)
    else: x[:,10]=g.integers(0,2,n);x[:,11]=g.integers(0,2,n)
    return x

def generate(seed,case,family):
    g=rng(seed,case,family,'factors'); all_true=[]
    families={'parity2':['P2'],'parity3':['P3'],'mixed':['P2','P3','A2']}
    eligible=[i for i,(typ,sub) in enumerate(GRAMMAR) if typ in families[family] and max(sub)<10]
    # Source picks novel factors unknown to all learners; no embedded feature indices in their inputs.
    picked=g.choice(eligible,size=5,replace=False).tolist()
    weights=np.array(g.choice([-1.,1.],5)*g.uniform(0.85,1.15,5))
    # 3 shared factors; 1 old-only; 1 new-only. Labels supplied only for observed actions.
    return picked,weights

def response(x,stage,picked,weights,seed,case,part):
    f=basis(x)[:,picked]
    y=f[:,:3]@weights[:3]+f[:,3 if stage==0 else 4]*weights[3 if stage==0 else 4]
    return y.astype(np.float64)+rng(seed,case,part,'noise').normal(0,0.3,len(x))

def make_world(seed,idx,fam):
    case=f'{idx}:{fam}';picked,w=generate(seed,case,fam)
    parts={}
    for key,stage,env,n in [('old_train',0,'old',OLD_N),('new_train',1,'new',NEW_N),('old_held',0,'old',HOLD_N),('new_held',1,'new',HOLD_N),('cold_held',1,'cold',HOLD_N)]:
        x=sample_actions(seed,case,key,n,env)
        y=response(x,stage,picked,w,seed,case,key)
        parts[key]={'x':x,'y':y,'stage':stage}
    return {'seed':seed,'case':case,'family':fam,'truth':picked,'weights':w.tolist(),'parts':parts}

def design(x,stage,full=True):
    f=basis(x).astype(np.float64)
    if not full:return f
    z=np.zeros_like(f)
    z[stage==1]=f[stage==1]
    return np.concatenate([f,z],axis=1)

def fit_ls(d,y,selected,anchor=None,penalty=0):
    if not selected:return np.zeros(0)
    a=d[:,selected]
    reg=0.02*np.eye(len(selected))
    rhs=a.T@y
    if anchor is not None and penalty>0:
        for i,k in enumerate(selected):
            if k in anchor:
                reg[i,i]+=penalty;rhs[i]+=penalty*anchor[k]
    return np.linalg.solve(a.T@a+reg,rhs)

def discover(d,y,n_allowed,max_support,locked=None,anchor=None):
    """Generate factor structure from residual contrasts; preserve identified factors, then add novelty."""
    selected=list(locked or [])
    coef=fit_ls(d,y,selected,anchor,penalty=20.0 if anchor else 0)
    available=np.ones(n_allowed,dtype=bool)
    if selected:available[selected]=False
    while len(selected)<max_support:
        resid=y-d[:,selected]@coef if selected else y
        v=np.abs(d[:,:n_allowed].T@resid)
        norm=np.linalg.norm(d[:,:n_allowed],axis=0)
        v=np.divide(v,norm,out=np.zeros_like(v),where=norm>0)
        v[~available]=-np.inf
        j=int(np.argmax(v))
        if not np.isfinite(v[j]):break
        selected.append(j);available[j]=False
        coef=fit_ls(d,y,selected,anchor,penalty=20.0 if anchor else 0)
    return selected,coef

def predict(d,selected,coef):return d[:,selected]@coef if selected else np.zeros(len(d))

def metric(y,p):return float(np.mean((y-p)**2))

def fit_families(world):
    p=world['parts'];start_basis=time.perf_counter()
    d0=design(p['old_train']['x'],np.zeros(OLD_N,dtype=int))
    d1=design(p['new_train']['x'],np.ones(NEW_N,dtype=int))
    d=np.vstack([d0,d1]);y=np.r_[p['old_train']['y'],p['new_train']['y']]
    k=len(GRAMMAR)
    common_basis_s=time.perf_counter()-start_basis
    t=time.perf_counter()
    selected0,c0=discover(d0,p['old_train']['y'],k,4)
    anchor=dict(zip(selected0,c0))
    # Structural memory and rehearsal: carry stage-one motifs as locked shared rules,
    # then discover new rules using exactly the same cumulative 192 observations as controls.
    keep=min(len(selected0),3)
    selected,c=discover(d,y,2*k,MAX_SUPPORT,locked=selected0[:keep],anchor=anchor)
    fit_s=time.perf_counter()-t
    methods={}
    methods['energy_structural']={'sel':selected,'coef':c.tolist(),'old_sel':selected0,'old_coef':c0.tolist(),'fit_s':fit_s+common_basis_s}
    # No-memory ablation: same selection grammar and fit budget, no locked factors/replay anchor.
    t=time.perf_counter();s_free,c_free=discover(d,y,2*k,MAX_SUPPORT)
    methods['energy_no_memory']={'sel':s_free,'coef':c_free.tolist(),'fit_s':time.perf_counter()-t+common_basis_s}
    # Matched conventional structural-memory control: OMP discovers four stage-one
    # factors from full dictionary, fixes three shared candidates, then warm-starts
    # from 192 labeled interventions with no special energy anchoring penalty.
    t=time.perf_counter();ompo=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(d0,p['old_train']['y'])
    oold=np.flatnonzero(np.abs(ompo.coef_)>1e-9).tolist()
    oold=sorted(oold,key=lambda z:-abs(ompo.coef_[z]))[:3]
    oms,omc=discover(d,y,2*k,MAX_SUPPORT,locked=oold)
    methods['omp_structural_memory']={'sel':oms,'coef':omc.tolist(),'fit_s':time.perf_counter()-t+common_basis_s}
    # Standard exhaustive factor-library OMP, same feature family and sparsity budget.
    t=time.perf_counter();omp=OrthogonalMatchingPursuit(n_nonzero_coefs=MAX_SUPPORT,fit_intercept=True)
    omp.fit(d,y);methods['omp_full']={'model':omp,'fit_s':time.perf_counter()-t+common_basis_s}
    # Stronger regularized dense conventional estimator.
    t=time.perf_counter();ridge=Ridge(alpha=40.0).fit(d,y);methods['ridge_full']={'model':ridge,'fit_s':time.perf_counter()-t+common_basis_s}
    t=time.perf_counter();lasso=ElasticNet(alpha=0.025,l1_ratio=0.85,max_iter=5000,tol=1e-5,random_state=0)
    lasso.fit(d,y);methods['elastic_net_full']={'model':lasso,'fit_s':time.perf_counter()-t+common_basis_s}
    # Nonlinear conventional learner on same observed raw action, environment label.
    Xraw=np.vstack([np.c_[p['old_train']['x'],np.zeros(OLD_N)],np.c_[p['new_train']['x'],np.ones(NEW_N)]])
    t=time.perf_counter();forest=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=int(world['seed'])+int(world['case'].split(':')[0]));forest.fit(Xraw,y)
    methods['forest_raw']={'model':forest,'fit_s':time.perf_counter()-t+common_basis_s}
    # Sham label negative: same energy architecture, same action count, permuted stage1+stage2 consequences.
    t=time.perf_counter();yp=rng(world['seed'],world['case'],'sham').permutation(y)
    s_sham,c_sham=discover(d,yp,2*k,MAX_SUPPORT)
    methods['shuffled_energy']={'sel':s_sham,'coef':c_sham.tolist(),'fit_s':time.perf_counter()-t+common_basis_s}
    return methods

def score_world(world):
    parts=world['parts'];methods=fit_families(world);scores={};k=len(GRAMMAR)
    for name,m in methods.items():
        t=time.perf_counter();s={}
        for key in ['old_held','new_held','cold_held']:
            z=parts[key];stage=np.full(len(z['x']),z['stage'],dtype=int)
            if name=='forest_raw':q=np.c_[z['x'],stage];yp=m['model'].predict(q)
            elif name in ('omp_full','ridge_full','elastic_net_full'):yp=m['model'].predict(design(z['x'],stage))
            else:yp=predict(design(z['x'],stage),m['sel'],np.asarray(m['coef']))
            s[key]=metric(z['y'],yp)
        if name in ('energy_no_memory','omp_structural_memory','shuffled_energy'):
            s['selected']=m['sel'];s['coef']=m['coef']
        if name=='energy_structural':
            z=parts['old_held'];yp=predict(design(z['x'],np.zeros(len(z['x']),dtype=int)),m['old_sel'],np.asarray(m['old_coef']))
            s['old_before']=metric(z['y'],yp)
            inferred={j if j<k else j-k for j in m['sel']};truth=set(world['truth'])
            s['true_factor_recall']=len(inferred.intersection(truth))/len(truth)
            s['found']=sorted(inferred)
            s['selected']=m['sel'];s['coef']=m['coef'];s['old_selected']=m['old_sel'];s['old_coef']=m['old_coef']
        s['fit_s']=m['fit_s'];s['pred_s']=time.perf_counter()-t
        scores[name]=s
    return scores

def run(seeds,world_ids,mode):
    t=time.perf_counter();cases=[];methods=['energy_structural','energy_no_memory','omp_structural_memory','omp_full','ridge_full','elastic_net_full','forest_raw','shuffled_energy']
    for seed in seeds:
        for world_id in world_ids:
            for fam in FAMILIES:
                w=make_world(seed,world_id,fam)
                scores=score_world(w)
                # Exact identity anchors to rederive truth without exposing it during fitting.
                case={'seed':seed,'world':world_id,'family':fam,'truth':w['truth'],'weights':w['weights'], 'scores':scores}
                cases.append(case)
    agg={}
    for m in methods:
        agg[m]={key:float(np.mean([z['scores'][m][key] for z in cases])) for key in ['old_held','new_held','cold_held']}
        agg[m]['fit_s']=float(sum(z['scores'][m]['fit_s'] for z in cases));agg[m]['pred_s']=float(sum(z['scores'][m]['pred_s'] for z in cases))
    agg['energy_structural']['old_before']=float(np.mean([z['scores']['energy_structural']['old_before'] for z in cases]))
    agg['energy_structural']['true_factor_recall']=float(np.mean([z['scores']['energy_structural']['true_factor_recall'] for z in cases]))
    return {'schema':'energy43.primary.v1','mode':mode,'seeds':seeds,'world_ids':world_ids,'families':FAMILIES,'source_n':N,'grammar_size':len(GRAMMAR),'cases':cases,'aggregate':agg,'wall_s':time.perf_counter()-t}

def decide(out,thresholds):
    a=out['aggregate'];e=a['energy_structural'];baseline=min(a[k]['cold_held'] for k in ('omp_structural_memory','omp_full','ridge_full','elastic_net_full','forest_raw'))
    seed_win=0
    for seed in out['seeds']:
        xs=[z for z in out['cases'] if z['seed']==seed]
        one=np.mean([z['scores']['energy_structural']['cold_held'] for z in xs]);other=min(np.mean([z['scores'][k]['cold_held'] for z in xs]) for k in ('omp_structural_memory','omp_full','ridge_full','elastic_net_full','forest_raw'))
        seed_win+=int(one<other)
    cost=e['fit_s']+e['pred_s'];opp=a['omp_full']['fit_s']+a['omp_full']['pred_s']
    gates={
        'cold_relative_gain_vs_strongest_10pct':e['cold_held']<=.9*baseline,
        'shared_factor_recall_at_least_60pct':e['true_factor_recall']>=.60,
        'old_retention_inflation_at_most_10pct':e['old_held']<=1.1*e['old_before'],
        'old_no_worse_than_best_control_5pct':e['old_held']<=1.05*min(a[k]['old_held'] for k in ('omp_structural_memory','omp_full','ridge_full','elastic_net_full','forest_raw')),
        'sham_negative_cold_relative_gain_20pct':e['cold_held']<=.8*a['shuffled_energy']['cold_held'],
        'seed_stability_two_of_three':seed_win>=2,
        'fit_and_eval_cost_at_most_2x_omp':cost<=2*opp,
    }
    return {'gates':gates,'passes':sum(gates.values()),'baseline_cold':baseline,'seed_wins':seed_win,'energy_cpu_s':cost,'omp_cpu_s':opp,'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO'}

def canonical(o):
    import copy
    o=copy.deepcopy(o);o.pop('wall_s',None)
    for m in o['aggregate'].values():m.pop('fit_s',None);m.pop('pred_s',None)
    for c in o['cases']:
        for q in c['scores'].values():q.pop('fit_s',None);q.pop('pred_s',None)
    return json.dumps(o,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--primary',action='store_true');ap.add_argument('--out',required=True);args=ap.parse_args()
    if args.smoke==args.primary:raise SystemExit('Choose exactly one --smoke or --primary')
    o=run([SMOKE_SEED] if args.smoke else PRIMARY_SEEDS,[0] if args.smoke else list(range(4)),'smoke' if args.smoke else 'primary')
    o['decision']=decide(o,None)
    Path(args.out).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'worlds':len(o['cases']),'decision':o['decision'],'agg':o['aggregate'],'wall_s':o['wall_s'],'semantic_sha256':hashlib.sha256(canonical(o)).hexdigest()}))
if __name__=='__main__':main()
