#!/usr/bin/env python3
"""Independent ENERGY-43 generator, source-label, structure, and 8-arm refit audit.
No import from experiment.py. Third-party NumPy/sklearn remains shared.
"""
import argparse,hashlib,itertools,json,os
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge,OrthogonalMatchingPursuit,ElasticNet
from sklearn.ensemble import RandomForestRegressor

SIZE=12
G=([('P1',tuple(c)) for c in itertools.combinations(range(12),1)]+
   [('P2',tuple(c)) for c in itertools.combinations(range(12),2)]+
   [('P3',tuple(c)) for c in itertools.combinations(range(12),3)]+
   [('A2',tuple(c)) for c in itertools.combinations(range(12),2)])
K=len(G)

def seedint(*parts):
    b=('E43:v1:'+':'.join(map(str,parts))).encode()
    return int.from_bytes(hashlib.sha256(b).digest()[:8],'little')

def randomizer(*p):return np.random.default_rng(seedint(*p))

def xmatrix(seed,identifier,part,environment,num):
    a=randomizer(seed,identifier,part).integers(0,2,(num,SIZE),dtype=np.int8)
    gen=randomizer(seed,identifier,part,'spur')
    if environment=='old':
        a[:,10]=np.logical_xor(a[:,0],gen.random(num)<.07)
        a[:,11]=np.logical_xor(a[:,1],gen.random(num)<.07)
    elif environment=='new':
        a[:,10]=np.logical_xor(1-a[:,0],gen.random(num)<.07)
        a[:,11]=np.logical_xor(a[:,2],gen.random(num)<.07)
    else:
        a[:,10]=gen.integers(0,2,num);a[:,11]=gen.integers(0,2,num)
    return a

def factor(x,typ,axes):
    if typ.startswith('P'):
        bit=np.zeros(x.shape[0],dtype=np.int8)
        for axis in axes:bit=np.bitwise_xor(bit,x[:,axis])
        return 1.-2.*bit if len(axes)%2==0 else 2.*bit-1.
    active=np.ones(len(x),dtype=bool)
    for axis in axes:active&=(x[:,axis]==1)
    return 2.*active.astype(float)-1.

def fullbasis(x):
    return np.column_stack([factor(x,typ,axes) for typ,axes in G]).astype(float)

def src(seed,identifier,family):
    gen=randomizer(seed,identifier,family,'factors')
    allowed=[ix for ix,(kind,axes) in enumerate(G) if kind in {'parity2':['P2'],'parity3':['P3'],'mixed':['P2','P3','A2']}[family] and max(axes)<10]
    chosen=gen.choice(allowed,size=5,replace=False).tolist()
    effects=(gen.choice([-1.,1.],5)*gen.uniform(.85,1.15,5)).tolist()
    return chosen,effects

def build(seed,identifier,family):
    chosen,impacts=src(seed,identifier,family)
    groups={}
    for part,env,stage,count in [('old_train','old',0,96),('new_train','new',1,96),('old_held','old',0,128),('new_held','new',1,128),('cold_held','cold',1,128)]:
        x=xmatrix(seed,identifier,part,env,count)
        allphi=np.column_stack([factor(x,*G[j]) for j in chosen])
        y=allphi[:,:3]@np.array(impacts[:3])+allphi[:,3+stage]*impacts[3+stage]
        y=y+randomizer(seed,identifier,part,'noise').normal(0,.3,count)
        groups[part]=(x,y,stage)
    return chosen,impacts,groups

def aug(x,stage):
    b=fullbasis(x)
    return np.column_stack([b,b*(np.array(stage)==1)[:,None]])

def ls(M,y,terms,anchored=None):
    if not terms:return np.zeros(0)
    mat=M[:,terms];p=mat.T@mat+.02*np.eye(len(terms));rhs=mat.T@y
    if anchored:
        for k,ind in enumerate(terms):
            if ind in anchored:p[k,k]+=20.;rhs[k]+=20.*anchored[ind]
    return np.linalg.solve(p,rhs)

def reconstruct(M,y,allowed,limit,initial=(),anchored=None):
    chosen=list(initial)
    beta=ls(M,y,chosen,anchored)
    for unused in range(limit-len(chosen)):
        resid=y-(M[:,chosen]@beta if chosen else 0)
        allcor=M[:,:allowed].T@resid
        norms=np.sqrt(np.einsum('ij,ij->j',M[:,:allowed],M[:,:allowed]))
        priorities=np.divide(np.abs(allcor),norms,out=np.zeros(allowed),where=norms>0)
        priorities[chosen]=-np.inf
        idx=int(np.argmax(priorities))
        if not np.isfinite(priorities[idx]):break
        chosen.append(idx);beta=ls(M,y,chosen,anchored)
    return chosen,beta

def msematch(got,expected,loc,errors,atol=3e-8):
    if not np.isclose(float(got),float(expected),rtol=1e-8,atol=atol):errors.append({'at':loc,'expected':float(expected),'got':float(got)})

def audit(record):
    problems=[];checks=0
    assert record['schema']=='energy43.primary.v1' and record['grammar_size']==K and record['source_n']==12
    rows=record['cases'];expected=len(record['seeds'])*len(record['world_ids'])*len(record['families']);assert len(rows)==expected
    scores_by_name={}
    names=['energy_structural','energy_no_memory','omp_structural_memory','omp_full','ridge_full','elastic_net_full','forest_raw','shuffled_energy']
    for z in rows:
        seed=int(z['seed']);identifier=f"{z['world']}:{z['family']}"
        truth,weights,sets=build(seed,identifier,z['family'])
        if truth!=z['truth']:problems.append((identifier,'truth',truth,z['truth']))
        checks+=1
        for t1,t2 in zip(weights,z['weights']):msematch(t1,t2,(identifier,'weight'),problems);checks+=1
        X0,Y0,_=sets['old_train'];X1,Y1,_=sets['new_train']
        D0=aug(X0,np.zeros(len(X0),dtype=int));D1=aug(X1,np.ones(len(X1),dtype=int))
        D=np.concatenate([D0,D1]); Y=np.concatenate([Y0,Y1]);
        oldsel,oldcoef=reconstruct(D0,Y0,K,4)
        def check_selector(name,sel,coef):
            receipt=z['scores'][name]
            if receipt.get('selected')!=sel:problems.append((identifier,name,'factor structure mismatch',receipt.get('selected'),sel))
            checks_=len(coef)
            for expected_v,got_v in zip(coef,receipt.get('coef',[])):
                msematch(got_v,expected_v,(identifier,name,'weight'),problems)
            return checks_
        # Required structural memory and multi-stage anchoring.
        saved=dict(zip(oldsel,oldcoef));sel,coef=reconstruct(D,Y,2*K,7,oldsel[:3],saved)
        checks+=check_selector('energy_structural',sel,coef)
        for got,want in zip(oldcoef,z['scores']['energy_structural']['old_coef']):msematch(got,want,(identifier,'old coefficient'),problems);checks+=1
        if oldsel!=z['scores']['energy_structural']['old_selected']:problems.append((identifier,'old factor mismatch'))
        free,fc=reconstruct(D,Y,2*K,7)
        checks+=check_selector('energy_no_memory',free,fc)
        old_omp=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(D0,Y0)
        locked=sorted(np.flatnonzero(abs(old_omp.coef_)>1e-9).tolist(),key=lambda j:-abs(old_omp.coef_[j]))[:3]
        ompc,oc=reconstruct(D,Y,2*K,7,locked)
        checks+=check_selector('omp_structural_memory',ompc,oc)
        sy=randomizer(seed,identifier,'sham').permutation(Y)
        sh,shc=reconstruct(D,sy,2*K,7)
        checks+=check_selector('shuffled_energy',sh,shc)
        omp=OrthogonalMatchingPursuit(n_nonzero_coefs=7,fit_intercept=True).fit(D,Y)
        ridge=Ridge(alpha=40.).fit(D,Y)
        lasso=ElasticNet(alpha=.025,l1_ratio=.85,max_iter=5000,tol=1e-5,random_state=0).fit(D,Y)
        raw=np.concatenate([np.c_[X0,np.zeros(96)],np.c_[X1,np.ones(96)]])
        forest=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=seed+int(z['world'])).fit(raw,Y)
        infer={
            'energy_structural':lambda v:aug(*v[:1],np.full(len(v[0]),v[2]))[:,sel]@coef,
            'energy_no_memory':lambda v:aug(v[0],np.full(len(v[0]),v[2]))[:,free]@fc,
            'omp_structural_memory':lambda v:aug(v[0],np.full(len(v[0]),v[2]))[:,ompc]@oc,
            'omp_full':lambda v:omp.predict(aug(v[0],np.full(len(v[0]),v[2]))),
            'ridge_full':lambda v:ridge.predict(aug(v[0],np.full(len(v[0]),v[2]))),
            'elastic_net_full':lambda v:lasso.predict(aug(v[0],np.full(len(v[0]),v[2]))),
            'forest_raw':lambda v:forest.predict(np.c_[v[0],np.full(len(v[0]),v[2])]),
            'shuffled_energy':lambda v:aug(v[0],np.full(len(v[0]),v[2]))[:,sh]@shc
        }
        for name in names:
            scores_by_name.setdefault(name,{'old_held':[],'new_held':[],'cold_held':[]})
            for part in ('old_held','new_held','cold_held'):
                v=sets[part];pred=infer[name](v)
                mse=float(np.mean((v[1]-pred)**2))
                msematch(z['scores'][name][part],mse,(identifier,name,part),problems)
                scores_by_name[name][part].append(mse);checks+=len(pred)
        v=sets['old_held'];pred=aug(v[0],np.zeros(len(v[0]),dtype=int))[:,oldsel]@oldcoef
        msematch(z['scores']['energy_structural']['old_before'],np.mean((v[1]-pred)**2),(identifier,'old before'),problems);checks+=len(pred)
        recovered={i if i<K else i-K for i in sel}
        msematch(z['scores']['energy_structural']['true_factor_recall'],len(recovered.intersection(truth))/5,(identifier,'factor recall'),problems);checks+=5
    for name in names:
        for part in ('old_held','new_held','cold_held'):
            v=np.mean(scores_by_name[name][part]);msematch(record['aggregate'][name][part],v,(name,part,'aggregate'),problems);checks+=1
    return {'status':'PASS' if not problems else 'FAIL','checks':checks,'worlds':len(rows),'errors':problems[:10], 'source_reconstructed':True,'all_8_arms_refit':True,'all_held_predictions_checked':True}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('--out',required=True);args=ap.parse_args()
    r= json.loads(Path(args.input).read_text());out=audit(r)
    Path(args.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='errors'},sort_keys=True))
    if out['status']!='PASS':print('FIRST_ERRORS',out['errors'][:5]);raise SystemExit(3)
if __name__=='__main__':main()
