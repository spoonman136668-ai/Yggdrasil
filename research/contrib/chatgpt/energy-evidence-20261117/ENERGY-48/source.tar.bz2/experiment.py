#!/usr/bin/env python3
"""ENERGY-48 external, synthetic *active intervention acquisition* experiment.
Scores only after separately frozen source AND prereg commits on GitHub.
Never uses a native Yggdrasil checkpoint, runner, or accepted scientific data.
"""
import argparse,hashlib,itertools,json,time,warnings
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet

PRIMARY=(9109,9127,9137)
SMOKE=99913
IDS=(0,1,2,3)
FAMILIES=('parity2','parity3','mixed')
FEATURES=[('p',v) for n in (1,2,3) for v in itertools.combinations(range(12),n)]+[('a',v) for v in itertools.combinations(range(12),2)]
K=len(FEATURES)
assert K==364
POLICIES=('contradiction_energy','contradiction_dense','committee','diverse','random','shuffled_contradiction','fixed')
LEARNERS=('elasticnet','omp7')
ARM_NAMES=[f'{p}:{m}' for p in POLICIES for m in LEARNERS]
BUDGET=24

def rng(*parts):
    seed=int.from_bytes(hashlib.sha256(('ENERGY48-v1|'+'|'.join(map(str,parts))).encode()).digest()[:8],'big')
    return np.random.default_rng(seed)

def phi(x):
    x=np.asarray(x,dtype=np.int8)
    z=np.empty((len(x),K),dtype=np.float64)
    for j,(kind,sup) in enumerate(FEATURES):
        s=x[:,sup]
        if kind=='p':z[:,j]=1-2*np.bitwise_xor.reduce(s,axis=1)
        else:z[:,j]=2*np.all(s==1,axis=1).astype(float)-1
    return z

def actions(case,part,stage,n):
    g=rng(case,part,'actions'); x=g.integers(0,2,size=(n,12),dtype=np.int8)
    # Arbitrarily randomized interventions on causal bits; nuisance bits correlate in old/new context.
    if part!='cold_held':
        c0=x[:,0] if stage==0 else 1-x[:,0]
        c1=x[:,1] if stage==0 else x[:,2]
        x[:,10]=np.bitwise_xor(c0,(g.random(n)<.08).astype(np.int8))
        x[:,11]=np.bitwise_xor(c1,(g.random(n)<.08).astype(np.int8))
    return x

def world(seed,idx,family):
    case=f'{seed}:{idx}:{family}';g=rng(case,'latent')
    if family=='parity2': pool=[i for i,(k,s) in enumerate(FEATURES) if k=='p' and len(s)==2 and max(s)<10]
    elif family=='parity3':pool=[i for i,(k,s) in enumerate(FEATURES) if k=='p' and len(s)==3 and max(s)<10]
    else:pool=[i for i,(k,s) in enumerate(FEATURES) if len(s)>=2 and max(s)<10]
    ids=[int(x) for x in g.choice(pool,5,replace=False)]
    w=[float((-1 if g.random()<.5 else 1)*g.uniform(.85,1.15)) for _ in range(5)]
    changed=idx!=3
    if not changed: ids[4]=ids[3];w[4]=w[3]
    # This ground truth lives ONLY in world generation/scoring. Policy inputs below exclude ids and weights.
    return {'case':case,'seed':seed,'idx':idx,'family':family,'truth':ids,'weights':w,'changed':changed}

def consequences(W,x,part,stage):
    ids=W['truth'];w=np.array(W['weights'])
    v=phi(x)[:,ids];label=v[:,:3]@w[:3]+v[:,3+stage]*w[3+stage]
    return label+rng(W['case'],part,'noise').normal(0,.3,len(x))

def ompf(A,y,n):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        fit=OrthogonalMatchingPursuit(n_nonzero_coefs=n,fit_intercept=True).fit(A,y)
    return fit

def elf(A,y,alpha=.025):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        model=ElasticNet(alpha=alpha,l1_ratio=.85,max_iter=4000,tol=1e-5,fit_intercept=True).fit(A,y)
    return model

def select_by_score(scores,poolx,observedx,budget,diverse_weight=.18):
    # Pre-fixed greedy coverage constraint; ALWAYS computed on unlabeled actions only.
    selected=[]; distances=np.sum(poolx[:,None,:]!=observedx[None,:,:],axis=2).min(axis=1).astype(float)
    total=np.asarray(scores,dtype=float);scale=max(float(np.max(np.abs(total))),1e-8)
    rank=total/scale
    used=np.zeros(len(poolx),dtype=bool)
    for _ in range(budget):
        vals=rank+diverse_weight*distances/12.;vals[used]=-np.inf
        j=int(np.argmax(vals)); selected.append(j);used[j]=True
        distances=np.minimum(distances,np.sum(poolx!=poolx[j],axis=1))
    return selected

def choose(policy,Ax_old,y_old,Ax_new,y_new,pool_x,case):
    """Cannot access hidden true factors, pool labels, held actions or held outcomes."""
    start=time.perf_counter()
    xold=phi(Ax_old);xnew=phi(Ax_new);xp=phi(pool_x)
    if policy in ('random','fixed'):
        if policy=='fixed':chosen=list(range(BUDGET))
        else:chosen=[int(i) for i in rng(case,'random_selector').choice(len(pool_x),size=BUDGET,replace=False)]
    elif policy=='diverse':
        chosen=select_by_score(np.zeros(len(pool_x)),pool_x,Ax_new,BUDGET,diverse_weight=1.)
    else:
        if policy=='contradiction_energy':
            o=ompf(xold,y_old,4);n=ompf(xnew,y_new,4)
            score=np.abs(o.predict(xp)-n.predict(xp))
        elif policy=='contradiction_dense':
            o=elf(xold,y_old);n=elf(xnew,y_new)
            score=np.abs(o.predict(xp)-n.predict(xp))
        elif policy=='committee':
            ps=[]
            for j in range(4):
                inds=rng(case,'bootstrap',j).integers(0,len(y_new),len(y_new))
                ps.append(elf(xnew[inds],y_new[inds]).predict(xp))
            score=np.std(np.array(ps),axis=0)
        elif policy=='shuffled_contradiction':
            ybad=rng(case,'shuffled').permutation(y_new)
            o=ompf(xold,y_old,4);n=ompf(xnew,ybad,4)
            score=np.abs(o.predict(xp)-n.predict(xp))
        else:raise ValueError(policy)
        chosen=select_by_score(score,pool_x,Ax_new,BUDGET)
    return chosen,time.perf_counter()-start

def gated(A0,A1):
    return np.vstack([np.column_stack([A0,np.zeros_like(A0)]),np.column_stack([np.zeros_like(A1),A1])])

def downstream(learner,Aold,yold,Anew,ynew,Told,Tnew,Tcold):
    a,b=phi(Aold),phi(Anew);g=gated(a,b);yy=np.concatenate([yold,ynew]);
    t0=np.column_stack([phi(Told),np.zeros((len(Told),K))])
    t1=np.column_stack([np.zeros((len(Tnew),K)),phi(Tnew)])
    tc=np.column_stack([np.zeros((len(Tcold),K)),phi(Tcold)])
    start=time.perf_counter()
    if learner=='elasticnet':fit=elf(g,yy)
    elif learner=='omp7':fit=ompf(g,yy,7)
    else:raise ValueError(learner)
    ans=[fit.predict(x).tolist() for x in (t0,t1,tc)]
    return ans,time.perf_counter()-start

def one_case(seed,idx,family):
    W=world(seed,idx,family);case=W['case']
    Xold=actions(case,'old_train',0,96);Yold=consequences(W,Xold,'old_train',0)
    Xnew=actions(case,'new_train',1,48);Ynew=consequences(W,Xnew,'new_train',1)
    Xpool=actions(case,'candidate_pool',1,192)
    # Labels generated AFTER all independent policy selections. No policy receives them.
    T=[actions(case,'old_held',0,128),actions(case,'new_held',1,128),actions(case,'cold_held',1,128)]
    target=[consequences(W,x,name,stage) for x,name,stage in zip(T,('old_held','new_held','cold_held'),(0,1,1))]
    selected={};cost={}
    for policy in POLICIES:
        ids,secs=choose(policy,Xold,Yold,Xnew,Ynew,Xpool,case)
        assert len(ids)==BUDGET and len(set(ids))==BUDGET and min(ids)>=0 and max(ids)<len(Xpool)
        selected[policy]=ids;cost[policy]=secs
    # The simulator has pool consequences; selected action labels become witnessed only after selection.
    allpool=consequences(W,Xpool,'candidate_pool',1)
    results={}
    for policy in POLICIES:
        indices=selected[policy]
        observed=np.concatenate([Xnew,Xpool[indices]])
        labels=np.concatenate([Ynew,allpool[indices]])
        for learner in LEARNERS:
            preds,sec=downstream(learner,Xold,Yold,observed,labels,*T)
            name=f'{policy}:{learner}'
            mse=[float(np.mean((np.array(p)-y)**2)) for p,y in zip(preds,target)]
            results[name]={'mse_old':mse[0],'mse_new':mse[1],'mse_cold':mse[2],
                           'pred_sha256':[hashlib.sha256(np.array(p,dtype='<f8').tobytes()).hexdigest() for p in preds],
                           'fit_predict_sec':sec}
    return {'case':case,'seed':seed,'idx':idx,'family':family,'changed':W['changed'],
            'truth_sha256':hashlib.sha256(json.dumps({'ids':W['truth'],'w':W['weights']},sort_keys=True).encode()).hexdigest(),
            'pool_x_sha256':hashlib.sha256(Xpool.tobytes()).hexdigest(),
            'held_sha256':[hashlib.sha256(np.asarray(y,dtype='<f8').tobytes()).hexdigest() for y in target],
            'selected':selected,'selection_sec':cost,'arms':results}

def summary(cases):
    policy_score={}
    for name in ARM_NAMES:
        policy=name.split(':')[0];ss={k:float(np.mean([c['arms'][name]['mse_'+k] for c in cases])) for k in ('old','new','cold')}
        ss['candidate_select_fit_predict_sec']=float(sum(c['selection_sec'][policy]+c['arms'][name]['fit_predict_sec'] for c in cases))
        ss['changed_cold_mse']=float(np.mean([c['arms'][name]['mse_cold'] for c in cases if c['changed']]))
        ss['nochange_cold_mse']=float(np.mean([c['arms'][name]['mse_cold'] for c in cases if not c['changed']]))
        policy_score[name]=ss
    candidate=policy_score['contradiction_energy:elasticnet']
    others=['contradiction_dense:elasticnet','committee:elasticnet','diverse:elasticnet','random:elasticnet','shuffled_contradiction:elasticnet','fixed:elasticnet']
    winner=min(others,key=lambda x:policy_score[x]['cold']);closest=policy_score[winner]
    seedwins=[]
    for seed in sorted({c['seed'] for c in cases}):
        sub=[c for c in cases if c['seed']==seed]
        val=np.mean([c['arms']['contradiction_energy:elasticnet']['mse_cold'] for c in sub])
        best=min(np.mean([c['arms'][n]['mse_cold'] for c in sub]) for n in others)
        seedwins.append(bool(val<best))
    random_ref=policy_score['random:elasticnet'];dense=policy_score['contradiction_dense:elasticnet'];committee=policy_score['committee:elasticnet'];sham=policy_score['shuffled_contradiction:elasticnet']
    gates={
        'cold_5pct_gain_vs_strongest_conventional':candidate['cold']<=.95*closest['cold'],
        'cold_5pct_gain_vs_random':candidate['cold']<=.95*random_ref['cold'],
        'changed_cold_5pct_gain_vs_random':candidate['changed_cold_mse']<=.95*random_ref['changed_cold_mse'],
        'cold_2pct_gain_vs_dense_contradiction':candidate['cold']<=.98*dense['cold'],
        'cold_2pct_gain_vs_committee':candidate['cold']<=.98*committee['cold'],
        'old_retention_within_2pct_of_best':candidate['old']<=1.02*min(policy_score[n]['old'] for n in others),
        'shuffled_selector_negative_5pct':candidate['cold']<=.95*sham['cold'],
        'seed_stability_2of3':sum(seedwins)>=2,
        'cost_max_2x_random':candidate['candidate_select_fit_predict_sec']<=2*random_ref['candidate_select_fit_predict_sec']}
    return {'arms':policy_score,'best_conventional':winner,'gates':gates,'gates_passed':sum(gates.values()),'gates_total':len(gates),'seed_wins':seedwins,
            'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO'}

def canonical(record):
    # Reproducible model/prediction/selection receipt excluding performance timings.
    import copy
    a=copy.deepcopy(record)
    for case in a['cases']:
        case.pop('selection_sec',None)
        for row in case['arms'].values():row.pop('fit_predict_sec',None)
    for row in a['summary']['arms'].values():row.pop('candidate_select_fit_predict_sec',None)
    a.pop('wall_seconds',None)
    return json.dumps(a,sort_keys=True,separators=(',',':')).encode()

def run(seeds,ids,mode):
    start=time.perf_counter()
    cases=[one_case(seed,idx,family) for seed in seeds for idx in ids for family in FAMILIES]
    result={'schema':'yggdrasil.energy48.v1','mode':mode,'seeds':list(seeds),'ids':list(ids),'families':list(FAMILIES),
            'primary_seeds':list(PRIMARY),'excluded_smoke':SMOKE,'cases':cases,'summary':summary(cases),'wall_seconds':time.perf_counter()-start}
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=('smoke','primary'),required=True);ap.add_argument('--out',required=True)
    args=ap.parse_args()
    seeds=(SMOKE,) if args.mode=='smoke' else PRIMARY;ids=(0,) if args.mode=='smoke' else IDS
    res=run(seeds,ids,args.mode);Path(args.out).write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'mode':args.mode,'cases':len(res['cases']),'summary':res['summary'],'semantic_sha256':hashlib.sha256(canonical(res)).hexdigest(),'wall_seconds':res['wall_seconds']},sort_keys=True))
