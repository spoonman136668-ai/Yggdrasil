#!/usr/bin/env python3
"""ENERGY-44 selective local predictive repair. External synthetic research only.
Immutable ENERGY-43 source is a dependency, not an accepted Yggdrasil checkpoint.
Primary seeds MUST NOT be executed until GitHub preregistration committed.
"""
import argparse, bz2, hashlib, importlib.util, json, time, sys
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor

BASE=Path(__file__).resolve().parent.parent/'energy43local'/'experiment.py.bz2'
if not BASE.exists():
    BASE=Path(__file__).resolve().parent.parent/'ENERGY-43'/'experiment.py.bz2'
SOURCE43_SHA='48a798f75c1afc9701158edb4131d076dbe07f9dd3ad9374b9095ad2b47fe79f'
b= bz2.decompress(BASE.read_bytes())
assert hashlib.sha256(b).hexdigest()==SOURCE43_SHA
mod=importlib.util.module_from_spec(importlib.util.spec_from_loader('energy43_reference',loader=None))
exec(compile(b,'ENERGY-43/experiment.py','exec'),mod.__dict__)
FAMILIES=mod.FAMILIES
SEEDS=[8713,8731,8741]; SMOKE_SEED=99829; IDS=[0,1,2,3]
K=len(mod.GRAMMAR)
ARMS=('selective_repair','omp_delta2','omp_structural_memory','full_omp7','stagewise_retrain','ridge','elasticnet','forest','no_repair','shuffled_delta')

def phi(x):return mod.basis(x).astype(float)

def ls(a,y,alpha=.02):return np.linalg.solve(a.T@a+alpha*np.eye(a.shape[1]),a.T@y)

def old_model(world):
    p=world['parts']['old_train'];o=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(phi(p['x']),p['y']);idx=np.flatnonzero(abs(o.coef_)>1.e-9).tolist()
    return idx,np.asarray(o.coef_)[idx]

def selective_pair(A,r):
    # Exactly two local context-specific repairs from a candidate set selected on *new witnessed outcomes* only.
    # No prior-stage coefficient may be changed. Minimize regularized violation energy on new-stage residual.
    corr=A.T@r;norm=np.sqrt((A*A).sum(axis=0));ranking=np.abs(corr)/np.maximum(norm,1.e-12)
    top=np.argsort(-ranking,kind='stable')[:16]
    best=(float('inf'),(9999,9999),None)
    for n,i in enumerate(top):
        for j in top[n+1:]:
            order=tuple(sorted((int(i),int(j))));B=A[:,list(order)]
            coef=ls(B,r)
            cost=float(np.mean((r-B@coef)**2)+.0001*float(np.dot(coef,coef)))
            item=(cost,order,coef)
            if item[:2]<best[:2]:best=item
    return list(best[1]),best[2]

def predict_factors(x,oldsel,oldcoef,delta=None,dc=None):
    a=phi(x);y=a[:,oldsel]@oldcoef
    if delta is not None:y=y+a[:,delta]@dc
    return y

def score_case(seed,idx,fam):
    w=mod.make_world(seed,idx,fam);p=w['parts'];T=time.perf_counter();olds,oldc=old_model(w)
    a=phi(p['new_train']['x']);r=p['new_train']['y']-a[:,olds]@oldc
    selected,coef=selective_pair(a,r);fit_s=time.perf_counter()-T
    t=time.perf_counter();op=OrthogonalMatchingPursuit(n_nonzero_coefs=2,fit_intercept=False).fit(a,r)
    ops=np.flatnonzero(abs(op.coef_)>1e-9).tolist();opc=np.asarray(op.coef_)[ops];omp2_fit_s=time.perf_counter()-t
    oldd=mod.design(p['old_train']['x'],np.zeros(len(p['old_train']['x']),dtype=int));newd=mod.design(p['new_train']['x'],np.ones(len(p['new_train']['x']),dtype=int))
    d=np.vstack([oldd,newd]);y=np.r_[p['old_train']['y'],p['new_train']['y']]
    k=len(mod.GRAMMAR);oldbase=phi(p['old_train']['x']);newbase=phi(p['new_train']['x'])
    t=time.perf_counter();o0=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(oldd,p['old_train']['y']);lock=sorted(np.flatnonzero(abs(o0.coef_)>1e-9).tolist(),key=lambda j:-abs(o0.coef_[j]))[:3]
    oc,ow=mod.discover(d,y,2*k,7,locked=lock);struct_fit=time.perf_counter()-t
    t=time.perf_counter();full=OrthogonalMatchingPursuit(n_nonzero_coefs=7,fit_intercept=True).fit(d,y);full_fit=time.perf_counter()-t
    t=time.perf_counter();restart=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(newbase,p['new_train']['y']);restart_fit=time.perf_counter()-t
    t=time.perf_counter();rid=Ridge(alpha=40).fit(d,y);rid_fit=time.perf_counter()-t
    t=time.perf_counter();enet=ElasticNet(alpha=.025,l1_ratio=.85,max_iter=5000,tol=1e-5,random_state=0).fit(d,y);enet_fit=time.perf_counter()-t
    t=time.perf_counter();raw=np.r_[np.c_[p['old_train']['x'],np.zeros(len(oldbase))],np.c_[p['new_train']['x'],np.ones(len(newbase))]]
    forest=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=seed+idx).fit(raw,y);forest_fit=time.perf_counter()-t
    t=time.perf_counter();sham=mod.rng(seed,w['case'],'E44-sham').permutation(r)
    shsel,shcoef=selective_pair(a,sham);sham_fit=time.perf_counter()-t
    fitted={'selective_repair':(fit_s,selected,coef),'omp_delta2':(omp2_fit_s,ops,opc),'omp_structural_memory':(struct_fit,oc,ow),'full_omp7':(full_fit,None,None),'stagewise_retrain':(restart_fit,None,None),'ridge':(rid_fit,None,None),'elasticnet':(enet_fit,None,None),'forest':(forest_fit,None,None),'no_repair':(0.,None,None),'shuffled_delta':(sham_fit,shsel,shcoef)}
    out={}
    for arm,(tf,_,__) in fitted.items():
        t=time.perf_counter();met={}
        for env in ('old_held','new_held','cold_held'):
            group=p[env];stage=group['stage'];X=group['x'];a=phi(X)
            if arm in ('selective_repair','omp_delta2','no_repair','shuffled_delta'):
                repair={'selective_repair':(selected,coef),'omp_delta2':(ops,opc),'shuffled_delta':(shsel,shcoef)}
                yy=a[:,olds]@oldc
                if stage and arm!='no_repair':
                    terms,weights=repair[arm];yy=yy+a[:,terms]@weights
            elif arm=='omp_structural_memory':yy=mod.design(X,np.full(len(X),stage,dtype=int))[:,oc]@ow
            elif arm=='full_omp7':yy=full.predict(mod.design(X,np.full(len(X),stage,dtype=int)))
            elif arm=='stagewise_retrain':yy=(restart.predict(a) if stage else a[:,olds]@oldc)
            elif arm=='ridge':yy=rid.predict(mod.design(X,np.full(len(X),stage,dtype=int)))
            elif arm=='elasticnet':yy=enet.predict(mod.design(X,np.full(len(X),stage,dtype=int)))
            elif arm=='forest':yy=forest.predict(np.c_[X,np.full(len(X),stage)])
            met[env]=float(np.mean((yy-group['y'])**2))
        met['fit_s']=float(tf);met['pred_s']=time.perf_counter()-t
        out[arm]=met
    for name,terms,weights in [('selective_repair',selected,coef),('omp_delta2',ops,opc),('shuffled_delta',shsel,shcoef)]:
        out[name]['repair_terms']=terms;out[name]['repair_weights']=np.asarray(weights).tolist()
    out['selective_repair']['old_terms']=olds;out['selective_repair']['old_weights']=oldc.tolist()
    out['selective_repair']['true_delta_recall']=len({z for z in selected if z in w['truth'][3:5]})/2
    out['selective_repair']['old_before']=out['no_repair']['old_held']
    out['omp_structural_memory']['terms']=oc;out['omp_structural_memory']['weights']=np.asarray(ow).tolist()
    return {'seed':seed,'world':idx,'family':fam,'truth':w['truth'],'truth_weights':w['weights'],'scores':out}

def summarize(cases):
    aggregate={}
    for arm in ARMS:
        aggregate[arm]={a:float(np.mean([r['scores'][arm][a] for r in cases])) for a in ('old_held','new_held','cold_held')}
        aggregate[arm]['fit_s']=sum(r['scores'][arm]['fit_s'] for r in cases)
        aggregate[arm]['pred_s']=sum(r['scores'][arm]['pred_s'] for r in cases)
    aggregate['selective_repair']['true_delta_recall']=float(np.mean([r['scores']['selective_repair']['true_delta_recall'] for r in cases]))
    aggregate['selective_repair']['old_before']=float(np.mean([r['scores']['selective_repair']['old_before'] for r in cases]))
    return aggregate

def decide(cases,agg,seeds):
    cand=agg['selective_repair'];controls=['omp_delta2','omp_structural_memory','full_omp7','stagewise_retrain','ridge','elasticnet','forest']
    best=min(agg[k]['cold_held'] for k in controls);old_best=min(agg[k]['old_held'] for k in controls)
    wins=0
    for seed in seeds:
        same=[w for w in cases if w['seed']==seed]
        c=np.mean([z['scores']['selective_repair']['cold_held'] for z in same]);bc=min(np.mean([z['scores'][k]['cold_held'] for z in same]) for k in controls)
        wins+=int(c<bc)
    cpu=cand['fit_s']+cand['pred_s'];baseline=agg['omp_structural_memory']['fit_s']+agg['omp_structural_memory']['pred_s']
    gates={
      'cold_gain_vs_best_control_10pct':cand['cold_held']<=.9*best,
      'old_retention_max_1pct':cand['old_held']<=1.01*cand['old_before'],
      'old_vs_best_control_5pct':cand['old_held']<=1.05*old_best,
      'cold_gain_vs_omp_delta2_5pct':cand['cold_held']<=.95*agg['omp_delta2']['cold_held'],
      'cold_gain_vs_shuffled_20pct':cand['cold_held']<=.8*agg['shuffled_delta']['cold_held'],
      'new_mechanism_delta_recall_80pct':cand['true_delta_recall']>=.8,
      'seed_stability_2of3':wins>=2,
      'fit_predict_cpu_max_3x_omp_structural':cpu<=3*baseline,
    }
    return {'gates':gates,'passes':sum(gates.values()),'fails':len(gates)-sum(gates.values()),'best_cold_control_mse':best,'best_old_control_mse':old_best,'seed_wins':wins,'candidate_cpu_s':cpu,'omp_structural_cpu_s':baseline,'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO'}

def canonical(out):
    import copy
    x=copy.deepcopy(out);x.pop('wall_s',None)
    for a in x['aggregate'].values():a.pop('fit_s',None);a.pop('pred_s',None)
    for row in x['cases']:
        for m in row['scores'].values():m.pop('fit_s',None);m.pop('pred_s',None)
    x['decision'].pop('candidate_cpu_s',None);x['decision'].pop('omp_structural_cpu_s',None)
    x['decision']['gates'].pop('fit_predict_cpu_max_3x_omp_structural',None)
    x['decision'].pop('passes',None);x['decision'].pop('fails',None);x['decision'].pop('classification',None)
    return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def run(seeds,worlds,mode):
    t=time.perf_counter();cases=[score_case(s,i,f) for s in seeds for i in worlds for f in FAMILIES]
    aggregate=summarize(cases);decision=decide(cases,aggregate,seeds)
    return {'schema':'energy44.primary.v1','mode':mode,'seeds':seeds,'worlds':worlds,'families':FAMILIES,'cases':cases,'aggregate':aggregate,'decision':decision,'wall_s':time.perf_counter()-t}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--primary',action='store_true');ap.add_argument('--out',required=True);args=ap.parse_args()
    if args.smoke==args.primary:raise SystemExit('choose exactly one --smoke or --primary')
    out=run([SMOKE_SEED] if args.smoke else SEEDS,[0] if args.smoke else IDS,'smoke' if args.smoke else 'primary')
    Path(args.out).write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'count':len(out['cases']),'decision':out['decision'],'aggregation':out['aggregate'],'semantic_sha256':hashlib.sha256(canonical(out)).hexdigest()}))
if __name__=='__main__':main()
