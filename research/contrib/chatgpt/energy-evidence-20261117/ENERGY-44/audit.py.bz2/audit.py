#!/usr/bin/env python3
"""ENERGY-44 independent source/generator, least-squares and 10-arm refit audit.
Does NOT import ENERGY-44 experiment. Uses separately authored ENERGY-43 auditor generator.
"""
import argparse,bz2,hashlib,importlib.util,json,time
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,Ridge,ElasticNet
from sklearn.ensemble import RandomForestRegressor
ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'energy43local'/'audit.py.bz2'
if not BASE.exists():BASE=ROOT/'ENERGY-43'/'audit.py.bz2'
blob=bz2.decompress(BASE.read_bytes())
assert hashlib.sha256(blob).hexdigest()=='b838cf23568016d97c068c8ea0e1e818b9355ab3a28992d602d1cb4f4d775e61'
a=importlib.util.module_from_spec(importlib.util.spec_from_loader('independent43',loader=None))
exec(compile(blob,'ENERGY-43/audit.py','exec'),a.__dict__)
K=len(a.G)
NAMES=('selective_repair','omp_delta2','omp_structural_memory','full_omp7','stagewise_retrain','ridge','elasticnet','forest','no_repair','shuffled_delta')

def direct_pairs(A,r):
    # Independent exact 2D ridge-0.02 normal-equation solution, no import of candidate code.
    gamma=A.T@r;norms=np.sqrt((A*A).sum(axis=0));order=np.argsort(-np.abs(gamma)/np.maximum(norms,1.e-12),kind='stable')[:16]
    gram=A.T@A;ys=float(r@r);n=len(r)
    best=(float('inf'),(9999,9999),None)
    for ii,orig_i in enumerate(order):
        for orig_j in order[ii+1:]:
            i,j=sorted((int(orig_i),int(orig_j)))
            m=np.array([[gram[i,i]+.02,gram[i,j]],[gram[j,i],gram[j,j]+.02]])
            vals=np.array([gamma[i],gamma[j]])
            coef=np.linalg.solve(m,vals)
            B=A[:,[i,j]]
            err=(ys-2*float(coef@vals)+float(coef@gram[np.ix_([i,j],[i,j])]@coef))/n+.0001*float(coef@coef)
            record=(float(err),(i,j),coef)
            if record[:2]<best[:2]:best=record
    return list(best[1]),best[2]

def check(x,y,ctx,errors,atol=1e-7):
    if not np.isclose(float(x),float(y),rtol=1e-7,atol=atol):errors.append({'what':ctx,'reported':x,'expected':y})

def verify(record):
    if record['schema']!='energy44.primary.v1' or record['families']!=['parity2','parity3','mixed']:raise AssertionError('source schema mismatch')
    if len(record['cases'])!=len(record['seeds'])*len(record['worlds'])*3:raise AssertionError('case count')
    err=[];count=0;agg={n:{k:[] for k in ('old_held','new_held','cold_held')} for n in NAMES};delta_rec=[]
    for c in record['cases']:
        seed=c['seed'];idx=c['world'];fam=c['family'];identifier=f'{idx}:{fam}'
        truth,weights,parts=a.build(seed,identifier,fam)
        if truth!=c['truth']:err.append(('source truth',identifier))
        for got,v in zip(c['truth_weights'],weights):check(got,v,(identifier,'true-weight'),err)
        count+=5
        X0,Y0,_=parts['old_train'];X1,Y1,_=parts['new_train']
        A0=a.fullbasis(X0);A1=a.fullbasis(X1);M0=a.aug(X0,np.zeros(len(X0),dtype=int));M1=a.aug(X1,np.ones(len(X1),dtype=int));M=np.vstack([M0,M1]);Y=np.r_[Y0,Y1]
        trained=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(A0,Y0); oldsel=np.flatnonzero(abs(trained.coef_)>1.e-9).tolist();oldcoef=trained.coef_[oldsel];r=Y1-A1[:,oldsel]@oldcoef
        cand,cw=direct_pairs(A1,r)
        OMP2=OrthogonalMatchingPursuit(n_nonzero_coefs=2,fit_intercept=False).fit(A1,r)
        osel=np.flatnonzero(abs(OMP2.coef_)>1e-9).tolist();ow=OMP2.coef_[osel]
        old_aug=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(M0,Y0)
        locked=sorted(np.flatnonzero(abs(old_aug.coef_)>1e-9).tolist(),key=lambda i:-abs(old_aug.coef_[i]))[:3]
        struct,sw=a.reconstruct(M,Y,2*K,7,initial=locked)
        full=OrthogonalMatchingPursuit(n_nonzero_coefs=7,fit_intercept=True).fit(M,Y)
        restart=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False).fit(A1,Y1)
        ridge=Ridge(alpha=40).fit(M,Y)
        enet=ElasticNet(alpha=.025,l1_ratio=.85,max_iter=5000,tol=1e-5,random_state=0).fit(M,Y)
        raw=np.vstack([np.c_[X0,np.zeros(len(X0))],np.c_[X1,np.ones(len(X1))]])
        forest=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=seed+idx).fit(raw,Y)
        sham=a.randomizer(seed,identifier,'E44-sham').permutation(r)
        shuffled,scoef=direct_pairs(A1,sham)
        values={'selective_repair':(cand,cw),'omp_delta2':(osel,ow),'shuffled_delta':(shuffled,scoef)}
        for name,(terms,coef) in values.items():
            got=c['scores'][name]
            if terms!=got['repair_terms']:err.append((identifier,name,'selected factors',terms,got['repair_terms']))
            for x,v in zip(coef,got['repair_weights']):check(x,v,(identifier,name,'coef'),err)
            count+=len(terms)
        if oldsel!=c['scores']['selective_repair']['old_terms']:err.append((identifier,'old terms'))
        for x,v in zip(oldcoef,c['scores']['selective_repair']['old_weights']):check(x,v,(identifier,'oldcoef'),err)
        if struct!=c['scores']['omp_structural_memory']['terms']:err.append((identifier,'struct terms'))
        for x,v in zip(sw,c['scores']['omp_structural_memory']['weights']):check(x,v,(identifier,'struct weights'),err)
        recall=len(set(cand).intersection(truth[3:5]))/2;delta_rec.append(recall)
        check(c['scores']['selective_repair']['true_delta_recall'],recall,(identifier,'recall'),err)
        for env in ('old_held','new_held','cold_held'):
            X,yy,stage=parts[env];Phi=a.fullbasis(X);D=a.aug(X,np.full(len(X),stage));ex={}
            oldp=Phi[:,oldsel]@oldcoef
            for name in ('selective_repair','omp_delta2','shuffled_delta','no_repair'):
                pred=oldp.copy()
                if stage and name!='no_repair':
                    selected,coefs=values[name];pred=pred+Phi[:,selected]@coefs
                ex[name]=pred
            ex.update({
                'omp_structural_memory':D[:,struct]@sw,
                'full_omp7':full.predict(D),
                'stagewise_retrain':restart.predict(Phi) if stage else oldp,
                'ridge':ridge.predict(D),
                'elasticnet':enet.predict(D),
                'forest':forest.predict(np.c_[X,np.full(len(X),stage)])})
            for name,pred in ex.items():
                mse=float(np.mean((yy-pred)**2));check(c['scores'][name][env],mse,(identifier,name,env),err)
                agg[name][env].append(mse);count+=len(pred)
            if env=='old_held':check(c['scores']['selective_repair']['old_before'],float(np.mean((yy-oldp)**2)),(identifier,'old_before'),err)
    for name in NAMES:
        for env in ('old_held','new_held','cold_held'):
            check(record['aggregate'][name][env],float(np.mean(agg[name][env])),('agg',name,env),err);count+=1
    check(record['aggregate']['selective_repair']['true_delta_recall'],float(np.mean(delta_rec)),('agg','recall'),err)
    return {'status':'PASS' if not err else 'FAIL','checked':count,'worlds':len(record['cases']),'all_ten_arms_refit':True,'all_held_predictions_compared':True,'source_reconstructed_from_independent_generator':True,'errors':err[:15]}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('result');ap.add_argument('--out',required=True);x=ap.parse_args()
    scores=json.loads(Path(x.result).read_text());z=verify(scores);Path(x.out).write_text(json.dumps(z,indent=2)+'\n')
    print(json.dumps({k:v for k,v in z.items() if k!='errors'}))
    if z['status']!='PASS':print(z['errors'][:3]);raise SystemExit(4)
if __name__=='__main__':main()
