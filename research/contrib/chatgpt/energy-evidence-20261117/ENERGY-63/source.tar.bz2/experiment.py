"""ENERGY-63: externally scoped, synthetic compositional hypothesis memory. Frozen-source experiment."""
import argparse, hashlib, itertools, json, math, os, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet, OrthogonalMatchingPursuit
from sklearn.kernel_ridge import KernelRidge

FAMILIES=('recombine','return_old','novel_quad')
ARMS=('factor_map','factor_bayes','factor_ridge','softmax_memory','best_snapshot',
      'recent_elasticnet','pooled_elasticnet','recent_krr','old_no_update','shuffled_probe')
PAIRS=list(itertools.combinations(range(12),2))
CODES=np.array(list(itertools.product(range(3),repeat=4)),dtype=int)

def arr_hash(x):
    a=np.asarray(x,dtype='<f8')
    return hashlib.sha256(a.tobytes()).hexdigest()

def features(x):
    signs=2*np.asarray(x,dtype=float)-1
    return signs[:,np.array(PAIRS)[:,0]] * signs[:,np.array(PAIRS)[:,1]]

def world(seed,wi,fam):
    # Unique independent RNG per (cohort, world index, mechanism family).
    r=np.random.default_rng(int(seed)*1000 + wi*13 + FAMILIES.index(fam)*100_000_013)
    supp=np.sort(r.permutation(10)[:8].reshape((4,2)),axis=1)
    mags=np.array([.85,1.05,1.15,1.35])
    a=r.choice([-1.,1.],size=4)*mags
    b=a.copy(); b[[0,2]]*=-1
    c=a.copy(); c[[1,3]]*=-1
    choices=np.array([0,1,2,1]); choices=choices[r.permutation(4)]
    prior=np.stack((a,b,c))
    d=prior[choices,np.arange(4)].copy() if fam!='return_old' else a.copy()
    four=np.sort(r.choice(10,size=4,replace=False))
    ids=r.permutation(1024)[:502]
    splits=[('A',80),('B',80),('C',80),('probe',6),('held_A',64),('held_B',64),('held_D',64),('held_cold',64)]
    sections={}
    offset=0
    for name,n in splits:
        taken=ids[offset:offset+n];offset+=n
        x10=((taken[:,None] >> np.arange(10))&1).astype(int)
        x=np.zeros((n,12),dtype=int);x[:,:10]=x10
        # Context-specific nuisance cues; cold cues are independent of effects.
        if name=='held_cold':
            x[:,10:]=r.integers(0,2,size=(n,2))
        else:
            cue1=x10[:,int(supp[0,0])].copy()
            cue2=x10[:,int(supp[1,0])].copy()
            if name in ('B','C','held_B'):
                cue1=1-cue1
            if name in ('C',):cue2=1-cue2
            cue1=np.bitwise_xor(cue1,(r.random(n)<.12).astype(int))
            cue2=np.bitwise_xor(cue2,(r.random(n)<.12).astype(int))
            x[:,10]=cue1;x[:,11]=cue2
        coef={'A':a,'B':b,'C':c,'probe':d,'held_A':a,'held_B':b,'held_D':d,'held_cold':d}[name]
        core=np.prod(2*x[:,supp]-1,axis=2)@coef
        extra=(1.30*np.prod(2*x[:,four]-1,axis=1)) if fam=='novel_quad' and name in ('probe','held_D','held_cold') else 0.
        y=core+extra+r.normal(0,.16,size=n)
        sections[name]={'ids':taken.astype(int).tolist(),'x':x.tolist(),'y':y.tolist()}
    return {'seed':seed,'world_id':wi,'family':fam,'supports':supp.tolist(),
            'coefficients':np.vstack((a,b,c,d)).tolist(),'four_support':four.tolist(),
            'sections':sections}

def ridge_weights(X,y,alpha=.12):
    return np.linalg.solve(X.T@X+alpha*np.eye(X.shape[1]),X.T@y)

def fit_prediction(case):
    secs=case['sections']
    xs={n:np.asarray(s['x'],dtype=int) for n,s in secs.items()}
    ys={n:np.asarray(s['y'],dtype=float) for n,s in secs.items()}
    Fs={n:features(x) for n,x in xs.items()}
    omp=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False)
    omp.fit(Fs['A'],ys['A'])
    select=np.flatnonzero(np.abs(omp.coef_)>1e-12)
    if len(select)!=4: raise ValueError(f'OMP support not 4: {len(select)}')
    coefs=np.stack([ridge_weights(Fs[s][:,select],ys[s]) for s in ('A','B','C')])
    q=Fs['probe'][:,select]; y=ys['probe']
    code_weights=coefs[CODES,np.arange(4)[None,:]]
    yp=q@code_weights.T
    err=np.sum((yp-y[:,None])**2,axis=0)
    changes=(CODES!=0).sum(axis=1)
    # Candidate: minimum empirical contradiction plus fixed factor-switch cost.
    cost=err+.16*changes
    chosen=int(np.argmin(cost))
    candidate=code_weights[chosen]
    # Strong conventional comparator: exact finite-codebook Bayesian averaging.
    logprior=np.sum(np.log(np.array([.50,.25,.25]))[CODES],axis=1)
    lb=logprior-err/(2*.36**2)
    prob=np.exp(lb-lb.max());prob=prob/prob.sum()
    bayes=prob@code_weights
    mean=coefs.mean(axis=0)
    rb=ridge_weights_with_prior(q,y,mean,1.0)
    snapshots=q@coefs.T
    e=np.sum((snapshots-y[:,None])**2,axis=0)
    sm=np.exp(-(e-e.min())/(2*.36**2));sm=sm/sm.sum()
    softmax=sm@coefs
    best=coefs[int(np.argmin(e))]
    # Every conventional model is fully fitted with the same historical stream and probe.
    rp=np.concatenate((Fs['C'],Fs['probe']))
    ry=np.concatenate((ys['C'],ys['probe']))
    pp=np.concatenate((Fs['A'],Fs['B'],Fs['C'],Fs['probe']))
    py=np.concatenate((ys['A'],ys['B'],ys['C'],ys['probe']))
    re=ElasticNet(alpha=.035,l1_ratio=.8,fit_intercept=True,max_iter=3000,tol=1e-5,selection='cyclic').fit(rp,ry)
    pe=ElasticNet(alpha=.035,l1_ratio=.8,fit_intercept=True,max_iter=3000,tol=1e-5,selection='cyclic').fit(pp,py)
    krr=KernelRidge(alpha=.3,kernel='rbf',gamma=.18).fit(xs['C'].tolist()+xs['probe'].tolist(),ry)
    shuffled=ridge_weights_with_prior(q,y[::-1],mean,1.0)
    stored={'support_indices':select.tolist(),'memory_coefficients':coefs.tolist(),
            'candidate_code':CODES[chosen].tolist(),'candidate_code_index':chosen,
            'posterior_weights':prob.tolist(),'softmax_weights':sm.tolist(),
            'snapshot_probe_errors':e.tolist(),'codebook_probe_errors':err.tolist()}
    held={}
    for target in ('held_A','held_B','held_D','held_cold'):
        T=Fs[target][:,select]
        X=Fs[target]
        value={'factor_map':T@candidate,'factor_bayes':T@bayes,'factor_ridge':T@rb,
               'softmax_memory':T@softmax,'best_snapshot':T@best,
               'recent_elasticnet':re.predict(X),'pooled_elasticnet':pe.predict(X),
               'recent_krr':krr.predict(xs[target]),'old_no_update':T@coefs[0],
               'shuffled_probe':T@shuffled}
        # Dedicated immutable historical readout heads, also available to matched controls.
        if target == 'held_A':
            value['factor_map'] = T@coefs[0]
        if target == 'held_B':
            value['factor_map'] = T@coefs[1]
        held[target]={k:{'mse':float(np.mean((pred-ys[target])**2)),
                          'predictions':np.asarray(pred,dtype=float).tolist(),
                          'pred_sha256':arr_hash(pred)} for k,pred in value.items()}
    return stored,held

def ridge_weights_with_prior(X,y,prior,alpha):
    return np.linalg.solve(X.T@X+alpha*np.eye(X.shape[1]),X.T@y+alpha*prior)

def summarize(cases):
    arm_metrics={arm:{ctx:float(np.mean([c['held'][ctx][arm]['mse'] for c in cases]))
                          for ctx in ('held_A','held_B','held_D','held_cold')}
                  for arm in ARMS}
    def per_subset(xs):
        return {arm:float(np.mean([c['held']['held_cold'][arm]['mse'] for c in xs])) for arm in ARMS}
    seed_metrics={str(seed):per_subset([x for x in cases if x['seed']==seed]) for seed in sorted(set(x['seed'] for x in cases))}
    family_metrics={fam:per_subset([x for x in cases if x['family']==fam]) for fam in FAMILIES}
    cand=arm_metrics['factor_map']['held_cold']
    other=min(arm_metrics[a]['held_cold'] for a in ARMS if a not in ('factor_map','shuffled_probe','old_no_update'))
    stable_count=sum(seed_metrics[s]['factor_map']<min(v for k,v in seed_metrics[s].items() if k not in ('factor_map','shuffled_probe','old_no_update')) for s in seed_metrics)
    old_diff=max(abs(c['held']['held_A']['factor_map']['mse']-c['held']['held_A']['old_no_update']['mse']) for c in cases)
    exercised=sum(bool(np.any(np.array(c['memory']['candidate_code'])!=0)) for c in cases)
    gates={
      'cold_gain5_vs_best_other': cand<=.95*other,
      'cold_gain3_vs_exact_factor_bayes':cand<=.97*arm_metrics['factor_bayes']['held_cold'],
      'cold_gain3_vs_softmax_memory':cand<=.97*arm_metrics['softmax_memory']['held_cold'],
      'both_seeds_win_strongest':stable_count==len(seed_metrics),
      'family_non_degradation_10pct':all(family_metrics[f]['factor_map']<=1.1*min(v for k,v in family_metrics[f].items() if k not in ('factor_map','shuffled_probe','old_no_update')) for f in FAMILIES),
      'old_exact_frozen':old_diff<1e-10,
      'shuffled_negative_20pct':cand<=.8*arm_metrics['shuffled_probe']['held_cold'],
      'factor_switches_exercised_20pct':exercised>=math.ceil(.2*len(cases))}
    critical=('cold_gain5_vs_best_other','cold_gain3_vs_exact_factor_bayes','cold_gain3_vs_softmax_memory','both_seeds_win_strongest')
    promising=all(gates[k] for k in critical) and sum(gates.values())>=7
    return {'arm_metrics':arm_metrics,'by_seed':seed_metrics,'by_family':family_metrics,
            'gates':{k:bool(v) for k,v in gates.items()},'gate_pass':sum(bool(v) for v in gates.values()),'gate_total':len(gates),
            'critical_gates':list(critical),'switch_worlds':exercised,
            'old_mse_frozen_max_delta':old_diff,
            'classification':'SCREEN_PROMISING' if promising else 'SCREEN_NO_GO'}

def run(seeds,world_ids):
    t=time.perf_counter();cases=[]
    for seed in seeds:
        for fam in FAMILIES:
            for wi in world_ids:
                case=world(int(seed),int(wi),fam)
                memory,held=fit_prediction(case)
                case['memory']=memory;case['held']=held
                cases.append(case)
    return {'experiment':'ENERGY-63','seeds':list(seeds),'world_ids':list(world_ids),
            'families':list(FAMILIES),'cases':cases,'summary':summarize(cases),
            'runtime_seconds':time.perf_counter()-t}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--seeds',type=int,nargs='+',required=True)
    p.add_argument('--world-ids',type=int,nargs='+',default=[0,1,2,3])
    p.add_argument('--out',required=True)
    a=p.parse_args()
    result=run(a.seeds,a.world_ids)
    Path(a.out).write_text(json.dumps(result,separators=(',',':'),sort_keys=True)+'\n')
    print(json.dumps({'cases':len(result['cases']),'summary':result['summary'],'seconds':result['runtime_seconds']},sort_keys=True))
