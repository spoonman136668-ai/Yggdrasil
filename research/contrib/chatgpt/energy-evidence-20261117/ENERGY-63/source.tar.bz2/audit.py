"""ENERGY-63 independently authored audit. Never imports experiment.py."""
import argparse, hashlib, itertools, json, math
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet,OrthogonalMatchingPursuit
from sklearn.kernel_ridge import KernelRidge

PAIR_IDS=np.array(tuple(itertools.combinations(range(12),2)),dtype=int)
TEMPLATES=np.array(tuple(itertools.product((0,1,2),repeat=4)),dtype=int)
KINDS=('recombine','return_old','novel_quad')
MODELS=('factor_map','factor_bayes','factor_ridge','softmax_memory','best_snapshot','recent_elasticnet','pooled_elasticnet','recent_krr','old_no_update','shuffled_probe')
PHASES=(('A',80),('B',80),('C',80),('probe',6),('held_A',64),('held_B',64),('held_D',64),('held_cold',64))

def ref_truth(seed,index,kind):
    """Rederive concealed mechanisms/intervention receipts without invoking scorer."""
    rg=np.random.default_rng(1000*int(seed)+13*int(index)+100_000_013*KINDS.index(kind))
    pairs=np.sort(rg.permutation(10)[:8].reshape(4,2),axis=1)
    a=rg.choice(np.array([-1.,1.]),size=4)*np.array([.85,1.05,1.15,1.35])
    b=a.copy();b[0]=-b[0];b[2]=-b[2]
    c=a.copy();c[1]=-c[1];c[3]=-c[3]
    sel=np.array([0,1,2,1])[rg.permutation(4)]
    memory=np.array([a,b,c])
    d=a.copy() if kind=='return_old' else memory[sel,np.arange(4)].copy()
    other=np.sort(rg.choice(10,4,replace=False))
    permutation=rg.permutation(1024)[:502]
    answer={};head=0
    for name,n in PHASES:
        idx=permutation[head:head+n];head+=n
        bits=np.zeros((n,12),dtype=int)
        bits[:,:10]=(idx[:,None]>>np.arange(10))&1
        if name=='held_cold':
            bits[:,10:12]=rg.integers(0,2,size=(n,2))
        else:
            cu=bits[:,pairs[0,0]].copy()
            cv=bits[:,pairs[1,0]].copy()
            if name in ('B','C','held_B'):cu=1-cu
            if name=='C':cv=1-cv
            cu=np.bitwise_xor(cu,(rg.random(n)<.12).astype(int))
            cv=np.bitwise_xor(cv,(rg.random(n)<.12).astype(int))
            bits[:,10]=cu;bits[:,11]=cv
        coef={'A':a,'B':b,'C':c,'probe':d,'held_A':a,'held_B':b,'held_D':d,'held_cold':d}[name]
        Z=np.prod(2*bits[:,pairs]-1,axis=2)
        signal=Z.dot(coef)
        if kind=='novel_quad' and name in ('probe','held_D','held_cold'):
            signal=signal+1.30*np.prod(2*bits[:,other]-1,axis=1)
        ys=signal+rg.normal(0,.16,size=n)
        answer[name]={'ids':idx.tolist(),'x':bits.tolist(),'y':ys.tolist()}
    return pairs.tolist(),np.array([a,b,c,d]).tolist(),other.tolist(),answer

def pair_phi(x):
    z=2*np.asarray(x,dtype=np.float64)-1
    return z[:,PAIR_IDS[:,0]]*z[:,PAIR_IDS[:,1]]

def fit_prior(M,y,prior,precision):
    return np.linalg.solve(M.T@M+precision*np.eye(M.shape[1]), M.T@y+precision*prior)

def ordinary_ridge(M,y):
    return np.linalg.solve(M.T@M+.12*np.eye(M.shape[1]),M.T@y)

def compare_scalar(x,y,label):
    if not np.isclose(float(x),float(y),atol=1e-9,rtol=1e-9):
        raise AssertionError(f'{label} disagrees {x}, {y}')

def audit_case(raw):
    count=0
    support,coef,quad,expected=ref_truth(raw['seed'],raw['world_id'],raw['family'])
    assert support==raw['supports'] and quad==raw['four_support'];count+=2
    assert np.allclose(coef,raw['coefficients'],atol=0,rtol=0);count+=16
    actual=raw['sections'];ids=[]
    for phase,n in PHASES:
        a=actual[phase];b=expected[phase]
        assert a['ids']==b['ids'] and a['x']==b['x']
        assert np.allclose(np.asarray(a['y']),np.asarray(b['y']),atol=1e-12,rtol=0)
        assert len(a['ids'])==n
        ids.extend(a['ids']);count+=n*3
    assert len(ids)==len(set(ids))==502;count+=503
    x={name:np.asarray(raw['sections'][name]['x'],dtype=int) for name,_ in PHASES}
    y={name:np.asarray(raw['sections'][name]['y'],dtype=float) for name,_ in PHASES}
    phi={name:pair_phi(x[name]) for name,_ in PHASES}
    fitted=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=False)
    fitted.fit(phi['A'],y['A'])
    chosen=np.flatnonzero(abs(fitted.coef_)>1e-12)
    assert chosen.tolist()==raw['memory']['support_indices'];count+=4
    mem=np.stack([ordinary_ridge(phi[key][:,chosen],y[key]) for key in ['A','B','C']])
    assert np.allclose(mem,raw['memory']['memory_coefficients'],atol=1e-10,rtol=0);count+=12
    Xq=phi['probe'][:,chosen]; yq=y['probe']
    table=mem[TEMPLATES,np.arange(4)[None,:]]
    residual=np.sum((Xq@table.T-yq[:,None])**2,axis=0)
    index=int(np.argmin(residual+.16*np.count_nonzero(TEMPLATES,axis=1)))
    assert index==raw['memory']['candidate_code_index']
    assert TEMPLATES[index].tolist()==raw['memory']['candidate_code'];count+=2
    assert np.allclose(residual,raw['memory']['codebook_probe_errors'],atol=1e-10,rtol=0);count+=len(residual)
    logprob=np.log(np.array([.50,.25,.25]))[TEMPLATES].sum(axis=1)-residual/(2*.36**2)
    prob=np.exp(logprob-logprob.max());prob/=prob.sum()
    assert np.allclose(prob,raw['memory']['posterior_weights'],atol=1e-10,rtol=0);count+=len(prob)
    predq=Xq@mem.T
    losses=np.sum((predq-yq[:,None])**2,axis=0)
    assert np.allclose(losses,raw['memory']['snapshot_probe_errors'],atol=1e-10,rtol=0);count+=3
    w=np.exp(-(losses-losses.min())/(2*.36**2));w/=w.sum()
    assert np.allclose(w,raw['memory']['softmax_weights'],atol=1e-10,rtol=0);count+=3
    candidate=table[index]
    bayes=prob@table
    ridge=fit_prior(Xq,yq,mem.mean(0),1.)
    soft=w@mem
    pick=mem[int(np.argmin(losses))]
    recent_X=np.concatenate((phi['C'],phi['probe']))
    recent_y=np.concatenate((y['C'],y['probe']))
    pooled_X=np.concatenate((phi['A'],phi['B'],phi['C'],phi['probe']))
    pooled_y=np.concatenate((y['A'],y['B'],y['C'],y['probe']))
    recent=ElasticNet(alpha=.035,l1_ratio=.8,fit_intercept=True,max_iter=3000,tol=1e-5,selection='cyclic').fit(recent_X,recent_y)
    pooled=ElasticNet(alpha=.035,l1_ratio=.8,fit_intercept=True,max_iter=3000,tol=1e-5,selection='cyclic').fit(pooled_X,pooled_y)
    krr=KernelRidge(alpha=.3,kernel='rbf',gamma=.18).fit(np.concatenate((x['C'],x['probe'])),recent_y)
    reversed_fit=fit_prior(Xq,yq[::-1],mem.mean(0),1.)
    for held in ('held_A','held_B','held_D','held_cold'):
        feat=phi[held]; selected=feat[:,chosen]
        vec={'factor_map':selected@candidate,'factor_bayes':selected@bayes,
            'factor_ridge':selected@ridge,'softmax_memory':selected@soft,
            'best_snapshot':selected@pick,'recent_elasticnet':recent.predict(feat),
            'pooled_elasticnet':pooled.predict(feat),'recent_krr':krr.predict(x[held]),
            'old_no_update':selected@mem[0],'shuffled_probe':selected@reversed_fit}
        if held=='held_A':vec['factor_map']=selected@mem[0]
        if held=='held_B':vec['factor_map']=selected@mem[1]
        for name in MODELS:
            values=np.asarray(raw['held'][held][name]['predictions'],dtype=float)
            assert np.allclose(values,vec[name],atol=1e-9,rtol=1e-9), (held,name)
            assert hashlib.sha256(np.asarray(vec[name],dtype='<f8').tobytes()).hexdigest()==raw['held'][held][name]['pred_sha256'],(held,name,'hash')
            mse=float(np.mean((values-y[held])**2))
            compare_scalar(mse,raw['held'][held][name]['mse'],name)
            count+=64+2
    return count

def audit(path):
    data=json.loads(Path(path).read_text())
    assert data['experiment']=='ENERGY-63'
    assert len(data['cases'])==len(data['seeds'])*len(data['world_ids'])*len(data['families'])
    counts=[]
    for case in data['cases']:
        counts.append(audit_case(case))
    for name,stats in data['summary']['arm_metrics'].items():
        for label,reported in stats.items():
            compare_scalar(np.mean([c['held'][label][name]['mse'] for c in data['cases']]),reported,'aggregate')
    for group in ('by_family','by_seed'):
        for label,metrics in data['summary'][group].items():
            cases=[c for c in data['cases'] if (c['family'] if group=='by_family' else str(c['seed']))==label]
            for arm,score in metrics.items():
                compare_scalar(np.mean([c['held']['held_cold'][arm]['mse'] for c in cases]),score,group)
    return {'result':'PASS','case_count':len(counts),'model_arms':len(MODELS),
            'independent_checks':sum(counts)+4*len(MODELS)+sum(len(v)*len(MODELS) for v in (data['summary']['by_family'],data['summary']['by_seed'])),
            'limitation':'Separate independently authored reconstruction and model refits, but shared NumPy/scikit-learn and the disclosed synthetic mechanism family.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scored_json');p.add_argument('--out',required=True)
    a=p.parse_args()
    result=audit(a.scored_json)
    Path(a.out).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result))
