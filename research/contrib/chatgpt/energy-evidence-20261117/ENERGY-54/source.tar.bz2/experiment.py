#!/usr/bin/env python3
"""ENERGY-54 independent synthetic out-of-bank causal acquisition evaluation.
No native Yggdrasil data/weights/runner/controller. One prespecified candidate.
"""
import argparse, hashlib, json, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
import benchmark53 as base

VERSION='ENERGY54.v1'
FAMILIES=('bank_parity4','novel_parity5','novel_conditional5')
POLICIES=('robust_eig','eig','tournament','d_optimal','hamming','random')
LEARNERS=('omp','elasticnet','ridge')
SEEDS_SCREEN=(99851,99863)
SEEDS_RESERVED=(9719,9733,9749)
DEV_SEED=99839
NOLD,NPOOL,NHELD,NANCHOR,BUDGET=80,96,48,4,16
NOISE=.20
OBS_SIGMA=.45
MISFIT_THRESHOLD=.55
GH_NODES,GH_WEIGHTS=np.polynomial.hermite.hermgauss(5)
GH_NODES=np.sqrt(2.)*GH_NODES
GH_WEIGHTS=GH_WEIGHTS/np.sqrt(np.pi)

def rng(seed,wid,family,tag):
    s=f'{VERSION}/{seed}/{wid}/{family}/{tag}'.encode()
    return np.random.default_rng(int.from_bytes(hashlib.sha256(s).digest()[:8], 'little'))

def cues(x,seed,wid,fam,section,stage):
    r=rng(seed,wid,fam,'cues-'+section)
    if stage=='old':
        a=x[:,0].copy(); b=x[:,1].copy()
    elif stage=='new':
        a=1-x[:,0]; b=x[:,2].copy()
    else:
        a=r.integers(0,2,len(x)).astype(float); b=r.integers(0,2,len(x)).astype(float)
    if stage!='cold':
        a=np.logical_xor(a,r.random(len(x))<.10).astype(float)
        b=np.logical_xor(b,r.random(len(x))<.10).astype(float)
    return np.column_stack([x,a,b])

def true_mechanism(x,fam,ids):
    v=x[:,ids]
    if fam=='bank_parity4':return np.prod(2*v-1,axis=1)
    if fam=='novel_parity5':return np.prod(2*v-1,axis=1)
    return 2*((v[:,0]>0)&(v[:,1]>0)&(np.logical_xor(v[:,2]>0, np.logical_xor(v[:,3]>0,v[:,4]>0)))).astype(float)-1

def world(seed,wid,fam):
    r=rng(seed,wid,fam,'latent')
    order=r.permutation(512);pos=0;sections={}
    for name,n,stage in [('old_train',NOLD,'old'),('pool',NPOOL,'new'),('old_test',NHELD,'old'),('new_test',NHELD,'new'),('cold_test',NHELD,'cold')]:
        ids=order[pos:pos+n];pos+=n
        x=base.bits(ids)
        sections[name]={'x':cues(x,seed,wid,fam,name,stage),'base_ids':ids.tolist()}
    old_idx=r.choice(base.CAUSAL_BASE_TERMS,size=4,replace=False)
    old_w=r.choice([-1.,1.],4)*r.uniform(.7,1.2,4)
    if fam=='bank_parity4':
        ids=base.BANK['parity4'][int(r.integers(0,8))]
    else:
        ids=tuple(sorted(r.choice(np.arange(9),size=5,replace=False).tolist()))
    new_w=float(r.choice([-1.,1.])*r.uniform(1.1,1.8))
    for name,piece in sections.items():
        x=piece['x'];y=base.low(x)[:,old_idx]@old_w
        if name!='old_train' and name!='old_test':y=y+new_w*true_mechanism(x,fam,ids)
        y=y+rng(seed,wid,fam,'noise-'+name).normal(0,NOISE,len(x))
        piece['y']=np.asarray(y)
    return sections,{'family':fam,'true_support':ids,'old_supports':old_idx.tolist(),'novel_representable':fam=='bank_parity4'}

def stable_max(vals,remaining):
    m=float(np.max(vals))
    return int(remaining[np.flatnonzero(vals>=m-1e-9)[0]])

def posterior_model(F,selected,seen,old_preds):
    A=F[selected];r=np.asarray(seen)-old_preds[selected]
    beta=(A*r[:,None]).sum(axis=0)/((A*A).sum(axis=0)+.7)
    predicted=A*beta[None,:]
    loss=np.sum((predicted-r[:,None])**2,axis=0)
    w=np.exp(-.5*(loss-loss.min())/.45)
    w=w/(w.sum()+1e-15)
    misfit=float(loss.min()/(float(r@r)+1e-12))
    return beta,w,misfit

def expected_information(beta,weights,Fremaining):
    # Bayesian expected KL(p(H|y,x)||p(H)) for Gaussian outcome noise;
    # deterministic 5-point Gauss-Hermite integration over each candidate hypothesis.
    means=Fremaining*beta[None,:] # (candidate, hypothesis)
    # all 24 possible source hypotheses and five GH nodes for each.
    y=means[:,:,None]+OBS_SIGMA*GH_NODES[None,None,:]
    # shape candidates, generating hypothesis, quadrature draw, evaluated hypothesis
    dy=y[:,:,:,None]-means[:,None,None,:]
    likes=np.exp(-.5*(dy/OBS_SIGMA)**2)
    post=likes*weights[None,None,None,:]
    den=post.sum(axis=-1,keepdims=True)
    post=post/(den+1e-200)
    kl=(post*(np.log(post+1e-200)-np.log(weights[None,None,None,:]+1e-200))).sum(axis=-1)
    return (kl*weights[None,:,None]*GH_WEIGHTS[None,None,:]).sum(axis=(1,2))

def choose_policy(policy,xpool,old_model,observe,seed,wid,fam):
    F=base.bank_features(xpool)
    anchor=rng(seed,wid,fam,'anchors').choice(NPOOL,NANCHOR,replace=False).tolist()
    selected=list(map(int,anchor));seen=[float(observe(i)) for i in selected]
    old_pred=old_model.predict(base.low(xpool))
    if policy=='random':order=rng(seed,wid,fam,'policy-random').permutation(NPOOL).tolist()
    fallback_count=0;misfits=[];time0=time.perf_counter()
    for step in range(BUDGET-NANCHOR):
        remaining=np.asarray([j for j in range(NPOOL) if j not in selected],dtype=int)
        if policy=='random':choice=next(j for j in order if j not in selected)
        elif policy=='hamming':
            diff=np.abs(xpool[remaining,None,:]-xpool[None,selected,:]).sum(axis=2)
            value=np.min(diff,axis=1)+.02*np.mean(diff,axis=1)
            choice=stable_max(value,remaining)
        else:
            beta,weight,misfit=posterior_model(F,selected,seen,old_pred)
            misfits.append(misfit)
            policy_here=policy
            if policy=='robust_eig' and misfit>MISFIT_THRESHOLD:
                policy_here='d_optimal';fallback_count+=1
            elif policy=='robust_eig':policy_here='eig'
            if policy_here=='d_optimal':
                A=F[selected];mat=np.linalg.inv(A.T@A+.45*np.eye(F.shape[1]))
                value=np.einsum('ij,jk,ik->i',F[remaining],mat,F[remaining])
            elif policy_here=='tournament':
                P=F[remaining]*beta[None,:]
                mn=P@weight
                value=(P*P)@weight-mn*mn+.002*np.var(F[remaining],axis=1)
            elif policy_here=='eig':
                value=expected_information(beta,weight,F[remaining])
            else:raise AssertionError(policy_here)
            choice=stable_max(value,remaining)
        selected.append(int(choice));seen.append(float(observe(choice)))
    return selected,seen,float(time.perf_counter()-time0),fallback_count,misfits

def fit_base(xold,yold):
    m=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True)
    m.fit(base.low(xold),yold)
    return m

def fit_learner(learner,x,y,old):
    f=base.bank_features(x)
    res=y-old.predict(base.low(x))
    if learner=='omp':m=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True)
    elif learner=='elasticnet':m=ElasticNet(alpha=.045,l1_ratio=.8,max_iter=3000,tol=1e-5,fit_intercept=True,selection='cyclic')
    else:m=Ridge(alpha=1.,fit_intercept=True)
    m.fit(f,res);return m

def digest(values):return hashlib.sha256(np.asarray(values,dtype='<f8').tobytes()).hexdigest()

def evaluate(seeds,world_limit=4):
    cases=[]
    for seed in seeds:
        for fam in FAMILIES:
            for wid in range(world_limit):
                s,truth=world(seed,wid,fam)
                xold,yold=s['old_train']['x'],s['old_train']['y'];xp,yp=s['pool']['x'],s['pool']['y']
                old=fit_base(xold,yold)
                pold=old.predict(base.low(s['old_test']['x']))
                old_mse=float(np.mean((pold-s['old_test']['y'])**2))
                record={'seed':seed,'family':fam,'world':wid,'true_support':list(truth['true_support']),
                        'old_mse':old_mse,'sections_sha256':hashlib.sha256(json.dumps({k:v['base_ids'] for k,v in s.items()},sort_keys=True).encode()).hexdigest(),
                        'arms':{}}
                for policy in POLICIES:
                    accessed=[]
                    def observe(i):
                        if i in accessed:raise AssertionError('Double label')
                        accessed.append(int(i));return yp[int(i)]
                    chosen,labels,selection_s,fb,misfits=choose_policy(policy,xp,old,observe,seed,wid,fam)
                    assert chosen==accessed and len(set(chosen))==BUDGET
                    arm={'indices':chosen,'seen_labels':[round(x,11) for x in labels],
                        'selection_s':selection_s,'fallback_count':fb,'misfit_trace':[round(x,10) for x in misfits],
                        'learners':{}}
                    for learner in LEARNERS:
                        start=time.perf_counter();m=fit_learner(learner,xp[chosen],np.asarray(labels),old)
                        preds={key:old.predict(base.low(s[key]['x']))+m.predict(base.bank_features(s[key]['x'])) for key in ('new_test','cold_test')}
                        elapsed=time.perf_counter()-start
                        arm['learners'][learner]={
                            'new_mse':float(np.mean((preds['new_test']-s['new_test']['y'])**2)),
                            'cold_mse':float(np.mean((preds['cold_test']-s['cold_test']['y'])**2)),
                            'old_mse':old_mse,'fit_s':elapsed,
                            'new_sha256':digest(preds['new_test']),'cold_sha256':digest(preds['cold_test'])}
                    record['arms'][policy]=arm
                cases.append(record)
    aggregate={}
    for p in POLICIES:
        aggregate[p]={'selection_s':sum(w['arms'][p]['selection_s'] for w in cases),
                      'fallback_total':sum(w['arms'][p]['fallback_count'] for w in cases)}
        for m in LEARNERS:
            aggregate[p][m]={k:float(np.mean([w['arms'][p]['learners'][m][k] for w in cases])) for k in ('new_mse','cold_mse','old_mse','fit_s')}
    return {'schema':'energy54.scored.v1','source_version':VERSION,'seeds':list(seeds),
            'world_count':len(cases),'families':list(FAMILIES),'policies':list(POLICIES),'learners':list(LEARNERS),
            'budget':{'old':NOLD,'pool':NPOOL,'anchors':NANCHOR,'selected':BUDGET,'held_each':NHELD},
            'aggregate':aggregate,'cases':cases}

def gates(r):
    a=r['aggregate'];c=r['cases'];cand=lambda k:a['robust_eig']['omp'][k]
    other_omp=min(a[p]['omp']['cold_mse'] for p in POLICIES if p!='robust_eig')
    other_any=min(a[p][m]['cold_mse'] for p in POLICIES if p!='robust_eig' for m in LEARNERS)
    per_seed=[]
    for seed in r['seeds']:
        cs=[v for v in c if v['seed']==seed]
        val=lambda p,m:np.mean([z['arms'][p]['learners'][m]['cold_mse'] for z in cs])
        per_seed.append({'seed':seed,'candidate':float(val('robust_eig','omp')),
                         'best_other_omp':float(min(val(p,'omp') for p in POLICIES if p!='robust_eig')),
                         'best_other_any':float(min(val(p,m) for p in POLICIES if p!='robust_eig' for m in LEARNERS))})
    per_family=[]
    for fam in FAMILIES:
        cs=[v for v in c if v['family']==fam]
        val=lambda p,m:np.mean([z['arms'][p]['learners'][m]['cold_mse'] for z in cs])
        per_family.append({'family':fam,'candidate':float(val('robust_eig','omp')),
                           'best_other_omp':float(min(val(p,'omp') for p in POLICIES if p!='robust_eig'))})
    gc={
        'gain5_vs_best_omp':cand('cold_mse')<=.95*other_omp,
        'gain5_vs_best_any':cand('cold_mse')<=.95*other_any,
        'gain10_vs_random_omp':cand('cold_mse')<=.90*a['random']['omp']['cold_mse'],
        'gain3_vs_tournament_omp':cand('cold_mse')<=.97*a['tournament']['omp']['cold_mse'],
        'per_seed_strict_both':len(per_seed)==2 and all(z['candidate']<z['best_other_omp'] for z in per_seed),
        'every_family_at_most10pct_worse':all(z['candidate']<=1.1*z['best_other_omp'] for z in per_family),
        'old_predictions_exact':all(z['arms']['robust_eig']['learners']['omp']['old_mse']==z['old_mse'] for z in c),
        'fallback_exercised':a['robust_eig']['fallback_total']>0 and a['robust_eig']['fallback_total']<12*len(c),
        'selection_compute_below8x_tournament':a['robust_eig']['selection_s']<=8*a['tournament']['selection_s']
    }
    critical=['gain5_vs_best_omp','gain5_vs_best_any','per_seed_strict_both']
    status='SCREEN_PROMISING' if all(gc[k] for k in critical) and sum(gc.values())>=8 else 'SCREEN_NO_GO'
    return {'status':status,'gates':gc,'passed':sum(gc.values()),'critical':critical,'per_seed':per_seed,'per_family':per_family,
            'candidate_cold':cand('cold_mse'),'best_other_omp':other_omp,'best_other_any':other_any}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seeds',nargs='+',required=True,type=int);parser.add_argument('--out',required=True);parser.add_argument('--world-limit',type=int,default=4)
    args=parser.parse_args();r=evaluate(args.seeds,args.world_limit)
    Path(args.out).write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps({'seeds':args.seeds,'worlds':r['world_count'],'gates':gates(r),'summary':r['aggregate']},indent=2))
