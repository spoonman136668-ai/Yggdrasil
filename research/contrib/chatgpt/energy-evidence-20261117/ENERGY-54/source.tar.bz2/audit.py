#!/usr/bin/env python3
"""ENERGY-54 independent intervention selector and full estimator-refit audit.
Shares the frozen generator/NumPy/sklearn numerical libraries, not fully independent science.
"""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet,Ridge
import experiment as e
import benchmark53 as base


def choose_other(policy,xpool,old,new_labels,seed,wid,fam):
    bank=base.bank_features(xpool);anchor=e.rng(seed,wid,fam,'anchors').choice(e.NPOOL,e.NANCHOR,replace=False)
    chosen=list(map(int,anchor));witnesses=[float(new_labels[j]) for j in chosen]
    rperm=e.rng(seed,wid,fam,'policy-random').permutation(e.NPOOL).tolist()
    old_prediction=old.predict(base.low(xpool));backups=0
    for i in range(e.BUDGET-e.NANCHOR):
        remain=np.array([k for k in range(e.NPOOL) if k not in chosen],dtype=int)
        if policy=='random':target=next(k for k in rperm if k not in chosen)
        elif policy=='hamming':
            distance=np.count_nonzero(xpool[remain,None,:]!=xpool[None,chosen,:],axis=2)
            score=np.min(distance,axis=1)+.02*np.mean(distance,axis=1)
            target=int(remain[np.flatnonzero(score>=score.max()-1e-9)[0]])
        else:
            A=bank[chosen];resid=np.array(witnesses)-old_prediction[chosen]
            coef=np.array([(A[:,k]@resid)/(A[:,k]@A[:,k]+.7) for k in range(A.shape[1])])
            errors=((A*coef[None,:]-resid[:,None])**2).sum(axis=0)
            weights=np.exp(-.5*(errors-np.min(errors))/.45);weights/=weights.sum()+1e-15
            mismatch=float(np.min(errors)/(resid@resid+1e-12))
            method=policy
            if policy=='robust_eig':
                method='d_optimal' if mismatch>e.MISFIT_THRESHOLD else 'eig'
                backups+=int(method=='d_optimal')
            if method=='d_optimal':
                inv=np.linalg.solve(A.T@A+.45*np.eye(bank.shape[1]),bank[remain].T)
                score=(bank[remain]*inv.T).sum(axis=1)
            elif method=='tournament':
                guess=bank[remain]*coef
                score=(guess*guess)@weights-(guess@weights)**2+.002*bank[remain].var(axis=1)
            else:
                score=np.zeros(len(remain))
                for q,k in enumerate(remain):
                    prediction=bank[k]*coef
                    y=prediction[:,None]+e.OBS_SIGMA*e.GH_NODES[None,:]
                    diffs=(y[:,:,None]-prediction[None,None,:])/e.OBS_SIGMA
                    probability=np.exp(-.5*diffs**2)*weights[None,None,:]
                    probability/=probability.sum(axis=2,keepdims=True)
                    relative=probability*(np.log(probability+1e-200)-np.log(weights[None,None,:]+1e-200))
                    KL=relative.sum(axis=2)
                    score[q]=(KL*weights[:,None]*e.GH_WEIGHTS[None,:]).sum()
            target=int(remain[np.flatnonzero(score>=np.max(score)-1e-9)[0]])
        chosen.append(int(target));witnesses.append(float(new_labels[int(target)]))
    return chosen,witnesses,backups


def fitted_other(learner,chosen,targets,old):
    F=base.bank_features(chosen)
    residual=targets-old.predict(base.low(chosen))
    if learner=='omp':m=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True)
    elif learner=='elasticnet':m=ElasticNet(alpha=.045,l1_ratio=.8,max_iter=3000,tol=1e-5,fit_intercept=True,selection='cyclic')
    else:m=Ridge(alpha=1.0,fit_intercept=True)
    return m.fit(F,residual)


def run(x):
    assert x['schema']=='energy54.scored.v1' and x['source_version']==e.VERSION
    assert x['world_count']==len(x['cases'])==len(x['seeds'])*len(e.FAMILIES)*(len(x['cases'])//(len(x['seeds'])*len(e.FAMILIES)))
    assert x['policies']==list(e.POLICIES) and x['learners']==list(e.LEARNERS)
    checks=0;metrics={p:{m:{k:[] for k in ('old_mse','new_mse','cold_mse')} for m in e.LEARNERS} for p in e.POLICIES}
    for w in x['cases']:
        seed,fam,wid=w['seed'],w['family'],w['world']
        assert seed in x['seeds'] and fam in e.FAMILIES and 0<=wid<4;checks+=1
        s,truth=e.world(seed,wid,fam)
        assert list(truth['true_support'])==w['true_support'];checks+=1
        ids=[j for name in ('old_train','pool','old_test','new_test','cold_test') for j in s[name]['base_ids']]
        assert len(ids)==len(set(ids))==e.NOLD+e.NPOOL+3*e.NHELD;checks+=1
        assert len(w['arms'])==len(e.POLICIES);checks+=1
        src_hash=hashlib.sha256(json.dumps({k:v['base_ids'] for k,v in s.items()},sort_keys=True).encode()).hexdigest()
        assert src_hash==w['sections_sha256'];checks+=1
        old=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(base.low(s['old_train']['x']),s['old_train']['y'])
        old_pred=old.predict(base.low(s['old_test']['x']))
        old_mse=float(np.mean((old_pred-s['old_test']['y'])**2))
        assert abs(old_mse-w['old_mse'])<1e-12;checks+=1
        for policy in e.POLICIES:
            arm=w['arms'][policy]
            chosen,values,fallback=choose_other(policy,s['pool']['x'],old,s['pool']['y'],seed,wid,fam)
            assert chosen==arm['indices'];checks+=1
            assert len(chosen)==len(set(chosen))==e.BUDGET;checks+=1
            assert np.allclose(values,arm['seen_labels'],atol=5.1e-11,rtol=0);checks+=1
            assert fallback==arm['fallback_count'];checks+=1
            for learner in e.LEARNERS:
                rec=arm['learners'][learner]
                model=fitted_other(learner,s['pool']['x'][chosen],np.asarray(values),old)
                for key in ('new','cold'):
                    sect=s[key+'_test'];pred=old.predict(base.low(sect['x']))+model.predict(base.bank_features(sect['x']))
                    assert e.digest(pred)==rec[key+'_sha256'];checks+=1
                    mse=float(np.mean((pred-sect['y'])**2))
                    assert abs(mse-rec[key+'_mse'])<1e-10;checks+=1
                    metrics[policy][learner][key+'_mse'].append(mse)
                assert rec['old_mse']==old_mse;checks+=1
                metrics[policy][learner]['old_mse'].append(old_mse)
    for policy in e.POLICIES:
        for learner in e.LEARNERS:
            for key,values in metrics[policy][learner].items():
                assert abs(np.mean(values)-x['aggregate'][policy][learner][key])<1e-10;checks+=1
    return {'status':'PASS','schema':'energy54.independent_audit.v1','checks':checks,
            'world_count':x['world_count'],'seeds':x['seeds'],
            'policy_reconstruction':'Independent chooser including scalar expected-information integration',
            'model_refit':'Independent estimator setup, shared sklearn',
            'source_generator_independent':False,'learners':len(e.LEARNERS),'policies':len(e.POLICIES)}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('scored');ap.add_argument('--out',required=True);arg=ap.parse_args()
    z=run(json.loads(Path(arg.scored).read_text()))
    Path(arg.out).write_text(json.dumps(z,sort_keys=True,indent=2)+'\n')
    print(json.dumps(z,sort_keys=True))
