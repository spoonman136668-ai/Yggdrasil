#!/usr/bin/env python3
"""ENERGY-25: prospective disjoint three-parent parity discovery.

Only synthetic interventions. All methods receive identical supervised public
(a_0,...,a_4, observed_y) action consequences, no source parent labels.
"""
import argparse
import hashlib
import itertools
import json
import platform
import time
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
PARENTS=list(itertools.combinations(range(5),3))
WORLD_INPUTS=list(itertools.product((-1,1), repeat=5))

def select(seed, world):
    pairs=[]
    for inp in WORLD_INPUTS:
        raw=f'energy25/protocol-v1/seed={seed}/world={world}/input={inp}'.encode()
        pairs.append((hashlib.sha256(raw).digest(),inp))
    pairs.sort(key=lambda x:x[0]);return [x[1] for x in pairs[:16]],[x[1] for x in pairs[16:]]

def design(inputs, high):
    rows=[]
    for a in inputs:
        if high: rows.append([1, *a, *(a[i]*a[j]*a[k] for i,j,k in PARENTS)])
        else: rows.append([1,*a])
    return np.asarray(rows,dtype=np.float64)

def learn(X,y,ridge):
    # Preregistered one-shot full-batch ridge fit. Intercept penalized equally.
    return np.linalg.solve(X.T@X+ridge*np.eye(X.shape[1]),X.T@y)

def classify(X,w):
    z=X@w
    return np.where(z>=0,1,-1).astype(int)

def oracle_predict(train_inputs,train_y,test_inputs,epsilon):
    # Exact, fully fitted conventional finite-hypothesis Bayesian controller,
    # 10 possible parent triples * two polarities, uniform prior, 5% error.
    candidates=[(p,sgn) for p in PARENTS for sgn in (-1,1)]
    logp=[]
    for p,sign in candidates:
        fitted=[sign*a[p[0]]*a[p[1]]*a[p[2]] for a in train_inputs]
        mistakes=sum(pred!=yy for pred,yy in zip(fitted,train_y))
        logp.append(mistakes*np.log(epsilon)+(len(train_y)-mistakes)*np.log(1-epsilon))
    logp=np.array(logp); weights=np.exp(logp-logp.max());weights=weights/weights.sum()
    pred=[]
    for a in test_inputs:
        q=sum(w*(sign*a[p[0]]*a[p[1]]*a[p[2]]) for w,(p,sign) in zip(weights,candidates))
        pred.append(1 if q>=0 else -1)
    return np.asarray(pred,dtype=int),float(weights.max()),candidates[int(weights.argmax())]

def run(seed, ridge, epsilon):
    cases=[]
    for parent in PARENTS:
      for sign in (-1,1):
        world=f'{parent}-{sign}'
        train,test=select(seed,world)
        ytr=np.asarray([sign*np.prod([a[i] for i in parent]) for a in train],dtype=np.float64)
        yte=np.asarray([sign*np.prod([a[i] for i in parent]) for a in test],dtype=np.int64)
        t0=time.perf_counter_ns()
        pair=learn(design(train,False),ytr,ridge)
        pair_pred=classify(design(test,False),pair)
        t1=time.perf_counter_ns()
        high=learn(design(train,True),ytr,ridge)
        high_pred=classify(design(test,True),high)
        t2=time.perf_counter_ns()
        # A separately parameterized standard cubic regression has the same
        # mathematical feature matrix and fitted objective; enforce parity.
        conventional=learn(design(train,True),ytr,ridge)
        conventional_pred=classify(design(test,True),conventional)
        t3=time.perf_counter_ns()
        bayes_pred,confidence,best=oracle_predict(train,ytr,test,epsilon)
        t4=time.perf_counter_ns()
        assert np.array_equal(high_pred,conventional_pred)
        assert set(train).isdisjoint(set(test)) and len(train)==len(test)==16
        fitted_parent=PARENTS[int(np.argmax(np.abs(high[6:])))]
        fitted_sign=int(np.sign(high[6+PARENTS.index(fitted_parent)]) or 1)
        cases.append({'seed':seed,'true_parent':list(parent),'true_sign':sign,
                      'train_inputs':[list(a) for a in train],
                      'train_labels':ytr.astype(int).tolist(),
                      'held_inputs':[list(a) for a in test],
                      'held_labels':yte.tolist(),
                      'predictions':{'pairwise':pair_pred.tolist(),'high_order_energy':high_pred.tolist(),
                                     'conventional_cubic':conventional_pred.tolist(),'bayesian_rules':bayes_pred.tolist()},
                      'trained_high_order':high.tolist(),
                      'chosen_parent':list(fitted_parent),'chosen_sign':fitted_sign,
                      'bayes_best':{'parent':list(best[0]),'sign':best[1], 'posterior_weight':confidence},
                      'fit_plus_predict_ns':{'pairwise':t1-t0,'high_order_energy':t2-t1,
                                             'conventional_cubic':t3-t2,'bayesian_rules':t4-t3}})
    return cases

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true')
    ap.add_argument('--out',type=Path);args=ap.parse_args()
    p=json.loads((HERE/'prereg.json').read_text())
    seeds=[p['smoke_seed']] if args.smoke else p['held_seeds']
    cases=[]
    for seed in seeds:cases.extend(run(seed,p['ridge_penalty'],p['bayes_observation_error']))
    methods=['pairwise','high_order_energy','conventional_cubic','bayesian_rules']
    total=len(cases)*16
    results={arm:sum(y==h for c in cases for y,h in zip(c['held_labels'],c['predictions'][arm])) for arm in methods}
    metrics={'seeds':seeds,'worlds':len(cases),'held_outcomes':total,'correct':results,
             'accuracies':{k:results[k]/total for k in results},
             'parent_correct':sum(c['chosen_parent']==c['true_parent'] and c['chosen_sign']==c['true_sign'] for c in cases),
             'sum_fit_plus_predict_ms':{k:sum(c['fit_plus_predict_ns'][k] for c in cases)/1e6 for k in methods},
             'classification':'DEV_SOURCE_FREE_STRUCTURAL_TEST','scientific_pass':False,'native_execution':False}
    if args.smoke:
        print(json.dumps(metrics,indent=2));return
    obj={'schema':'energy25.structural-constraint-scored.v1','protocol':p,'metrics':metrics,'cases':cases,
         'environment':{'python':platform.python_version(),'numpy':np.__version__}}
    out=args.out or HERE/'scored.json';out.write_text(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps(metrics,indent=2))

if __name__=='__main__':main()
