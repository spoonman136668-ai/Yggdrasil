# ENERGY-25 initial independent audit failure — retained, not overwritten

The initial independent audit recomputed the frozen learned cubic energy
weights through an augmented least-squares solver (`scipy.linalg.lstsq`) rather
than the scored experiment's normal-equation solver (`numpy.linalg.solve`).
Fifteen held predictions spread across four worlds disagreed, despite the two
solutions agreeing to less than 1e-9 on weights. All discrepant margins were
within 4e-12 of zero. The initial auditor asserted bitwise classification
agreement and failed; it was not a scientific scoring or model failure, and no
scored source/seed, result or acceptance threshold was changed after scoring.

A separately authored post-score exact-rational certificate solved the ridge
normal equations for all held predictions whose scored margin magnitude was
below 1e-9. It found **32 exactly zero** margins across **six** worlds, so a
floating-point sign-based tie break is ill-conditioned. Of the 32 original
near-zero predictions, only seven matched truth (arbitrary near-zero sign),
and numerical solvers disagreed in 15 predictions (twice in the audit because
both cubic energy and conventional cubic controls fit the same objective).

The amended audit explicitly retains and counts these near-zero discrepancies,
fails on any material-margin discrepancy, and checks the independent exact-
rational diagnostics. The original 1,055 / 1,280 energy score is preserved as
recorded; it is **not** claimed to be bitwise solver- or platform-independent.
Do not fix the 32 zero-margin classifications post hoc and call the resulting
number the preregistered score.
