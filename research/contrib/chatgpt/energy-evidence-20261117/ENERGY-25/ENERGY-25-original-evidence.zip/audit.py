#!/usr/bin/env python3
"""Independent ENERGY-25 arithmetic/source audit; never imports experiment.py."""
from pathlib import Path
from itertools import combinations,product
import collections,hashlib,json,math
import numpy as np
from scipy.linalg import lstsq

ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'scored.json').read_text())
freeze=json.loads((ROOT/'freeze.json').read_text())
protocol=json.loads((ROOT/'prereg.json').read_text())
for filename,expected in freeze['files_sha256'].items():
    assert hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()==expected,(filename,'SOURCE_DRIFT')
assert protocol==s['protocol']
seeds=[103,211,307,401]
parents=list(combinations(range(5),3))
points=list(product((-1,1),repeat=5))
caseid=set();checked=0
correct=collections.Counter();parents_correct=0
failures=[]
ambiguous=[]
near_zero_mismatches=0
for c in s['cases']:
    key=(c['seed'],tuple(c['true_parent']),c['true_sign'])
    assert key not in caseid;caseid.add(key)
    assert c['seed'] in seeds and tuple(c['true_parent']) in parents and c['true_sign'] in [-1,1]
    expected_order=sorted(points,key=lambda inp:hashlib.sha256((f'energy25/protocol-v1/seed={c["seed"]}/world={tuple(c["true_parent"])}-{c["true_sign"]}/input={inp}').encode()).digest())
    x=[tuple(i) for i in c['train_inputs']]
    h=[tuple(i) for i in c['held_inputs']]
    assert x==expected_order[:16] and h==expected_order[16:]
    assert len(set(x+h))==32 and len(set(x).intersection(h))==0
    labels=lambda a: c['true_sign']*math.prod(a[k] for k in c['true_parent'])
    assert [labels(a) for a in x]==c['train_labels']
    assert [labels(a) for a in h]==c['held_labels']
    # Independent linear algebra: augmented least-squares not the original
    # normal-equations implementation. Same objective/penalty, all terms.
    def features(aa,cubic):
        return np.array([[1,*a,*[math.prod(a[k] for k in q) for q in parents]] if cubic else [1,*a] for a in aa],dtype=float)
    for name,cubic in [('pairwise',False),('high_order_energy',True),('conventional_cubic',True)]:
        A=features(x,cubic);T=features(h,cubic)
        augmented=np.vstack([A,math.sqrt(protocol['ridge_penalty'])*np.eye(A.shape[1])])
        y=np.concatenate([np.array(c['train_labels'],dtype=float),np.zeros(A.shape[1])])
        w=lstsq(augmented,y,lapack_driver='gelsd')[0]
        prediction=np.where(T@w>=0,1,-1).astype(int)
        original_pred=np.array(c['predictions'][name])
        mismatches=np.flatnonzero(prediction!=original_pred)
        if len(mismatches):
            # Different correct implementations of the same ridge objective
            # can disagree on exact-zero score ties. Log, never suppress.
            original_margin=T@np.asarray(c['trained_high_order'],dtype=float) if cubic else None
            if not (cubic and all(abs(float((T@w)[int(i)]))<1e-9 and abs(float(original_margin[int(i)]))<1e-9 for i in mismatches)):
                raise AssertionError((key,name,'MATERIAL_NUMERIC_DIVERGENCE',mismatches.tolist()))
            near_zero_mismatches+=len(mismatches)
            ambiguous.append({'case':key,'arm':name,'n':len(mismatches)})
        if name=='high_order_energy':assert np.max(np.abs(w-np.array(c['trained_high_order'])))<1e-9
    # Distinct exact Bayesian implementation with integer weights:
    # eps=1/20, hence each candidate weight = 19**correct * 1**wrong.
    all_candidates=[(q,p) for q in parents for p in [-1,1]]
    weights=[]
    for q,sgn in all_candidates:
        n=sum(sgn*math.prod(a[k] for k in q)==v for a,v in zip(x,c['train_labels']))
        weights.append(19**n)
    predicted=[]
    for a in h:
        mass=sum(w*sgn*math.prod(a[k] for k in q) for w,(q,sgn) in zip(weights,all_candidates))
        predicted.append(1 if mass>=0 else -1)
    assert predicted==c['predictions']['bayesian_rules']
    assert c['predictions']['high_order_energy']==c['predictions']['conventional_cubic']
    recovered=tuple(c['chosen_parent'])==tuple(c['true_parent']) and c['chosen_sign']==c['true_sign']
    parents_correct+=recovered
    for name,values in c['predictions'].items():
        correct[name]+=sum(a==b for a,b in zip(values,c['held_labels']))
    if not all(a==b for a,b in zip(c['predictions']['high_order_energy'],c['held_labels'])):
        failures.append({'seed':c['seed'],'parent':c['true_parent'],'sign':c['true_sign'],
                         'wrong':sum(a!=b for a,b in zip(c['predictions']['high_order_energy'],c['held_labels']))})
    checked+=16
assert len(caseid)==80 and checked==1280
assert parents_correct==80
assert dict(correct)==s['metrics']['correct']
assert s['metrics']['held_outcomes']==1280 and s['metrics']['parent_correct']==parents_correct
assert abs(correct['high_order_energy']/checked-s['metrics']['accuracies']['high_order_energy'])<1e-12
assert correct['bayesian_rules']==1280
assert protocol['scientific_pass'] is False and s['metrics']['scientific_pass'] is False
numerical=json.loads((ROOT/'post_score_numerical.json').read_text())
assert numerical['exact_rational_zero_margins']==32
assert numerical['unstable_prediction_count']==32
assert numerical['worlds_affected']==6
assert near_zero_mismatches==30  # two independently fitted cubic arms, 15 each
assert all(x['exact_sign']==0 for x in numerical['case_receipts'])
for receipt in numerical['case_receipts']:
    found=[c for c in s['cases'] if c['seed']==receipt['seed'] and c['true_parent']==receipt['parent'] and c['true_sign']==receipt['sign']]
    assert len(found)==1
    c=found[0]
    idx=receipt['held_index']
    assert c['predictions']['high_order_energy'][idx]==receipt['stored_label']
    assert c['held_labels'][idx]==receipt['true_label']
assert s['metrics']['correct']['bayesian_rules']>s['metrics']['correct']['high_order_energy']
print(json.dumps({'status':'PASS','frozen_source_hashes':'MATCH','independent_train_predict_checks':80*16*4,
                  'independent_held_labeled_outcomes':checked,'correct':dict(correct),
                  'recovered_relation_parent_sign':parents_correct,'energy_worlds_not_all_held_correct':len(failures),
                  'energy_vs_exact_bayes_held_deficit':correct['bayesian_rules']-correct['high_order_energy'],
                  'exact_rational_zero_margins':numerical['exact_rational_zero_margins'],
                  'near_zero_solver_prediction_disagreements':near_zero_mismatches},sort_keys=True))
