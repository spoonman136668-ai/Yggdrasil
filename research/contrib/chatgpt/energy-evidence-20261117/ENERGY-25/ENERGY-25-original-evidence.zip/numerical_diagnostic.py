#!/usr/bin/env python3
"""Post-score independent exact arithmetic investigation; no score modifications."""
import itertools,json,math
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from scipy.linalg import lstsq
import sympy as S
p=Path(__file__).resolve().parent
casefile=json.loads((p/'scored.json').read_text())['cases']
parents=list(itertools.combinations(range(5),3))
unstable=[];tie_count=0;tie_correct=0
for c in casefile:
 X=np.array([[1,*a,*[math.prod(a[k] for k in q) for q in parents]] for a in c['train_inputs']],dtype=int)
 T=np.array([[1,*a,*[math.prod(a[k] for k in q) for q in parents]] for a in c['held_inputs']],dtype=int)
 original=T@np.array(c['trained_high_order']);near=np.flatnonzero(np.abs(original)<1e-9)
 if len(near)==0:continue
 gram=S.Matrix(X.T@X)+S.eye(X.shape[1])*S.Rational(1,1000)
 rhs=S.Matrix(X.T@np.asarray(c['train_labels'],dtype=int))
 weights=gram.inv()*rhs
 for pos in near:
  score=(S.Matrix([T[int(pos)].tolist()]).multiply(weights))[0]
  exact_label=1 if score>=0 else -1
  stored=c['predictions']['high_order_energy'][int(pos)]
  if score==0:tie_count+=1;tie_correct+=(stored==c['held_labels'][int(pos)])
  unstable.append({'seed':c['seed'],'parent':c['true_parent'],'sign':c['true_sign'],
                  'held_index':int(pos),'stored_margin':float(original[int(pos)]),
                  'exact_sign':int(S.sign(score)),'exact_label_tie_positive':exact_label,
                  'stored_label':stored,'true_label':c['held_labels'][int(pos)]})
assert unstable
report={'schema':'energy25.post_score_numerical_diagnostic.v1',
        'classification':'POST_SCORE_DIAGNOSTIC_NOT_PRIMARY','unstable_prediction_count':len(unstable),
        'worlds_affected':len(set((x['seed'],tuple(x['parent']),x['sign']) for x in unstable)),
        'exact_rational_zero_margins':tie_count,'ties_recorded_correct':tie_correct,
        'case_receipts':unstable}
(p/'post_score_numerical.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='case_receipts'},indent=2))
