#!/usr/bin/env python3
"""ENERGY-24 independent mathematical and trajectory audit.

Never imports experiment.py. Reads frozen source and score but does not modify them;
rederives world, actions, observed episodes, posterior, held factual outcomes,
and per-world policy reward independently from pinned counter-based draw keys.
"""
import json
import hashlib
import math
from fractions import Fraction as Q
from pathlib import Path
from random import Random
from collections import defaultdict

ROOT=Path(__file__).resolve().parent
EXPECTED_SOURCE='eaf999e65c2091b6753ece24933c492f337b9cc52747c009bff14b49af6f2d4b'
EXPECTED_PREREG='7cc41274cd94786ed7040de7c507eb2da6a0439254b2004c10ece8e04003fdb5'
assert hashlib.sha256((ROOT/'experiment.py').read_bytes()).hexdigest()==EXPECTED_SOURCE,'source drift'
assert hashlib.sha256((ROOT/'prereg.json').read_bytes()).hexdigest()==EXPECTED_PREREG,'prereg drift'
S=json.loads((ROOT/'scored.json').read_text())
P=json.loads((ROOT/'per_world.json').read_text())
assert S['source_prereg_sha256']==EXPECTED_PREREG
assert S['classification']=='DEVELOPMENT_NO_GO'
assert S['scientific_pass'] is False and S['deployment']=='NONE'
assert len(P)==768
assert set(tuple(z['seed'] for z in P))=={501,607,809}

checks=0

def test(condition,msg):
    global checks
    checks+=1
    if not condition:raise AssertionError(msg)

def digest(*parts):
    return hashlib.sha256('/'.join(str(v) for v in parts).encode('ascii')).digest()

def draw(*parts):
    return int.from_bytes(digest(*parts)[:8],'big')

def flip(prob,*parts):
    return int(draw('energy24',*parts) < float(prob)*2**64)

def env(seed,cohort,idx):
    rr=Random(draw('world-v1',seed,cohort,idx));p=[];q=[]
    for _ in range(2):
        p.append([Q(rr.randrange(1,20),20) for a in range(2)])
        q.append([Q(rr.randrange(1,20),20) for t in range(8)])
    hidden=int(draw('energy24','hidden',seed,cohort,idx)<(Q(1,8) if cohort=='prior_sampling_old_7_8' else Q(1))*2**64)
    return p,q,hidden

def h_entropy(p):
    p=float(p)
    return 0.0 if p==0.0 or p==1.0 else -p*math.log2(p)-(1-p)*math.log2(1-p)

def info_kl(prior,params):
    mean=sum(a*b for a,b in zip(prior,params))
    score=0.0
    for probability, cond in zip(prior,params):
        for outcome in (0,1):
            pc=cond if outcome else 1-cond
            pm=mean if outcome else 1-mean
            joint=probability*pc
            if joint:
                score+=float(joint)*math.log2(float(pc/pm))
    return score

def rank(probs,weights,kind):
    if kind=='information_gain':return info_kl(weights,probs)
    center=sum(a*b for a,b in zip(weights,probs))
    v=sum(a*(b-center)**2 for a,b in zip(weights,probs))
    return (v,-abs(center-Q(1,2)))

def choose(probs,weights,kind,seed,cohort,idx,episode,stage):
    if kind=='random':return draw('act-v1',seed,cohort,idx,kind,episode,stage)%2
    v0=rank(probs[0],weights,kind)
    v1=rank(probs[1],weights,kind)
    return int(v1>v0+1e-14) if kind=='information_gain' else int(v1>v0)

def posterior(weights,conds,y):
    z=[w*(p if y else 1-p) for w,p in zip(weights,conds)]
    return tuple(v/sum(z) for v in z)

def expected_plan(p,q,weights):
    all_values=[]; all_second=[]
    for a in (0,1):
        second=[]
        for s in (0,1):
            part=posterior(weights,(p[0][a],p[1][a]),s)
            values=[sum(part[h]*q[h][4*a+2*s+b] for h in (0,1)) for b in (0,1)]
            second.append(int(values[1]>values[0]))
        all_second.append(second)
        v=sum(weights[h]*sum((p[h][a] if s else 1-p[h][a])*q[h][4*a+2*s+second[s]] for s in (0,1)) for h in (0,1))
        all_values.append(v)
    a=int(all_values[1]>all_values[0])
    return a,all_second[a]

def test_policy(z,n,kind,p,q,hidden,weights):
    a,second=expected_plan(p,q,weights)
    expectation=sum((p[hidden][a] if state else 1-p[hidden][a])*q[hidden][4*a+2*state+second[state]] for state in (0,1))
    successes=0
    for t in range(64):
        state=flip(p[hidden][a],'held',z['seed'],z['cohort'],z['world'],t,'transition',a)
        second_action=second[state]
        successes+=flip(q[hidden][4*a+2*state+second_action],'held',z['seed'],z['cohort'],z['world'],t,'reward',a,state,second_action)
    e=z['budgets'][str(n)][kind]
    test(successes==e['held_success'],f'held reward mismatch {z["seed"]} {n} {kind}')
    test(abs(float(expectation)-e['expected_return'])<1e-11,f'expectation mismatch {n} {kind}')
    if 'posterior_novel' in e:
        claimed=Q(*e['posterior_novel'])
        test(claimed==weights[1],f'posterior mismatch {n} {kind}')
        test(abs(float((1-weights[hidden])**2)-e['hidden_brier'])<1e-11,f'posterior brier mismatch {n} {kind}')
    return successes

sums=defaultdict(int)
for z in P:
    seed,cohort,idx=z['seed'],z['cohort'],z['world']
    p,q,hidden=env(seed,cohort,idx)
    test(z['true_context']==hidden,f'hidden cohort miswired {seed}:{idx}')
    for kind in ('source_variance','information_gain','random'):
        w=(Q(7,8),Q(1,8))
        for step in range(16):
            a=choose([(p[0][i],p[1][i]) for i in (0,1)],w,kind,seed,cohort,idx,step,'first')
            state=flip(p[hidden][a],'probe',seed,cohort,idx,step,'transition',a)
            w=posterior(w,(p[0][a],p[1][a]),state)
            bb=choose([(q[0][4*a+2*state+i],q[1][4*a+2*state+i]) for i in (0,1)],w,kind,seed,cohort,idx,step,'second')
            reward=flip(q[hidden][4*a+2*state+bb],'probe',seed,cohort,idx,step,'reward',a,state,bb)
            w=posterior(w,(q[0][4*a+2*state+bb],q[1][4*a+2*state+bb]),reward)
            n=step+1
            if n in (1,2,4,8,16):
                succ=test_policy(z,n,kind,p,q,hidden,w)
                sums[(cohort,str(n),kind)]+=succ
    for n in (1,2,4,8,16):
        for kind,w in (('frozen_prior',(Q(7,8),Q(1,8))),('oracle_latent',(Q(int(hidden==0)),Q(int(hidden==1))))):
            succ=test_policy(z,n,kind,p,q,hidden,w)
            sums[(cohort,str(n),kind)]+=succ
for (cohort,n,kind),total in sums.items():
    claimed=S['summary'][cohort][n][kind]['total']['held_success']
    test(total==claimed,f'aggregate mismatch {cohort},{n},{kind}: {total}!={claimed}')
for cohort in ('prior_sampling_old_7_8','forced_novel_shift'):
    v=S['summary'][cohort]['16']
    ig=v['information_gain']['total']['held_success'];baseline=v['source_variance']['total']['held_success']
    test(S['primary_gate'][cohort]['held_reward_delta_pp']==round((ig-baseline)/24576*100,5),'primary gate arithmetic mismatch')
    test(ig <= baseline,'unfrozen claim of advantage')
test(S['development_pass'] is False,'unexpected promotion')
res={'schema':'yggdrasil.energy24.independent.audit.v1','result':'PASS','assertion_checks':checks,'source_sha256':EXPECTED_SOURCE,'prereg_sha256':EXPECTED_PREREG,'worlds':len(P),'original_source_actions':0,'protected_first_use':0,'native_checkpoint_evaluated':False,'scientific_pass':False,'deployment':'NONE','primary_rechecked':{c:{n:{a:sums[(c,str(n),a)] for a in ('source_variance','information_gain','random')} for n in (1,2,4,8,16)} for c in ('prior_sampling_old_7_8','forced_novel_shift')}}
(ROOT/'audit_result.json').write_text(json.dumps(res,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if k!='primary_rechecked'},indent=2))
