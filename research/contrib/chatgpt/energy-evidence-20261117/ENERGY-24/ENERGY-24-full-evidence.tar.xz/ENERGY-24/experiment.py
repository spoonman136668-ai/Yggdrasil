#!/usr/bin/env python3
"""Frozen ENERGY-24 source-grounded two-stage causal acquisition trial.

Source-only synthetic development. No Yggdrasil import, native checkpoint access,
protected first-use, synthetic-feedback replay into a native model, or deployment.
"""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import random
import time

HERE = Path(__file__).resolve().parent
PREREG = HERE / 'prereg.json'
SEEDS = (501,607,809)
COHORTS = ('prior_sampling_old_7_8','forced_novel_shift')
POLICIES = ('source_variance','information_gain','random')
BUDGETS = (1,2,4,8,16)
WORLDS = 128
HELD = 64


def draw_int(*parts):
    return int.from_bytes(sha256('/'.join(map(str, parts)).encode('ascii')).digest()[:8],'big')


def uniform(*parts):
    # Independent deterministic draws, never exposed in model observations.
    return draw_int('energy24',*parts)/2**64


def bernoulli(p,*parts):
    return int(uniform(*parts) < float(p))


def entropy(p):
    p=float(p)
    if p<=0 or p>=1:
        return 0.0
    return -p*math.log2(p)-(1-p)*math.log2(1-p)


def source_variance(probs,weights):
    mean=sum(w*p for w,p in zip(weights,probs))
    var=sum(w*(p-mean)**2 for w,p in zip(weights,probs))
    return var,-abs(mean-F(1,2))


def info_gain(probs,weights):
    mean=sum(w*p for w,p in zip(weights,probs))
    return entropy(mean)-sum(float(w)*entropy(p) for w,p in zip(weights,probs))


def update(prior, p0,p1, observed):
    likelihood = [p0,p1] if observed else [1-p0,1-p1]
    products = tuple(x*y for x,y in zip(prior,likelihood))
    total=sum(products)
    assert total>0
    return tuple(x/total for x in products)


def world(seed,cohort,index):
    # Independent candidate joint structures, constrained to quantized, nonzero
    # probabilities to permit exact Bayesian updates and no divide-by-zero.
    # Shared structure is familiar across source/task; hidden H is source-only.
    rng = random.Random(draw_int('world-v1',seed,cohort,index))
    trans=[]
    reward=[]
    for h in (0,1):
        trans.append(tuple(F(rng.randrange(1,20),20) for _ in range(2)))
        reward.append(tuple(F(rng.randrange(1,20),20) for _ in range(8)))
    true = int(uniform('hidden',seed,cohort,index) < (F(1,8) if cohort==COHORTS[0] else 1))
    return tuple(trans), tuple(reward),true


def term_ix(first,state,second):
    return 4*first+2*state+second


def probs_transition(trans,first):
    return tuple(trans[h][first] for h in (0,1))


def probs_reward(reward,first,state,second):
    return tuple(reward[h][term_ix(first,state,second)] for h in (0,1))


def choose_probe(probs_per_action,weights,policy,seed,cohort,index,probe,stage):
    if policy=='random':
        return draw_int('act-v1',seed,cohort,index,policy,probe,stage)%2
    if policy=='source_variance':
        ranks=[source_variance(p,weights) for p in probs_per_action]
        return int(ranks[1]>ranks[0])
    ranks=[info_gain(p,weights) for p in probs_per_action]
    return int(ranks[1]>ranks[0]+1e-14)


def acquire(trans,reward,hidden,seed,cohort,index,policy,probe_count):
    weights=(F(7,8),F(1,8))
    log=[]
    for probe in range(probe_count):
        x1=choose_probe([probs_transition(trans,a) for a in (0,1)],weights,policy,
                        seed,cohort,index,probe,'first')
        s2=bernoulli(trans[hidden][x1], 'probe',seed,cohort,index,probe,'transition',x1)
        p=probs_transition(trans,x1)
        weights=update(weights,*p,s2)
        x2=choose_probe([probs_reward(reward,x1,s2,a) for a in (0,1)],weights,policy,
                        seed,cohort,index,probe,'second')
        y=bernoulli(reward[hidden][term_ix(x1,s2,x2)], 'probe',seed,cohort,index,probe,'reward',x1,s2,x2)
        p=probs_reward(reward,x1,s2,x2)
        weights=update(weights,*p,y)
        log.append((x1,s2,x2,y))
    assert len(log)==probe_count
    return weights,log


def plan(trans,reward,weights):
    values=[]
    actions=[]
    for first in (0,1):
        p=sum(w*trans[h][first] for h,w in enumerate(weights))
        second=[]
        for state in (0,1):
            qweights=update(weights,*probs_transition(trans,first),state)
            vals=[sum(w*reward[h][term_ix(first,state,a)] for h,w in enumerate(qweights)) for a in (0,1)]
            second.append(int(vals[1]>vals[0]))
        # Calculate expected reward directly, including latent-specific transition probabilities.
        ret=sum(weights[h]*sum((1-trans[h][first],trans[h][first])[state]*reward[h][term_ix(first,state,second[state])] for state in (0,1)) for h in (0,1))
        values.append(ret)
        actions.append(second)
    selected=int(values[1]>values[0])
    return selected,actions,values


def score(trans,reward,hidden,weights,seed,cohort,index,probe_count,policy):
    first,seconds,_=plan(trans,reward,weights)
    ret=sum((1-trans[hidden][first],trans[hidden][first])[state]*reward[hidden][term_ix(first,state,seconds[first][state])] for state in (0,1))
    successes=0
    trans_brier=0.0
    reward_brier=0.0
    for k in range(HELD):
        state=bernoulli(trans[hidden][first], 'held',seed,cohort,index,k,'transition',first)
        a2=seconds[first][state]
        successes+=bernoulli(reward[hidden][term_ix(first,state,a2)],'held',seed,cohort,index,k,'reward',first,state,a2)
        # Independently evaluated on identical fixed random actions and facts across arms.
        a1=draw_int('held-matched-first',seed,cohort,index,k)%2
        a_second=draw_int('held-matched-second',seed,cohort,index,k)%2
        actual_state=bernoulli(trans[hidden][a1], 'held-fixed',seed,cohort,index,k,'transition',a1)
        actual_reward=bernoulli(reward[hidden][term_ix(a1,actual_state,a_second)],'held-fixed',seed,cohort,index,k,'reward',a1,actual_state,a_second)
        p=float(sum(w*trans[h][a1] for h,w in enumerate(weights)))
        qweights=update(weights,*probs_transition(trans,a1),actual_state)
        q=float(sum(w*reward[h][term_ix(a1,actual_state,a_second)] for h,w in enumerate(qweights)))
        trans_brier+=(p-actual_state)**2
        reward_brier+=(q-actual_reward)**2
    hb=float(weights[hidden])
    return successes, float(ret), float((1-hb)**2),trans_brier,reward_brier


def verify_source_prereg(p):
    assert p['schema']=='yggdrasil.energy24.disjoint-causal-information-acquisition.prereg.v1'
    assert p['seeds']==list(SEEDS)
    assert p['training_budgets']==list(BUDGETS)
    assert p['worlds_per_seed_cohort']==WORLDS
    assert p['held_episodes_per_world_budget_arm']==HELD
    assert set(p['policies'])>=set(POLICIES)
    assert p['cohorts']==list(COHORTS)


def main():
    opts=argparse.ArgumentParser()
    opts.add_argument('--output', default=str(HERE/'scored.json'))
    args=opts.parse_args()
    prereg=PREREG.read_bytes()
    protocol=json.loads(prereg)
    verify_source_prereg(protocol)
    totals=defaultdict(lambda:{'worlds':0,'held_success':0,'oracle_expected_return_sum':0.0,'hidden_brier_sum':0.0,'held_transition_brier_sum':0.0,'held_reward_brier_sum':0.0,'acquisition_cpu_seconds':0.0,'total_cpu_seconds':0.0,'probes':0,'hypothesis_errors':0,'probe_action_disagreements':0})
    per_world=[]
    t0=time.process_time()
    for seed in SEEDS:
        for cohort in COHORTS:
            for idx in range(WORLDS):
                trans,reward,hidden=world(seed,cohort,idx)
                result={'seed':seed,'cohort':cohort,'world':idx,'true_context':hidden,'budgets':{}}
                for policy in POLICIES:
                    weights=(F(7,8),F(1,8))
                    log=[]
                    last=0
                    cpu_costs={}
                    for n in BUDGETS:
                        st=time.process_time()
                        # Sequential cumulative probes; never reset earlier fitted posterior.
                        for probe in range(last,n):
                            x1=choose_probe([probs_transition(trans,a) for a in (0,1)],weights,policy,seed,cohort,idx,probe,'first')
                            s2=bernoulli(trans[hidden][x1], 'probe',seed,cohort,idx,probe,'transition',x1)
                            weights=update(weights,*probs_transition(trans,x1),s2)
                            x2=choose_probe([probs_reward(reward,x1,s2,a) for a in (0,1)],weights,policy,seed,cohort,idx,probe,'second')
                            y=bernoulli(reward[hidden][term_ix(x1,s2,x2)],'probe',seed,cohort,idx,probe,'reward',x1,s2,x2)
                            weights=update(weights,*probs_reward(reward,x1,s2,x2),y)
                            log.append((x1,s2,x2,y))
                        cpu_add=time.process_time()-st
                        last=n
                        score_start=time.process_time()
                        successes,oracle_return,hb,bt,br=score(trans,reward,hidden,weights,seed,cohort,idx,n,policy)
                        cpu_score=time.process_time()-score_start
                        key=(str(seed),cohort,str(n),policy)
                        v=totals[key]
                        v['worlds']+=1
                        v['held_success']+=successes
                        v['oracle_expected_return_sum']+=oracle_return
                        v['hidden_brier_sum']+=hb
                        v['held_transition_brier_sum']+=bt
                        v['held_reward_brier_sum']+=br
                        v['acquisition_cpu_seconds']+=cpu_add
                        v['total_cpu_seconds']+=cpu_add+cpu_score
                        v['probes']+=n
                        result['budgets'].setdefault(str(n),{})[policy]={'held_success':successes,'expected_return':round(oracle_return,12),'posterior_novel':[weights[1].numerator,weights[1].denominator],'hidden_brier':round(hb,12),'transition_brier':round(bt/HELD,12),'reward_brier':round(br/HELD,12),'acquired':n}
                    assert len(log)==BUDGETS[-1]
                # Nonlearning descriptive frozen-prior and source-truth oracle.
                for n in BUDGETS:
                    for control,weight in (('frozen_prior',(F(7,8),F(1,8))),('oracle_latent',(F(int(hidden==0)),F(int(hidden==1))))):
                        succ,expected,prior_brier,bt,br=score(trans,reward,hidden,weight,seed,cohort,idx,n,control)
                        k=(str(seed),cohort,str(n),control)
                        v=totals[k]
                        v['worlds']+=1;v['held_success']+=succ;v['oracle_expected_return_sum']+=expected
                        v['hidden_brier_sum']+=prior_brier
                        v['held_transition_brier_sum']+=bt;v['held_reward_brier_sum']+=br;v['probes']+=0
                        result['budgets'][str(n)][control]={'held_success':succ,'expected_return':round(expected,12),'hidden_brier':round(prior_brier,12)}
                per_world.append(result)
    summary={}
    for (seed,cohort,n,arm),v in sorted(totals.items()):
        denominator=v['worlds']*HELD
        summary.setdefault(cohort,{}).setdefault(n,{}).setdefault(arm,{'per_seed':{}})['per_seed'][seed]={
            'worlds':v['worlds'],
            'successes':v['held_success'],
            'held_policy_return':round(v['held_success']/denominator,10),
            'true_expected_policy_return':round(v['oracle_expected_return_sum']/v['worlds'],10),
            'hidden_brier':round(v['hidden_brier_sum']/v['worlds'],10),
            'transition_brier':round(v['held_transition_brier_sum']/denominator,10),
            'reward_brier':round(v['held_reward_brier_sum']/denominator,10),
            'cpu_total_seconds':round(v['total_cpu_seconds'],6),
            'acquired_probes':v['probes'],
        }
    for cohort in COHORTS:
        for n in map(str,BUDGETS):
            for arm,v in summary[cohort][n].items():
                s=list(v['per_seed'].values());v['total']={
                    'worlds':sum(x['worlds'] for x in s),
                    'held_success':sum(x['successes'] for x in s),
                    'held_total':sum(x['worlds']*HELD for x in s),
                    'held_policy_return':round(sum(x['successes'] for x in s)/sum(x['worlds']*HELD for x in s),10),
                    'true_expected_policy_return':round(sum(x['true_expected_policy_return']*x['worlds'] for x in s)/sum(x['worlds'] for x in s),10),
                    'hidden_brier':round(sum(x['hidden_brier']*x['worlds'] for x in s)/sum(x['worlds'] for x in s),10),
                    'transition_brier':round(sum(x['transition_brier']*x['worlds'] for x in s)/sum(x['worlds'] for x in s),10),
                    'reward_brier':round(sum(x['reward_brier']*x['worlds'] for x in s)/sum(x['worlds'] for x in s),10),
                    'cpu_total_seconds':round(sum(x['cpu_total_seconds'] for x in s),6),
                }
    decisions={}
    for cohort in COHORTS:
        v=summary[cohort]['16'];ig=v['information_gain']['total'];base=v['source_variance']['total'];rnd=v['random']['total']
        per=[v['information_gain']['per_seed'][str(z)]['successes']-v['source_variance']['per_seed'][str(z)]['successes'] for z in SEEDS]
        decisions[cohort]={
            'held_reward_delta_pp':round(100*(ig['held_policy_return']-base['held_policy_return']),5),
            'hidden_brier_delta':round(ig['hidden_brier']-base['hidden_brier'],10),
            'seed_success_deltas':per,
            'improvement_over_random_pp':round(100*(ig['held_policy_return']-rnd['held_policy_return']),5),
            'meets_reward':ig['held_policy_return']-base['held_policy_return']>=.02,
            'meets_brier':ig['hidden_brier']<=base['hidden_brier'],
            'meets_seed':sum(x>0 for x in per)>=2,
            'meets_random':ig['held_policy_return']>rnd['held_policy_return'],
            'cpu_ratio_over_variance':round(ig['cpu_total_seconds']/base['cpu_total_seconds'],5),
        }
    passed=all(all(v[k] for k in ('meets_reward','meets_brier','meets_seed','meets_random')) and v['cpu_ratio_over_variance']<=2 for v in decisions.values())
    result={'schema':'yggdrasil.energy24.held-acquisition-score.v1','classification':'DEVELOPMENT_GO' if passed else 'DEVELOPMENT_NO_GO','scientific_pass':False,'accepted_native':False,'deployment':'NONE',
            'source_prereg_sha256':sha256(prereg).hexdigest(),
            'cohorts':list(COHORTS),'seeds':list(SEEDS),'worlds_per_seed_cohort':WORLDS,'held_episodes_per_world_budget_arm':HELD,'training_budgets':list(BUDGETS),
            'summary':summary,'primary_gate':decisions,'development_pass':passed,
            'not_native':True,'original_source_actions':0,'protected_first_use':0,'held_learning_updates':0,
            'whole_process_cpu_seconds_instrumented':round(time.process_time()-t0,6)}
    out=Path(args.output)
    out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    (out.parent/'per_world.json').write_text(json.dumps(per_world,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps({'classification':result['classification'],'primary_gate':decisions,'total_worlds':WORLDS*len(SEEDS)*len(COHORTS),'total_scored_held_events':WORLDS*len(SEEDS)*len(COHORTS)*len(BUDGETS)*5*HELD,'overall_cpu':result['whole_process_cpu_seconds_instrumented']},indent=2))

if __name__=='__main__':main()
