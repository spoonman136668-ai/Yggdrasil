#!/usr/bin/env python3
"""ENERGY-47. Two-stage protected old head + causal repair arbitration; synthetic external research ONLY.
Do not score primary seeds before protocol is committed to GitHub.
Requires exact sha256 pinned ENERGY-46/experiment.py on sibling directory.
"""
import argparse,copy,hashlib,importlib.util,json,time,warnings
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet,OrthogonalMatchingPursuit
from sklearn.ensemble import RandomForestRegressor

SEEDS=(9001,9011,9023)
SMOKE=99891
FAMILIES=('parity2','parity3','mixed')
IDS=(0,1,2,3)
EXPECTED_E46='fa38237a02f5fd76b66406ef6dccfe9b35bd406a24697ca81642d7c1ef1e1698'
ARMS=('gated_router','elastic_router','joint_elastic','new_elastic','new_omp4','omp_structural','gated_repair','no_repair','sham_new','forest','full_omp7')
STRONG=('elastic_router','joint_elastic','new_elastic','new_omp4','omp_structural','gated_repair','forest','full_omp7')


def frozen_generator():
    path=Path(__file__).resolve().parent.parent/'energy46local'/'experiment.py'
    if not path.exists():path=Path(__file__).resolve().parent.parent/'ENERGY-46'/'experiment.py'
    data=path.read_bytes()
    if hashlib.sha256(data).hexdigest()!=EXPECTED_E46:raise RuntimeError('ENERGY-46 generator SHA mismatch')
    s=importlib.util.spec_from_file_location('frozen_energy46_generator',str(path));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    return m
E=frozen_generator()

def en(A,y):
    return ElasticNet(alpha=.025,l1_ratio=.85,max_iter=5000,tol=1e-5,random_state=0).fit(A,y)

def get_omp(A,y,k=4):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        m=OrthogonalMatchingPursuit(n_nonzero_coefs=k,fit_intercept=False).fit(A,y)
    ix=np.flatnonzero(abs(m.coef_)>1e-8).astype(int).tolist()
    return ix,np.asarray(m.coef_[ix],dtype=float)

def block(A,stage):
    z=np.zeros_like(A)
    return np.column_stack((A,z)) if stage==0 else np.column_stack((z,A))

def fit_heads(seed,idx,family):
    w=E.make_world(seed,idx,family);p=w['parts'];x0=p['old_train']['x'];x1=p['new_train']['x'];y0=p['old_train']['y'];y1=p['new_train']['y'];a0=E.phi(x0);a1=E.phi(x1)
    fit_time={}
    t=time.perf_counter();old_en=en(a0,y0);fit_time['old_en']=time.perf_counter()-t
    t=time.perf_counter();oix,ow=get_omp(a0,y0,4);fit_time['old_omp']=time.perf_counter()-t
    t=time.perf_counter();joint=en(np.vstack((block(a0,0),block(a1,1))),np.r_[y0,y1]);fit_time['joint_en']=time.perf_counter()-t
    t=time.perf_counter();new_en=en(a1,y1);fit_time['new_en']=time.perf_counter()-t
    t=time.perf_counter();nix,nw=get_omp(a1,y1,4);fit_time['new_omp']=time.perf_counter()-t
    t=time.perf_counter();gated=E.replace(a1,y1,oix,split=72);fit_time['gate']=time.perf_counter()-t
    t=time.perf_counter();memix,memw=get_omp(np.vstack((block(a0,0),block(a1,1))),np.r_[y0,y1],7);fit_time['mem']=time.perf_counter()-t
    t=time.perf_counter();forest=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=seed+idx).fit(np.vstack((np.c_[x0,np.zeros(96)],np.c_[x1,np.ones(96)])),np.r_[y0,y1]);fit_time['forest']=time.perf_counter()-t
    # Outer arbiter: use only 76 new training witnesses to fit models; last 20 are decision labels.
    # ENERGY-46 gate gets an INNER 56/20 split within the first 76 to avoid reusing outer arbiter labels.
    t=time.perf_counter()
    inner=E.replace(a1[:76],y1[:76],oix,split=56)
    innerweights=E.fit(a1[:76],y1[:76],inner['ids'])
    pred_gate=a1[76:,inner['ids']]@innerweights
    jpart=en(np.vstack((block(a0,0),block(a1[:76],1))),np.r_[y0,y1[:76]])
    pred_joint=jpart.predict(block(a1[76:],1))
    npart=en(a1[:76],y1[:76]);pred_new=npart.predict(a1[76:])
    si,sw=get_omp(a1[:76],y1[:76],4);pred_omp=a1[76:,si]@sw
    errors={'gate':float(np.mean((pred_gate-y1[76:])**2)),
            'joint':float(np.mean((pred_joint-y1[76:])**2)),
            'new':float(np.mean((pred_new-y1[76:])**2)),
            'omp':float(np.mean((pred_omp-y1[76:])**2))}
    # Fixed penalty for complex gate and opaque OMP; no adaptive tuning on primary.
    adjusted={k:v+(.02 if k=='gate' else .005 if k=='omp' else 0) for k,v in errors.items()}
    ranked=('joint','new','omp','gate')
    selected=min(ranked,key=lambda k:(adjusted[k],ranked.index(k)))
    selected_en=min(('joint','new'),key=lambda k:(errors[k],('joint','new').index(k)))
    route_time=time.perf_counter()-t
    fit_time['router']=route_time
    # Fit correction on ALL 96 new witnesses *while retaining the preliminarily selected supports*.
    fix_ids=inner['ids'];fix_coef=E.fit(a1,y1,fix_ids)
    # negative: same old head, but shuffled new labels with a physically matched en fit.
    t=time.perf_counter();shuffled=en(a1,E.rng('e47_sham',seed,idx,family).permutation(y1));fit_time['sham']=time.perf_counter()-t
    return w,dict(a0=a0,a1=a1,old_en=old_en,old_ids=oix,old_coef=ow,joint=joint,new_en=new_en,new_ids=nix,new_coef=nw,
                  gate=gated,inner=inner,correction_ids=fix_ids,correction_coef=fix_coef,mem_ids=memix,mem_coef=memw,forest=forest,
                  sham=shuffled,selected=selected,selected_en=selected_en,val=errors),fit_time

def case_score(seed,idx,family):
    w,h,times=fit_heads(seed,idx,family)
    p=w['parts'];scores={arm:{} for arm in ARMS}
    def calc(arm,A,x,stage):
        old=h['old_en'].predict(A)
        if arm in ('gated_router','elastic_router','gated_repair','no_repair','sham_new','new_elastic','new_omp4') and stage==0:return old
        if arm=='gated_router':pick=h['selected']
        elif arm=='elastic_router':pick=h['selected_en']
        elif arm=='gated_repair':pick='gate'
        elif arm=='new_elastic':pick='new'
        elif arm=='new_omp4':pick='omp'
        else:pick=None
        if pick=='gate':return A[:,h['correction_ids']]@h['correction_coef']
        if pick=='joint':return h['joint'].predict(block(A,stage))
        if pick=='new':return h['new_en'].predict(A)
        if pick=='omp':return A[:,h['new_ids']]@h['new_coef']
        if arm=='joint_elastic':return h['joint'].predict(block(A,stage))
        if arm=='omp_structural' or arm=='full_omp7':return block(A,stage)[:,h['mem_ids']]@h['mem_coef']
        if arm=='forest':return h['forest'].predict(np.c_[x,np.full(len(x),stage)])
        if arm=='sham_new':return h['sham'].predict(A)
        return old
    elapsed={
    'gated_router':times['old_en']+times['old_omp']+times['joint_en']+times['new_en']+times['new_omp']+times['gate']+times['router'],
    'elastic_router':times['old_en']+times['joint_en']+times['new_en']+times['router'],
    'joint_elastic':times['joint_en'],
    'new_elastic':times['old_en']+times['new_en'],
    'new_omp4':times['old_en']+times['new_omp'],
    'omp_structural':times['mem'],'gated_repair':times['old_en']+times['old_omp']+times['gate'],
    'no_repair':times['old_en'],'sham_new':times['old_en']+times['sham'],
    'forest':times['forest'],'full_omp7':times['mem']}
    for arm in ARMS:
        t=time.perf_counter()
        for field in ('old_held','new_held','cold_held'):
            v=p[field];A=E.phi(v['x']);pred=calc(arm,A,v['x'],v['stage'])
            scores[arm][field]=float(np.mean((pred-v['y'])**2))
        scores[arm]['fit_s']=float(elapsed[arm]);scores[arm]['pred_s']=float(time.perf_counter()-t)
    return {'seed':seed,'idx':idx,'family':family,'changed':w['changed'], 'truth_ids':w['truth'],
            'route':h['selected'],'en_route':h['selected_en'],'validation':h['val'],'gate_inner_trigger':h['inner']['trigger'],
            'gate_changed_truth':bool(set(h['inner']['ids']) !=set(h['old_ids'])),
            'selected_ids':h['correction_ids'],'old_ids':h['old_ids'], 'old_checkpoint_sha256':hashlib.sha256(np.asarray(h['old_en'].coef_).tobytes()+np.asarray([h['old_en'].intercept_],dtype=np.float64).tobytes()).hexdigest(),
            'scores':scores}

def summarize(rows,seeds):
    agg={a:{k:float(np.mean([r['scores'][a][k] for r in rows])) for k in ('old_held','new_held','cold_held')}|{k:float(sum(r['scores'][a][k] for r in rows)) for k in ('fit_s','pred_s')} for a in ARMS}
    c=agg['gated_router'];bestcold=min(agg[a]['cold_held'] for a in STRONG);bestold=min(agg[a]['old_held'] for a in STRONG)
    perseed={str(s):{'candidate':float(np.mean([r['scores']['gated_router']['cold_held'] for r in rows if r['seed']==s])),
                     'best_control':min(float(np.mean([r['scores'][a]['cold_held'] for r in rows if r['seed']==s])) for a in STRONG)} for s in seeds}
    changes=[r for r in rows if r['changed']];nonchanges=[r for r in rows if not r['changed']]
    use_changed=sum(r['route']=='gate' for r in changes)/len(changes)
    use_unchanged=sum(r['route']=='gate' for r in nonchanges)/len(nonchanges)
    gates={
     'old_retention_max_1pct':c['old_held']<=1.01*agg['no_repair']['old_held'],
     'old_vs_best_5pct':c['old_held']<=1.05*bestold,
     'cold_vs_best_10pct':c['cold_held']<=.90*bestcold,
     'cold_vs_elastic_router_5pct':c['cold_held']<=.95*agg['elastic_router']['cold_held'],
     'new_vs_elastic_router_5pct':c['new_held']<=.95*agg['elastic_router']['new_held'],
     'changed_gate_use_at_least_60pct':use_changed>=.60,
     'unchanged_gate_use_at_most_10pct':use_unchanged<=.10,
     'seed_wins_at_least_2of3':sum(v['candidate']<v['best_control'] for v in perseed.values())>=2 if len(seeds)==3 else False,
     'sham_new_20pct':c['new_held']<=.8*agg['sham_new']['new_held'],
     'time_at_most_3x_joint_en':c['fit_s']+c['pred_s']<=3*(agg['joint_elastic']['fit_s']+agg['joint_elastic']['pred_s'])}
    decision={'gates':gates,'passes':sum(gates.values()),'fails':len(gates)-sum(gates.values()),'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO',
              'best_conventional_old':bestold,'best_conventional_cold':bestcold,'perseed':perseed,'changed_gate_use':use_changed,'unchanged_gate_use':use_unchanged,
              'route_counts':{mode:sum(r['route']==mode for r in rows) for mode in ('gate','joint','new','omp')}}
    return agg,decision

def canonical(src):
    z=copy.deepcopy(src);z.pop('wall_s',None)
    for row in z['cases']:
        for vals in row['scores'].values():vals.pop('fit_s',None);vals.pop('pred_s',None)
    for vals in z['aggregate'].values():vals.pop('fit_s',None);vals.pop('pred_s',None)
    z['decision'].pop('passes',None);z['decision'].pop('fails',None);z['decision'].pop('classification',None);z['decision']['gates'].pop('time_at_most_3x_joint_en',None)
    return json.dumps(z,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def run(seeds,ids,mode):
    t=time.perf_counter();cases=[case_score(s,i,f) for s in seeds for i in ids for f in FAMILIES];agg,decision=summarize(cases,seeds)
    return {'schema':'energy47.primary.v1','mode':mode,'seeds':list(seeds),'ids':list(ids),'families':list(FAMILIES),'cases':cases,'aggregate':agg,'decision':decision,'wall_s':time.perf_counter()-t}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');ap.add_argument('--primary',action='store_true');ap.add_argument('--out',required=True);q=ap.parse_args()
    if q.smoke==q.primary:raise ValueError('smoke XOR primary required')
    result=run((SMOKE,) if q.smoke else SEEDS,(0,3) if q.smoke else IDS,'smoke' if q.smoke else 'primary')
    Path(q.out).write_text(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'mode':result['mode'],'n':len(result['cases']),'decision':result['decision'],'aggregate':result['aggregate'],
                      'canonical_sha256':hashlib.sha256(canonical(result)).hexdigest()},sort_keys=True))
if __name__=='__main__':main()
