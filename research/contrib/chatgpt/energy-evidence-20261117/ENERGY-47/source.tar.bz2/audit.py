#!/usr/bin/env python3
"""ENERGY-47 source-independent refit audit. It does not import ENERGY-47 experiment.py.
Rebuilds worlds using independently authored ENERGY-46 auditor, verifies fitted arms and gates.
Shared NumPy and sklearn numerical backends are disclosed; no native Yggdrasil use.
"""
import argparse,hashlib,importlib.util,json,time,warnings
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet
from sklearn.ensemble import RandomForestRegressor

NAMES=('gated_router','elastic_router','joint_elastic','new_elastic','new_omp4','omp_structural','gated_repair','no_repair','sham_new','forest','full_omp7')
COMPARATORS=('elastic_router','joint_elastic','new_elastic','new_omp4','omp_structural','gated_repair','forest','full_omp7')
BASE_SHA='528509534942e2e18bb2880f411db2e1af2dc9b9128cfb8a024f6779d3858074'
def source_auditor():
    fn=Path(__file__).resolve().parent.parent/'energy46local'/'audit.py'
    if not fn.exists():fn=Path(__file__).resolve().parent.parent/'ENERGY-46'/'audit.py'
    assert hashlib.sha256(fn.read_bytes()).hexdigest()==BASE_SHA,'independent source generator drift'
    s=importlib.util.spec_from_file_location('independent_base_world',fn);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    return m
E=source_auditor()
def en(A,y):return ElasticNet(alpha=.025,l1_ratio=.85,max_iter=5000,tol=1e-5,random_state=0).fit(A,y)
def omp(A,y,n):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        model=OrthogonalMatchingPursuit(n_nonzero_coefs=n,fit_intercept=False).fit(A,y)
    ids=np.flatnonzero(abs(model.coef_)>1e-8).astype(int).tolist()
    return ids,np.asarray(model.coef_[ids],dtype=float)
def wrap(A,phase):
    return np.hstack((A,np.zeros_like(A))) if phase==0 else np.hstack((np.zeros_like(A),A))

def proposal(A,y,baseline,split=56):
    first=A[:split];target=y[:split];v=E.weighted_fit(first,target,baseline)
    base=float(np.mean((A[split:,baseline]@v-y[split:])**2))
    diff=target-first[:,baseline]@v
    ranking=np.abs(first.T@diff)/np.maximum(np.linalg.norm(first,axis=0),1e-9)
    ranking[baseline]=-np.inf
    selected=np.argsort(-ranking,kind='stable')[:24]
    best=(float('inf'),(10**9,10**9),[],None)
    for deleted in baseline:
        for added in selected:
            ids=[q for q in baseline if q!=deleted]+[int(added)]
            co=E.weighted_fit(first,target,ids)
            score=float(np.mean((A[split:,ids]@co-y[split:])**2))
            sig=(deleted,int(added))
            if (score,sig)<(best[0],best[1]):best=(score,sig,ids,co)
    trigger=bool(base-best[0]>=.12)
    ids=best[2] if trigger else baseline
    return ids,trigger

def match(a,b,label):
    if not np.isclose(a,b,rtol=3e-7,atol=3e-9):raise AssertionError(f'{label} value {a} != stored {b}')

def audit(src):
    checks=0
    for record in src['cases']:
        seed=int(record['seed']);idx=int(record['idx']);fam=record['family'];world=E.reworld(seed,idx,fam);parts=world['parts']
        assert record['changed']==(idx!=3) and record['truth_ids']==world['ids'];checks+=3
        old_x,y0=parts['old_train'];new_x,y1=parts['new_train'];a0=E.features(old_x);a1=E.features(new_x)
        old=en(a0,y0);new=en(a1,y1);joint=en(np.vstack((wrap(a0,0),wrap(a1,1))),np.r_[y0,y1]);oi,oc=omp(a0,y0,4);ni,nc=omp(a1,y1,4)
        mi,mc=omp(np.vstack((wrap(a0,0),wrap(a1,1))),np.r_[y0,y1],7)
        repair,trigger=proposal(a1,y1,oi,72)
        rf=RandomForestRegressor(n_estimators=60,max_depth=9,min_samples_leaf=3,n_jobs=1,random_state=seed+idx).fit(np.vstack((np.c_[old_x,np.zeros(len(old_x))],np.c_[new_x,np.ones(len(new_x))])),np.r_[y0,y1])
        sham=en(a1,E.local_rng('e47_sham',seed,idx,fam).permutation(y1))
        vgate,vt=proposal(a1[:76],y1[:76],oi,56)
        pred_gate=a1[76:,vgate]@E.weighted_fit(a1[:76],y1[:76],vgate)
        partial_joint=en(np.vstack((wrap(a0,0),wrap(a1[:76],1))),np.r_[y0,y1[:76]])
        partial_new=en(a1[:76],y1[:76]);pi,pw=omp(a1[:76],y1[:76],4)
        errors={
        'gate':float(np.mean((pred_gate-y1[76:])**2)),
        'joint':float(np.mean((partial_joint.predict(wrap(a1[76:],1))-y1[76:])**2)),
        'new':float(np.mean((partial_new.predict(a1[76:])-y1[76:])**2)),
        'omp':float(np.mean((a1[76:,pi]@pw-y1[76:])**2))}
        order=('joint','new','omp','gate')
        adjusted={q:score+(.02 if q=='gate' else .005 if q=='omp' else 0.) for q,score in errors.items()}
        selected=min(order,key=lambda q:(adjusted[q],order.index(q)))
        enroute=min(('joint','new'),key=lambda q:(errors[q],('joint','new').index(q)))
        assert selected==record['route'] and enroute==record['en_route']
        assert vt==record['gate_inner_trigger'] and vgate==record['selected_ids'] and oi==record['old_ids'];checks+=4
        assert bool(set(vgate)!=set(oi))==record['gate_changed_truth'];checks+=1
        for key in errors:match(errors[key],record['validation'][key],f'{seed}/{fam}/validation {key}');checks+=1
        cbytes=old.coef_.tobytes()+np.asarray([old.intercept_],dtype=np.float64).tobytes()
        assert hashlib.sha256(cbytes).hexdigest()==record['old_checkpoint_sha256'];checks+=1
        corrected=E.weighted_fit(a1,y1,vgate)
        for env in ('old_held','new_held','cold_held'):
            x,y=parts[env];phase=0 if env=='old_held' else 1;A=E.features(x);frozen=old.predict(A)
            def chosen(mode):
                if mode=='gate':return A[:,vgate]@corrected
                if mode=='joint':return joint.predict(wrap(A,phase))
                if mode=='new':return new.predict(A)
                if mode=='omp':return A[:,ni]@nc
                raise ValueError(mode)
            pred={
              'gated_router':frozen if not phase else chosen(selected),
              'elastic_router':frozen if not phase else chosen(enroute),
              'joint_elastic':joint.predict(wrap(A,phase)),
              'new_elastic':frozen if not phase else new.predict(A),
              'new_omp4':frozen if not phase else A[:,ni]@nc,
              'omp_structural':wrap(A,phase)[:,mi]@mc,
              'gated_repair':frozen if not phase else A[:,vgate]@corrected,
              'no_repair':frozen,
              'sham_new':frozen if not phase else sham.predict(A),
              'forest':rf.predict(np.c_[x,np.full(len(x),phase)]),
              'full_omp7':wrap(A,phase)[:,mi]@mc}
            for name,predictions in pred.items():
                match(float(np.mean((predictions-y)**2)),record['scores'][name][env],f'{seed}/{idx}/{fam}/{name}/{env}')
                checks+=len(predictions)
    # compute totals and each gate independently from frozen, without importing experiment.py
    agg={m:{env:float(np.mean([c['scores'][m][env] for c in src['cases']])) for env in ('old_held','new_held','cold_held')} for m in NAMES}
    for name in NAMES:
        for env in ('old_held','new_held','cold_held'):
            match(agg[name][env],src['aggregate'][name][env],f'aggregates {name} {env}');checks+=1
    s=agg['gated_router'];bestold=min(agg[m]['old_held'] for m in COMPARATORS);bestcold=min(agg[m]['cold_held'] for m in COMPARATORS)
    changed=[z for z in src['cases'] if z['changed']];unchanged=[z for z in src['cases'] if not z['changed']]
    newuse=sum(z['route']=='gate' for z in changed)/len(changed);falseuse=sum(z['route']=='gate' for z in unchanged)/len(unchanged)
    perseed={str(s0):{'candidate':float(np.mean([z['scores']['gated_router']['cold_held'] for z in src['cases'] if z['seed']==s0])),
                     'best_control':min(float(np.mean([z['scores'][m]['cold_held'] for z in src['cases'] if z['seed']==s0])) for m in COMPARATORS)} for s0 in src['seeds']}
    gates={
      'old_retention_max_1pct':s['old_held']<=1.01*agg['no_repair']['old_held'],
      'old_vs_best_5pct':s['old_held']<=1.05*bestold,
      'cold_vs_best_10pct':s['cold_held']<=.90*bestcold,
      'cold_vs_elastic_router_5pct':s['cold_held']<=.95*agg['elastic_router']['cold_held'],
      'new_vs_elastic_router_5pct':s['new_held']<=.95*agg['elastic_router']['new_held'],
      'changed_gate_use_at_least_60pct':newuse>=.60,
      'unchanged_gate_use_at_most_10pct':falseuse<=.10,
      'seed_wins_at_least_2of3':sum(v['candidate']<v['best_control'] for v in perseed.values())>=2 if len(src['seeds'])==3 else False,
      'sham_new_20pct':s['new_held']<=.8*agg['sham_new']['new_held'],
      'time_at_most_3x_joint_en':src['aggregate']['gated_router']['fit_s']+src['aggregate']['gated_router']['pred_s']<=3*(src['aggregate']['joint_elastic']['fit_s']+src['aggregate']['joint_elastic']['pred_s'])}
    assert gates==src['decision']['gates'],(gates,src['decision']['gates']);checks+=len(gates)
    for seed in perseed:
        match(perseed[seed]['candidate'],src['decision']['perseed'][seed]['candidate'],'seed candidate');match(perseed[seed]['best_control'],src['decision']['perseed'][seed]['best_control'],'seed ctrl');checks+=2
    assert src['decision']['passes']==sum(gates.values()) and src['decision']['fails']==len(gates)-sum(gates.values());checks+=2
    return {'schema':'energy47.audit.v1','status':'PASS','checks':checks,'worlds':len(src['cases']),'arms':list(NAMES),'source_generator_independently_reconstructed':True,'full_model_refit_and_held_scoring':True,'seedwise_and_gate_aggregation':True,'library_caveat':'Same NumPy/scikit-learn numerical backends as scorer, independent algorithmic implementation; native Yggdrasil acceptance not performed.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('scored');ap.add_argument('--out',required=True);args=ap.parse_args()
    src=json.loads(Path(args.scored).read_text());v=audit(src);Path(args.out).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps(v))
if __name__=='__main__':main()
