#!/usr/bin/env python3
"""Independent ENERGY-40 source reconstruction and all-case deterministic audit.
No imports from the original scorer or Yggdrasil owner; shares NumPy RNG only.
"""
import argparse
import hashlib
import json
import math
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

PREFIX='energy40-v1'
SEEDS=[8303,8311,8329]
FAMILIES=['erdos','modular','lattice']
SIZES=[32,64,96]
METHODS=['anneal','ils','greedy','random','highs']


def hashed(*parts):
    return hashlib.sha256('/'.join(str(q) for q in (PREFIX,*parts)).encode('ascii')).digest()


def integer(modulus,*parts):
    return int.from_bytes(hashed(*parts)[:8], 'big')%modulus


def public_edges(seed,fam,n):
    pairs=set()
    for i in range(n):
        j=(i+1)%n
        pairs.add((min(i,j),max(i,j)))
    rank=[]
    for i in range(n):
        for j in range(i+1,n):
            if (i,j) in pairs:continue
            p=0 if fam=='erdos' else (int(i//8!=j//8) if fam=='modular' else int(min(j-i,n-j+i)>4))
            rank.append((p,hashed('pair',seed,fam,n,0,i,j),i,j))
    rank.sort()
    pairs.update((q[2],q[3]) for q in rank[:2*n])
    hidden=[integer(2,'hidden',seed,fam,n,0,i) for i in range(n)]
    result=[]
    for i,j in sorted(pairs):
        flip=1 if integer(100,'frustrate',seed,fam,n,0,i,j)<22 else 0
        t=(hidden[i]^hidden[j])^flip
        w=integer(4,'weight',seed,fam,n,0,i,j)+1
        result.append([i,j,t,w])
    assert len(result)==3*n
    return result


def objective(edges, assignment):
    return sum(w for i,j,parity,w in edges if ((assignment[i]+assignment[j])%2)!=parity)


def vector_cost(edges, states):
    costs=np.zeros(len(states),dtype=np.int32)
    for i,j,t,w in edges:
        costs+=w*((states[:,i]^states[:,j])!=t)
    return costs


def local_reconstruction(edges,seed,family,n,method):
    rng=np.random.default_rng(integer(2**32,'shared-local',seed,family,n,0))
    spins=rng.choice(np.array([-1,1],dtype=np.int32),size=(12,n))
    b=(spins<0).astype(np.int8)
    vals=vector_cost(edges,b)
    idx=int(vals.argmin());best=int(vals[idx]);best_bits=b[idx].tolist()
    incident=[[] for _ in range(n)]
    for i,j,target,weight in edges:
        incident[i].append((j,target,weight))
        incident[j].append((i,target,weight))
    for sweep in range(48):
        temp=3.0*(0.04/3.0)**(sweep/47.0)
        for i in rng.permutation(n):
            change=np.zeros(12,dtype=np.int32)
            for neigh,target,w in incident[i]:
                satisfied=(b[:,i]^b[:,neigh])==target
                change+=np.where(satisfied,w,-w)
            if method=='anneal':
                accept=(change<=0)|(rng.random(12)<np.exp(-np.maximum(change,0)/temp))
            else:
                accept=change<0
            b[accept,i]^=1
            vals[accept]+=change[accept]
            k=int(vals.argmin())
            if int(vals[k])<best:
                best=int(vals[k]);best_bits=b[k].tolist()
        if method=='ils' and (sweep+1)%8==0 and sweep!=47:
            for row in range(12):
                ids=rng.choice(n,size=max(1,n//10),replace=False)
                b[row,ids]^=1
            vals=vector_cost(edges,b)
    assert objective(edges,best_bits)==best
    return best,bytes(best_bits).hex()


def random_reconstruction(edges,seed,family,n):
    rng=np.random.default_rng(integer(2**32,'random',seed,family,n,0))
    state=rng.choice(np.array([-1,1],dtype=np.int8),size=(12*49,n))
    bits=(state<0).astype(np.int8)
    costs=vector_cost(edges,bits)
    k=int(costs.argmin())
    return int(costs[k]),bytes(bits[k]).hex()


def compute_summary(cases):
    hits=defaultdict(int);excess=defaultdict(int);times=defaultdict(float)
    wins=defaultdict(int);losses=defaultdict(int);fam_hits=defaultdict(int)
    weight_total=0;certified=0;certified_good=0;large_hits=0
    for case in cases:
        opt=case['best_observed_cost']
        weight_total+=sum(edge[3] for edge in case['edges'])
        cert=case['certified_optimum'] is not None
        if cert:
            certified+=1
            certified_good+=int(case['solvers']['anneal']['cost']==opt)
        for m,s in case['solvers'].items():
            times[m]+=case['generation_s']+s['elapsed_s']
            if s['cost'] is not None:
                hits[m]+=int(s['cost']==opt)
                excess[m]+=s['cost']-opt
        a=case['solvers']['anneal']['cost']
        for ctrl in ['greedy','ils']:
            b=case['solvers'][ctrl]['cost']
            wins[ctrl]+=int(a<b);losses[ctrl]+=int(a>b)
        fam_hits[case['family']]+=int(a==opt)
        if case['n']==96:large_hits+=int(a==opt)
    N=len(cases)
    gates={
        'best_observed_at_least_80pct':hits['anneal']/N>=.80,
        'net_win_over_greedy_at_least_20pct':(wins['greedy']-losses['greedy'])/N>=.20,
        'net_win_over_ils_at_least_10pct':(wins['ils']-losses['ils'])/N>=.10,
        'sum_weight_normalized_gap_at_most_1pct':excess['anneal']/weight_total<=.01,
        'n96_best_observed_at_least_two_thirds':large_hits/sum(c['n']==96 for c in cases)>=2/3,
        'each_family_best_observed_at_least_two_thirds':all(fam_hits[f]/sum(c['family']==f for c in cases)>=2/3 for f in FAMILIES),
        'elapsed_at_most_1_5x_ils':times['anneal']<=1.5*times['ils'],
        'certified_subset_quality':certified>=3 and certified_good==certified
    }
    return hits,excess,dict(times),certified,certified_good,dict(wins),dict(losses),dict(fam_hits),large_hits,gates


def main():
    ap=argparse.ArgumentParser();ap.add_argument('scored');ap.add_argument('--out',required=True)
    args=ap.parse_args();start=time.perf_counter()
    source=json.loads(Path(args.scored).read_text());smoke=source['mode']=='smoke'
    assert source['schema']=='yggdrasil.energy40.score.v1'
    expected={(99703, f,n) for f,n in [('erdos',32),('modular',64),('lattice',96)]} if smoke else {(s,f,n) for s in SEEDS for f in FAMILIES for n in SIZES}
    assert {(c['seed'],c['family'],c['n']) for c in source['cases']}==expected
    checks=0
    for case in source['cases']:
        s,f,n=case['seed'],case['family'],case['n']
        edges=public_edges(s,f,n)
        assert edges==case['edges'];checks+=len(edges)
        assert case['world']==0
        assert len(case['solvers'])==len(METHODS)
        assert min(v['cost'] for v in case['solvers'].values() if v['cost'] is not None)==case['best_observed_cost'];checks+=1
        for m,obj in case['solvers'].items():
            if obj['bits_hex'] is None:
                assert obj['cost'] is None and m=='highs';checks+=1;continue
            bits=list(bytes.fromhex(obj['bits_hex']))
            assert len(bits)==n and set(bits)<={0,1};checks+=n
            assert objective(edges,bits)==obj['cost'];checks+=1
        for m in ('anneal','ils','greedy'):
            cost,bits=local_reconstruction(edges,s,f,n,m)
            assert cost==case['solvers'][m]['cost'] and bits==case['solvers'][m]['bits_hex'],(s,f,n,m,cost,case['solvers'][m]['cost'])
            checks+=2
        cost,bits=random_reconstruction(edges,s,f,n)
        assert cost==case['solvers']['random']['cost'] and bits==case['solvers']['random']['bits_hex']
        checks+=2
        h=case['solvers']['highs']
        assert bool(h['certified'])==(case['certified_optimum'] is not None)
        if h['certified']:
            assert h['cost']==case['best_observed_cost']
            assert abs(h['dual_bound']-h['cost'])<1e-5
            checks+=3
    hit,excess,times,cert,certgood,wins,losses,famhit,large,gates=compute_summary(source['cases'])
    summary=source['summary']
    for m in METHODS:
        assert summary['best_observed_hits'][m]==hit[m]
        assert summary['excess_weight_over_best_observed'][m]==excess[m]
        assert abs(summary['policy_generate_plus_solver_elapsed_s'][m]-times[m])<1e-6
        checks+=3
    assert summary['certified_optima']==cert and summary['certified_subset_anneal_hits']==certgood
    assert summary['anneal_wins']==wins and summary['anneal_losses']==losses
    assert summary['family_anneal_best_hits']==famhit and summary['n96_anneal_best_hits']==large
    assert summary['gates']==gates
    assert summary['classification']==('DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO')
    checks+=len(gates)+7
    out={'status':'PASS','checks':checks,'mode':source['mode'],'worlds':len(source['cases']),
         'scored_sha256':hashlib.sha256(Path(args.scored).read_bytes()).hexdigest(),
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'certified_optima':cert,'independent_replay':True,'gates':gates,
         'qualification':'Independent source and local-search replay. Shares NumPy RNG and trusts HiGHS exact certificate metadata; no native Yggdrasil acceptance.',
         'audit_wall_s':time.perf_counter()-start}
    Path(args.out).write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
