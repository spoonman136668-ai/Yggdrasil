#!/usr/bin/env python3
"""ENERGY-40: prospective scaling of frustrated XOR2 energy minimization.

External synthetic research, no learning, Yggdrasil training, or accepted-state change.
Exact certificates from HiGHS only; all other minima are best-observed bounds.
"""
import argparse
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix

VERSION = 'energy40-v1'
SEEDS = (8303, 8311, 8329)
FAMILIES = ('erdos', 'modular', 'lattice')
SIZES = (32, 64, 96)
STARTS = 12
SWEEPS = 48
HIGHS_LIMIT = 0.35
SOLVERS = ('anneal', 'ils', 'greedy', 'random', 'highs')


def digest(*x):
    return hashlib.sha256('/'.join(map(str, (VERSION, *x))).encode('ascii')).digest()


def randint(m, *x):
    return int.from_bytes(digest(*x)[:8], 'big') % m


def make_graph(seed, family, n, world=0):
    start = time.perf_counter()
    ring = {tuple(sorted((i, (i + 1) % n))) for i in range(n)}
    candidates = []
    for i in range(n):
        for j in range(i + 1, n):
            if (i, j) in ring:
                continue
            if family == 'erdos':
                priority = 0
            elif family == 'modular':
                priority = int(i // 8 != j // 8)
            elif family == 'lattice':
                priority = int(min(j - i, n - (j - i)) > 4)
            else:
                raise ValueError(family)
            candidates.append((priority, digest('pair', seed, family, n, world, i, j), i, j))
    candidates.sort()
    pairs = sorted(ring | {(i, j) for _, _, i, j in candidates[:2*n]})
    hidden = [randint(2, 'hidden', seed, family, n, world, i) for i in range(n)]
    edges = []
    for i, j in pairs:
        flipped = int(randint(100, 'frustrate', seed, family, n, world, i, j) < 22)
        parity = hidden[i] ^ hidden[j] ^ flipped
        weight = 1 + randint(4, 'weight', seed, family, n, world, i, j)
        edges.append([i, j, parity, weight])
    assert len(edges) == 3*n and len({(e[0], e[1]) for e in edges}) == 3*n
    return edges, time.perf_counter() - start


def energy(edges, bits):
    return int(sum(w for i, j, t, w in edges if (int(bits[i]) ^ int(bits[j])) != t))


def spin_objective(edges, spins):
    bits = (spins < 0).astype(np.int8)
    scores = np.zeros(len(spins), dtype=np.int32)
    for i, j, t, w in edges:
        scores += w * ((bits[:, i] ^ bits[:, j]) != t)
    return scores


def coupling(edges, n):
    j = np.zeros((n, n), dtype=np.int32)
    for i, k, parity, w in edges:
        j[i, k] = j[k, i] = w * (1 - 2*parity)
    return j


def search(edges, n, seed, family, method):
    started = time.perf_counter()
    assert method in ('anneal', 'ils', 'greedy')
    rng = np.random.default_rng(randint(2**32, 'shared-local', seed, family, n, 0))
    j = coupling(edges, n)
    states = rng.choice(np.array([-1, 1], dtype=np.int32), size=(STARTS, n))
    values = spin_objective(edges, states)
    idx = int(values.argmin())
    best = int(values[idx]); best_bits = (states[idx] < 0).astype(np.int8).tolist()
    for sweep in range(SWEEPS):
        t = 3.0 * (0.04/3.0)**(sweep/(SWEEPS-1))
        for i in rng.permutation(n):
            delta = states[:, i] * (states @ j[:, i])
            if method == 'anneal':
                take = (delta <= 0) | (rng.random(STARTS) < np.exp(-np.maximum(delta, 0)/t))
            else:
                take = delta < 0
            states[take, i] *= -1
            values[take] += delta[take]
            idx = int(values.argmin())
            if int(values[idx]) < best:
                best = int(values[idx]); best_bits = (states[idx] < 0).astype(np.int8).tolist()
        # Strong, fixed-budget diversification for the conventional ILS control.
        if method == 'ils' and (sweep+1) % 8 == 0 and sweep != SWEEPS-1:
            for row in range(STARTS):
                chosen = rng.choice(n, size=max(1, n//10), replace=False)
                states[row, chosen] *= -1
            values = spin_objective(edges, states)
    assert best == energy(edges, best_bits)
    return {'cost': best, 'bits_hex': bits_hex(best_bits), 'elapsed_s': time.perf_counter()-started,
            'proposals': STARTS*SWEEPS*n}


def bits_hex(bits):
    return bytes(int(x) for x in bits).hex()


def random_policy(edges, n, seed, family):
    began = time.perf_counter()
    rng = np.random.default_rng(randint(2**32, 'random', seed, family, n, 0))
    states = rng.choice(np.array([-1, 1], dtype=np.int8), size=(STARTS*(SWEEPS+1), n))
    costs = spin_objective(edges, states)
    k = int(costs.argmin())
    bits = (states[k] < 0).astype(np.int8).tolist()
    return {'cost': int(costs[k]), 'bits_hex': bits_hex(bits), 'elapsed_s': time.perf_counter()-began,
            'sampled_assignments': len(states)}


def highs_policy(edges, n):
    began = time.perf_counter()
    m = len(edges); count = n+2*m
    rr = []; cc = []; vv = []; coefficients = np.zeros(count); constant = 0
    for k, (i, j, parity, weight) in enumerate(edges):
        for col, val in ((i, 1), (j, 1), (n+k, -2), (n+m+k, -1)):
            rr.append(k); cc.append(col); vv.append(val)
        coefficients[n+m+k] = weight * (1-2*parity)
        constant += weight*parity
    mat = coo_matrix((vv, (rr, cc)), shape=(m, count)).tocsr()
    opt = milp(coefficients, integrality=np.ones(count), bounds=Bounds(0,1),
               constraints=LinearConstraint(mat, np.zeros(m), np.zeros(m)),
               options={'time_limit': HIGHS_LIMIT, 'mip_rel_gap': 0.0, 'presolve': True})
    assignment = None if opt.x is None else np.rint(opt.x[:n]).astype(np.int8).tolist()
    cost = None if assignment is None else energy(edges, assignment)
    bound = None if opt.mip_dual_bound is None else float(opt.mip_dual_bound) + constant
    certified = bool(opt.status == 0 and opt.success and cost is not None)
    if certified:
        assert bound is not None and abs(cost - bound) < 1e-5, ('bad HiGHS dual', cost, bound)
    return {'cost': cost, 'bits_hex': None if assignment is None else bits_hex(assignment),
            'certified': certified, 'status': int(opt.status), 'dual_bound': bound,
            'elapsed_s': time.perf_counter() - began}


def one(seed, family, n):
    graph, generated_s = make_graph(seed, family, n)
    solvers = {m:search(graph, n, seed, family, m) for m in ('anneal','ils','greedy')}
    solvers['random'] = random_policy(graph, n, seed, family)
    solvers['highs'] = highs_policy(graph, n)
    costs = [a['cost'] for a in solvers.values() if a['cost'] is not None]
    best = min(costs)
    if solvers['highs']['certified']:
        assert solvers['highs']['cost'] == best
    return {'seed':seed, 'family':family, 'n':n, 'world':0, 'edges':graph, 'generation_s':generated_s,
            'best_observed_cost':best, 'certified_optimum':solvers['highs']['cost'] if solvers['highs']['certified'] else None,
            'solvers': solvers}


def summarize(cases):
    total=len(cases); hit={m:sum(x['solvers'][m]['cost']==x['best_observed_cost'] for x in cases) for m in SOLVERS}
    win=lambda a,b:sum(x['solvers'][a]['cost'] is not None and x['solvers'][b]['cost'] is not None and x['solvers'][a]['cost'] < x['solvers'][b]['cost'] for x in cases)
    losses=lambda a,b:win(b,a)
    times={m:sum(x['generation_s'] + x['solvers'][m]['elapsed_s'] for x in cases) for m in SOLVERS}
    excess={m:sum(max(0,x['solvers'][m]['cost']-x['best_observed_cost']) for x in cases if x['solvers'][m]['cost'] is not None) for m in SOLVERS}
    certainty=sum(x['solvers']['highs']['certified'] for x in cases)
    certified=[x for x in cases if x['certified_optimum'] is not None]
    hit_family={fam:sum(x['family']==fam and x['solvers']['anneal']['cost']==x['best_observed_cost'] for x in cases) for fam in FAMILIES}
    hit_large=sum(x['n']==96 and x['solvers']['anneal']['cost']==x['best_observed_cost'] for x in cases)
    weights=sum(sum(e[3] for e in x['edges']) for x in cases)
    gates={
      'best_observed_at_least_80pct':hit['anneal']/total >= .80,
      'net_win_over_greedy_at_least_20pct':(win('anneal','greedy')-losses('anneal','greedy'))/total >= .20,
      'net_win_over_ils_at_least_10pct':(win('anneal','ils')-losses('anneal','ils'))/total >= .10,
      'sum_weight_normalized_gap_at_most_1pct':excess['anneal']/weights <= .01,
      'n96_best_observed_at_least_two_thirds':hit_large/sum(x['n']==96 for x in cases) >= 2/3,
      'each_family_best_observed_at_least_two_thirds':all(hit_family[f]/sum(x['family']==f for x in cases) >= 2/3 for f in FAMILIES),
      'elapsed_at_most_1_5x_ils':times['anneal'] <= 1.5*times['ils'],
      'certified_subset_quality':certainty>=3 and all(x['solvers']['anneal']['cost']==x['certified_optimum'] for x in certified)
    }
    return {'worlds':total,'best_observed_hits':hit, 'excess_weight_over_best_observed':excess,
            'total_weight':weights, 'certified_optima':certainty, 'certified_subset_anneal_hits':sum(x['solvers']['anneal']['cost']==x['certified_optimum'] for x in certified),
            'anneal_wins':{'greedy':win('anneal','greedy'),'ils':win('anneal','ils')},
            'anneal_losses':{'greedy':losses('anneal','greedy'),'ils':losses('anneal','ils')},
            'family_anneal_best_hits':hit_family,'n96_anneal_best_hits':hit_large,
            'policy_generate_plus_solver_elapsed_s':times, 'gates':gates,
            'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO'}


def main():
    p=argparse.ArgumentParser();p.add_argument('--smoke',action='store_true');p.add_argument('--out',required=True)
    a=p.parse_args();began=time.perf_counter()
    configs=([(99703,'erdos',32),(99703,'modular',64),(99703,'lattice',96)] if a.smoke
             else [(seed,family,n) for seed in SEEDS for family in FAMILIES for n in SIZES])
    cases=[one(*cfg) for cfg in configs]
    result={'schema':'yggdrasil.energy40.score.v1','mode':'smoke' if a.smoke else 'primary',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seeds':[99703] if a.smoke else list(SEEDS),
            'parameters':{'families':list(FAMILIES),'sizes':list(SIZES),'starts':STARTS,'sweeps':SWEEPS,'highs_limit_s':HIGHS_LIMIT},
            'cases':cases,'summary':summarize(cases),'all_method_wall_s':time.perf_counter()-began,
            'scientific_pass':False,'native_yggdrasil_training':False,'deployment':'NONE'}
    Path(a.out).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'mode':result['mode'],'summary':result['summary'], 'wall':result['all_method_wall_s']},sort_keys=True,indent=2))


if __name__=='__main__':main()
