#!/usr/bin/env python3
"""ENERGY-16: audit transcribed author records. With --verify-upstream, re-fetch GitHub source and verify blob SHA1 and extracted values. Does not train or test models."""
import argparse
import hashlib
import json
import statistics
import urllib.request
from pathlib import Path

HERE = Path(__file__).parent


def git_blob_sha(content):
    return hashlib.sha1(f"blob {len(content)}\0".encode()+content).hexdigest()


def analyze(snapshot):
    checks=0
    maze=snapshot['maze_unique']
    assert all(len(x['cold_fit_seed_s'])==3 and len(x['correct_per_seed'])==3 for x in maze['baseline'].values());checks+=1
    assert len(maze['cram_cold_fit_seed_s']) == 3; checks+=1
    assert abs(statistics.mean(maze['cram_cold_fit_seed_s'])-maze['cram_full_cold_fit_mean_s'])<1e-12;checks+=1
    assert sum(maze['cram_correct_per_seed'])==3000;checks+=1
    comparisons=[]
    for name, v in maze['baseline'].items():
        mean_fit=statistics.mean(v['cold_fit_seed_s'])
        correct=sum(v['correct_per_seed'])
        assert 0 <= correct <= 3000;checks+=1
        assert min(v['cold_fit_seed_s'])>0;checks+=1
        comparisons.append({'method':name,'recorded_cold_fit_mean_s':mean_fit,
                            'reported_cold_fit_ratio_to_cram':mean_fit/maze['cram_full_cold_fit_mean_s'],
                            'reported_exact_mazes_out_of_3000':correct,'accuracy_pct':100*correct/3000})
    assert next(x for x in comparisons if x['method']=='TRM')['reported_exact_mazes_out_of_3000']==2767;checks+=1
    assert next(x for x in comparisons if x['method']=='EqR')['reported_exact_mazes_out_of_3000']==1996;checks+=1
    assert maze['baseline']['EqR']['correct_per_seed'][2]==0;checks+=1
    assert maze['baseline']['HRM']['correct_per_seed'][2]==10;checks+=1
    assert maze['cram_full_warm_fit_mean_s'] < maze['cram_full_cold_fit_mean_s'];checks+=1
    sudoku=snapshot['sudoku_extreme']
    assert sum(sudoku['cram_solved_per_seed'])==1238307;checks+=1
    assert all(x<=sudoku['test_puzzles_per_seed'] for x in sudoku['cram_solved_per_seed']); checks+=1
    ops_ratios={}
    for task_name, obj in [('maze_unique',maze),('sudoku_extreme',sudoku)]:
        old,new=obj['inference_ops_old_table'],obj['inference_ops_complete_export']
        assert new>old>0; checks+=1
        ops_ratios[task_name]={"old_export":old,"complete_export":new,"complete_divided_by_old":new/old,
                               "hrm_complete_divided_by_cram_complete":obj['full_ops_baseline']['HRM']/new,
                               "trm_complete_divided_by_cram_complete":obj['full_ops_baseline']['TRM']/new}
    assert snapshot['baseline_export_code_dirty'] is True;checks+=1
    assert len(snapshot['sources'])==5;checks+=1
    return {'classification':'PUBLISHED_RECORD_ARITHMETIC_PASS_REPRODUCTION_UNVERIFIED',
            'checks':checks,'source_commit':snapshot['upstream_commit'],
            'baseline_export_dirty':True,
            'maze_unique':{'cram_cold_s':maze['cram_full_cold_fit_mean_s'],
                           'cram_warm_s':maze['cram_full_warm_fit_mean_s'],
                           'cram_accuracy_pct':100*sum(maze['cram_correct_per_seed'])/3000,
                           'comparisons':sorted(comparisons,key=lambda x:x['recorded_cold_fit_mean_s'])},
            'operations':ops_ratios,
            'methodology_warning':'Source reported results are not independently reproduced; moved baseline wrappers have not been rerun from the published layout. No scientific promotion.'}


def verify_upstream(snapshot):
    """Optional authoritative-source check. Network required. Git blob SHA1 binds exact bytes to pinned ref."""
    raw={}
    for path,sha in snapshot['sources'].items():
        url=f"https://raw.githubusercontent.com/Prefrontal-AI/CRAM/{snapshot['upstream_commit']}/{path}"
        with urllib.request.urlopen(url,timeout=20) as resp:
            content=resp.read()
        got=git_blob_sha(content)
        assert got==sha, f"Upstream blob mismatch: {path} {got} != {sha}"
        raw[path]=content
    fit=json.loads(raw['results/baseline-fit-times.json'])
    ops=json.loads(raw['results/op-counts.json'])
    maze=json.loads(raw['experiments/runs/table/maze-unique__cram-sgd-fg.json'])
    sudoku=json.loads(raw['experiments/runs/table/sudoku-extreme__cram-0-fit.json'])
    assert fit['code_dirty'] is True
    s=snapshot['maze_unique']; t=snapshot['sudoku_extreme']
    for k,src in [('cram_full_cold_fit_mean_s','fit_gpu_cold_s'),('cram_full_warm_fit_mean_s','fit_gpu_warm_s'),('cram_update_loop_mean_s','train_gpu_s')]:
        assert abs(s[k]-maze[src])<1e-12,(k,src)
    assert abs(t['cram_full_cold_fit_mean_s']-sudoku['fit_gpu_cold_s'])<1e-12
    assert [x['solved'] for x in sudoku['extra']['per_seed']]==t['cram_solved_per_seed']
    opmap={(x['benchmark'],x['method']):x for x in ops['cells']}
    for name,data,method in [('maze-unique',s,'maze_unique'),('sudoku-extreme',t,'sudoku_extreme')]:
        assert abs(data['inference_ops_complete_export']-opmap[(name,'CRAM')]['new'])<1e-5
        assert abs(data['inference_ops_old_table']-opmap[(name,'CRAM')]['old'])<1e-5
        for base in ['HRM','TRM']:
            assert abs(data['full_ops_baseline'][base]-opmap[(name,base)]['new'])<1e-5
    for method,saved in s['baseline'].items():
        matched=sorted((x for x in fit['cells'] if x['task']=='Maze-Unique' and x['method']==method),key=lambda x:x['seed'])
        assert len(matched)==3
        assert [x['fit_seconds'] for x in matched]==saved['cold_fit_seed_s']
        for src,want in zip(matched,saved['correct_per_seed']):
            scores=[x for x in src['test_scores'].values() if isinstance(x,str) and '/1000' in x]
            if method=='EqR': scores=[x for x in scores if x.startswith('test-D64-B128:')]
            assert scores and int(scores[0].split(':')[-1].strip().split('/')[0])==want,(method,src['seed'],scores,want)
    return {'source_blobs_checked':len(raw),'validation':'PASS'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-upstream',action='store_true');args=ap.parse_args()
    snap=json.loads((HERE/'records_snapshot.json').read_text())
    result=analyze(snap)
    if args.verify_upstream:
        result['network_source_verification']=verify_upstream(snap)
    else:
        result['network_source_verification']='verified through GitHub connector during gate; optional independent re-fetch supported'
    (HERE/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('ENERGY-16',result['classification'],'checks',result['checks'])
    for item in result['maze_unique']['comparisons']:
        print(item['method'],round(item['recorded_cold_fit_mean_s'],3),round(item['reported_cold_fit_ratio_to_cram']),item['reported_exact_mazes_out_of_3000'])

if __name__=='__main__':main()
