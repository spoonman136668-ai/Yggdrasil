#!/usr/bin/env python3
"""ENERGY-15 read-only source-fidelity preflight. No fit, inference, datasets, network, runners or first-use."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import platform
import re
import sys
import zipfile
import numpy as np

BASE = Path("/mnt/data")
ZIP = BASE / "ENERGY-14-evidence.zip"
FILE = BASE / "ENERGY-14B" / "experiment.py"
UPSTREAM_SHA = "62bbe830c7d6f87f2ba18f30a28039258b986454"
UPSTREAM_TRAIN_BLOB = "ea320ae6a00275d2069628cb944a29abc3baa08b"
UPSTREAM_SAMPLER = "batches() uses rng.permutation(n), dropping incomplete last blocks"
SEEDS = (67, 79, 101)
N = 256
BATCH = 64
UPDATES = 20

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sample_upstream(seed):
    rng = np.random.default_rng(seed)
    out = []
    while len(out) < UPDATES:
        perm = rng.permutation(N)
        for i in range(0, N-BATCH+1, BATCH):
            if len(out) >= UPDATES:
                break
            out.append(perm[i:i+BATCH])
    return np.concatenate(out)

def sample_mathport(seed):
    rng = np.random.default_rng(seed)
    return np.concatenate([rng.integers(0, N, size=BATCH) for _ in range(UPDATES)])

def main():
    checks=0
    assert ZIP.is_file() and FILE.is_file()
    with zipfile.ZipFile(ZIP) as archive:
        assert archive.testzip() is None
        names = set(archive.namelist())
        manifest = json.loads(archive.read("ENERGY-14B/MANIFEST.json"))
        assert manifest["upstream_commit"] == UPSTREAM_SHA
        for path, expected_sha in manifest["records"].items():
            assert path in names and digest(archive.read(path)) == expected_sha, path
            checks += 1
        assert digest(FILE.read_bytes()) == manifest["records"]["ENERGY-14B/experiment.py"]
        checks += 1
        scored = json.loads(archive.read("ENERGY-14B/scored.json"))
        assert [x["seed"] for x in scored["cases"]] == list(SEEDS)
        assert [x["n"] for x in scored["cases"]] == [64,64,64]
        assert sum(x["exact_boards"] for x in scored["cases"]) == 192
        checks += 3

    source = FILE.read_text()
    tree = ast.parse(source)
    train = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "train")
    train_source = ast.get_source_segment(source, train)
    assert re.search(r"rng\.integers\(0,\s*len\(xs\),\s*size=64\)", train_source)
    assert "rng.permutation" not in train_source
    checks += 2

    samples=[]
    for seed in SEEDS:
        actual = sample_mathport(seed)
        upstream = sample_upstream(seed)
        current_counts = np.bincount(actual,minlength=N)
        upstream_counts = np.bincount(upstream,minlength=N)
        assert not np.array_equal(actual, upstream)
        assert np.all(upstream_counts == 5)
        assert len(actual) == len(upstream) == BATCH*UPDATES
        checks += 3
        samples.append({
            "seed":seed,
            "sampled_slots":int(len(actual)),
            "math_port": {
                "unique_training_examples_seen":int(np.count_nonzero(current_counts)),
                "never_sampled":int(np.count_nonzero(current_counts == 0)),
                "min_repeats":int(current_counts.min()),
                "max_repeats":int(current_counts.max())
            },
            "upstream_recipe_at_n256": {
                "unique_training_examples_seen":int(np.count_nonzero(upstream_counts)),
                "never_sampled":0,
                "min_repeats":5,
                "max_repeats":5
            }
        })

    # Hardware capability only. Do not import the code or launch CUDA.
    torch_available = importlib.util.find_spec("torch") is not None
    cuda_available = False
    torch_version = "unavailable"
    if torch_available:
        import torch
        torch_version = torch.__version__
        cuda_available = bool(torch.cuda.is_available())
    triton_available = importlib.util.find_spec("triton") is not None

    output={
        "gate":"ENERGY-15",
        "classification":"READ_ONLY_UPSTREAM_FIDELITY_PREFLIGHT",
        "status":"PREFLIGHT_PASS_UPSTREAM_EXECUTION_UNVERIFIED",
        "checked_assertions":checks,
        "prior_evidence_archive_sha256":digest(ZIP.read_bytes()),
        "prior_evidence_integrity":"PASS",
        "upstream_repository":"Prefrontal-AI/CRAM",
        "upstream_commit":UPSTREAM_SHA,
        "upstream_train_file_blob_sha":UPSTREAM_TRAIN_BLOB,
        "upstream_sampler":UPSTREAM_SAMPLER,
        "math_port_sampler":"rng.integers with replacement per batch",
        "sampling_recipe_equivalent":False,
        "per_seed":samples,
        "environment":{
            "python":platform.python_version(),
            "torch":torch_version,
            "cuda_available":cuda_available,
            "triton_importable":triton_available,
        },
        "gpu_original_reproduction":"NOT_EXECUTED",
        "official_datasets":"NOT_FETCHED",
        "reserved_scientific_first_use":"NOT_CONSUMED",
        "original_baselines":"NOT_EXECUTED",
        "repo_or_runner_mutation":"NONE",
        "evaluation_caveat":"Upstream sampler fact independently read from pinned repository source; this local preflight checks the math-port and reproduces the two schedules without running models."
    }
    Path(__file__).with_name("results.json").write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps({"checks":checks,"integrity":"PASS","source_fidelity":"FAIL: batch sampling differs","cuda":cuda_available,"triton":triton_available,"samples":samples},indent=2))

if __name__ == "__main__":
    main()
