#!/usr/bin/env python3
"""ENERGY-51: fresh higher-order intervention learning; EXTERNAL synthetic research only.
Frozen source must be committed with preregistration BEFORE any primary seeds are scored.
"""
import argparse, hashlib, itertools, json, time, os, platform, sys
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor

VERSION='E51:v1'
FAMILIES=('parity45','threshold','conditional_mod')
ARMS=('structural_energy','separate_omp','elasticnet','rbf_krr','poly_krr','extra_trees','no_adapt','shuffled_new')
GROUPS=('train_old','train_new','test_old','test_new','test_cold')
COMBOS=[c for degree in range(1,6) for c in itertools.combinations(range(12),degree)]
DEGREES=np.array([len(x) for x in COMBOS],dtype=np.int8)
COMBO_TO_INDEX={c:i for i,c in enumerate(COMBOS)}


def keyed(seed,case,tag):
    digest=hashlib.sha256(f'{VERSION}|{seed}|{case}|{tag}'.encode()).digest()
    return np.random.default_rng(int.from_bytes(digest[:8],'big'))


def motif_eval(x,ident):
    kind,indices=ident
    s=np.asarray(x)[:,list(indices)].sum(axis=1)
    if kind=='parity':return (1-2*(s%2)).astype(float)
    if kind=='majority':return (2*(s>=3)-1).astype(float)
    if kind=='modulo':return (2*((s%3)==0)-1).astype(float)
    if kind=='gated':
        a=np.asarray(x)[:,indices[0]]==1
        b=np.asarray(x)[:,list(indices[1:])].sum(axis=1)
        return np.where(a,1-2*(b%2),2*(b>=2)-1).astype(float)
    raise ValueError(kind)


def world(seed,wid,family):
    case=f'{wid}:{family}'
    rng=keyed(seed,case,'motifs')
    kinds={'parity45':['parity']*5,'threshold':['parity','majority','majority','parity','majority'],'conditional_mod':['parity','modulo','gated','modulo','gated']}[family]
    used=set();motifs=[]
    for kind in kinds:
        arity=int(rng.choice((4,5))) if kind=='parity' else 5
        for _ in range(200):
            tup=tuple(sorted(int(v) for v in rng.choice(10,arity,replace=False)))
            if (kind,tup) not in used:used.add((kind,tup));break
        else:raise RuntimeError('supports exhausted')
        motifs.append((kind,tup))
    coeff=rng.choice((-1.,1.),5)*rng.uniform(.75,1.15,5)
    # 360 unique underlying causal 10-bit assignments across all train/held contexts.
    nums=keyed(seed,case,'unique-interventions').permutation(1024)[:360]
    out={}
    spans=(('train_old',72),('train_new',72),('test_old',72),('test_new',72),('test_cold',72))
    start=0
    for tag,count in spans:
        nums2=nums[start:start+count];start+=count
        base=((nums2[:,None]>>np.arange(10))&1).astype(np.int8)
        nuisance=keyed(seed,case,tag+':nuisance')
        if tag in ('train_old','test_old'):
            cue10=base[:,0].copy();cue11=base[:,1].copy()
        elif tag in ('train_new','test_new'):
            cue10=1-base[:,0];cue11=base[:,2].copy()
        else:
            cue10=nuisance.integers(0,2,count,dtype=np.int8)
            cue11=nuisance.integers(0,2,count,dtype=np.int8)
        if tag!='test_cold':
            cue10=np.where(nuisance.random(count)<.10,1-cue10,cue10).astype(np.int8)
            cue11=np.where(nuisance.random(count)<.10,1-cue11,cue11).astype(np.int8)
        x=np.column_stack((base,cue10,cue11)).astype(np.int8)
        stage=0 if tag.endswith('old') else 1
        inds=[0,1,2,3 if stage==0 else 4]
        noiseless=sum(float(coeff[i])*motif_eval(x,motifs[i]) for i in inds)
        noise=keyed(seed,case,tag+':label-noise').normal(0,.25,count)
        out[tag]={'x':x,'y':noiseless+noise,'mu':noiseless}
    return {'seed':seed,'wid':wid,'family':family,'case':case,'motifs':motifs,'coeff':coeff,'data':out}


def features(x):
    # (-1) raised to parity count, all <=5th-order Walsh monomials.
    z=1.-2.*np.asarray(x,dtype=np.float32)
    out=np.empty((len(x),len(COMBOS)),dtype=np.float32)
    for idx,comb in enumerate(COMBOS):
        out[:,idx]=np.prod(z[:,comb],axis=1)
    return out


def sparse_forward(X,y,max_terms,priority=True):
    # Residual-energy greedy learner, explicitly tests unseen fourth/fifth-order
    # factor supports with a fixed complexity penalty and refitted selected terms.
    X=np.asarray(X,dtype=np.float64);y=np.asarray(y,dtype=np.float64)
    cols=X-X.mean(axis=0)
    norms=np.sqrt((cols*cols).sum(axis=0))
    norms=np.maximum(norms,1e-7)
    res=y-y.mean();selected=[];weight=np.zeros(0);intercept=float(y.mean())
    for _ in range(max_terms):
        score=np.abs(cols.T@res)/norms
        if priority:score=score/(1.+.045*(DEGREES-1))
        if selected:score[selected]=-np.inf
        j=int(np.argmax(score))
        if not np.isfinite(score[j]) or score[j]<.03:break
        selected.append(j)
        A=np.column_stack([np.ones(len(y)),X[:,selected]])
        pen=np.eye(len(selected)+1)*.02;pen[0,0]=0
        theta=np.linalg.solve(A.T@A+pen,A.T@y)
        intercept=float(theta[0]);weight=theta[1:]
        res=y-A@theta
    return {'cols':selected,'weights':[float(v) for v in weight],'intercept':intercept}


def predict_sparse(model,X):
    inds=model['cols']
    return np.asarray(model['intercept']+X[:,inds]@np.asarray(model['weights']),dtype=float) if inds else np.full(len(X),model['intercept'])


def fit_model(arm,w,ft):
    X0=ft['train_old'];X1=ft['train_new'];Y0=w['data']['train_old']['y'];Y1=w['data']['train_new']['y'];rng=keyed(w['seed'],w['case'],arm+':fit')
    if arm in ('structural_energy','no_adapt','shuffled_new'):
        old=sparse_forward(X0,Y0,6)
        yy=Y1.copy()
        if arm=='shuffled_new':yy=yy[rng.permutation(len(yy))]
        # Treat old factual predictions as an immutable checkpoint. Discover novel
        # corrective latent factors using only new-stage factual consequences.
        correction=sparse_forward(X1,yy-predict_sparse(old,X1),5) if arm!='no_adapt' else {'cols':[],'weights':[],'intercept':0.}
        return {'old':old,'correction':correction,'type':'correction'}
    if arm=='separate_omp':
        # A fully trained matched sparse baseline, one OMP6 for each context.
        pair=[]
        for X,Y in ((X0,Y0),(X1,Y1)):
            m=OrthogonalMatchingPursuit(n_nonzero_coefs=6,fit_intercept=True).fit(X,Y)
            pair.append(m)
        return {'models':pair,'type':'linear'}
    if arm=='elasticnet':
        pair=[]
        for X,Y in ((X0,Y0),(X1,Y1)):
            m=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=1100,tol=.0005,selection='cyclic').fit(X,Y)
            pair.append(m)
        return {'models':pair,'type':'linear'}
    if arm in ('rbf_krr','poly_krr','extra_trees'):
        pair=[]
        for i,(key,Y) in enumerate((('train_old',Y0),('train_new',Y1))):
            X=w['data'][key]['x'].astype(float)
            if arm=='rbf_krr':m=KernelRidge(kernel='rbf',gamma=.30,alpha=.20)
            elif arm=='poly_krr':m=KernelRidge(kernel='polynomial',degree=5,gamma=1/12,coef0=1,alpha=.25)
            else:m=ExtraTreesRegressor(n_estimators=64,max_depth=12,min_samples_leaf=2,n_jobs=1,random_state=int(rng.integers(1,2**31)))
            pair.append(m.fit(X,Y))
        return {'models':pair,'type':'raw'}
    raise KeyError(arm)


def predict_model(model,arm,ft,w,tag):
    stage=0 if tag=='test_old' else 1
    if model['type']=='correction':
        X=ft[tag]
        y=predict_sparse(model['old'],X)
        return y if stage==0 else y+predict_sparse(model['correction'],X)
    return model['models'][stage].predict(w['data'][tag]['x'].astype(float) if model['type']=='raw' else ft[tag])


def score_world(seed,wid,family,include_pred=True):
    w=world(seed,wid,family)
    allx=np.vstack([w['data'][key]['x'] for key in GROUPS])
    allf=features(allx); ft={};off=0
    for key in GROUPS:ft[key]=allf[off:off+72];off+=72
    row={'seed':seed,'wid':wid,'family':family,'case':w['case'],'source_hash':hashlib.sha256(allx.tobytes()).hexdigest(),
         'true_supports':[{'operator':op,'bits':list(bits),'weight':float(c)} for (op,bits),c in zip(w['motifs'],w['coeff'])],
         'observed_train_hash':hashlib.sha256(np.concatenate((w['data']['train_old']['y'],w['data']['train_new']['y'])).tobytes()).hexdigest(),
         'models':{}}
    for arm in ARMS:
        st=time.perf_counter();m=fit_model(arm,w,ft);fitted=time.perf_counter()-st
        st=time.perf_counter();pred={tag:predict_model(m,arm,ft,w,tag) for tag in ('test_old','test_new','test_cold')};elapsed=time.perf_counter()-st
        mses={tag:float(np.mean((pred[tag]-w['data'][tag]['y'])**2)) for tag in pred}
        rec={'mse':mses,'fit_seconds':fitted,'predict_seconds':elapsed}
        if include_pred:rec['predictions']={tag:[float(v) for v in pred[tag]] for tag in pred}
        if arm in ('structural_energy','no_adapt','shuffled_new'):
            rec['old_supports']=[COMBOS[j] for j in m['old']['cols']]
            rec['correction_supports']=[COMBOS[j] for j in m['correction']['cols']]
            rec['old_model']=m['old'];rec['correction_model']=m['correction']
        row['models'][arm]=rec
    return row


def evaluate(seeds,wids,families):
    st=time.perf_counter();rows=[score_world(seed,wid,family) for seed in seeds for wid in wids for family in families]
    arms={arm:{} for arm in ARMS}
    for arm in ARMS:
        arms[arm]={'mse':{tag:float(np.mean([r['models'][arm]['mse'][tag] for r in rows])) for tag in ('test_old','test_new','test_cold')},
                   'seconds':float(sum(r['models'][arm]['fit_seconds']+r['models'][arm]['predict_seconds'] for r in rows))}
    oldbase=arms['structural_energy']['mse']['test_old'];cold=arms['structural_energy']['mse']['test_cold']
    strongest=min(arms[a]['mse']['test_cold'] for a in ('separate_omp','elasticnet','rbf_krr','poly_krr','extra_trees'))
    bestold=min(arms[a]['mse']['test_old'] for a in ('separate_omp','elasticnet','rbf_krr','poly_krr','extra_trees'))
    pa=[]
    for row in rows:
        true={tuple(v['bits']) for v in row['true_supports'] if v['operator']=='parity' and len(v['bits'])>=4}
        found={tuple(v) for v in row['models']['structural_energy']['old_supports']+row['models']['structural_energy']['correction_supports']}
        if true:pa.extend([int(x in found) for x in true])
    recall=float(np.mean(pa)) if pa else 0
    seed_margin={str(seed):float(np.mean([r['models']['structural_energy']['mse']['test_cold'] for r in rows if r['seed']==seed]) -
                             min(np.mean([r['models'][a]['mse']['test_cold'] for r in rows if r['seed']==seed]) for a in ('separate_omp','elasticnet','rbf_krr','poly_krr','extra_trees'))) for seed in seeds}
    family_margin={family:float(np.mean([r['models']['structural_energy']['mse']['test_cold'] for r in rows if r['family']==family])/
                            min(np.mean([r['models'][a]['mse']['test_cold'] for r in rows if r['family']==family]) for a in ('separate_omp','elasticnet','rbf_krr','poly_krr','extra_trees'))) for family in families}
    gates={
      'cold_10pct_better_than_best_conventional':cold<=.9*strongest,
      'higher_order_parity_recall_60pct':recall>=.6,
      'old_frozen_retention_exact':abs(arms['structural_energy']['mse']['test_old']-arms['no_adapt']['mse']['test_old'])<1e-10,
      'new_no_worse_than_best_conventional_5pct':arms['structural_energy']['mse']['test_new']<=1.05*min(arms[a]['mse']['test_new'] for a in ('separate_omp','elasticnet','rbf_krr','poly_krr','extra_trees')),
      'cold_at_least_20pct_better_than_shuffled':cold<=.8*arms['shuffled_new']['mse']['test_cold'],
      'seed_stability_2_of_3':sum(v<0 for v in seed_margin.values())>=2,
      'cost_below_2x_separate_omp':arms['structural_energy']['seconds']<=2*arms['separate_omp']['seconds'],
      'cold_vs_new_degradation_at_most_20pct':cold<=1.2*arms['structural_energy']['mse']['test_new'],
      'every_family_at_most_10pct_worse_than_best':all(v<=1.10 for v in family_margin.values())
    }
    return {'schema':'energy51.primary.v1','seeds':list(seeds),'worlds':len(rows),'rows':rows,'aggregate':arms,'higher_order_parity_recall':recall,
            'seed_margin_vs_best':seed_margin,'family_ratio_vs_best':family_margin,'gates':gates,'gate_passed':sum(gates.values()),
            'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO','whole_experiment_wall_seconds':time.perf_counter()-st,
            'runtime':{'python':sys.version.split()[0],'numpy':np.__version__,'system':platform.system(),'blas':'single thread contract'} }


def canonical(obj):
    def walk(x):
        if isinstance(x,dict):return {k:walk(v) for k,v in x.items() if k not in ('fit_seconds','predict_seconds','seconds','whole_experiment_wall_seconds','runtime')}
        if isinstance(x,list):return [walk(v) for v in x]
        return x
    return json.dumps(walk(obj),sort_keys=True,separators=(',',':'),allow_nan=False).encode()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);m=ap.add_mutually_exclusive_group(required=True);m.add_argument('--smoke',action='store_true');m.add_argument('--primary',action='store_true');args=ap.parse_args()
    seeds=[99971] if args.smoke else [9311,9323,9341]
    r=evaluate(seeds,[0] if args.smoke else [0,1,2,3],FAMILIES)
    Path(args.out).write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({'status':r['classification'],'worlds':r['worlds'],'gates':r['gate_passed'],'aggregate':r['aggregate'],'recall':r['higher_order_parity_recall'],'seconds':r['whole_experiment_wall_seconds']},indent=2))
