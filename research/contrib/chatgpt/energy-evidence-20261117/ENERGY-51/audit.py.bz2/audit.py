#!/usr/bin/env python3
"""ENERGY-51 independently reconstructed constraint/prediction audit; source-free labels,
held invariants, full-arm refits. Shares sklearn estimators as an explicit limitation.
"""
import argparse,hashlib,itertools,json,os,sys
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor
import experiment as E


def verify_close(x,y,label,tol=1e-7):
    a=np.asarray(x);b=np.asarray(y)
    if a.shape!=b.shape or not np.allclose(a,b,rtol=tol,atol=tol):
        raise AssertionError(f'{label}: mismatch {a.shape} != {b.shape}, max diff {np.max(np.abs(a-b)) if a.shape==b.shape else "n/a"}')
    return int(a.size)

def literal_motif(bits,entry):
    idx=entry['bits'];k=entry['operator']
    n=int(sum(int(bits[j]) for j in idx))
    if k=='parity':return float(1 if n%2==0 else -1)
    if k=='majority':return float(1 if n>=3 else -1)
    if k=='modulo':return float(1 if n%3==0 else -1)
    if k=='gated':
        sub=sum(int(bits[j]) for j in idx[1:])
        return float((1 if sub%2==0 else -1) if int(bits[idx[0]]) else (1 if sub>=2 else -1))
    raise AssertionError(k)

def sourcefree_fit(X,y,n):
    # Independent implementation of penalized greedy selection and centered LS.
    X=np.asarray(X,dtype=float);y=np.asarray(y,dtype=float)
    base=np.mean(X,axis=0);centered=X-base
    norm=np.maximum(np.sqrt(np.einsum('ij,ij->j',centered,centered)),1e-7)
    ids=[];theta=np.array([np.mean(y)]);res=y-y.mean()
    for _ in range(n):
        scores=(np.abs(centered.T@res)/norm)/(1+.045*(E.DEGREES-1))
        scores[ids]=-np.inf
        j=int(np.argmax(scores))
        if not np.isfinite(scores[j]) or scores[j]<.03:break
        ids.append(j)
        A=np.column_stack((np.ones(len(y)),X[:,ids]));pen=np.diag([0.]+[.02]*len(ids))
        theta=np.linalg.solve(A.T@A+pen,A.T@y)
        res=y-A@theta
    return {'cols':ids,'intercept':float(theta[0]),'weights':list(map(float,theta[1:]))}

def pred(m,X):
    return np.asarray(m['intercept']+X[:,m['cols']]@np.asarray(m['weights']),dtype=float) if m['cols'] else np.full(len(X),m['intercept'])

def independently_refit(arm,X0,X1,Y0,Y1,world,fts):
    if arm in ('structural_energy','no_adapt','shuffled_new'):
        old=sourcefree_fit(X0,Y0,6)
        Y=Y1.copy()
        if arm=='shuffled_new':
            Y=Y[E.keyed(world['seed'],world['case'],arm+':fit').permutation(len(Y))]
        delta=sourcefree_fit(X1,Y-pred(old,X1),5) if arm!='no_adapt' else {'cols':[],'intercept':0.,'weights':[]}
        return {tag:pred(old,fts[tag])+(pred(delta,fts[tag]) if tag!='test_old' else 0) for tag in ('test_old','test_new','test_cold')},(old,delta)
    models=[]
    for tag in ('train_old','train_new'):
        i=0 if tag=='train_old' else 1
        x=np.asarray(world['data'][tag]['x'],dtype=float)
        y=(Y0,Y1)[i]
        f=(X0,X1)[i]
        if arm=='separate_omp':model=OrthogonalMatchingPursuit(n_nonzero_coefs=6,fit_intercept=True).fit(f,y)
        elif arm=='elasticnet':model=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=1100,tol=.0005,selection='cyclic').fit(f,y)
        elif arm=='rbf_krr':model=KernelRidge(alpha=.20,kernel='rbf',gamma=.30).fit(x,y)
        elif arm=='poly_krr':model=KernelRidge(kernel='polynomial',degree=5,gamma=1/12,coef0=1,alpha=.25).fit(x,y)
        elif arm=='extra_trees':
            r=E.keyed(world['seed'],world['case'],arm+':fit')
            states=[int(r.integers(1,2**31)) for _ in range(2)]
            model=ExtraTreesRegressor(n_estimators=64,max_depth=12,min_samples_leaf=2,n_jobs=1,random_state=states[i]).fit(x,y)
        else:raise AssertionError(arm)
        models.append(model)
    return {tag:models[0 if tag=='test_old' else 1].predict(fts[tag] if arm in ('separate_omp','elasticnet') else world['data'][tag]['x'].astype(float)) for tag in ('test_old','test_new','test_cold')},None

def verify(doc):
    seeds=doc['seeds'];wids=sorted({r['wid'] for r in doc['rows']});families=sorted({r['family'] for r in doc['rows']})
    assert doc['worlds']==len(doc['rows'])==len(seeds)*len(wids)*len(families)
    assert len(E.COMBOS)==1585 and len(set(E.COMBOS))==1585
    nchecks=0; aggregate={arm:{tag:[] for tag in ('test_old','test_new','test_cold')} for arm in E.ARMS}
    for r in doc['rows']:
        w=E.world(r['seed'],r['wid'],r['family'])
        assert r['case']==w['case']
        assert [(v['operator'],tuple(v['bits'])) for v in r['true_supports']]==w['motifs']
        nchecks+=len(w['motifs'])
        x=np.vstack([w['data'][tag]['x'] for tag in E.GROUPS])
        assert hashlib.sha256(x.tobytes()).hexdigest()==r['source_hash']
        assert len(set(tuple(row[:10]) for row in x))==360
        assert len(set(tuple(row) for row in x))==360
        nchecks+=720
        yy=np.concatenate([w['data']['train_old']['y'],w['data']['train_new']['y']])
        assert hashlib.sha256(yy.tobytes()).hexdigest()==r['observed_train_hash']
        f=E.features(x);fs={tag:f[i*72:(i+1)*72] for i,tag in enumerate(E.GROUPS)}
        # Recompute all hidden consequences from first principles. Never use
        # plant truth while fitting or recovering model predictions.
        for tag in E.GROUPS:
            expected=[]
            for bits in w['data'][tag]['x']:
                ids=(0,1,2,3 if tag.endswith('old') else 4)
                expected.append(sum(float(w['coeff'][j])*literal_motif(bits,r['true_supports'][j]) for j in ids))
            nchecks+=verify_close(expected,w['data'][tag]['mu'],'hidden rule',1e-12)
        for j,combo in enumerate(E.COMBOS):
            if j%57==0:
                exp=np.array([(-1.)**sum(int(bits[i]) for i in combo) for bits in x])
                nchecks+=verify_close(exp,f[:,j],f'Fourier col{j}',1e-12)
        for arm in E.ARMS:
            pred0,structure=independently_refit(arm,fs['train_old'],fs['train_new'],w['data']['train_old']['y'],w['data']['train_new']['y'],w,fs)
            for tag in ('test_old','test_new','test_cold'):
                saved=r['models'][arm]['predictions'][tag]
                nchecks+=verify_close(saved,pred0[tag],f'{r["case"]}/{arm}/{tag}',2e-6)
                err=np.mean((np.asarray(saved)-w['data'][tag]['y'])**2)
                nchecks+=verify_close(err,r['models'][arm]['mse'][tag],f'mse {arm}/{tag}',1e-10)
                aggregate[arm][tag].append(float(err))
            if structure:
                old,delta=structure
                orig=r['models'][arm]
                assert [E.COMBOS[j] for j in old['cols']]==[tuple(k) for k in orig['old_supports']]
                assert [E.COMBOS[j] for j in delta['cols']]==[tuple(k) for k in orig['correction_supports']]
                nchecks+=4
    for arm in E.ARMS:
        for tag in ('test_old','test_new','test_cold'):
            nchecks+=verify_close(np.mean(aggregate[arm][tag]),doc['aggregate'][arm]['mse'][tag],f'agg {arm}/{tag}',1e-10)
    assert sum(doc['gates'].values())==doc['gate_passed']
    assert doc['classification']==('DEVELOPMENT_GO' if all(doc['gates'].values()) else 'DEVELOPMENT_NO_GO')
    return {'status':'PASS','checks':nchecks,'worlds':doc['worlds'],'models':len(E.ARMS),'scope':'Source regeneration; unique intervention sets; hidden rule independent recomputation; Fourier basis; independent greedy refit; conventional sklearn refit; every held prediction and metric. Same generator and sklearn estimator libraries used.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('primary');p.add_argument('--out',required=True);a=p.parse_args()
    obj=json.loads(Path(a.primary).read_text());v=verify(obj)
    Path(a.out).write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
