#!/usr/bin/env python3
"""ENERGY-39: reproducible, isolated classical Ising-energy vs exact CSP solvers.

Synthetic development ONLY, no learned Yggdrasil native model. A signed XOR2
constraint graph is fully public to each solver. The planted assignment is never
provided to solvers. Exact exhaustive search fixes a global XOR symmetry.
"""
import argparse
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix

SEEDS=(8209,8221,8231)
FAMILIES=('erdos','modular','lattice')
SIZES=(14,18)
WORLDS=(0,1)
METHODS=('anneal','greedy','random','highs','enumerate')
STARTS=12
SWEEPS=60
MILP_LIMIT=2.0


def digest(*items):
    return hashlib.sha256('/'.join(map(str,('energy39-v1',*items))).encode('ascii')).digest()


def randint(bound,*items):
    return int.from_bytes(digest(*items)[:8],'big') % bound


def generator(seed,family,n,world):
    """Returns [(i,j,expected xor parity,positive integer weight)] public CSP."""
    begun=time.perf_counter()
    cycle={tuple(sorted((i,(i+1)%n))) for i in range(n)}
    others=[]
    for i in range(n):
        for j in range(i+1,n):
            if (i,j) in cycle:continue
            if family=='erdos': priority=0
            elif family=='modular':priority=0 if i//4==j//4 else 1
            elif family=='lattice':priority=0 if min(j-i,n-j+i)<=4 else 1
            else:raise ValueError(family)
            others.append((priority,digest('pair',seed,family,n,world,i,j),i,j))
    others.sort()
    chosen=sorted(cycle|{(i,j) for _,_,i,j in others[:2*n]})
    planted=[randint(2,'plant',seed,family,n,world,i) for i in range(n)]
    edges=[]
    for i,j in chosen:
        noise=randint(100,'frustration',seed,family,n,world,i,j)<22
        parity=(planted[i]^planted[j]) ^ int(noise)
        weight=1+randint(4,'weight',seed,family,n,world,i,j)
        edges.append([i,j,parity,weight])
    assert len(edges)==3*n and len(set((i,j) for i,j,_,_ in edges))==len(edges)
    return edges,time.perf_counter()-begun


def violation(edges,bits):
    return sum(w for i,j,t,w in edges if ((int(bits[i])^int(bits[j]))!=t))


def jmatrix(edges,n):
    j=np.zeros((n,n),dtype=np.float64)
    for i,k,t,w in edges:
        j[i,k]=j[k,i]=w*(1-2*t)
    return j


def score_spins(edges,states):
    # Input (count,n) spin matrix; parity-1 when spins differ.
    bits=(states<0).astype(np.int8)
    result=np.zeros(len(bits),dtype=np.int32)
    for i,j,t,w in edges:
        result+=w*((bits[:,i]^bits[:,j])!=t)
    return result


def local_sampler(edges,n,seed,family,world,anneal):
    start=time.perf_counter()
    rng=np.random.default_rng(randint(2**32,'sampler',seed,family,n,world))
    j=jmatrix(edges,n)
    states=rng.choice(np.array([-1.,1.]),size=(STARTS,n))
    best=int(score_spins(edges,states).min())
    for sweep in range(SWEEPS):
        temp=3.0*(0.04/3.0)**(sweep/(SWEEPS-1)) if anneal else 0.0
        for i in rng.permutation(n):
            delta=states[:,i]*(states@j[:,i])
            if anneal:
                chance=np.exp(-np.maximum(delta,0)/temp)
                accept=(delta<=0)|(rng.random(STARTS)<chance)
            else:
                accept=(delta<0)
            states[accept,i]*=-1
        best=min(best,int(score_spins(edges,states).min()))
    return best,time.perf_counter()-start


def random_solver(edges,n,seed,family,world):
    start=time.perf_counter()
    rng=np.random.default_rng(randint(2**32,'random',seed,family,n,world))
    sample=rng.choice(np.array([-1.,1.]),size=(STARTS*(SWEEPS+1),n))
    return int(score_spins(edges,sample).min()),time.perf_counter()-start


def enumerate_exact(edges,n):
    start=time.perf_counter()
    best=sum(w for _,_,_,w in edges)
    # Global XOR symmetry permits fixing x0=0, preserving all solutions' cost.
    for lo in range(0,1<<(n-1),8192):
        x=np.arange(lo,min(lo+8192,1<<(n-1)),dtype=np.uint32)<<1
        score=np.zeros(len(x),dtype=np.int32)
        for i,j,t,w in edges:
            score+=w*((((x>>i)^(x>>j))&1)!=t)
        best=min(best,int(score.min()))
    return best,time.perf_counter()-start


def highs_solver(edges,n):
    start=time.perf_counter()
    m=len(edges);total=n+2*m
    # Binary x_i, binary carry z_e, parity p_e, with x_i+x_j-2z_e-p_e=0.
    rows=[];cols=[];data=[];c=np.zeros(total,dtype=np.float64)
    constant=0
    for e,(i,j,t,w) in enumerate(edges):
        for col,val in ((i,1.0),(j,1.0),(n+e,-2.0),(n+m+e,-1.0)):
            rows.append(e);cols.append(col);data.append(val)
        c[n+m+e]=w*(1-2*t)
        constant+=w*t
    matrix=coo_matrix((data,(rows,cols)),shape=(m,total)).tocsr()
    constraints=LinearConstraint(matrix,np.zeros(m),np.zeros(m))
    sol=milp(c,integrality=np.ones(total),bounds=Bounds(0,1),constraints=constraints,
             options={'time_limit':MILP_LIMIT,'mip_rel_gap':0,'presolve':True})
    value=None
    if sol.x is not None:
        spins=np.rint(sol.x[:n]).astype(np.int32)
        value=int(violation(edges,spins))
    return {'cost':value,'certified':bool(sol.status==0 and sol.success),
            'status':int(sol.status),'dual_bound':float(sol.mip_dual_bound)+constant if sol.mip_dual_bound is not None else None,
            'time_seconds':time.perf_counter()-start}


def one(seed,family,n,world):
    edges,gen_time=generator(seed,family,n,world)
    opt,exact_s=enumerate_exact(edges,n)
    anneal,anneal_s=local_sampler(edges,n,seed,family,world,True)
    greedy,greedy_s=local_sampler(edges,n,seed,family,world,False)
    random,random_s=random_solver(edges,n,seed,family,world)
    highs=highs_solver(edges,n)
    costs={'anneal':anneal,'greedy':greedy,'random':random,'highs':highs['cost'],'enumerate':opt}
    for m,cost in costs.items():
        if cost is not None: assert cost>=opt, (m,seed,family,n,world,cost,opt)
    if highs['certified']:assert highs['cost']==opt,(seed,family,n,world,highs['cost'],opt)
    return {'seed':seed,'family':family,'n':n,'world':world,'edges':edges,'exact_optimum':opt,
            'costs':costs,'highs_certificate':{'certified':highs['certified'],'status':highs['status'],
                                              'dual_bound':highs['dual_bound']},
            'seconds':{'generation':gen_time,'anneal':anneal_s,'greedy':greedy_s,
                       'random':random_s,'highs':highs['time_seconds'],'enumerate':exact_s}}


def stats(cases):
    k=len(cases)
    optimal={m:sum(c['costs'][m]==c['exact_optimum'] for c in cases if c['costs'][m] is not None) for m in METHODS}
    gaps={m:sum(max(0,(c['costs'][m]-c['exact_optimum'])) if c['costs'][m] is not None else 0 for c in cases) for m in METHODS}
    elapsed={m:sum(c['seconds'][m]+c['seconds']['generation'] for c in cases) for m in METHODS}
    solves={m:sum(c['seconds'][m] for c in cases) for m in METHODS}
    family={f:{'count':sum(c['family']==f for c in cases),'anneal_optimal':sum(c['family']==f and c['costs']['anneal']==c['exact_optimum'] for c in cases)} for f in FAMILIES}
    large=[c for c in cases if c['n']==18]
    certified=sum(c['highs_certificate']['certified'] for c in cases)
    gates={
      'anneal_optimal_at_least_90pct':optimal['anneal']/k>=.90,
      'anneal_beats_greedy_10pp':(optimal['anneal']-optimal['greedy'])/k>=.10,
      'anneal_beats_random_30pp':(optimal['anneal']-optimal['random'])/k>=.30,
      'anneal_optimal_at_least_80pct_each_family':all(family[f]['anneal_optimal']/family[f]['count']>=.80 for f in FAMILIES),
      'anneal_optimal_at_least_80pct_n18':sum(c['costs']['anneal']==c['exact_optimum'] for c in large)/len(large)>=.80,
      'energy_speed_2x_vs_exact_enumeration':elapsed['anneal']<=.5*elapsed['enumerate'],
      'energy_speed_2x_vs_highs_exact':certified==k and elapsed['anneal']<=.5*elapsed['highs'],
      'highs_certifies_every_instance':certified==k,
    }
    return {'count':k,'optimal_count':optimal,'total_absolute_excess_cost':gaps,
            'all_in_seconds_source_plus_solver':elapsed,'solver_seconds':solves,'family':family,
            'highs_certified_count':certified,'gates':gates,
            'classification':'DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO'}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--smoke',action='store_true')
    ap.add_argument('--out',required=True)
    arg=ap.parse_args()
    started=time.perf_counter()
    configs=([(99563,f,n,0) for f,n in (('erdos',14),('modular',18),('lattice',18))]
             if arg.smoke else [(s,f,n,w) for s in SEEDS for f in FAMILIES for n in SIZES for w in WORLDS])
    cases=[one(*k) for k in configs]
    result={'schema':'yggdrasil.energy39.result.v1','experiment_id':'ENERGY-39',
            'mode':'smoke' if arg.smoke else 'primary',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seeds':[99563] if arg.smoke else list(SEEDS),
            'config':{'sizes':list(SIZES),'families':list(FAMILIES),'world_ids':list(WORLDS),
                      'starts':STARTS,'sweeps':SWEEPS,'milp_time_limit_seconds':MILP_LIMIT},
            'cases':cases,'summary':stats(cases),
            'wall_seconds':time.perf_counter()-started,
            'scientific_pass':False,'native_checkpoint_run':False,'deployment':'NONE'}
    Path(arg.out).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2,sort_keys=True))

if __name__=='__main__':main()
