#!/usr/bin/env python3
"""ENERGY-39 independent world/solver audit; does not import experiment.py.

Independent graph reconstruction, parity-oracle, annealing/greedy/random replay,
all score gates. HiGHS original certificate is compared against a separately
computed exhaustive minimum; no claim of independently implementing HiGHS.
"""
import hashlib
import json
import math
import sys
from pathlib import Path
from itertools import combinations
import numpy as np

ROOT=Path(__file__).parent
SEEDS=(8209,8221,8231)
FAMILIES=('erdos','modular','lattice')
SIZES=(14,18)
WORLDS=(0,1)
STARTS=12
SWEEPS=60
METHODS=('anneal','greedy','random','highs','enumerate')


def key(*values):
    return hashlib.sha256('/'.join(str(x) for x in ('energy39-v1',*values)).encode('ascii')).digest()


def draw(lim,*x):
    return int.from_bytes(key(*x)[:8],'big')%lim


def independent_edges(seed,family,n,world):
    ring={tuple(sorted((i,(i+1)%n))) for i in range(n)}
    choices=[]
    for i,j in combinations(range(n),2):
        if (i,j) in ring:continue
        if family=='erdos':p=0
        elif family=='modular':p=int(i//4!=j//4)
        else:p=int(min(j-i,n-j+i)>4)
        choices.append((p,key('pair',seed,family,n,world,i,j),(i,j)))
    choices.sort()
    pairs=sorted(ring | {v for _,_,v in choices[:2*n]})
    assignment={i:draw(2,'plant',seed,family,n,world,i) for i in range(n)}
    return [[i,j,(assignment[i]^assignment[j])^int(draw(100,'frustration',seed,family,n,world,i,j)<22),
             1+draw(4,'weight',seed,family,n,world,i,j)] for i,j in pairs]


def oracle(edges,n):
    # Alternative vectorized enumeration over all assignments with x0=0.
    samples=np.arange(1<<(n-1),dtype=np.uint32)*2
    err=np.zeros(len(samples),dtype=np.int32)
    for i,j,t,w in edges:
        a=(samples & (1<<i))!=0
        b=(samples & (1<<j))!=0
        err+=w*((a!=b)!=bool(t))
    return int(err.min())


def spin_energy(edges,s):
    b=s<0
    energy=np.zeros(len(s),dtype=np.int32)
    for i,j,t,w in edges:
        energy+=w*((b[:,i]!=b[:,j])!=bool(t))
    return energy


def sampler(edges,n,seed,family,world,with_temp):
    rng=np.random.default_rng(draw(2**32,'sampler',seed,family,n,world))
    s=rng.choice(np.array([-1.,1.]),size=(STARTS,n))
    best=int(spin_energy(edges,s).min())
    neighbors=[[] for _ in range(n)]
    for i,j,t,w in edges:
        sign=w*(1-2*t)
        neighbors[i].append((j,sign));neighbors[j].append((i,sign))
    for sweep in range(SWEEPS):
        temperature=3*(.04/3)**(sweep/(SWEEPS-1)) if with_temp else 0.
        for i in rng.permutation(n):
            field=sum((scale*s[:,j] for j,scale in neighbors[i]),np.zeros(STARTS))
            diff=s[:,i]*field
            if with_temp:
                chance=np.exp(-np.maximum(diff,0)/temperature)
                accepted=(diff<=0)|(rng.random(STARTS)<chance)
            else:accepted=diff<0
            s[accepted,i]*=-1.
        best=min(best,int(spin_energy(edges,s).min()))
    return best


def random_sample(edges,n,seed,family,world):
    rng=np.random.default_rng(draw(2**32,'random',seed,family,n,world))
    s=rng.choice(np.array([-1.,1.]),size=(STARTS*(SWEEPS+1),n))
    return int(spin_energy(edges,s).min())


def audit(path):
    b=Path(path).read_bytes()
    result=json.loads(b)
    checks=0
    def check(cond,subject):
        nonlocal checks
        checks+=1
        if not cond:raise AssertionError(subject)
    smoke=result['mode']=='smoke'
    expected={ (99563,f,n,0) for f,n in [('erdos',14),('modular',18),('lattice',18)] } if smoke else {
        (s,f,n,w) for s in SEEDS for f in FAMILIES for n in SIZES for w in WORLDS}
    check(result['schema']=='yggdrasil.energy39.result.v1','schema')
    check(result['config']['starts']==STARTS and result['config']['sweeps']==SWEEPS,'frozen work')
    check(len(result['cases'])==len(expected),'cohort cardinality')
    identifiers=set()
    for case in result['cases']:
        seed,family,n,world=[case[k] for k in ('seed','family','n','world')]
        keyid=(seed,family,n,world)
        check(keyid in expected and keyid not in identifiers,'identity unique')
        identifiers.add(keyid)
        edges=independent_edges(seed,family,n,world)
        check(edges==case['edges'],'independently reconstructed constraints')
        check(len(edges)==3*n,'edge count')
        check(all(0<=i<j<n and t in (0,1) and 1<=w<=4 for i,j,t,w in edges),'legal graph')
        gold=oracle(edges,n)
        check(gold==case['exact_optimum']==case['costs']['enumerate'],'exact reference verified')
        check(sampler(edges,n,seed,family,world,True)==case['costs']['anneal'],'anneal replay')
        check(sampler(edges,n,seed,family,world,False)==case['costs']['greedy'],'greedy replay')
        check(random_sample(edges,n,seed,family,world)==case['costs']['random'],'random replay')
        check(all(x>=gold for x in case['costs'].values() if x is not None),'negative cost gap forbidden')
        if case['highs_certificate']['certified']:
            check(case['costs']['highs']==gold,'HiGHS exact vs independent oracle')
            bound=case['highs_certificate']['dual_bound']
            check(bound is None or abs(bound-gold)<1e-6,'HiGHS lower bound')
        for m in METHODS:
            check(case['seconds'][m]>=0,'negative duration')
        check(case['seconds']['generation']>=0,'negative source time')
    check(identifiers==expected,'full cohort')
    summary=result['summary'];k=len(expected)
    optimal={m:sum(c['costs'][m] is not None and c['costs'][m]==c['exact_optimum'] for c in result['cases']) for m in METHODS}
    check(optimal==summary['optimal_count'],'optimal counts')
    check(summary['count']==k,'summary count')
    costs={m:sum(c['seconds']['generation']+c['seconds'][m] for c in result['cases']) for m in METHODS}
    check(all(abs(costs[m]-summary['all_in_seconds_source_plus_solver'][m])<1e-8 for m in METHODS),'runtime sums')
    family={f:[c for c in result['cases'] if c['family']==f] for f in FAMILIES}
    certified=sum(c['highs_certificate']['certified'] for c in result['cases'])
    check(certified==summary['highs_certified_count'],'certificate count')
    large=[c for c in result['cases'] if c['n']==18]
    derived={
      'anneal_optimal_at_least_90pct':optimal['anneal']/k>=.90,
      'anneal_beats_greedy_10pp':(optimal['anneal']-optimal['greedy'])/k>=.10,
      'anneal_beats_random_30pp':(optimal['anneal']-optimal['random'])/k>=.30,
      'anneal_optimal_at_least_80pct_each_family':all(sum(c['costs']['anneal']==c['exact_optimum'] for c in group)/len(group)>=.80 for group in family.values()),
      'anneal_optimal_at_least_80pct_n18':sum(c['costs']['anneal']==c['exact_optimum'] for c in large)/len(large)>=.80,
      'energy_speed_2x_vs_exact_enumeration':costs['anneal']<=.5*costs['enumerate'],
      'energy_speed_2x_vs_highs_exact':certified==k and costs['anneal']<=.5*costs['highs'],
      'highs_certifies_every_instance':certified==k,
    }
    check(derived==summary['gates'],'gates fixed')
    check(summary['classification']==('DEVELOPMENT_GO' if all(derived.values()) else 'DEVELOPMENT_NO_GO'),'classification')
    check(result['scientific_pass'] is False and result['native_checkpoint_run'] is False and result['deployment']=='NONE','authority')
    return {'status':'PASS','checks':checks,'cases':len(expected),'source_free':True,
            'reconstructs_all_constraints':True,'replays_all_nonnative_solvers':True,
            'independent_exact_enumeration':True,'highs_certificates_crosschecked':certified,
            'result_sha256':hashlib.sha256(b).hexdigest(),'gates':derived,
            'limitations':'Uses shared NumPy RNG for replay and SciPy HiGHS certification, not native Yggdrasil research or a separate HiGHS implementation.'}


if __name__=='__main__':
    d=audit(sys.argv[1] if len(sys.argv)>1 else 'scored.json')
    Path(sys.argv[2] if len(sys.argv)>2 else 'audit_result.json').write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
    print(json.dumps(d,sort_keys=True,indent=2))
