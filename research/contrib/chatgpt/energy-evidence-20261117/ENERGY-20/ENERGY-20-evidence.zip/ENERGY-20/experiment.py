"""ENERGY-20: isolated sourced synthetic causal-energy transition comparison.

The CKAD20 world is copied byte-identically from pinned GitHub source; only this
new file is authored. No native model integration or protected original data.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
import math
from pathlib import Path
import time
import numpy as np
from scipy.optimize import minimize
from source_world import make_episode, public_views, rollout

HERE=Path(__file__).resolve().parent
SEEDS=(411,523,647)
N_TRAIN=112
N_EVAL=144
BITS=(0,1)
EVAL_FAMILIES=(("invariant",0),("context_switch",1),("terminal_switch",1))
ARMS=("beta_full","beta_pooled","beta_selected","logistic_saturated","energy_factor","energy_shuffled","energy_frozen")
LAM=1.0

def _hash_bytes(data):return sha256(data).hexdigest()

def action_bits(cohort, seed, index):
    z=sha256(f"energy20/action-v1/{cohort}/{seed}/{index}".encode()).digest()
    return z[0]&1,z[1]&1

def source_row(ep, first, second):
    return rollout(ep,lambda _s:first,lambda _s,_x,_t:second)

def episodes(cohort, seed, family, regime, count):
    return [make_episode(cohort=cohort,seed=seed,index=k,family=family,regime=regime) for k in range(count)]

def train_rows(seed, phase):
    specs=[("energy20-fit-a","invariant",0)]
    if phase==1: specs.append(("energy20-fit-b","context_switch",1))
    rows=[]
    for cohort,family,regime in specs:
        for k,ep in enumerate(episodes(cohort,seed,family,regime,N_TRAIN)):
            x1,x2=action_bits(cohort,seed,k)
            observed=source_row(ep,x1,x2)
            rows.append((ep.s1,x1,observed['s2'],x2,observed['y']))
    return rows

class Beta:
    def __init__(self,rows):
        self.transitions=Counter();self.terminals=Counter()
        self.transition_brier=[Fraction(0),Fraction(0)];self.terminal_brier=[Fraction(0),Fraction(0)]
        for s,x,t,a,y in rows:
            for i,key in enumerate(((s,x),(x,))):
                p=self._prob(self.transitions,(i,*key))
                self.transition_brier[i]+=(p-t)**2
            for i,key in enumerate(((s,x,t,a),(t,a))):
                p=self._prob(self.terminals,(i,*key))
                self.terminal_brier[i]+=(p-y)**2
            for i,key in enumerate(((s,x),(x,))):self.transitions[(i,*key),t]+=1
            for i,key in enumerate(((s,x,t,a),(t,a))):self.terminals[(i,*key),y]+=1
        self.t_select=int(self.transition_brier[1]<=self.transition_brier[0])
        self.y_select=int(self.terminal_brier[1]<=self.terminal_brier[0])
    @staticmethod
    def _prob(counts,key):
        p=counts[key,1]+1;n=counts[key,0]+counts[key,1]+2
        return p/n
    def transition(self,s,x,mode):
        i=0 if mode=="full" else 1 if mode=="pooled" else self.t_select
        return self._prob(self.transitions,(i, *((s,x) if i==0 else (x,))))
    def terminal(self,s,x,t,a,mode):
        i=0 if mode=="full" else 1 if mode=="pooled" else self.y_select
        return self._prob(self.terminals,(i, *((s,x,t,a) if i==0 else (t,a))))

def features(s,x,t,model):
    if model=="energy":
        # Source prior: two competing causal parity rule families, plus bias.
        return np.array([1 if t==x else -1,
                         1 if t==(x^s) else -1,
                         1 if t==(x^1) else -1],dtype=float)
    # Conventional saturated logistic, one free logit per public (s,x) cell.
    v=np.zeros(4,dtype=float);v[2*s+x]=2*t-1
    return v

class LogLinear:
    def __init__(self,rows,model="energy",shuffle=False,seed=0):
        self.model=model;self.dim=3 if model=="energy" else 4
        arr=list(rows)
        if shuffle:
            rng=np.random.default_rng(seed+1_029_121)
            contexts=rng.permutation([r[0] for r in arr]).tolist()
            arr=[(contexts[k],r[1],r[2],r[3],r[4]) for k,r in enumerate(arr)]
        x=np.stack([features(s,a,t,model) for s,a,t,_,_ in arr])
        # P(observed t | s,x) = sigmoid(2 * dot(theta, signed observed-state features)).
        def objective(theta):
            z=2*x@theta
            value=np.logaddexp(0,-z).sum()+LAM*theta@theta
            delta=-2/(1+np.exp(np.clip(z,-80,80)))
            grad=x.T@delta+2*LAM*theta
            return float(value),grad
        result=minimize(objective,np.zeros(self.dim),jac=True,method="L-BFGS-B",options={"ftol":1e-14,"gtol":1e-8,"maxiter":500})
        if not result.success and np.max(np.abs(result.jac))>1e-5:
            raise RuntimeError("TRAINING_NOT_CONVERGED "+str(result.message))
        self.weights=result.x
        self.grad_inf=float(np.max(np.abs(result.jac)))
        self.iters=int(result.nit)
        self.loss=float(result.fun)
    def transition(self,s,a):
        z1=2*features(s,a,1,self.model)@self.weights
        z0=2*features(s,a,0,self.model)@self.weights
        e0=np.exp(z0-max(z0,z1));e1=np.exp(z1-max(z0,z1))
        return float(e1/(e0+e1))

def train_all(rows, frozen_rows,seed):
    start=time.perf_counter()
    beta=Beta(rows)
    base_t=time.perf_counter()-start
    start=time.perf_counter();logistic=LogLinear(rows,"saturated");log_t=time.perf_counter()-start
    start=time.perf_counter();energy=LogLinear(rows,"energy");ene_t=time.perf_counter()-start
    start=time.perf_counter();shuffle=LogLinear(rows,"energy",True,seed);scr_t=time.perf_counter()-start
    start=time.perf_counter();frozen=LogLinear(frozen_rows,"energy");fr_t=time.perf_counter()-start
    return {"beta":beta,"logistic":logistic,"energy":energy,"scrambled":shuffle,"frozen":frozen}, {"beta":base_t,"logistic":log_t,"energy":ene_t,"scrambled":scr_t,"frozen":fr_t}

def forecast(models,arm,s,x,t=None,a=None):
    beta=models["beta"]
    if t is not None:return beta.terminal(s,x,t,a,"selected")
    if arm.startswith("beta_"):
        mode=arm.split("_")[1]
        return beta.transition(s,x,mode)
    key={"logistic_saturated":"logistic","energy_factor":"energy","energy_shuffled":"scrambled","energy_frozen":"frozen"}[arm]
    return models[key].transition(s,x)

def make_plan(models,arm,s):
    values=[];seconds=[]
    for first in BITS:
        p=forecast(models,arm,s,first)
        second_by_state=[];expected=[]
        for state in BITS:
            ys=[forecast(models,arm,s,first,state,a) for a in BITS]
            a=int(ys[1]>ys[0]);second_by_state.append(a);expected.append(ys[a])
        seconds.append(second_by_state)
        values.append((1-p)*expected[0]+p*expected[1])
    first=int(values[1]>values[0])
    return first, seconds[first]

def evaluate(models,seed,cohort,family,regime):
    total={arm:{"reward_sum":0,"transition_brier_sum":0.0,"terminal_brier_sum":0.0,"choices":[]} for arm in ARMS}
    for k,ep in enumerate(episodes(cohort,seed,family,regime,N_EVAL)):
        s=ep.s1
        # Match diagnostic prediction target: randomized factual rollout, no update on held data.
        x1,x2=action_bits(cohort,seed,k)
        factual=source_row(ep,x1,x2)
        for arm in ARMS:
            p=forecast(models,arm,s,x1)
            q=forecast(models,arm,s,x1,factual["s2"],x2)
            first,seconds=make_plan(models,arm,s)
            row=rollout(ep,lambda _s:first,lambda _s,_x,t:seconds[t])
            z=total[arm];z["reward_sum"]+=row["y"]
            z["transition_brier_sum"]+=(p-factual["s2"])**2
            z["terminal_brier_sum"]+=(q-factual["y"])**2
            z["choices"].append(first)
    return {arm:{"reward_sum":x["reward_sum"],"n":N_EVAL,
         "transition_brier":round(x["transition_brier_sum"]/N_EVAL,9),
         "terminal_brier":round(x["terminal_brier_sum"]/N_EVAL,9),
         "first_action_ones":sum(x["choices"])} for arm,x in total.items()}

def smoke():
    for seed in (411,523):
        rows=train_rows(seed,0);assert len(rows)==N_TRAIN
        assert len(set(rows))<=N_TRAIN
        models,t=train_all(rows,rows,seed)
        for s,x in ((0,0),(0,1),(1,0),(1,1)):
            for arm in ARMS:
                p=forecast(models,arm,s,x)
                assert 0<p<1 and math.isfinite(p)
                a,b=make_plan(models,arm,s)
                assert a in BITS and len(b)==2 and all(v in BITS for v in b)
        assert _hash_bytes(Path(__file__).with_name("source_world.py").read_bytes())
    return {"smoke":"PASS","seeds":[411,523],"n_train":N_TRAIN}

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--smoke",action="store_true");parser.add_argument("--out",default="scored.json");args=parser.parse_args()
    if args.smoke:
        print(json.dumps(smoke(),sort_keys=True));return
    freeze=json.loads((HERE/"freeze.json").read_text())
    for fn,h in freeze["sha256"].items():
        assert _hash_bytes((HERE/fn).read_bytes())==h,(fn,"changed after freeze")
    start=time.perf_counter()
    data=[]
    for seed in SEEDS:
        first_rows=train_rows(seed,0)
        for phase in (0,1):
            rows=train_rows(seed,phase)
            models,times=train_all(rows,first_rows,seed)
            cohorts={f"{f}-{r}":evaluate(models,seed,f"energy20-held-{f}-{r}",f,r) for f,r in EVAL_FAMILIES}
            data.append({"seed":seed,"phase":phase,"training_count":len(rows),"times":times,
                         "fit":{k:{"weights":v.weights.tolist(),"gradient_inf":v.grad_inf,"iters":v.iters} for k,v in models.items() if isinstance(v,LogLinear)},
                         "select":{"transition":models["beta"].t_select,"terminal":models["beta"].y_select},"cohorts":cohorts})
    scored={"schema":"energy20.outcome.v1","classification":"isolated_source-authenticated_synthetic_development","upstream_sha":"d8f27db46af889afdfeb104fc471a710fc6d5c06",
            "source_git_blob":"160001d60f2ce2ca7ca3e9ab5d14261ba9ce42a8", "seeds":SEEDS,"training_per_phase":N_TRAIN,
            "held_per_seed_family":N_EVAL,"arms":ARMS,"results":data,"timing_total_s":round(time.perf_counter()-start,3),
            "native_model_replayed":False,"protected_first_use":False,"yggdrasil_source_mutated":False}
    path=HERE/args.out;path.write_text(json.dumps(scored,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"output":str(path),"records":len(data),"total_seconds":scored["timing_total_s"]},sort_keys=True))

if __name__=="__main__":main()
