"""Independent ENERGY-20 scorer: no import of experiment.py; source-world only.

Reconstructs training and evaluation episode draws from their public source
namespace and verifies every scored policy reward and diagnostic prediction.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from hashlib import sha256, sha1
from pathlib import Path
import json, math, sys
import numpy as np
from source_world import make_episode, public_views, rollout

ROOT=Path(__file__).resolve().parent
ARMS=("beta_full","beta_pooled","beta_selected","logistic_saturated","energy_factor","energy_shuffled","energy_frozen")
FAMILIES=(("invariant",0),("context_switch",1),("terminal_switch",1))
SEEDS=(411,523,647)


def safe_hash(file):return sha256((ROOT/file).read_bytes()).hexdigest()
def git_hash(file):
    b=(ROOT/file).read_bytes();return sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def action(cohort, seed, index):
    h=sha256(('energy20/action-v1/'+cohort+'/'+str(seed)+'/'+str(index)).encode('ascii')).digest()
    return h[0]%2,h[1]%2

def observed(ep,x,a):
    return rollout(ep,lambda _s:x,lambda _s,_x,_t:a)

def rows(seed,stage):
    spec=[('energy20-fit-a','invariant',0)]
    if stage==1:spec.append(('energy20-fit-b','context_switch',1))
    out=[]
    for name,fam,regime in spec:
        for k in range(112):
            ep=make_episode(cohort=name,seed=seed,index=k,family=fam,regime=regime)
            x,a=action(name,seed,k);row=observed(ep,x,a)
            out.append((ep.s1,x,row['s2'],a,row['y']))
    return out

def fitted_counts(rows):
    tr=Counter();te=Counter()
    trans=[Fraction(0),Fraction(0)];term=[Fraction(0),Fraction(0)]
    def p(c,key):return Fraction(c[(key,1)]+1,c[(key,0)]+c[(key,1)]+2)
    for s,x,t,a,y in rows:
        keys=[(0,s,x),(1,x)];rkeys=[(0,s,x,t,a),(1,t,a)]
        for idx,key in enumerate(keys):trans[idx]+=(p(tr,key)-t)**2
        for idx,key in enumerate(rkeys):term[idx]+=(p(te,key)-y)**2
        for key in keys:tr[(key,t)]+=1
        for key in rkeys:te[(key,y)]+=1
    return tr,te,int(trans[1]<=trans[0]),int(term[1]<=term[0])

def tprob(info,arm,s,x):
    tr,te,tx,ty=info[:4]
    if arm.startswith('beta_'):
        k=arm.split('_')[1]
        mode={'full':0,'pooled':1,'selected':tx}[k]
        key=(0,s,x) if mode==0 else (1,x)
        return (tr[(key,1)]+1)/(tr[(key,0)]+tr[(key,1)]+2)
    w=info[4][{'logistic_saturated':'logistic','energy_factor':'energy','energy_shuffled':'scrambled','energy_frozen':'frozen'}[arm]]
    def weight(state):
        if arm=='logistic_saturated':return w[2*s+x]*(2*state-1)
        return (w[0]*(1 if state==x else -1)
                +w[1]*(1 if state==(x^s) else -1)
                +w[2]*(1 if state!=(x) else -1))
    a=2*weight(0);b=2*weight(1);return 1/(1+math.exp(a-b))

def yprob(info,s,x,t,a):
    tr,te,tx,ty=info[:4]
    key=(0,s,x,t,a) if ty==0 else (1,t,a)
    return (te[(key,1)]+1)/(te[(key,0)]+te[(key,1)]+2)

def plan(info,arm,s):
    vals=[];contingency=[]
    for x in (0,1):
        p=tprob(info,arm,s,x);best=[];act=[]
        for t in (0,1):
            y=[yprob(info,s,x,t,a) for a in (0,1)]
            a=int(y[1]>y[0]);best.append(y[a]);act.append(a)
        vals.append((1-p)*best[0]+p*best[1]);contingency.append(act)
    first=int(vals[1]>vals[0]);return first,contingency[first]

def audit():
    freeze=json.loads((ROOT/'freeze.json').read_text())
    assert git_hash('source_world.py')==freeze['upstream_github_blob']=='160001d60f2ce2ca7ca3e9ab5d14261ba9ce42a8'
    for name,h in freeze['sha256'].items():assert safe_hash(name)==h
    sc=json.loads((ROOT/'scored.json').read_text())
    assert sc['schema']=='energy20.outcome.v1' and sc['seeds']==list(SEEDS)
    assert tuple(sc['arms'])==ARMS and len(sc['results'])==6
    checks=0;exact=0;negatives=[];gradients=[]
    for record in sc['results']:
        seed=record['seed'];stage=record['phase'];training=rows(seed,stage)
        assert len(training)==(stage+1)*112 and record['training_count']==len(training);checks+=2
        tr,te,tx,ty=fitted_counts(training)
        assert record['select']=={'transition':tx,'terminal':ty};checks+=1
        w={k:v['weights'] for k,v in record['fit'].items()}
        info=(tr,te,tx,ty,w)
        for key,meta in record['fit'].items():
            assert meta['gradient_inf']<=1e-5,meta
            assert meta['iters']<=500
            checks+=2;gradients.append(meta['gradient_inf'])
        for fam,regime in FAMILIES:
            cohort=f'energy20-held-{fam}-{regime}'
            expected=record['cohorts'][f'{fam}-{regime}']
            totals={a:{'reward':0,'tp':0.0,'yp':0.0,'ones':0} for a in ARMS}
            for k in range(144):
                ep=make_episode(cohort=cohort,seed=seed,index=k,family=fam,regime=regime)
                s=ep.s1; first,second=action(cohort,seed,k)
                factual=observed(ep,first,second)
                for arm in ARMS:
                    p=tprob(info,arm,s,first)
                    q=yprob(info,s,first,factual['s2'],second)
                    x,act=plan(info,arm,s)
                    got=observed(ep,x,act[ep.transition(x)])
                    z=totals[arm];z['reward']+=got['y'];z['tp']+=(p-factual['s2'])**2
                    z['yp']+=(q-factual['y'])**2;z['ones']+=x
                    checks+=4
            for arm,z in totals.items():
                a=expected[arm]
                assert a['n']==144 and a['reward_sum']==z['reward'] and a['first_action_ones']==z['ones'],(seed,stage,fam,arm,'reward')
                assert abs(a['transition_brier']-z['tp']/144)<6e-10,(seed,stage,fam,arm,'Brier')
                assert abs(a['terminal_brier']-z['yp']/144)<6e-10,(seed,stage,fam,arm,'terminal')
                checks+=5;exact+=1
        # Original CKAD-20 evaluation must remain unavailable to this isolated probe.
    z={'schema':'energy20.audit.v1','status':'PASS','assertions':checks,'aggregate_rows_verified':exact,
       'max_abs_optimizer_grad':max(gradients),'verified_source_git_blob':git_hash('source_world.py'),
       'native_original_checkpoint_executed':False,'protected_first_use':False,
       'independence':'Does not import experiment.py; derives each held factual episode, decision and Brier from original source_world.py and recorded weights, independently fits all conventional counts.'}
    (ROOT/'audit_result.json').write_text(json.dumps(z,indent=2,sort_keys=True)+'\n')
    print(json.dumps(z,sort_keys=True));return z
if __name__=='__main__':audit()
