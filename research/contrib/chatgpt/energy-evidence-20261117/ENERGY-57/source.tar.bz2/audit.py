#!/usr/bin/env python3
"""ENERGY-57 external independent re-generation and refitting auditor.
Does not import the scorer. Shares the public NumPy/sklearn solvers and their semantics.
"""
import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge, ElasticNet, OrthogonalMatchingPursuit
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor

FAMS=['stable_edges','flipped_relation','unseen_triple']
N0,N1,NH=96,96,72
COMBO2=list(itertools.combinations(range(12),2))
COMBO4=[t for k in range(1,5) for t in itertools.combinations(range(12),k)]
EDGE_PAIRS=list(itertools.combinations(range(4),2))
ARMS=['stable_relations','separate_relations','unconditional_shared','full_omp','full_elasticnet','rbf_krr','extra_trees','no_adapt','shuffled_new']

def rebuilt(seed,wi,family):
    gen=np.random.default_rng(np.random.SeedSequence([5701,int(seed),int(wi),FAMS.index(family)]))
    roles=list(map(int,gen.permutation(10)))
    signed=(gen.choice([-1.,1.],size=8)*gen.uniform([.9,.9,.9,.9,.55,.55,.6,.55],[1.4,1.4,1.4,1.4,.95,.95,1.,.95])).tolist()
    key=list(map(int,gen.permutation(1024)[:N0+N1+3*NH]))
    bits=((np.asarray(key)[:,None]>>np.arange(10))&1).astype(np.int8)
    observed=np.empty((len(key),12),dtype=np.int8); observed[:,:10]=bits
    for t in range(len(key)):
        stage='old' if t<N0 or N0+N1<=t<N0+N1+NH else 'new' if t<N0+N1 or N0+N1+NH<=t<N0+N1+2*NH else 'cold'
        if stage=='old': raw=[bits[t,roles[0]],bits[t,roles[3]]]
        elif stage=='new':raw=[1-bits[t,roles[0]],bits[t,roles[3]]]
        else:raw=gen.integers(0,2,size=2)
        for q in range(2):
            if stage=='cold': observed[t,10+q]=raw[q]
            else:observed[t,10+q]=raw[q] if gen.random()>=.08 else 1-raw[q]
    s=observed*2-1
    modules=[s[:,roles[2*k]]*s[:,roles[2*k+1]] for k in range(4)]
    a,b,c,d=modules
    invariant=sum(signed[i]*modules[i] for i in range(4))
    old=signed[4]*a*b+signed[5]*c*d+signed[6]*a*c
    new=(signed[4] if family!='flipped_relation' else -signed[4])*a*b+signed[5]*c*d+signed[7]*b*d
    if family=='unseen_triple':new=new+.85*a*b*c
    ranges=[(0,N0,True),(N0,N0+N1,False),(N0+N1,N0+N1+NH,True),(N0+N1+NH,N0+N1+2*NH,False),(N0+N1+2*NH,len(key),False)]
    yy=np.empty(len(key),float)
    for start,stop,isold in ranges:
        yy[start:stop]=invariant[start:stop]+(old if isold else new)[start:stop]+gen.normal(0,.2,stop-start)
    return {'seed':int(seed),'world_id':int(wi),'family':family,'roles':roles,'scales':signed,'causal_keys':key,'x':observed.tolist(),'y':yy.tolist(), 'spans':{'train_old':[0,N0],'train_new':[N0,N0+N1],'held_old':[N0+N1,N0+N1+NH],'held_new':[N0+N1+NH,N0+N1+2*NH],'held_cold':[N0+N1+2*NH,N0+N1+3*NH]}}

def basis(spins,terms):return np.asarray([np.prod(spins[:,list(t)],axis=1) for t in terms],dtype=float).T

def regr(z,y,alpha=.3):return Ridge(alpha=alpha,solver='svd').fit(z,y)

def shared_coef(zo,zn,yo,yn,shared):
    n0,n1=len(yo),len(yn)
    cols=[];descriptions=[]
    for j in range(10):
        if j>=4 and (j-4) in shared:
            cols.append(np.r_[zo[:,j],zn[:,j]]);descriptions.append((j,'both'))
        else:
            cols.extend([np.r_[zo[:,j],np.zeros(n1)],np.r_[np.zeros(n0),zn[:,j]]]);descriptions.extend([(j,'old'),(j,'new')])
    cols.extend((np.r_[np.ones(n0),np.zeros(n1)],np.r_[np.zeros(n0),np.ones(n1)]))
    ridge=Ridge(alpha=.4,fit_intercept=False,solver='svd').fit(np.asarray(cols).T,np.r_[yo,yn])
    newweights=np.zeros(10)
    for value,(ix,s) in zip(ridge.coef_[:-2],descriptions):
        if s in ('new','both'):newweights[ix]=value
    return newweights,float(ridge.coef_[-1])

def replay(w):
    x=np.asarray(w['x'],np.int8); y=np.asarray(w['y'],float);s=x*2-1
    old=slice(0,N0);new=slice(N0,N0+N1)
    held=[slice(*w['spans']['held_'+ph]) for ph in ('old','new','cold')]
    zpair=basis(s,COMBO2)
    candidate=OrthogonalMatchingPursuit(n_nonzero_coefs=4).fit(zpair[old],y[old])
    ix=np.where(np.abs(candidate.coef_)>1e-9)[0].tolist()
    if len(ix)!=4:raise ValueError('retrieved base support count')
    small=zpair[:,ix]
    relation=np.column_stack([small]+[small[:,a]*small[:,b] for a,b in EDGE_PAIRS])
    oldfit=regr(relation[old],y[old]);newfit=regr(relation[new],y[new])
    oldpredict=oldfit.predict(relation[held[0]])
    invariant=[i for i,(a,b) in enumerate(zip(oldfit.coef_[4:],newfit.coef_[4:])) if min(abs(a),abs(b))>=.20 and np.sign(a)==np.sign(b) and abs(a-b)<=.35]
    beta,bias=shared_coef(relation[old],relation[new],y[old],y[new],invariant)
    pb,pbias=shared_coef(relation[old],relation[new],y[old],y[new],list(range(6)))
    out={
      'stable_relations':[oldpredict,relation[held[1]]@beta+bias,relation[held[2]]@beta+bias],
      'separate_relations':[oldpredict,newfit.predict(relation[held[1]]),newfit.predict(relation[held[2]])],
      'unconditional_shared':[oldpredict,relation[held[1]]@pb+pbias,relation[held[2]]@pb+pbias],
      'no_adapt':[oldpredict,oldfit.predict(relation[held[1]]),oldfit.predict(relation[held[2]])]
    }
    perm=np.random.default_rng(np.random.SeedSequence([5707,w['seed'],w['world_id'],FAMS.index(w['family'])])).permutation(y[new]);sham=regr(relation[new],perm)
    out['shuffled_new']=[oldpredict,sham.predict(relation[held[1]]),sham.predict(relation[held[2]])]
    wide=basis(s,COMBO4)
    for name,oldmodel,newmodel,inputs in (
      ('full_omp',OrthogonalMatchingPursuit(n_nonzero_coefs=8).fit(wide[old],y[old]),OrthogonalMatchingPursuit(n_nonzero_coefs=8).fit(wide[new],y[new]),wide),
      ('full_elasticnet',ElasticNet(alpha=.055,l1_ratio=.8,max_iter=2000,tol=.0005).fit(wide[old],y[old]),ElasticNet(alpha=.055,l1_ratio=.8,max_iter=2000,tol=.0005).fit(wide[new],y[new]),wide),
      ('rbf_krr',KernelRidge(alpha=.25,kernel='rbf',gamma=.20).fit(x[old],y[old]),KernelRidge(alpha=.25,kernel='rbf',gamma=.20).fit(x[new],y[new]),x),
      ('extra_trees',ExtraTreesRegressor(n_estimators=48,max_depth=12,min_samples_leaf=2,n_jobs=1,random_state=7).fit(x[old],y[old]),ExtraTreesRegressor(n_estimators=48,max_depth=12,min_samples_leaf=2,n_jobs=1,random_state=13).fit(x[new],y[new]),x)):
        out[name]=[oldmodel.predict(inputs[held[0]]),newmodel.predict(inputs[held[1]]),newmodel.predict(inputs[held[2]])]
    return out,[list(COMBO2[i]) for i in ix],invariant

def audit(obj):
    errors=[];checks=0;cases=obj['cases'];eps=5e-9
    for case in cases:
        w=case['world'];ref=rebuilt(w['seed'],w['world_id'],w['family']);
        for k in ref:
            if k in ('scales','y'):
                a=np.asarray(w[k],float);b=np.asarray(ref[k],float)
                if a.shape!=b.shape or not np.allclose(a,b,rtol=0,atol=1e-11):errors.append(f'{w["seed"]} {w["world_id"]} {k}')
                checks+=len(a)
            else:
                if w[k]!=ref[k]:errors.append(f'{w["seed"]} {w["world_id"]} {k}')
                checks+=1
        if len(set(w['causal_keys']))!=N0+N1+3*NH:errors.append('duplicate underlying do action')
        checks+=1
        out,selected,inv=replay(ref)
        if selected!=case['info']['selected_pairs']:errors.append('selected causal primitive mismatched')
        if inv!=case['info']['invariant_edges']:errors.append('invariant edge selection mismatched')
        checks+=2
        for arm in ARMS:
            if arm not in case['predictions']:errors.append('arm missing '+arm);continue
            for k,ph in enumerate(('old','new','cold')):
                got=np.asarray(case['predictions'][arm][k],float)
                want=np.asarray(out[arm][k],float)
                if got.shape!=want.shape or not np.allclose(got,want,rtol=0,atol=eps): errors.append(f'{w["seed"]}:{w["world_id"]}:{w["family"]}:{arm}:{ph}:prediction')
                checks+=len(want)
                yr=np.asarray(ref['y'][slice(*ref['spans']['held_'+ph])],float)
                score=float(np.mean((want-yr)**2))
                if abs(score-case['metrics'][arm][ph])>eps:errors.append(f'{arm} {ph} MSE')
                checks+=1
    for arm in ARMS:
        for ph in ('old','new','cold'):
            score=float(np.mean([c['metrics'][arm][ph] for c in cases]))
            if abs(score-obj['aggregate'][arm][ph])>eps:errors.append('aggregate '+arm+ph)
            checks+=1
    for seed in obj['seeds']:
        for arm in ARMS:
            score=float(np.mean([c['metrics'][arm]['cold'] for c in cases if c['world']['seed']==seed]))
            if abs(score-obj['per_seed'][str(seed)][arm])>eps:errors.append('seed group mismatch')
            checks+=1
    for family in obj['families']:
        for arm in ARMS:
            score=float(np.mean([c['metrics'][arm]['cold'] for c in cases if c['world']['family']==family]))
            if abs(score-obj['per_family'][family][arm])>eps:errors.append('family group mismatch')
            checks+=1
    correct=0
    for case in cases:
        roles=case['world']['roles'];true={tuple(sorted(roles[i*2:i*2+2])) for i in range(4)}
        seen={tuple(sorted(pair)) for pair in case['info']['selected_pairs']}
        correct+=len(true&seen)
    if abs(obj['primitive_recall']-correct/(len(cases)*4))>eps:errors.append('recall mismatch')
    checks+=len(cases)*4
    correct_edge=0;candidate_edges=0;ground_edge_count=0;false_edges=0
    for case in cases:
        w=case['world'];roles=w['roles']
        latent={tuple(sorted(roles[2*j:2*j+2])):j for j in range(4)}
        decoded=[latent.get(tuple(sorted(x))) for x in case['info']['selected_pairs']]
        invariant_truth={(2,3)} if w['family']=='flipped_relation' else {(0,1),(2,3)}
        ground_edge_count+=len(invariant_truth)
        for j in case['info']['invariant_edges']:
            a,b=EDGE_PAIRS[j];a,b=decoded[a],decoded[b]
            if a is not None and b is not None and tuple(sorted([a,b])) in invariant_truth:correct_edge+=1
            else:false_edges+=1
            candidate_edges+=1
    if abs(obj['invariant_edge_recall']-correct_edge/ground_edge_count)>eps:errors.append('invariant edge recall mismatch')
    if abs(obj['invariant_edge_precision']-correct_edge/max(1,candidate_edges))>eps:errors.append('invariant edge precision mismatch')
    if obj['invariant_edges_selected']!=candidate_edges or obj['invariant_edges_false']!=false_edges:errors.append('invariant edge receipts mismatch')
    checks+=candidate_edges+ground_edge_count+4
    return {'experiment':'ENERGY-57','auditor':'independent-generation-and-structural-refit-v1','checks':checks,'errors':errors[:40],'error_count':len(errors),'status':'PASS' if not errors else 'FAIL','worlds':len(cases),'arms':len(ARMS),'seeds':obj['seeds'],'generator_independent_of_scorer_import':True,'backend_shared':'NumPy and sklearn are shared'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('score');p.add_argument('--out',required=True);arg=p.parse_args()
    obj=json.loads(Path(arg.score).read_text());report=audit(obj);Path(arg.out).write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('status','checks','error_count','worlds')}));raise SystemExit(0 if report['status']=='PASS' else 2)
