#!/usr/bin/env python3
"""ENERGY-57: External synthetic prospective test of invariant learned causal-factor edges.
Does NOT train or alter native Yggdrasil. No eval labels available at fit time.
"""
import argparse,hashlib,itertools,json,time
from pathlib import Path
from functools import lru_cache
import numpy as np
from sklearn.linear_model import Ridge, ElasticNet, OrthogonalMatchingPursuit
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor

FAMILIES=('stable_edges','flipped_relation','unseen_triple')
ARMS=('stable_relations','separate_relations','unconditional_shared','full_omp','full_elasticnet','rbf_krr','extra_trees','no_adapt','shuffled_new')
NOLD=96; NNEW=96; NHELD=72
@lru_cache(None)
def combos(upto):return tuple(c for d in range(1,upto+1) for c in itertools.combinations(range(12),d))
def spin(x):return 2*np.asarray(x,dtype=np.int8)-1
def features(x,terms):
    s=spin(x);return np.column_stack([np.prod(s[:,c],axis=1) for c in terms]).astype(float)
def rng_world(seed,idx,family):return np.random.default_rng(np.random.SeedSequence([5701,int(seed),int(idx),FAMILIES.index(family)]))
def world(seed,idx,family):
    rng=rng_world(seed,idx,family)
    roles=rng.permutation(10).tolist()
    scales=(rng.choice([-1.,1.],size=8)*rng.uniform([.9,.9,.9,.9,.55,.55,.6,.55],[1.4,1.4,1.4,1.4,.95,.95,1.,.95])).tolist()
    n=NOLD+NNEW+3*NHELD
    keys=rng.permutation(1024)[:n].astype(int)
    xb=((keys[:,None]>>np.arange(10))&1).astype(np.int8)
    x=np.column_stack((xb,np.zeros((n,2),dtype=np.int8)))
    stages=['old']*NOLD+['new']*NNEW+['old']*NHELD+['new']*NHELD+['cold']*NHELD
    for i,st in enumerate(stages):
        if st=='old':cue=(int(xb[i,roles[0]]),int(xb[i,roles[3]]))
        elif st=='new':cue=(1-int(xb[i,roles[0]]),int(xb[i,roles[3]]))
        else:cue=tuple(int(z) for z in rng.integers(0,2,size=2))
        for j,c in enumerate(cue):x[i,10+j]=int(c if st=='cold' or rng.random()>=.08 else 1-c)
    ss=spin(x)
    primitive=np.column_stack([ss[:,roles[2*k]]*ss[:,roles[2*k+1]] for k in range(4)])
    a,b,c,d=[primitive[:,i] for i in range(4)]
    shifts=(np.asarray(scales[:4])*primitive).sum(axis=1)
    old_relation=scales[4]*a*b+scales[5]*c*d+scales[6]*a*c
    new_relation=(scales[4] if family!='flipped_relation' else -scales[4])*a*b+scales[5]*c*d+scales[7]*b*d
    if family=='unseen_triple':new_relation=new_relation+.85*a*b*c
    offsets=[(0,NOLD,'old'),(NOLD,NOLD+NNEW,'new'),(NOLD+NNEW,NOLD+NNEW+NHELD,'old'),(NOLD+NNEW+NHELD,NOLD+NNEW+2*NHELD,'new'),(NOLD+NNEW+2*NHELD,n,'new')]
    y=np.zeros(n)
    for lo,hi,st in offsets:
        y[lo:hi]=shifts[lo:hi]+(old_relation if st=='old' else new_relation)[lo:hi]+rng.normal(0,.20,hi-lo)
    spans={k:[*val] for k,val in {'train_old':(0,NOLD),'train_new':(NOLD,NOLD+NNEW),'held_old':(NOLD+NNEW,NOLD+NNEW+NHELD),'held_new':(NOLD+NNEW+NHELD,NOLD+NNEW+2*NHELD),'held_cold':(NOLD+NNEW+2*NHELD,n)}.items()}
    return {'seed':int(seed),'world_id':int(idx),'family':family,'roles':roles,'scales':scales,'causal_keys':keys.tolist(),'x':x.tolist(),'y':y.tolist(),'spans':spans}

def choose_pair_terms(pairs_old,y_old):
    # Training-ONLY old basis. Four disjoint pair supports, greedy OMP4 full pair basis.
    model=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(pairs_old,y_old)
    chosen=np.flatnonzero(np.abs(model.coef_)>1e-9).tolist()
    if len(chosen)!=4: raise RuntimeError('missing support')
    return chosen

def relational_features(pair_features,chosen):
    z=pair_features[:,chosen];return np.column_stack((z,*[z[:,i]*z[:,j] for i,j in itertools.combinations(range(4),2)]))

def reg(z,y,alpha=.3):return Ridge(alpha=alpha,fit_intercept=True,solver='svd').fit(z,y)
def fit_shared_relations(old_x,new_x,old_y,new_y,invariant):
    # 10 features = 4 primitive pairs and 6 products; stage-specific primitive weights,
    # stage-specific changing edges; invariant edges have one coefficient shared across OLD and NEW.
    n0,n1=len(old_y),len(new_y)
    blocks=[]; cols=[]
    for j in range(10):
        if j>=4 and (j-4) in invariant:
            col=np.concatenate((old_x[:,j],new_x[:,j])); blocks.append(col);cols.append((j,'shared'))
        else:
            blocks.append(np.concatenate((old_x[:,j],np.zeros(n1))));cols.append((j,'old'))
            blocks.append(np.concatenate((np.zeros(n0),new_x[:,j])));cols.append((j,'new'))
    # Separate stage intercepts, regularize numeric fit.
    blocks.extend((np.concatenate((np.ones(n0),np.zeros(n1))),np.concatenate((np.zeros(n0),np.ones(n1)))))
    fit=Ridge(alpha=.4,fit_intercept=False,solver='svd').fit(np.column_stack(blocks),np.r_[old_y,new_y])
    beta=np.zeros(10); bias=fit.coef_[-1]
    for v,(j,stage) in zip(fit.coef_[:-2],cols):
        if stage in ('new','shared'):beta[j]=v
    return beta,bias

def fit_arms(w):
    x=np.asarray(w['x'],dtype=np.int8);y=np.asarray(w['y'],dtype=float)
    spans=w['spans'];old=slice(*spans['train_old']);new=slice(*spans['train_new'])
    targets=[slice(*spans['held_'+k]) for k in ('old','new','cold')]
    pairs=combos(2)[12:]  # 12 unary then 66 pair parity products.
    z2=features(x,pairs)
    selected=choose_pair_terms(z2[old],y[old]); r=relational_features(z2,selected)
    pold=reg(r[old],y[old]); pnew=reg(r[new],y[new]); predo=pold.predict(r[targets[0]])
    edges_old=pold.coef_[4:];edges_new=pnew.coef_[4:]
    invariant=[i for i,(a,b) in enumerate(zip(edges_old,edges_new)) if min(abs(a),abs(b))>=.20 and np.sign(a)==np.sign(b) and abs(a-b)<=.35]
    beta,bias=fit_shared_relations(r[old],r[new],y[old],y[new],invariant)
    predictions={}; timings={}
    predictions['stable_relations']=[predo.tolist(),(r[targets[1]]@beta+bias).tolist(),(r[targets[2]]@beta+bias).tolist()]
    predictions['separate_relations']=[predo.tolist(),pnew.predict(r[targets[1]]).tolist(),pnew.predict(r[targets[2]]).tolist()]
    pb,intercept=fit_shared_relations(r[old],r[new],y[old],y[new],list(range(6)))
    predictions['unconditional_shared']=[predo.tolist(),(r[targets[1]]@pb+intercept).tolist(),(r[targets[2]]@pb+intercept).tolist()]
    predictions['no_adapt']=[predo.tolist(),pold.predict(r[targets[1]]).tolist(),pold.predict(r[targets[2]]).tolist()]
    seed=np.random.SeedSequence([5707,w['seed'],w['world_id'],FAMILIES.index(w['family'])]); shuf=np.random.default_rng(seed).permutation(y[new]);msh=reg(r[new],shuf)
    predictions['shuffled_new']=[predo.tolist(),msh.predict(r[targets[1]]).tolist(),msh.predict(r[targets[2]]).tolist()]
    f4=features(x,combos(4))
    def add_arm(name,make_old,make_new,mat):
        start=time.perf_counter();m0=make_old(mat[old],y[old]);m1=make_new(mat[new],y[new]);timings[name]=time.perf_counter()-start
        predictions[name]=[m0.predict(mat[q]).tolist() for q in targets[:1]]+[m1.predict(mat[q]).tolist() for q in targets[1:]]
    add_arm('full_omp',lambda a,b:OrthogonalMatchingPursuit(n_nonzero_coefs=8).fit(a,b),lambda a,b:OrthogonalMatchingPursuit(n_nonzero_coefs=8).fit(a,b),f4)
    add_arm('full_elasticnet',lambda a,b:ElasticNet(alpha=.055,l1_ratio=.8,max_iter=2000,tol=.0005).fit(a,b),lambda a,b:ElasticNet(alpha=.055,l1_ratio=.8,max_iter=2000,tol=.0005).fit(a,b),f4)
    add_arm('rbf_krr',lambda a,b:KernelRidge(alpha=.25,kernel='rbf',gamma=.20).fit(a,b),lambda a,b:KernelRidge(alpha=.25,kernel='rbf',gamma=.20).fit(a,b),x)
    add_arm('extra_trees',lambda a,b:ExtraTreesRegressor(n_estimators=48,max_depth=12,min_samples_leaf=2,n_jobs=1,random_state=7).fit(a,b),lambda a,b:ExtraTreesRegressor(n_estimators=48,max_depth=12,min_samples_leaf=2,n_jobs=1,random_state=13).fit(a,b),x)
    # Time all graph paths together with full factor-selection overhead (not source generation).
    return predictions,{'selected':selected,'selected_pairs':[list(pairs[i]) for i in selected],'invariant_edges':invariant,'timings_control':timings}

def evaluate(seeds,ids=(0,1,2,3),families=FAMILIES):
    cases=[];t0=time.perf_counter()
    for seed in seeds:
      for family in families:
       for idx in ids:
        c=world(seed,idx,family)
        pred,info=fit_arms(c);truth=np.asarray(c['y'],float);metrics={}
        for k,p in pred.items():metrics[k]={domain:float(np.mean((np.asarray(p[i])-truth[slice(*c['spans']['held_'+domain])])**2)) for i,domain in enumerate(('old','new','cold'))}
        cases.append({'world':c,'predictions':pred,'info':info,'metrics':metrics})
    aggregate={arm:{p:float(np.mean([case['metrics'][arm][p] for case in cases])) for p in ('old','new','cold')} for arm in ARMS}
    by_seed={str(s):{arm:float(np.mean([c['metrics'][arm]['cold'] for c in cases if c['world']['seed']==s])) for arm in ARMS} for s in seeds}
    by_family={fam:{arm:float(np.mean([c['metrics'][arm]['cold'] for c in cases if c['world']['family']==fam])) for arm in ARMS} for fam in families}
    # Learning of actual base supports (hidden terms excluded from fit), no planted edge oracle used in candidate.
    correct=0;matched_stable=0;selected_stable=0;selected_notstable=0;total_stable=0
    edges=list(itertools.combinations(range(4),2))
    for c in cases:
        w=c['world']; primitive_by_bits={tuple(sorted(w['roles'][2*i:2*i+2])):i for i in range(4)}
        correct+=len(set(primitive_by_bits)&{tuple(sorted(p)) for p in c['info']['selected_pairs']})
        learned_ids=[primitive_by_bits.get(tuple(sorted(p))) for p in c['info']['selected_pairs']]
        true_invariants={(2,3)} if w['family']=='flipped_relation' else {(0,1),(2,3)}
        total_stable+=len(true_invariants)
        for edge_i in c['info']['invariant_edges']:
            a,b=edges[edge_i];ia,ib=learned_ids[a],learned_ids[b]
            if ia is not None and ib is not None and tuple(sorted((ia,ib))) in true_invariants:
                matched_stable+=1
            else:selected_notstable+=1
            selected_stable+=1
    return {'experiment':'ENERGY-57','source':'E57:invariant-relational-v1','seeds':list(seeds),'ids':list(ids),'families':list(families),'cases':cases,'aggregate':aggregate,'per_seed':by_seed,'per_family':by_family,'primitive_recall':correct/(4*len(cases)),'invariant_edge_recall':matched_stable/total_stable,'invariant_edge_precision':matched_stable/max(1,selected_stable),'invariant_edges_selected':selected_stable,'invariant_edges_false':selected_notstable,'elapsed_total_seconds':time.perf_counter()-t0}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seeds',nargs='+',type=int,required=True);parser.add_argument('--ids',nargs='+',type=int,default=[0,1,2,3]);parser.add_argument('--out',required=True);a=parser.parse_args()
    r=evaluate(a.seeds,a.ids);Path(a.out).write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n');print(json.dumps({'cases':len(r['cases']),'cold':{n:round(d['cold'],5) for n,d in r['aggregate'].items()},'primitive_recall':r['primitive_recall'],'seconds':r['elapsed_total_seconds']}))
