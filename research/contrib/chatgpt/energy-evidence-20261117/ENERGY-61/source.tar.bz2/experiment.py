#!/usr/bin/env python3
"""ENERGY-61: external synthetic causal operator composition; not native Yggdrasil."""
import argparse, hashlib, itertools, json, math, os, sys, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.kernel_ridge import KernelRidge
from sklearn.preprocessing import PolynomialFeatures

FAMILIES=('xor_and','and_xor','conditional')
ARMS=('program_memory','fresh_full_bank_omp','pooled_full_bank_omp','fresh_poly_elasticnet','fresh_composition_elasticnet','fresh_extra_trees','fresh_hgb','fresh_rbf_krr','softmax_old_fresh','old_no_update','shuffled_new')
NOLD=80; NNEW=80; NHELD=64

def rng_from(*args):
    key='E61:v1:'+':'.join(map(str,args))
    seed=int.from_bytes(hashlib.sha256(key.encode()).digest()[:8],'little')
    return np.random.default_rng(seed)

def op(a,b,which):
    return (a^b) if which=='xor' else (a&b)

def generator(seed,worldid,family):
    """Unique 10-bit intervention assignments; nuisance policy shift; hidden composition."""
    rng=rng_from(seed,worldid,family,'generator')
    ids=rng.permutation(1024)[:NOLD+NNEW+3*NHELD].astype(np.int64)
    core=((ids[:,None]>>np.arange(10,dtype=np.int64))&1).astype(np.int8)
    perm=rng.permutation(10)
    s1=[int(x) for x in perm[:5]]
    s2=[int(x) for x in perm[5:10]]
    x=np.empty((len(ids),12),np.int8); x[:,:10]=core
    # OLD and NEW cue correlations flip; COLD nuisance is independent.
    for i in range(len(ids)):
        a,b=int(core[i,0]),int(core[i,2]);flip=int(rng.random()<.08)
        if i<NOLD: x[i,10]=a^flip; x[i,11]=b^(int(rng.random()<.08))
        elif i<NOLD+NNEW: x[i,10]=1-a^flip; x[i,11]=b^(int(rng.random()<.08))
        elif i<NOLD+NNEW+NHELD: x[i,10]=a^flip; x[i,11]=b^(int(rng.random()<.08))
        elif i<NOLD+NNEW+2*NHELD: x[i,10]=1-a^flip; x[i,11]=b^(int(rng.random()<.08))
        else: x[i,10]=rng.integers(2); x[i,11]=rng.integers(2)
    def factor(z,s,mode):
        a,b,c,d,e=[z[:,j] for j in s]
        if mode=='xor_and': return op(op(a,b,'and'),op(c,d,'and'),'xor')
        if mode=='and_xor': return op(op(a,b,'xor'),op(c,d,'xor'),'and')
        return np.where(a==1,op(b,c,'xor'),op(d,e,'and')).astype(np.int8)
    shared=2*factor(core,s1,family)-1
    # A structural changed factor: no high-level mechanism/operator is supplied to learner.
    mode2={'xor_and':'and_xor','and_xor':'conditional','conditional':'xor_and'}[family]
    old_extra=2*factor(core,s2,mode2)-1
    new_extra=2*factor(core,s2,family)-1
    coeff=float(rng.choice([-1,1]))
    y=np.empty(len(ids),float)
    y[:NOLD]=1.7*shared[:NOLD]+.8*coeff*old_extra[:NOLD]
    y[NOLD:]=1.7*shared[NOLD:]+.8*coeff*new_extra[NOLD:]
    y+=rng.normal(0,.18,len(ids))
    return {'x':x,'y':y,'ids':ids,'support':s1,'changed_support':s2,'old_op':mode2,'new_op':family,'sign':coeff}

# Generic Boolean primitives AND and XOR supplied; high-order compositions not supplied as templates.
PAIRS=list(itertools.combinations(range(12),2))
PAIR_SPEC=[(a,b,typ) for a,b in PAIRS for typ in ('and','xor')]
COMPS=[]
for a in range(len(PAIR_SPEC)):
    i,j,_=PAIR_SPEC[a]
    for b in range(a+1,len(PAIR_SPEC)):
        k,l,_=PAIR_SPEC[b]
        if len({i,j,k,l})==4:
            for typ in ('and','xor'): COMPS.append((a,b,typ))
# Full, predeclared generic AST space, same to every method that searches it.
NBANK=len(PAIR_SPEC)+len(COMPS)

def bank(x):
    n=len(x); base=np.empty((n,len(PAIR_SPEC)),np.int8)
    for i,(a,b,typ) in enumerate(PAIR_SPEC): base[:,i]=op(x[:,a],x[:,b],typ)
    arr=np.empty((n,NBANK),np.float32); arr[:,:len(PAIR_SPEC)]=base*2-1
    for i,(a,b,typ) in enumerate(COMPS):arr[:,len(PAIR_SPEC)+i]=2*op(base[:,a],base[:,b],typ)-1
    return arr

def fit_selection(X,y,limit=4,preselected=(),allow_composition=True):
    """Greedy conditional Boolean-program search with an unpenalized intercept and ridge refit."""
    assert len(y)==len(X)
    columns=np.arange(X.shape[1]) if allow_composition else np.arange(len(PAIR_SPEC))
    selected=list(preselected)
    means=X.mean(axis=0)
    Z=X-means
    sd=np.sqrt(np.sum(Z*Z,axis=0));sd=np.maximum(sd,1e-9)
    r=y-y.mean()
    for _ in range(max(0,limit-len(selected))):
        score=np.abs(Z[:,columns].T@r)/sd[columns]
        if len(selected): score[np.isin(columns,selected)]=-1
        best=int(columns[int(np.argmax(score))]);selected.append(best)
        A=np.c_[np.ones(len(X)),X[:,selected]]
        penalty=np.eye(len(selected)+1)*.08;penalty[0,0]=0
        coef=np.linalg.solve(A.T@A+penalty,A.T@y)
        r=y-A@coef
    if not selected:
        return {'ids':[],'coef':[float(y.mean())]}
    A=np.c_[np.ones(len(X)),X[:,selected]]
    penalty=np.eye(len(selected)+1)*.08;penalty[0,0]=0
    coef=np.linalg.solve(A.T@A+penalty,A.T@y)
    return {'ids':selected,'coef':coef.tolist()}

def pred(model,B):return np.c_[np.ones(len(B)),B[:,model['ids']]]@np.asarray(model['coef'],float)

def normal_cv(y,guess):return float(np.mean((np.asarray(y)-np.asarray(guess))**2))

def score_case(seed,wid,family,include_predictions=True):
    w=generator(seed,wid,family); x=w['x']; y=w['y']; b=bank(x)
    old=np.arange(NOLD);new=np.arange(NOLD,NOLD+NNEW)
    splits={'old':np.arange(NOLD+NNEW,NOLD+NNEW+NHELD),'new':np.arange(NOLD+NNEW+NHELD,NOLD+NNEW+2*NHELD),'cold':np.arange(NOLD+NNEW+2*NHELD,len(y))}
    assert len(np.unique(w['ids']))==len(y)
    starts=time.perf_counter()
    oldfit=fit_selection(b[old],y[old],4)
    freshfit=fit_selection(b[new],y[new],4)
    pooledfit=fit_selection(b[np.r_[old,new]],y[np.r_[old,new]],4)
    # persistent old checkpoint: search among 2 old causal modules, then 2 novel generic modules in new world.
    candidate=fit_selection(b[new],y[new],4,oldfit['ids'][:2])
    def output(m):return {k:pred(m,b[idx]) for k,idx in splits.items()}
    p_old=output(oldfit)
    p_fresh=output(freshfit)
    p_pool=output(pooledfit)
    p_cand=output(candidate)
    # OLD readout always comes from the frozen OLD checkpoint, never from the new correction.
    p_cand['old']=p_old['old'].copy()
    fit_time=time.perf_counter()-starts
    poly=PolynomialFeatures(degree=4,include_bias=False)
    zp=poly.fit_transform(x.astype(float)*2-1)
    enet=ElasticNet(alpha=.05,l1_ratio=.8,max_iter=2500,tol=1e-3,selection='cyclic')
    t=time.perf_counter();enet.fit(zp[new],y[new]);p_enet={k:enet.predict(zp[idx]) for k,idx in splits.items()};en_time=time.perf_counter()-t
    enetfull=ElasticNet(alpha=.045,l1_ratio=.8,max_iter=2000,tol=1e-3,selection='cyclic')
    t=time.perf_counter();enetfull.fit(b[new].astype(float),y[new]);p_enetfull={k:enetfull.predict(b[idx].astype(float)) for k,idx in splits.items()};enfull_time=time.perf_counter()-t
    tree=ExtraTreesRegressor(n_estimators=96,max_depth=14,min_samples_leaf=2,n_jobs=1,random_state=int(seed)+wid)
    t=time.perf_counter();tree.fit(x[new],y[new]);p_tree={k:tree.predict(x[idx]) for k,idx in splits.items()};tree_time=time.perf_counter()-t
    hgb=HistGradientBoostingRegressor(max_iter=95,max_leaf_nodes=11,l2_regularization=.2,learning_rate=.065,random_state=int(seed)+wid,min_samples_leaf=5)
    t=time.perf_counter();hgb.fit(x[new],y[new]);p_hgb={k:hgb.predict(x[idx]) for k,idx in splits.items()};hgb_time=time.perf_counter()-t
    krr=KernelRidge(alpha=.23,kernel='rbf',gamma=.18)
    t=time.perf_counter();krr.fit(x[new],y[new]);p_krr={k:krr.predict(x[idx]) for k,idx in splits.items()};krr_time=time.perf_counter()-t
    # Matched memory: conventional softmax mixing old + fresh new snapshots, using TRAIN-ONLY new loss.
    old_mse=normal_cv(y[new],pred(oldfit,b[new]));fresh_mse=normal_cv(y[new],pred(freshfit,b[new]))
    wt=np.exp(-np.array([old_mse,fresh_mse])/.17);wt=wt/wt.sum()
    p_soft={k:wt[0]*p_old[k]+wt[1]*p_fresh[k] for k in splits}
    shufrng=rng_from(seed,wid,family,'sham')
    sham=fit_selection(b[new],y[new][shufrng.permutation(NNEW)],4)
    p_sham=output(sham)
    preds={'program_memory':p_cand,'fresh_full_bank_omp':p_fresh,'pooled_full_bank_omp':p_pool,'fresh_poly_elasticnet':p_enet,'fresh_composition_elasticnet':p_enetfull,'fresh_extra_trees':p_tree,'fresh_hgb':p_hgb,'fresh_rbf_krr':p_krr,'softmax_old_fresh':p_soft,'old_no_update':p_old,'shuffled_new':p_sham}
    receipt={'seed':int(seed),'world_id':int(wid),'family':family,'ids_sha256':hashlib.sha256(w['ids'].tobytes()).hexdigest(),'x_sha256':hashlib.sha256(x.tobytes()).hexdigest(),'y_sha256':hashlib.sha256(y.tobytes()).hexdigest(),'hidden_support':w['support'],'hidden_changed_support':w['changed_support'],'hidden_old_operator':w['old_op'],'hidden_new_operator':w['new_op'],'models':{'old':oldfit,'candidate':candidate,'new_only':freshfit,'pooled':pooledfit,'shuffled':sham},'weights_softmax':wt.tolist(),'mse':{name:{k:normal_cv(y[idx],prediction[k]) for k,idx in splits.items()} for name,prediction in preds.items()},'run_cost_seconds':{'bank_search_old_new_pooled_candidate':fit_time,'poly_elasticnet':en_time,'composition_elasticnet':enfull_time,'extra_trees':tree_time,'hist_gradient_boost':hgb_time,'rbf_krr':krr_time},'pred_sha256':{name:{k:hashlib.sha256(np.asarray(p,float).tobytes()).hexdigest() for k,p in predictions.items()} for name,predictions in preds.items()}}
    if include_predictions:receipt['data']={'ids':w['ids'].tolist(),'actions':x.tolist(),'observed_outcomes':y.tolist(),'predictions':{name:{k:p.tolist() for k,p in predictions.items()} for name,predictions in preds.items()}}
    return receipt

def aggregate(cases):
    def avg(arm,spl):return float(np.mean([c['mse'][arm][spl] for c in cases]))
    return {'mean_mse':{arm:{k:avg(arm,k) for k in ('old','new','cold')} for arm in ARMS},'seed_mse':{str(seed):{arm:float(np.mean([c['mse'][arm]['cold'] for c in cases if c['seed']==seed])) for arm in ARMS} for seed in sorted({c['seed'] for c in cases})},'family_mse':{family:{arm:float(np.mean([c['mse'][arm]['cold'] for c in cases if c['family']==family])) for arm in ARMS} for family in FAMILIES}}

def run(seeds,world_ids=(0,1)):
    t=time.perf_counter();cases=[score_case(seed,wid,fam) for seed in seeds for wid in world_ids for fam in FAMILIES]
    out={'study':'ENERGY-61','version':'1.0','seeds':list(seeds),'world_ids':list(world_ids),'families':list(FAMILIES),'n_worlds':len(cases),'arms':list(ARMS),'bank_features':NBANK,'old_witnesses':NOLD,'new_witnesses':NNEW,'held_each':NHELD,'cases':cases,'summary':aggregate(cases),'elapsed_seconds':time.perf_counter()-t}
    return out

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seeds',nargs='+',type=int,required=True);parser.add_argument('--world-ids',nargs='+',type=int,default=[0,1]);parser.add_argument('--out',required=True)
    args=parser.parse_args();r=run(args.seeds,args.world_ids);Path(args.out).write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n');print(json.dumps({'worlds':r['n_worlds'],'summary':r['summary']['mean_mse'],'seconds':r['elapsed_seconds']},indent=2))
