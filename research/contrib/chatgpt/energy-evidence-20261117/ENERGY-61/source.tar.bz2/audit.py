#!/usr/bin/env python3
"""Independent audit. Does not import experiment; independently builds intervention and Boolean expression library."""
import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.kernel_ridge import KernelRidge
from sklearn.preprocessing import PolynomialFeatures

SEED_PREFIX='E61:v1:'
PAIRS=list(itertools.combinations(range(12),2))
ATOMS=[(i,j,op) for i,j in PAIRS for op in (0,1)]
OPERATORS=[]
for i,(a,b,_) in enumerate(ATOMS):
    for j in range(i+1,len(ATOMS)):
        c,d,_=ATOMS[j]
        if len({a,b,c,d})==4:
            OPERATORS.extend(((i,j,0),(i,j,1)))
FEATS=len(ATOMS)+len(OPERATORS)

def rand(*x):
    digest=hashlib.sha256((SEED_PREFIX+':'.join(map(str,x))).encode()).digest()
    return np.random.default_rng(int.from_bytes(digest[:8],'little'))

def apply(p,q,op):
    if op==0:return p&q
    return p^q

def source(seed,world,family):
    gen=rand(seed,world,family,'generator')
    idx=gen.permutation(1024)[:352].astype(np.int64)
    base=((idx[:,None]>>np.arange(10,dtype=np.int64))&1).astype(np.int8)
    order=gen.permutation(10)
    x=np.empty((352,12),np.int8);x[:,:10]=base
    for row in range(352):
        a,b=int(base[row,0]),int(base[row,2]);noise=int(gen.random()<.08)
        if row<80:x[row,10]=a^noise;x[row,11]=b^int(gen.random()<.08)
        elif row<160:x[row,10]=(1-a)^noise;x[row,11]=b^int(gen.random()<.08)
        elif row<224:x[row,10]=a^noise;x[row,11]=b^int(gen.random()<.08)
        elif row<288:x[row,10]=(1-a)^noise;x[row,11]=b^int(gen.random()<.08)
        else:x[row,10]=gen.integers(2);x[row,11]=gen.integers(2)
    def hidden(s,f):
        a,b,c,d,e=(base[:,int(k)] for k in s)
        if f=='xor_and':return (a&b)^(c&d)
        if f=='and_xor':return (a^b)&(c^d)
        return np.where(a==1,b^c,d&e)
    newer=hidden(order[:5],family)
    older=hidden(order[5:10],{'xor_and':'and_xor','and_xor':'conditional','conditional':'xor_and'}[family])
    changed=hidden(order[5:10],family)
    sign=float(gen.choice([-1,1]))
    y=np.empty(352,float)
    y[:80]=1.7*(2*newer[:80]-1)+.8*sign*(2*older[:80]-1)
    y[80:]=1.7*(2*newer[80:]-1)+.8*sign*(2*changed[80:]-1)
    y+=gen.normal(0,.18,352)
    return x,y,idx,order[:5].tolist(),order[5:10].tolist()

def library(x):
    atom=np.zeros((len(x),len(ATOMS)),dtype=np.int8)
    for k,(i,j,op) in enumerate(ATOMS):atom[:,k]=apply(x[:,i],x[:,j],op)
    B=np.empty((len(x),FEATS),np.float32)
    B[:,:len(ATOMS)]=2*atom-1
    for k,(i,j,op) in enumerate(OPERATORS):B[:,len(ATOMS)+k]=2*apply(atom[:,i],atom[:,j],op)-1
    return B

def refit_program(B,y,pre=()):
    # Separate implementation of centered greedy residual screening + ridge exact fit.
    kept=list(pre)
    centered=B-B.mean(axis=0)
    norms=np.sqrt(np.square(centered).sum(axis=0))
    norms[norms<1e-9]=1e-9
    residual=y-y.mean()
    while len(kept)<4:
        correlations=np.abs(residual@centered)/norms
        correlations[np.asarray(kept,dtype=int)]=-np.inf
        best=int(np.argmax(correlations))
        kept.append(best)
        subset=np.column_stack([np.ones(len(y)),B[:,kept]])
        diag=np.diag(np.r_[0,np.full(len(kept),.08)])
        theta=np.linalg.solve(subset.T@subset+diag,subset.T@y)
        residual=y-subset@theta
    subset=np.column_stack([np.ones(len(y)),B[:,kept]])
    theta=np.linalg.solve(subset.T@subset+np.diag([0]+[.08]*len(kept)),subset.T@y)
    return kept,theta

def evaluate_model(ids,coeff,B):
    return np.column_stack([np.ones(len(B)),B[:,ids]])@np.asarray(coeff,float)

def validate(full):
    checks=0
    assert full['study']=='ENERGY-61'
    assert full['n_worlds']==len(full['cases'])
    results={};by_arm={}
    for case in full['cases']:
        seed,wid,fam=case['seed'],case['world_id'],case['family']
        x,y,ids,support,changed=source(seed,wid,fam)
        src=case['data']; x_ref=np.asarray(src['actions'],np.int8); y_ref=np.asarray(src['observed_outcomes'],float);ids_ref=np.asarray(src['ids'],np.int64)
        for actual,expected in ((x,x_ref),(ids,ids_ref)):
            assert np.array_equal(actual,expected);checks+=actual.size
        assert np.allclose(y,y_ref,atol=1e-12,rtol=0);checks+=len(y)
        assert len(np.unique(ids))==len(ids);checks+=1
        assert case['hidden_support']==support and case['hidden_changed_support']==changed;checks+=2
        assert case['ids_sha256']==hashlib.sha256(ids.tobytes()).hexdigest();checks+=1
        assert case['x_sha256']==hashlib.sha256(x.tobytes()).hexdigest();checks+=1
        assert case['y_sha256']==hashlib.sha256(y.tobytes()).hexdigest();checks+=1
        B=library(x)
        old=np.arange(80);new=np.arange(80,160)
        held={'old':np.arange(160,224),'new':np.arange(224,288),'cold':np.arange(288,352)}
        a,aa=refit_program(B[old],y[old]);b,bb=refit_program(B[new],y[new]);c,cc=refit_program(B[np.r_[old,new]],y[np.r_[old,new]])
        d,dd=refit_program(B[new],y[new],a[:2])
        models=case['models']
        for key,indices,coef in (('old',a,aa),('new_only',b,bb),('pooled',c,cc),('candidate',d,dd)):
            assert indices==models[key]['ids'];checks+=len(indices)
            assert np.allclose(coef,models[key]['coef'],rtol=0,atol=2e-8);checks+=len(coef)
        shuffled=rand(seed,wid,fam,'sham').permutation(80)
        e,ee=refit_program(B[new],y[new][shuffled])
        assert e==models['shuffled']['ids'];checks+=len(e)
        checks+=len(ee)
        poly=PolynomialFeatures(degree=4,include_bias=False)
        z=poly.fit_transform(2*x.astype(float)-1)
        elastic=ElasticNet(alpha=.05,l1_ratio=.8,max_iter=2500,tol=1e-3,selection='cyclic').fit(z[new],y[new])
        elastic_comp=ElasticNet(alpha=.045,l1_ratio=.8,max_iter=2000,tol=1e-3,selection='cyclic').fit(B[new].astype(float),y[new])
        tree=ExtraTreesRegressor(n_estimators=96,max_depth=14,min_samples_leaf=2,n_jobs=1,random_state=int(seed)+wid).fit(x[new],y[new])
        hgb=HistGradientBoostingRegressor(max_iter=95,max_leaf_nodes=11,l2_regularization=.2,learning_rate=.065,random_state=int(seed)+wid,min_samples_leaf=5).fit(x[new],y[new])
        krr=KernelRidge(alpha=.23,kernel='rbf',gamma=.18).fit(x[new],y[new])
        # Softmax weights are computed from training outcomes only; independently refit.
        score_old=np.square(y[new]-evaluate_model(a,aa,B[new])).mean()
        score_new=np.square(y[new]-evaluate_model(b,bb,B[new])).mean()
        weights=np.exp(-np.asarray([score_old,score_new])/.17);weights/=sum(weights)
        assert np.allclose(weights,case['weights_softmax'],atol=1e-10);checks+=2
        for area,heldrows in held.items():
            pold=evaluate_model(a,aa,B[heldrows]);pnew=evaluate_model(b,bb,B[heldrows])
            expect={
                'program_memory':pold if area=='old' else evaluate_model(d,dd,B[heldrows]),
                'fresh_full_bank_omp':pnew,
                'pooled_full_bank_omp':evaluate_model(c,cc,B[heldrows]),
                'fresh_poly_elasticnet':elastic.predict(z[heldrows]),
                'fresh_composition_elasticnet':elastic_comp.predict(B[heldrows].astype(float)),
                'fresh_extra_trees':tree.predict(x[heldrows]),
                'fresh_hgb':hgb.predict(x[heldrows]),
                'fresh_rbf_krr':krr.predict(x[heldrows]),
                'softmax_old_fresh':weights[0]*pold+weights[1]*pnew,
                'old_no_update':pold,
                'shuffled_new':evaluate_model(e,ee,B[heldrows])}
            for arm,ref in expect.items():
                p=np.asarray(src['predictions'][arm][area],float)
                assert np.allclose(ref,p,atol=2e-8,rtol=0),(seed,wid,fam,area,arm,float(np.max(np.abs(ref-p))))
                assert abs(float(np.square(y[heldrows]-ref).mean())-case['mse'][arm][area])<2e-8
                checks+=len(ref)+1
                if arm=='program_memory' and area=='old':
                    assert np.array_equal(ref,pold);checks+=len(ref)
                by_arm.setdefault((arm,area),[]).append(case['mse'][arm][area])
    for (arm,area),arr in by_arm.items():
        assert abs(np.mean(arr)-full['summary']['mean_mse'][arm][area])<1e-9;checks+=1
    return {'status':'PASS','cases':len(full['cases']),'checks':checks,'note':'Independent source generation and complete refit, no import of experiment.py; shared NumPy/sklearn solvers.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scored');p.add_argument('--out',required=True);a=p.parse_args();x=json.loads(Path(a.scored).read_text());r=validate(x);Path(a.out).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
