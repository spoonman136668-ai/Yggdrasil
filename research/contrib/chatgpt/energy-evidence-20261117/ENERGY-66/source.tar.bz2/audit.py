"""ENERGY-66 independent scorer-refit audit. Does not import scorer.
Limit: both use disclosed simulator rules and NumPy/scikit-learn numerical solvers.
"""
import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet,Ridge
from sklearn.model_selection import KFold
PAIRS=list(itertools.combinations(range(8),2))
QUADS=list(itertools.combinations(range(8),4))
ALL=PAIRS+QUADS
ARMS=['two_factor_residual','matched_elasticnet','full_bank_elasticnet','matched_omp5','full_bank_omp5','softmax_memory','old_support_only','old_frozen','shuffled_new','truth_oracle']

def matrix(X,terms):
    xx=np.asarray(X)
    return np.asarray([[float(np.prod(row[list(term)])) for term in terms] for row in xx],dtype=float)

def en(X,Y):
    cv=KFold(3,shuffle=True,random_state=66017)
    ranks=[]
    for a in (.005,.025,.08):
        err=[]
        for train,val in cv.split(X):
            m=ElasticNet(alpha=a,l1_ratio=.85,max_iter=5000,tol=1e-6,selection='cyclic').fit(X[train],Y[train]);err.append(float(np.mean((m.predict(X[val])-Y[val])**2)))
        ranks.append((float(np.mean(err)),a))
    score,alpha=min(ranks)
    return ElasticNet(alpha=alpha,l1_ratio=.85,max_iter=5000,tol=1e-6,selection='cyclic').fit(X,Y),{'alpha':alpha,'cv_mse':score}

def verify(case):
    n=0;p=case['splits'];t=case['truth'];family=case['family_id'];model=case['models']
    ids=[id for sp in ['train_old','train_new','held_old','held_new','held_cold'] for id in p[sp]['ids']]
    assert len(ids)==len(set(ids))==212;n+=213
    for blockname in ['train_old','train_new','held_old','held_new','held_cold']:
        block=p[blockname];X=np.asarray(block['x']);Y=np.asarray(block['y']);N=np.asarray(block['noise'])
        assert len(X)==len(Y)==len(N)==len(block['ids']);n+=1
        stage=blockname not in ('train_old','held_old')
        terms=[tuple(term) for term in t['pair_supports']]
        weights=t['new_coeff'] if stage else t['old_coeff']
        expected=sum(float(w)*matrix(X,[s])[:,0] for s,w in zip(terms,weights))
        if stage:
            for quad in t['quad_supports'][:3 if family==1 else 2]:
                expected+=(.92 if family==1 and tuple(quad)==tuple(t['quad_supports'][2]) else 1.05)*matrix(X,[tuple(quad)])[:,0]
            if family==2:expected+=.92*matrix(X,[tuple(t['fifth'])])[:,0]
        assert np.allclose(expected+N,Y,atol=3e-14,rtol=0);n+=len(Y)
        for idx,row in zip(block['ids'],X):
            assert np.array_equal(row,[2*((idx>>k)&1)-1 for k in range(8)]);n+=1
    xo=np.asarray(p['train_old']['x']);yo=np.asarray(p['train_old']['y']);xn=np.asarray(p['train_new']['x']);yn=np.asarray(p['train_new']['y'])
    old=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True).fit(matrix(xo,PAIRS),yo)
    oldterms=[PAIRS[k] for k in np.flatnonzero(abs(old.coef_)>1e-9)]
    assert oldterms==[tuple(x) for x in model['old_supports']];n+=3
    selected=[];q=matrix(xn,QUADS)
    for step in range(2):
        active=oldterms+[QUADS[k] for k in selected]
        refit=Ridge(alpha=.1).fit(matrix(xn,active),yn)
        err=yn-refit.predict(matrix(xn,active))
        basis=np.column_stack([np.ones(len(xn)),matrix(xn,active)])
        orth=q-basis@np.linalg.lstsq(basis,q,rcond=None)[0]
        scores=abs(orth.T@err)/(np.linalg.norm(orth,axis=0)+1e-12)
        scores[selected]=-np.inf
        selected.append(int(np.argmax(scores)))
    assert [QUADS[k] for k in selected]==[tuple(x) for x in model['discovered_quads']];n+=2
    candterms=oldterms+[QUADS[k] for k in selected]
    candidate=Ridge(alpha=.1).fit(matrix(xn,candterms),yn)
    matched,cv1=en(matrix(xn,oldterms+QUADS),yn)
    full,cv2=en(matrix(xn,ALL),yn)
    for k,cv in [('matched_cv',cv1),('full_cv',cv2)]:
        assert np.allclose([model[k]['alpha'],model[k]['cv_mse']],[cv['alpha'],cv['cv_mse']],atol=1e-8,rtol=0);n+=2
    m_omp=OrthogonalMatchingPursuit(n_nonzero_coefs=5,fit_intercept=True).fit(matrix(xn,oldterms+QUADS),yn)
    f_omp=OrthogonalMatchingPursuit(n_nonzero_coefs=5,fit_intercept=True).fit(matrix(xn,ALL),yn)
    only=Ridge(alpha=.1).fit(matrix(xn,oldterms),yn)
    baseline=old.predict(matrix(xn,PAIRS));fitted=f_omp.predict(matrix(xn,ALL))
    weights=np.exp(-np.asarray([np.mean((baseline-yn)**2),np.mean((fitted-yn)**2)])/0.4)
    weights/=weights.sum()
    assert np.allclose(weights,model['softmax_weights'],rtol=0,atol=1e-8);n+=2
    rng=np.random.default_rng(np.random.SeedSequence([case['seed'],660,99,case['family_id'],case['world_id']]))
    negative=Ridge(alpha=.1).fit(matrix(xn,candterms),rng.permutation(yn))
    oracleterms=[tuple(s) for s in t['pair_supports']]+[tuple(s) for s in t['quad_supports'][:3 if family==1 else 2]]
    if family==2:oracleterms.append(tuple(t['fifth']))
    oracle=Ridge(alpha=.1).fit(matrix(xn,oracleterms),yn)
    for stage in ('old','new','cold'):
        XX=np.asarray(p['held_'+stage]['x']);YY=np.asarray(p['held_'+stage]['y'])
        frozen=old.predict(matrix(XX,PAIRS))
        preds={'two_factor_residual':candidate.predict(matrix(XX,candterms)),
            'matched_elasticnet':matched.predict(matrix(XX,oldterms+QUADS)),
            'full_bank_elasticnet':full.predict(matrix(XX,ALL)),
            'matched_omp5':m_omp.predict(matrix(XX,oldterms+QUADS)),
            'full_bank_omp5':f_omp.predict(matrix(XX,ALL)),
            'softmax_memory':weights[0]*frozen+weights[1]*f_omp.predict(matrix(XX,ALL)),
            'old_support_only':only.predict(matrix(XX,oldterms)),
            'old_frozen':frozen,'shuffled_new':negative.predict(matrix(XX,candterms)),
            'truth_oracle':oracle.predict(matrix(XX,oracleterms))}
        for arm in ARMS:
            actual=frozen if stage=='old' else preds[arm]
            saved=np.asarray(case['predictions'][arm][stage])
            assert np.allclose(actual,saved,rtol=0,atol=1e-8),(case['seed'],case['world_id'],case['family'],stage,arm)
            assert abs(float(np.mean((saved-YY)**2))-case['mse'][arm][stage])<1e-8
            n+=len(saved)+1
    hash_old=hashlib.sha256(np.asarray(case['predictions']['old_frozen']['old'],dtype='<f8').tobytes()).hexdigest()
    assert model['old_prediction_sha256']==hash_old;n+=1
    return n

def main():
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('--out',required=True);args=p.parse_args()
    obj=json.loads(Path(args.source).read_text());assert obj['experiment']=='ENERGY-66'
    counts=sum(verify(c) for c in obj['cases'])
    for a in ARMS:
        for stage in ('old','new','cold'):
            x=np.mean([c['mse'][a][stage] for c in obj['cases']]);assert abs(x-obj['aggregate']['means'][a][stage])<1e-10;counts+=1
    result={'status':'PASS','experiment':'ENERGY-66','worlds':len(obj['cases']),'checks':counts,'scorer_imported':False,'limitations':'Shared disclosed synthetic mechanism and sklearn/NumPy, not independently recreated science.'}
    Path(args.out).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
