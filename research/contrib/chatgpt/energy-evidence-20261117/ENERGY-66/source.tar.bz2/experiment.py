"""ENERGY-66 external synthetic falsification: sequential two-quadratic-factor assimilation.
No native Yggdrasil training; source frozen BEFORE prospective experiment and audit.
"""
import argparse, hashlib, itertools, json, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
from sklearn.model_selection import KFold
PAIRS=tuple(itertools.combinations(range(8),2))
QUADS=tuple(itertools.combinations(range(8),4))
BANK=PAIRS+QUADS
FAMILIES=('double_quad','triple_quad','double_quad_plus_fifth')
SPLITS=(('train_old',56),('train_new',48),('held_old',36),('held_new',36),('held_cold',36))
ARMS=('two_factor_residual','matched_elasticnet','full_bank_elasticnet','matched_omp5','full_bank_omp5','softmax_memory','old_support_only','old_frozen','shuffled_new','truth_oracle')

def features(x,terms):
    x=np.asarray(x,dtype=np.float64)
    return np.column_stack([np.prod(x[:,term],axis=1) for term in terms])

def cv_en(x,y):
    folds=KFold(n_splits=3,shuffle=True,random_state=66017)
    best=(float('inf'),float('inf'))
    for alpha in (.005,.025,.08):
        errors=[]
        for a,b in folds.split(x):
            m=ElasticNet(alpha=alpha,l1_ratio=.85,tol=1e-6,max_iter=5000,selection='cyclic').fit(x[a],y[a])
            errors.append(np.mean((m.predict(x[b])-y[b])**2))
        best=min(best,(float(np.mean(errors)),alpha))
    return ElasticNet(alpha=best[1],l1_ratio=.85,tol=1e-6,max_iter=5000,selection='cyclic').fit(x,y),{'alpha':best[1],'cv_mse':best[0]}

def world(seed,fi,wid):
    rng=np.random.default_rng(np.random.SeedSequence([seed,660,fi,wid]))
    ids=rng.permutation(256)[:212]
    x=np.stack([2*((ids>>k)&1)-1 for k in range(8)],axis=1).astype(float)
    pairperm=rng.permutation(8)[:6]
    pair=[tuple(sorted(int(a) for a in pairperm[j:j+2])) for j in (0,2,4)]
    co=np.asarray([rng.choice([-1,1])*rng.uniform(.9,1.3) for _ in range(3)])
    cn=co+rng.normal(0,.13,size=3)
    qorder=rng.permutation(len(QUADS));q=[QUADS[int(k)] for k in qorder[:3]]
    f=tuple(sorted(int(k) for k in rng.permutation(8)[:5]))
    stages=np.r_[np.zeros(56),np.ones(48),np.zeros(36),np.ones(72)]
    noise=rng.normal(0,.18,size=212)
    y=np.zeros(212)
    for j in range(212):
        yy=sum((cn if stages[j] else co)[i]*float(np.prod(x[j,t])) for i,t in enumerate(pair))
        if stages[j]:
            yy+=1.05*float(np.prod(x[j,q[0]]))+1.05*float(np.prod(x[j,q[1]]))
            if fi==1: yy+=.92*float(np.prod(x[j,q[2]]))
            if fi==2: yy+=.92*float(np.prod(x[j,f]))
        y[j]=yy+noise[j]
    parts={};offset=0
    for split,n in SPLITS:
        parts[split]={'ids':ids[offset:offset+n].tolist(),'x':x[offset:offset+n].tolist(),'y':y[offset:offset+n].tolist(),'noise':noise[offset:offset+n].tolist()};offset+=n
    return {'seed':seed,'family':FAMILIES[fi],'family_id':fi,'world_id':wid,'truth':{'pair_supports':pair,'old_coeff':co.tolist(),'new_coeff':cn.tolist(),'quad_supports':q,'fifth':f,'noise_sd':.18},'splits':parts}

def sequential_quad_selection(xn,yn,old_terms):
    chosen=[]
    xold=features(xn,old_terms)
    allquad=features(xn,QUADS)
    for step in range(2):
        already=old_terms+[QUADS[j] for j in chosen]
        refit=Ridge(alpha=.1).fit(features(xn,already),yn)
        residual=yn-refit.predict(features(xn,already))
        basis=np.column_stack([np.ones(len(xn)),features(xn,already)])
        orth=allquad-basis@np.linalg.lstsq(basis,allquad,rcond=None)[0]
        score=np.abs(orth.T@residual)/(np.linalg.norm(orth,axis=0)+1e-12)
        score[chosen]=-np.inf
        chosen.append(int(np.argmax(score)))
    return chosen

def case_run(r):
    p=r['splits'];xo=np.asarray(p['train_old']['x']);yo=np.asarray(p['train_old']['y']);xn=np.asarray(p['train_new']['x']);yn=np.asarray(p['train_new']['y'])
    old=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True).fit(features(xo,PAIRS),yo)
    terms=[PAIRS[k] for k in np.flatnonzero(np.abs(old.coef_)>1e-9)]
    indices=sequential_quad_selection(xn,yn,terms)
    selected=terms+[QUADS[k] for k in indices]
    candidate=Ridge(alpha=.1).fit(features(xn,selected),yn)
    matched,matchedcv=cv_en(features(xn,terms+list(QUADS)),yn)
    full,fullcv=cv_en(features(xn,BANK),yn)
    matchomp=OrthogonalMatchingPursuit(n_nonzero_coefs=5,fit_intercept=True).fit(features(xn,terms+list(QUADS)),yn)
    fullomp=OrthogonalMatchingPursuit(n_nonzero_coefs=5,fit_intercept=True).fit(features(xn,BANK),yn)
    oldonly=Ridge(alpha=.1).fit(features(xn,terms),yn)
    o=old.predict(features(xn,PAIRS));n=fullomp.predict(features(xn,BANK))
    raw=np.asarray([-np.mean((o-yn)**2)/.4,-np.mean((n-yn)**2)/.4]);soft=np.exp(raw-raw.max());soft/=soft.sum()
    rng=np.random.default_rng(np.random.SeedSequence([r['seed'],660,99,r['family_id'],r['world_id']]))
    shuffled=Ridge(alpha=.1).fit(features(xn,selected),rng.permutation(yn))
    oracle_terms=[tuple(t) for t in r['truth']['pair_supports']]+[tuple(t) for t in r['truth']['quad_supports'][:3 if r['family_id']==1 else 2]]
    if r['family_id']==2:oracle_terms.append(tuple(r['truth']['fifth']))
    oracle=Ridge(alpha=.1).fit(features(xn,oracle_terms),yn)
    preds={a:{} for a in ARMS};mse={a:{} for a in ARMS}
    for stage in ('old','new','cold'):
        block=p['held_'+stage];xh=np.asarray(block['x']);yh=np.asarray(block['y'])
        base=old.predict(features(xh,PAIRS))
        out={
            'two_factor_residual':candidate.predict(features(xh,selected)),
            'matched_elasticnet':matched.predict(features(xh,terms+list(QUADS))),
            'full_bank_elasticnet':full.predict(features(xh,BANK)),
            'matched_omp5':matchomp.predict(features(xh,terms+list(QUADS))),
            'full_bank_omp5':fullomp.predict(features(xh,BANK)),
            'softmax_memory':soft[0]*base+soft[1]*fullomp.predict(features(xh,BANK)),
            'old_support_only':oldonly.predict(features(xh,terms)),
            'old_frozen':base,
            'shuffled_new':shuffled.predict(features(xh,selected)),
            'truth_oracle':oracle.predict(features(xh,oracle_terms))}
        for arm in ARMS:
            value=base if stage=='old' else out[arm]
            preds[arm][stage]=value.tolist()
            mse[arm][stage]=float(np.mean((value-yh)**2))
    r['models']={'old_supports':terms,'discovered_quads':[QUADS[k] for k in indices],'matched_cv':matchedcv,'full_cv':fullcv,'softmax_weights':soft.tolist(),'old_prediction_sha256':hashlib.sha256(np.asarray(preds['old_frozen']['old'],dtype='<f8').tobytes()).hexdigest()}
    r['predictions']=preds;r['mse']=mse
    return r

def summarize(cases):
    means={a:{s:float(np.mean([c['mse'][a][s] for c in cases])) for s in ('old','new','cold')} for a in ARMS}
    candidate=means['two_factor_residual']['cold']
    controls=('matched_elasticnet','full_bank_elasticnet','matched_omp5','full_bank_omp5','softmax_memory')
    best=min(means[a]['cold'] for a in controls)
    cohorts={str(k):{a:float(np.mean([c['mse'][a]['cold'] for c in cases if c['seed']==k])) for a in ARMS} for k in sorted({c['seed'] for c in cases})}
    families={f:{a:float(np.mean([c['mse'][a]['cold'] for c in cases if c['family']==f])) for a in ARMS} for f in FAMILIES}
    doubles=[c for c in cases if c['family']=='double_quad']
    recall=sum(len({tuple(k) for k in c['models']['discovered_quads']} & {tuple(k) for k in c['truth']['quad_supports'][:2]}) for c in doubles)/(2*len(doubles))
    gates={
      'cold_gain5_strongest':candidate<=.95*best,
      'cold_gain5_matched_elasticnet':candidate<=.95*means['matched_elasticnet']['cold'],
      'cold_gain5_full_elasticnet':candidate<=.95*means['full_bank_elasticnet']['cold'],
      'per_seed_strict_wins':all(v['two_factor_residual']<min(v[a] for a in controls) for v in cohorts.values()),
      'each_family_nondegradation10pct':all(v['two_factor_residual']<=1.1*min(v[a] for a in controls) for v in families.values()),
      'double_quad_both_recall70pct':recall>=.70,
      'old_exact':all(c['predictions'][a]['old']==c['predictions']['old_frozen']['old'] for c in cases for a in ARMS),
      'improvement20pct_old_frozen':candidate<=.8*means['old_frozen']['cold'],
      'shuffled_negative20pct':candidate<=.8*means['shuffled_new']['cold'],
    }
    critical=('cold_gain5_strongest','cold_gain5_matched_elasticnet','per_seed_strict_wins','each_family_nondegradation10pct')
    decision='SCREEN_PROMISING' if all(gates[g] for g in critical) and sum(gates.values())>=8 else 'SCREEN_NO_GO'
    return {'means':means,'by_seed':cohorts,'by_family':families,'double_quad_recall':recall,'gates':gates,'passed':sum(gates.values()),'total_gates':len(gates),'classification':decision,'best_conventional_cold':best}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,nargs='+',required=True);ap.add_argument('--ids',type=int,nargs='+',default=[0,1,2,3]);ap.add_argument('--out',required=True);args=ap.parse_args()
    t=time.perf_counter();cases=[case_run(world(seed,fi,wid)) for seed in args.seeds for fi in range(3) for wid in args.ids]
    obj={'experiment':'ENERGY-66','version':'v1-frozen','seeds':args.seeds,'ids':args.ids,'cases':cases,'aggregate':summarize(cases),'runtime_seconds':time.perf_counter()-t}
    Path(args.out).write_text(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps({'worlds':len(cases),'classification':obj['aggregate']['classification'],'gates':obj['aggregate']['gates'],'cold':{a:z['cold'] for a,z in obj['aggregate']['means'].items()},'time':obj['runtime_seconds']},indent=2))
if __name__=='__main__':main()
