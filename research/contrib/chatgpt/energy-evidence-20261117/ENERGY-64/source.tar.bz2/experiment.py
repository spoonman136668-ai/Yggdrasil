"""ENERGY-64: synthetic permutation-transfer frozen scorer; external research only."""
import argparse,hashlib,itertools,json,time
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet, OrthogonalMatchingPursuit, Ridge
from sklearn.ensemble import ExtraTreesRegressor

FAMILIES=('return_permuted','reweight_permuted','novel_quad_permuted')
PAIRS=list(itertools.combinations(range(6),2))
QUADS=list(itertools.combinations(range(6),4))
PERMS=np.asarray(list(itertools.permutations(range(6))),dtype=np.int8)
ARMS=('contrast_refit','full_bayes_refit','fixed_bayes','new_pair_elasticnet','new_degree4_elasticnet','new_pair_omp','new_pair_ridge','new_extra_trees','naive_old','shuffled_new')


def keyed_rng(seed,world_id,family,stream):
    raw=f'ENERGY64-V1|{seed}|{world_id}|{family}|{stream}'.encode()
    return np.random.default_rng(int.from_bytes(hashlib.sha256(raw).digest()[:8],'little'))


def all_actions(seed,world_id,family):
    r=keyed_rng(seed,world_id,family,'actions')
    used=set(); newpairs=[]
    choices=r.permutation(256).tolist()
    for bit in range(6):
        count=0
        for v in choices:
            v=int(v); flipped=v^(1<<bit)
            if v in used or flipped in used: continue
            used.add(v);used.add(flipped)
            newpairs.extend([v,flipped]); count+=1
            if count==3: break
        if count!=3:raise RuntimeError('insufficient disjoint paired interventions')
    remaining=r.permutation(np.asarray([x for x in range(256) if x not in used],dtype=int))
    assert len(remaining)==220
    old=remaining[:72];oldh=remaining[72:120];newh=remaining[120:168];coldh=remaining[168:216]
    assert len(set(newpairs+old.tolist()+oldh.tolist()+newh.tolist()+coldh.tolist()))==252
    return {'old':old.tolist(),'new':newpairs,'old_held':oldh.tolist(),'new_held':newh.tolist(),'cold_held':coldh.tolist()}


def old_bits(actions):
    a=np.asarray(actions,dtype=np.uint16)
    return ((a[:,None]>>np.arange(8))&1).astype(np.int8)


def feature_bits(bits,order):
    return np.prod(1-2*bits[:,np.array(order,dtype=int)],axis=1).astype(float)


def pair_features(bits):
    x=bits[:,:6]
    spins=1-2*x
    return np.stack([spins[:,a]*spins[:,b] for a,b in PAIRS],axis=1).astype(float)


def degree4_features(bits):
    spins=1-2*bits[:,:6]
    return np.stack([spins[:,a]*spins[:,b]*spins[:,c]*spins[:,d] for a,b,c,d in QUADS],axis=1).astype(float)


def world(seed,wid,family):
    r=keyed_rng(seed,wid,family,'truth')
    action=all_actions(seed,wid,family)
    p=r.permutation(6).tolist() # observed NEW index j gets OLD coordinate p[j]
    truth_pairs=[(0,1),(2,3),(4,5)]
    origcoef=(np.array([1.2,-1.0,.8])*r.choice([-1,1],size=3)).tolist()
    newcoef=origcoef.copy()
    if family=='reweight_permuted':newcoef[1]*=.45
    shift=.35 if family!='return_permuted' else 0.0
    old_bias=float(r.normal(0,.15));new_bias=old_bias+shift
    hiddenquad=tuple(sorted(r.choice(6,size=4,replace=False).tolist()))
    def stage(name,seen,source):
        bits=old_bits(action[name]); causal=bits.copy(); observed=bits.copy()
        permuted=source!='old'
        if permuted: observed[:,:6]=causal[:,p]
        cue_rng=keyed_rng(seed,wid,family,'cue_'+name)
        if source=='old':cue_sources=(causal[:,0],causal[:,4]);strength=.88
        elif source=='cold':cue_sources=(causal[:,2],causal[:,5]);strength=.5
        else:cue_sources=(causal[:,3],causal[:,1]);strength=.88
        cues=np.stack([np.where(cue_rng.random(len(bits))<strength,cue_sources[i],1-cue_sources[i]) for i in range(2)],axis=1)
        obs=np.concatenate([observed,cues],axis=1).astype(np.int8)
        coef=origcoef if source=='old' else newcoef
        y=np.ones(len(bits))* (old_bias if source=='old' else new_bias)
        for i,order in enumerate(truth_pairs):y+=coef[i]*feature_bits(causal,order)
        if source!='old' and family=='novel_quad_permuted':y+=.9*feature_bits(causal,hiddenquad)
        noise=keyed_rng(seed,wid,family,'noise_'+name).normal(0,.18,len(bits))
        y=y+noise
        return {'action_ids':action[name], 'x':obs.tolist(),'y':y.tolist(),'source':source}
    data={}
    for name,src in [('old','old'),('new','new'),('old_held','old'),('new_held','new'),('cold_held','cold')]:data[name]=stage(name,True,src)
    return {'seed':seed,'world':wid,'family':family,'permutation_truth':p,'old_pairs_truth':[list(z) for z in truth_pairs], 'coeff_old_truth':origcoef,'coeff_new_truth':newcoef,'quad_truth':list(hiddenquad),'old_bias_truth':old_bias,'new_bias_truth':new_bias,'streams':data}


def fit_old(w):
    old=w['streams']['old'];x=np.array(old['x']);y=np.array(old['y']);feat=pair_features(x)
    model=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True).fit(feat,y)
    selected=np.where(np.abs(model.coef_)>1e-9)[0].tolist()
    if len(selected)!=3:
        # selection can be fewer only if degenerate; store exact model for audit
        selected=sorted(np.argsort(np.abs(model.coef_))[-3:].tolist())
    return selected,model.coef_[selected].astype(float),float(model.intercept_),model


def all_perm_features(x,selected):
    x=np.asarray(x,dtype=np.int8)
    spin=1-2*x[:,:6]
    perms=PERMS
    ids=np.asarray([PAIRS[j] for j in selected],dtype=int)
    a=perms[:,ids[:,0]];b=perms[:,ids[:,1]]
    feats=spin[:,a]*spin[:,b]
    return np.moveaxis(feats,0,1).astype(float) # [720,n,3]


def solve_models(x,y,selected,oldcoef,oldbias,alpha=.5):
    feat=all_perm_features(x,selected)
    a=np.concatenate((np.ones((len(PERMS),len(y),1)),feat),axis=2)
    reg=np.diag([.001,alpha,alpha,alpha]);prior=np.asarray([oldbias,*oldcoef],float)
    lhs=np.einsum('pni,pnj->pij',a,a)+reg
    rhs=np.einsum('pni,n->pi',a,y)+reg@prior
    coef=np.linalg.solve(lhs,rhs[...,None])[...,0]
    train_pred=np.einsum('pni,pi->pn',a,coef)
    prior_pen=np.sum((coef-prior)*((coef-prior)@reg),axis=1)
    return coef,train_pred,prior_pen


def posterior(vals,temperature):
    a=-np.asarray(vals)/(temperature*temperature)
    a=a-np.max(a)
    weights=np.exp(a);return weights/np.sum(weights)


def predict_permuted(x,selected,coef,weights):
    feat=all_perm_features(x,selected)
    raw=np.einsum('pni,pi->pn',np.concatenate((np.ones((len(PERMS),len(x),1)),feat),axis=2),coef)
    return weights@raw


def fixed_bayes(x_train,y_train,x_test,selected,oldcoef,oldbias):
    feat_train=all_perm_features(x_train,selected)
    feat_test=all_perm_features(x_test,selected)
    scores=np.einsum('pni,i->pn',feat_train,oldcoef)+oldbias
    err=np.sum((scores-y_train)**2,axis=1)
    weights=posterior(err/2,.45)
    return weights@(np.einsum('pni,i->pn',feat_test,oldcoef)+oldbias),float(np.max(weights))


def predict_arms(w):
    streams=w['streams'];old=streams['old'];new=streams['new'];oldh=streams['old_held'];nh=streams['new_held'];ch=streams['cold_held']
    xo=np.array(old['x']);yo=np.array(old['y']);xn=np.array(new['x']);yn=np.array(new['y']);xoh=np.array(oldh['x']);xnh=np.array(nh['x']);xch=np.array(ch['x']);
    selected,oldcoef,oldbias,oldmodel=fit_old(w)
    coef,fit,p_pen=solve_models(xn,yn,selected,oldcoef,oldbias)
    full_loss=np.sum((fit-yn[None,:])**2,axis=1)+p_pen
    # all new data labels used in refit, but posterior mapping scores differ
    # actual 18 paired interventions, 3 pairs per input bit, same nuisance context
    diff_y=yn[0::2]-yn[1::2]
    diff_fit=fit[:,0::2]-fit[:,1::2]
    contrast_loss=np.sum((diff_fit-diff_y[None,:])**2,axis=1)+p_pen
    cweights=posterior(contrast_loss/2,.46)
    fweights=posterior(full_loss/2,.38)
    oldpred=oldmodel.predict(pair_features(xoh))
    results={}
    def store(k,n,c,meta=None):
        results[k]={'old_pred':oldpred.tolist(),'new_pred':np.asarray(n).tolist(),'cold_pred':np.asarray(c).tolist(),
                    'old_mse':float(np.mean((oldpred-np.array(oldh['y']))**2)),
                    'new_mse':float(np.mean((np.asarray(n)-np.array(nh['y']))**2)),
                    'cold_mse':float(np.mean((np.asarray(c)-np.array(ch['y']))**2))}
        if meta is not None:results[k]['meta']=meta
    store('contrast_refit',predict_permuted(xnh,selected,coef,cweights),predict_permuted(xch,selected,coef,cweights),{'top_weight':float(np.max(cweights)), 'map_entropy':float(-np.sum(cweights*np.log(np.maximum(cweights,1e-300))))})
    store('full_bayes_refit',predict_permuted(xnh,selected,coef,fweights),predict_permuted(xch,selected,coef,fweights),{'top_weight':float(np.max(fweights))})
    n_fixed,peak=fixed_bayes(xn,yn,xnh,selected,oldcoef,oldbias)
    c_fixed,_=fixed_bayes(xn,yn,xch,selected,oldcoef,oldbias)
    store('fixed_bayes',n_fixed,c_fixed,{'top_weight':peak})
    ftrain=pair_features(xn);fnew=pair_features(xnh);fcold=pair_features(xch)
    qtrain=np.concatenate((ftrain,degree4_features(xn)),axis=1)
    qnew=np.concatenate((fnew,degree4_features(xnh)),axis=1);qcold=np.concatenate((fcold,degree4_features(xch)),axis=1)
    models={
        'new_pair_elasticnet':(ElasticNet(alpha=.035,l1_ratio=.8,fit_intercept=True,max_iter=6000,tol=1e-7),ftrain,fnew,fcold),
        'new_degree4_elasticnet':(ElasticNet(alpha=.035,l1_ratio=.8,fit_intercept=True,max_iter=6000,tol=1e-7),qtrain,qnew,qcold),
        'new_pair_omp':(OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True),ftrain,fnew,fcold),
        'new_pair_ridge':(Ridge(alpha=1,fit_intercept=True),ftrain,fnew,fcold),
        'new_extra_trees':(ExtraTreesRegressor(n_estimators=48,min_samples_leaf=2,max_features=1.0,random_state=611,n_jobs=1),xn,xnh,xch),
    }
    for name,(model,a,b,c) in models.items():
        model.fit(a,yn)
        store(name,model.predict(b),model.predict(c))
    store('naive_old',oldmodel.predict(pair_features(xnh)),oldmodel.predict(pair_features(xch)))
    shuffled=np.roll(yn,len(yn)//2)
    shmodel=ElasticNet(alpha=.035,l1_ratio=.8,fit_intercept=True,max_iter=6000,tol=1e-7).fit(qtrain,shuffled)
    store('shuffled_new',shmodel.predict(qnew),shmodel.predict(qcold))
    return {'old_support':selected,'old_coefficients':oldcoef.tolist(),'old_bias_fit':oldbias,'arms':results}


def aggregate(cases):
    by_arm={k:{metric:float(np.mean([z['evaluation']['arms'][k][metric] for z in cases])) for metric in ('old_mse','new_mse','cold_mse')} for k in ARMS}
    best_other=min((k for k in ARMS if k not in ('contrast_refit','shuffled_new','naive_old')),key=lambda k:by_arm[k]['cold_mse'])
    target=by_arm['contrast_refit']['cold_mse'];best=by_arm[best_other]['cold_mse'];fixed=by_arm['full_bayes_refit']['cold_mse']
    by_seed={str(s):{k:float(np.mean([z['evaluation']['arms'][k]['cold_mse'] for z in cases if z['seed']==s])) for k in ARMS} for s in sorted({x['seed'] for x in cases})}
    by_family={f:{k:float(np.mean([z['evaluation']['arms'][k]['cold_mse'] for z in cases if z['family']==f])) for k in ARMS} for f in FAMILIES}
    gates={
      'cold_vs_strongest_other_5pct':target<=.95*best,
      'cold_vs_full_posterior_3pct':target<=.97*fixed,
      'cold_vs_naive_old_20pct':target<=.8*by_arm['naive_old']['cold_mse'],
      'cold_vs_fixed_bayes_5pct':target<=.95*by_arm['fixed_bayes']['cold_mse'],
      'seed_positive_each':all(by_seed[s]['contrast_refit']<min(v for k,v in by_seed[s].items() if k not in ('contrast_refit','naive_old','shuffled_new')) for s in by_seed),
      'family_noninferiority_10pct':all(by_family[f]['contrast_refit']<=1.1*min(v for k,v in by_family[f].items() if k not in ('contrast_refit','naive_old','shuffled_new')) for f in FAMILIES),
      'old_exact_retained':all(all(abs(z['evaluation']['arms'][k]['old_mse']-z['evaluation']['arms']['contrast_refit']['old_mse'])<1e-11 for k in ARMS) for z in cases),
      'shuffled_negative_20pct':target<=.8*by_arm['shuffled_new']['cold_mse'],
      'posterior_spread_exercised':float(np.mean([z['evaluation']['arms']['contrast_refit']['meta']['map_entropy'] for z in cases]))>=.25,
    }
    return {'by_arm':by_arm,'by_seed':by_seed,'by_family':by_family,'best_other':best_other,'gates':gates,
    'pass_count':sum(gates.values()),'total_gates':len(gates),'critical':['cold_vs_strongest_other_5pct','cold_vs_full_posterior_3pct','seed_positive_each'],
    'decision':'SCREEN_PROMISING' if all(gates.get(k) for k in ('cold_vs_strongest_other_5pct','cold_vs_full_posterior_3pct','seed_positive_each')) and sum(gates.values())>=8 else 'SCREEN_NO_GO'}


def run(seeds,world_ids=range(4)):
    t=time.monotonic();cases=[]
    for seed in seeds:
        for family in FAMILIES:
            for wid in world_ids:
                w=world(int(seed),int(wid),family)
                e=predict_arms(w)
                cases.append({'seed':int(seed),'world_id':int(wid),'family':family,'source':w,'evaluation':e})
    return {'experiment':'ENERGY-64','schema':'energy64-original-score-v1','seeds':list(map(int,seeds)),'world_ids':list(map(int,world_ids)),
        'cases':cases,'summary':aggregate(cases),'elapsed_seconds':time.monotonic()-t}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seeds',nargs='+',type=int,required=True);parser.add_argument('--world-ids',nargs='+',type=int,default=[0,1,2,3]);parser.add_argument('--out',required=True);args=parser.parse_args()
    data=run(args.seeds,args.world_ids)
    Path(args.out).write_text(json.dumps(data,sort_keys=True,separators=(',',':'))+'\n')
    s=data['summary'];print(json.dumps({'seeds':args.seeds,'worlds':len(data['cases']),'decision':s['decision'],'pass':s['pass_count'],'gates':s['gates'],'cold':{k:round(v['cold_mse'],6) for k,v in s['by_arm'].items()},'runtime_seconds':round(data['elapsed_seconds'],3)},indent=2))
