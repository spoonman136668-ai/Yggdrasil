"""ENERGY-64 independently written audit. Never imports experiment.py.

Checks source-keyed generated truth, disjoint intervention assignments,
paired do actions, all 720 map refits, all conventional fits/predictions,
per-case scores and aggregate scores. Third-party NumPy/sklearn shared.
"""
import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import ElasticNet, OrthogonalMatchingPursuit, Ridge
from sklearn.ensemble import ExtraTreesRegressor

BIN_PAIRS=list(itertools.combinations(range(6),2)); FOUR=list(itertools.combinations(range(6),4)); MAPS=list(itertools.permutations(range(6)))
NAMES=['contrast_refit','full_bayes_refit','fixed_bayes','new_pair_elasticnet','new_degree4_elasticnet','new_pair_omp','new_pair_ridge','new_extra_trees','naive_old','shuffled_new']
FAMS=('return_permuted','reweight_permuted','novel_quad_permuted')


def rng(seed,w,f,name):
    key=f'ENERGY64-V1|{seed}|{w}|{f}|{name}'
    return np.random.default_rng(int.from_bytes(hashlib.sha256(key.encode()).digest()[:8],'little'))


def inputs(ids):
    a=np.asarray(ids,dtype=np.uint16)
    return np.column_stack([(a>>j)&1 for j in range(8)]).astype(np.int8)


def design(x,pairs):
    spins=1-2*np.asarray(x)[:,:6]
    return np.asarray([np.prod(spins[:,list(q)],axis=1) for q in pairs]).T.astype(float)


def enumerate_maps(x,chosen):
    spins=1-2*np.asarray(x)[:,:6]
    out=np.empty((len(MAPS),len(x),3),dtype=float)
    for i,mapping in enumerate(MAPS):
        for j,sel in enumerate(chosen):
            a,b=BIN_PAIRS[sel]
            out[i,:,j]=spins[:,mapping[a]]*spins[:,mapping[b]]
    return out


def dist(err,t):
    s=-(err/t**2);s-=max(s)
    r=np.exp(s)
    return r/sum(r)


def checkclose(actual,expected,key,count,tol=2e-9):
    a=np.asarray(actual,dtype=float);b=np.asarray(expected,dtype=float)
    if a.shape!=b.shape or not np.allclose(a,b,rtol=0,atol=tol):
        raise ValueError(f'{key}: shape/values disagree, max diff={np.max(np.abs(a-b)) if a.shape==b.shape else "SHAPE"}')
    count[0]+=int(a.size)


def rebuild_source(case,count):
    seed,wi,f=case['seed'],case['world_id'],case['family'];raw=case['source']
    r=rng(seed,wi,f,'actions');used=set();expected=[];pool=r.permutation(256).tolist()
    for bit in range(6):
        found=0
        for value in pool:
            other=int(value)^(1<<bit)
            if int(value) in used or other in used: continue
            used.add(int(value));used.add(other);expected.extend([int(value),other]);found+=1
            if found==3:break
        assert found==3
    rem=r.permutation(np.array([x for x in range(256) if x not in used],dtype=int))
    streams=raw['streams'];assigned={'new':expected,'old':rem[:72].tolist(),'old_held':rem[72:120].tolist(),'new_held':rem[120:168].tolist(),'cold_held':rem[168:216].tolist()}
    for name,values in assigned.items():
        assert streams[name]['action_ids']==values,f'{name} assignment mismatch'
        count[0]+=len(values)
    assert len(set(sum(assigned.values(),[])))==252
    truth=rng(seed,wi,f,'truth');p=truth.permutation(6).tolist()
    coeff=np.array([1.2,-1.,.8])*truth.choice([-1,1],size=3)
    changed=coeff.copy()
    if f=='reweight_permuted':changed[1]*=.45
    b_old=float(truth.normal(0,.15));b_new=b_old+(.35 if f!='return_permuted' else 0)
    quad=tuple(sorted(truth.choice(6,size=4,replace=False).tolist()))
    assert raw['permutation_truth']==p and raw['quad_truth']==list(quad)
    checkclose(raw['coeff_old_truth'],coeff,'hidden old coefficient',count)
    checkclose(raw['coeff_new_truth'],changed,'hidden new coefficient',count)
    checkclose(raw['old_bias_truth'],b_old,'hidden bias',count)
    checkclose(raw['new_bias_truth'],b_new,'hidden new bias',count)
    for name,values in assigned.items():
        source='old' if name in ('old','old_held') else 'cold' if name=='cold_held' else 'new'
        bits=inputs(values);x=bits.copy()
        if source!='old':x[:,:6]=bits[:,p]
        nr=rng(seed,wi,f,'cue_'+name)
        if source=='old':cue=(bits[:,0],bits[:,4]);prob=.88
        elif source=='cold':cue=(bits[:,2],bits[:,5]);prob=.5
        else:cue=(bits[:,3],bits[:,1]);prob=.88
        for a in range(2):
            mask=nr.random(len(x))<prob
            x=np.column_stack((x,np.where(mask,cue[a],1-cue[a])))
        q=coeff if source=='old' else changed
        yy=(b_old if source=='old' else b_new)+sum(q[j]*np.prod(1-2*bits[:,list(pair)],axis=1) for j,pair in enumerate(((0,1),(2,3),(4,5))))
        if f=='novel_quad_permuted' and source!='old':yy+=.9*np.prod(1-2*bits[:,list(quad)],axis=1)
        yy+=rng(seed,wi,f,'noise_'+name).normal(0,.18,len(bits))
        checkclose(x,streams[name]['x'],name+' observed inputs',count,tol=0)
        checkclose(yy,streams[name]['y'],name+' source labels',count)
    return raw


def checkcase(case,count):
    src=rebuild_source(case,count);d=src['streams'];ev=case['evaluation'];
    xold=np.asarray(d['old']['x']);yold=np.asarray(d['old']['y']);xnew=np.asarray(d['new']['x']);ynew=np.asarray(d['new']['y'])
    xoldh=np.asarray(d['old_held']['x']);xnewh=np.asarray(d['new_held']['x']);xcold=np.asarray(d['cold_held']['x'])
    old_head=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True).fit(design(xold,BIN_PAIRS),yold)
    selected=np.flatnonzero(abs(old_head.coef_)>1e-9).tolist()
    if len(selected)!=3:selected=sorted(np.argsort(abs(old_head.coef_))[-3:].tolist())
    assert selected==ev['old_support']; count[0]+=3
    oc=old_head.coef_[selected];ob=float(old_head.intercept_)
    checkclose(oc,ev['old_coefficients'],'old fitted coefficients',count)
    checkclose(ob,ev['old_bias_fit'],'old fitted bias',count)
    oh=old_head.predict(design(xoldh,BIN_PAIRS))
    oldlabels=np.asarray(d['old_held']['y']);nl=np.asarray(d['new_held']['y']);cl=np.asarray(d['cold_held']['y'])
    fx=enumerate_maps(xnew,selected);fn=enumerate_maps(xnewh,selected);fc=enumerate_maps(xcold,selected)
    prior=np.r_[ob,oc];regular=np.diag([.001,.5,.5,.5]);coefs=[];tr=[];pen=[]
    for j in range(len(MAPS)):
        xx=np.column_stack((np.ones(len(xnew)),fx[j]))
        cc=np.linalg.solve(xx.T@xx+regular,xx.T@ynew+regular@prior)
        coefs.append(cc);tr.append(xx@cc);pen.append((cc-prior)@regular@(cc-prior))
    fit=np.asarray(tr);coefs=np.asarray(coefs);pen=np.asarray(pen)
    full=np.sum((fit-ynew[None,:])**2,axis=1)+pen
    delta=fit[:,::2]-fit[:,1::2]-(ynew[::2]-ynew[1::2])[None,:]
    contrast=np.sum(delta**2,axis=1)+pen
    cw=dist(contrast/2,.46);fw=dist(full/2,.38)
    nn=np.einsum('pni,pi->pn',np.concatenate((np.ones((len(MAPS),len(xnewh),1)),fn),axis=2),coefs)
    cc=np.einsum('pni,pi->pn',np.concatenate((np.ones((len(MAPS),len(xcold),1)),fc),axis=2),coefs)
    preds={'contrast_refit':(cw@nn,cw@cc),'full_bayes_refit':(fw@nn,fw@cc)}
    fixedfit=np.einsum('pni,i->pn',fx,oc)+ob
    bw=dist(np.sum((fixedfit-ynew[None,:])**2,axis=1)/2,.45)
    preds['fixed_bayes']=(bw@(np.einsum('pni,i->pn',fn,oc)+ob),bw@(np.einsum('pni,i->pn',fc,oc)+ob))
    pair=design(xnew,BIN_PAIRS);ph=design(xnewh,BIN_PAIRS);pc=design(xcold,BIN_PAIRS)
    total=np.column_stack((pair,design(xnew,FOUR)))
    th=np.column_stack((ph,design(xnewh,FOUR)));tc=np.column_stack((pc,design(xcold,FOUR)))
    choices={
        'new_pair_elasticnet':(ElasticNet(alpha=.035,l1_ratio=.8,max_iter=6000,tol=1e-7),pair,ph,pc),
        'new_degree4_elasticnet':(ElasticNet(alpha=.035,l1_ratio=.8,max_iter=6000,tol=1e-7),total,th,tc),
        'new_pair_omp':(OrthogonalMatchingPursuit(n_nonzero_coefs=3),pair,ph,pc),
        'new_pair_ridge':(Ridge(alpha=1),pair,ph,pc),
        'new_extra_trees':(ExtraTreesRegressor(n_estimators=48,min_samples_leaf=2,max_features=1.0,random_state=611,n_jobs=1),xnew,xnewh,xcold),
    }
    for name,(model,a,b,c) in choices.items():
        model.fit(a,ynew);preds[name]=(model.predict(b),model.predict(c))
    preds['naive_old']=(old_head.predict(ph),old_head.predict(pc))
    sh=ElasticNet(alpha=.035,l1_ratio=.8,max_iter=6000,tol=1e-7).fit(total,np.roll(ynew,len(ynew)//2))
    preds['shuffled_new']=(sh.predict(th),sh.predict(tc))
    assert set(preds)==set(NAMES)
    for name,(newpred,coldpred) in preds.items():
        evidence=ev['arms'][name]
        for key,expected in (('old_pred',oh),('new_pred',newpred),('cold_pred',coldpred)):
            checkclose(expected,evidence[key],f'{name}.{key}',count)
        for key,pred,truth in (('old_mse',oh,oldlabels),('new_mse',newpred,nl),('cold_mse',coldpred,cl)):
            checkclose(float(np.mean((pred-truth)**2)),evidence[key],f'{name}.{key}',count)
    checkclose(ev['arms']['contrast_refit']['meta']['top_weight'],max(cw),'candidate peak',count)
    checkclose(ev['arms']['contrast_refit']['meta']['map_entropy'],-sum(cw*np.log(np.maximum(cw,1e-300))),'candidate entropy',count)
    checkclose(ev['arms']['full_bayes_refit']['meta']['top_weight'],max(fw),'bayes peak',count)
    checkclose(ev['arms']['fixed_bayes']['meta']['top_weight'],max(bw),'fixed peak',count)


def main(file):
    doc=json.loads(Path(file).read_text())
    count=[0]
    assert doc['experiment']=='ENERGY-64'
    for case in doc['cases']:
        assert case['seed'] in doc['seeds'] and case['world_id'] in doc['world_ids'] and case['family'] in FAMS
        checkcase(case,count)
    assert len(doc['cases'])==len(doc['seeds'])*len(doc['world_ids'])*len(FAMS)
    arm_summary={}
    for name in NAMES:
        arm_summary[name]={}
        for field in ('old_mse','new_mse','cold_mse'):
            value=np.mean([c['evaluation']['arms'][name][field] for c in doc['cases']])
            checkclose(value,doc['summary']['by_arm'][name][field],f'aggregate-{name}-{field}',count)
            arm_summary[name][field]=value
    for group,groups in (('by_seed',doc['seeds']),('by_family',FAMS)):
        for label in groups:
            mask=[c for c in doc['cases'] if (c['seed']==label if group=='by_seed' else c['family']==label)]
            for name in NAMES:
                value=np.mean([c['evaluation']['arms'][name]['cold_mse'] for c in mask])
                checkclose(value,doc['summary'][group][str(label)][name],f'{group}/{label}/{name}',count)
    cand=arm_summary['contrast_refit']['cold_mse'];other={k:v['cold_mse'] for k,v in arm_summary.items() if k not in ('contrast_refit','shuffled_new','naive_old')}
    minname=min(other,key=other.get)
    assert doc['summary']['best_other']==minname
    byseed=doc['summary']['by_seed'];byfam=doc['summary']['by_family']
    gates={
        'cold_vs_strongest_other_5pct':cand<=.95*other[minname],
        'cold_vs_full_posterior_3pct':cand<=.97*arm_summary['full_bayes_refit']['cold_mse'],
        'cold_vs_naive_old_20pct':cand<=.8*arm_summary['naive_old']['cold_mse'],
        'cold_vs_fixed_bayes_5pct':cand<=.95*arm_summary['fixed_bayes']['cold_mse'],
        'seed_positive_each':all(v['contrast_refit']<min(v[k] for k in other) for v in byseed.values()),
        'family_noninferiority_10pct':all(byfam[f]['contrast_refit']<=1.1*min(byfam[f][k] for k in other) for f in FAMS),
        'old_exact_retained':all(all(abs(c['evaluation']['arms'][k]['old_mse']-c['evaluation']['arms']['contrast_refit']['old_mse'])<1e-11 for k in NAMES) for c in doc['cases']),
        'shuffled_negative_20pct':cand<=.8*arm_summary['shuffled_new']['cold_mse'],
        'posterior_spread_exercised':np.mean([c['evaluation']['arms']['contrast_refit']['meta']['map_entropy'] for c in doc['cases']])>=.25}
    gates={k:bool(v) for k,v in gates.items()}
    assert gates==doc['summary']['gates']
    assert sum(gates.values())==doc['summary']['pass_count'] and len(gates)==doc['summary']['total_gates']
    count[0]+=len(gates)
    decision='SCREEN_PROMISING' if all(gates[k] for k in ('cold_vs_strongest_other_5pct','cold_vs_full_posterior_3pct','seed_positive_each')) and sum(gates.values())>=8 else 'SCREEN_NO_GO'
    assert decision==doc['summary']['decision']
    return {'experiment':'ENERGY-64','source':str(file),'verdict':'PASS','checks':count[0],'worlds':len(doc['cases']),'decision':decision,'gates':gates,'best_other':minname}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('source');ap.add_argument('--out',required=True);args=ap.parse_args()
    r=main(args.source);Path(args.out).write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r,indent=2))
