#!/usr/bin/env python3
"""Independent implementation of ENERGY-62 data/feature/model readback.
Never imports the scorer; shares declared sklearn numerical solvers.
"""
import argparse,json,hashlib
from pathlib import Path
from itertools import combinations
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet,Ridge
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor
M=('reused_composition','fresh_omp','matched_elasticnet','matched_ridge','rbf_kernel','extra_trees','old_no_update','shuffled_new','atom_only_omp','softmax_memory')
F=('conditional5','nested_xor5','threshold5')
class Counts:
 def __init__(self):self.n=0
 def check(self,v,msg):
  if not bool(v):raise AssertionError(msg)
  self.n+=1
 def eq(self,a,b,msg,tol=1e-9):
  a=np.asarray(a);b=np.asarray(b)
  self.check(a.shape==b.shape,msg+' shape')
  diff=np.max(np.abs(a.astype(float)-b.astype(float))) if a.size else 0
  self.check(diff<=tol,msg+' max_diff '+str(diff))

def rng(*parts):
  h=hashlib.sha256((':'.join(map(str,('E62v1',)+parts))).encode()).digest()
  return np.random.default_rng(int.from_bytes(h[:8],'big'))

def generator(seed,idx,fam):
  r=rng('world',seed,idx,fam)
  actions=((np.arange(256)[:,None]>>np.arange(8))&1).astype('int8')
  actions=actions[r.permutation(256)[:224]]
  role=list(map(int,r.permutation(8)[:7]));a,b,c,d,e,f,g=role
  items={};cur=0
  for label,length,context in zip(('train_old','train_new','held_old','held_new','held_cold'),(64,64,32,32,32),('old','new','old','new','cold')):
    raw=actions[cur:cur+length];cur+=length
    xi=np.empty((length,10),dtype='int8');xi[:,:8]=raw
    if context=='old':
      xi[:,8]=raw[:,1] ^ (r.random(length)<.12)
      xi[:,9]=raw[:,3] ^ (r.random(length)<.12)
    elif context=='new':
      xi[:,8]=(1-raw[:,1]) ^ (r.random(length)<.12)
      xi[:,9]=raw[:,5] ^ (r.random(length)<.12)
    else:xi[:,8:10]=r.integers(0,2,(length,2))
    shared=(raw[:,a]!=raw[:,b]);
    if context=='old':other=(raw[:,c] != (raw[:,d]&raw[:,e]))
    elif fam=='conditional5':other=np.where(raw[:,c]>0,(raw[:,d]!=raw[:,e]),(raw[:,f]&raw[:,g])>0)
    elif fam=='nested_xor5':other=((raw[:,c]&raw[:,d])!=(raw[:,e]&(raw[:,f]^raw[:,g])))
    else:other= (raw[:,c] != (raw[:,d]&((raw[:,e]+raw[:,f]+raw[:,g])>=2)))
    target=.65*(2*shared.astype(float)-1)+1.2*(2*other.astype(float)-1)+.18*r.normal(size=length)
    items[label]={'x':xi,'y':target}
  return role,items

def base_features(x):
  feats=[]; masks=[]
  for j in range(10):feats.append(2*x[:,j].astype(float)-1);masks.append(1<<j)
  for i,j in combinations(range(10),2):
    feats.append(2*(x[:,i]!=x[:,j]).astype(float)-1);masks.append((1<<i)|(1<<j))
    feats.append(2*(x[:,i]&x[:,j]).astype(float)-1);masks.append((1<<i)|(1<<j))
  return np.array(feats).T,masks

def topparents(x,y):
  feat,_=base_features(x);s=np.abs(feat.T @ (y-y.mean())/len(y));return sorted(np.argsort(-s,kind='stable')[:17].tolist())

def expand(x,parent_ids):
  basis,mask=base_features(x)
  extras=[]
  for i,j in combinations(sorted(parent_ids),2):
    if mask[i]&mask[j]:continue
    v=basis[:,i]>0;w=basis[:,j]>0
    extras.append(2*(v!=w).astype(float)-1)
    extras.append(2*(v&w).astype(float)-1)
  return np.column_stack([basis]+extras)

def omp(x,y,k=5):
  model=OrthogonalMatchingPursuit(n_nonzero_coefs=min(k,x.shape[1]),fit_intercept=True)
  return model.fit(x,y)

def biased(x,y,old_ids):
  residual=y-y.mean();selected=[];borrow=set(old_ids)
  for iteration in range(5):
    s=np.abs(x.T@residual)/len(y)
    if borrow:
      for b in borrow:
        if b<len(s):s[b]*=1.12
    for j in selected:s[j]=-1
    new=int(np.argmax(s))
    if s[new]<1e-9:break
    selected.append(new)
    z=np.column_stack((np.ones(len(y)),x[:,selected]))
    residual=y-z@np.linalg.lstsq(z,y,rcond=None)[0]
  if not selected:return selected,np.array([y.mean()])
  z=np.column_stack((np.ones(len(y)),x[:,selected]))
  return selected,np.linalg.lstsq(z,y,rcond=None)[0]

def audit_case(c,counts):
  seed=c['seed'];wid=c['world_id'];fam=c['family'];counts.check(fam in F,'family')
  roles, d=generator(seed,wid,fam)
  counts.eq(roles,c['roles'],'roles')
  for key, value in d.items():
    counts.eq(value['x'],c['data'][key]['x'],key+' actions',0)
    counts.eq(value['y'],c['data'][key]['y'],key+' consequence',1e-12)
  seen=np.concatenate([v['x'][:,:8] for v in d.values()])
  counts.check(len({tuple(row) for row in seen})==224,'unique causal interventions')
  xo,yo=d['train_old']['x'],d['train_old']['y'];xn,yn=d['train_new']['x'],d['train_new']['y']
  old_parents=topparents(xo,yo);new_parents=topparents(xn,yn)
  parents=sorted(set(old_parents[:7]+new_parents[:14]))
  counts.eq(old_parents,c['arms']['meta']['old_parent_ids'],'old parent indices',0)
  counts.eq(new_parents,c['arms']['meta']['new_parent_ids'],'new parent indices',0)
  counts.eq(parents,c['arms']['meta']['union_parent_ids'],'joined parent indices',0)
  old_basis=expand(xo,parents);new_basis=expand(xn,parents);held={k:expand(d[k]['x'],parents) for k in ('held_old','held_new','held_cold')}
  counts.check(old_basis.shape[1]==c['arms']['meta']['bank_size'],'bank width')
  old=omp(old_basis,yo);old_select=np.flatnonzero(np.abs(old.coef_)>1e-8).tolist()
  counts.eq(old_select,c['arms']['meta']['old_chosen'],'old selected',0)
  new_select,new_coef=biased(new_basis,yn,old_select)
  counts.eq(new_select,c['arms']['meta']['candidate']['selected'],'candidate selection',0)
  counts.eq(new_coef,c['arms']['meta']['candidate']['coef'],'candidate weights',1e-9)
  counts.check(sum(i>=100 for i in new_select)==c['arms']['meta']['new_programs_selected'],'composed feature count')
  fits={
   'fresh_omp':omp(new_basis,yn),
   'matched_elasticnet':ElasticNet(alpha=.025,l1_ratio=.85,max_iter=2500,tol=1e-5,selection='cyclic').fit(new_basis,yn),
   'matched_ridge':Ridge(alpha=3.).fit(new_basis,yn),
   'rbf_kernel':KernelRidge(alpha=.3,gamma=.19,kernel='rbf').fit(xn,yn),
   'extra_trees':ExtraTreesRegressor(n_estimators=48,max_depth=9,min_samples_leaf=2,random_state=19,n_jobs=1).fit(xn,yn),
   'shuffled_new':omp(new_basis,yn[rng('shuf',seed,wid,fam).permutation(len(yn))]),
   'atom_only_omp':omp(new_basis[:,:100],yn)
  }
  memscore=-np.array([np.mean((old.predict(new_basis)-yn)**2),np.mean((fits['fresh_omp'].predict(new_basis)-yn)**2)])/.10
  mem=np.exp(memscore-np.max(memscore));mem/=mem.sum()
  for name in M:
    for query,feature in held.items():
      if name=='reused_composition' and query!='held_old':pred=np.full(len(feature),new_coef[0])+(feature[:,new_select]@new_coef[1:] if new_select else 0)
      elif query=='held_old' or name=='old_no_update':pred=old.predict(feature)
      elif name=='softmax_memory':pred=mem[0]*old.predict(feature)+mem[1]*fits['fresh_omp'].predict(feature)
      elif name=='rbf_kernel' or name=='extra_trees':pred=fits[name].predict(d[query]['x'])
      elif name=='atom_only_omp':pred=fits[name].predict(feature[:,:100])
      else:pred=fits[name].predict(feature)
      actual=np.asarray(c['arms'][name]['prediction'][query]);counts.eq(pred,actual,f'{seed}/{wid}/{fam}/{name}/{query} predictions',1e-8)
      mse=float(np.mean((pred-d[query]['y'])**2));counts.eq(mse,c['arms'][name]['mse'][query],f'{name}/{query} mse',1e-8)
      for predicted,stored in zip(pred,actual):counts.eq(predicted,stored,f'{name}/{query} each predicted',1e-8)
  return True

def audit(obj):
  counts=Counts()
  counts.check(obj['schema']=='yggdrasil.energy62.scores.v1','schema')
  pairs=[(int(s),int(i),f) for s in obj['seeds'] for i in obj['world_ids'] for f in obj['families']]
  counts.check(len(obj['cases'])==len(pairs),'case count')
  for c,required in zip(obj['cases'],pairs):
    counts.check((c['seed'],c['world_id'],c['family'])==required,'case ordering')
    audit_case(c,counts)
  for m in M:
    for key in ('held_old','held_new','held_cold'):
      score=float(np.mean([c['arms'][m]['mse'][key] for c in obj['cases']]))
      counts.eq(score,obj['summary'][m][key],m+'/'+key+' aggregate')
  for s in obj['seeds']:
    for m in M:
      score=float(np.mean([c['arms'][m]['mse']['held_cold'] for c in obj['cases'] if c['seed']==s]));counts.eq(score,obj['seed_summary'][str(s)][m],str(s)+'/'+m+' seed')
  for f in obj['families']:
    for m in M:
      score=float(np.mean([c['arms'][m]['mse']['held_cold'] for c in obj['cases'] if c['family']==f]));counts.eq(score,obj['family_summary'][f][m],f+'/'+m+' family')
  total=sum(c['arms']['meta']['new_programs_selected'] for c in obj['cases'])
  counts.check(total==obj['new_composition_count'],'composed features')
  return {'status':'PASS','independent_refit_checks':counts.n,'cases':len(obj['cases']),'seeds':obj['seeds'],'all_arms':list(M),'independence_caveat':'Independent source reconstruction and model refits, but same published sklearn/NumPy solvers and same known synthetic generation specification'}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('--out',required=True);a=p.parse_args()
 obj=json.loads(Path(a.source).read_text());receipt=audit(obj);Path(a.out).write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(receipt,sort_keys=True))
