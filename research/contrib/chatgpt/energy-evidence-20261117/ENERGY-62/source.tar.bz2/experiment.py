#!/usr/bin/env python3
"""ENERGY-62: external tokenless synthetic causal-composition falsification.
All learned features depend only on labeled training data; no native Yggdrasil changes.
"""
import argparse, hashlib, json, time
from pathlib import Path
from itertools import combinations
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor

FAMILIES=('conditional5','nested_xor5','threshold5')
METHODS=('reused_composition','fresh_omp','matched_elasticnet','matched_ridge','rbf_kernel','extra_trees','old_no_update','shuffled_new','atom_only_omp','softmax_memory')

def rng_for(*args):
    h=hashlib.sha256((':'.join(map(str,('E62v1',)+args))).encode()).digest()
    return np.random.default_rng(int.from_bytes(h[:8],'big'))

def noise_bits(x, stage, rng):
    n=len(x); out=np.empty((n,10),dtype=np.int8);out[:,:8]=x
    if stage=='old':
        out[:,8]=x[:,1] ^ (rng.random(n)<.12)
        out[:,9]=x[:,3] ^ (rng.random(n)<.12)
    elif stage=='new':
        out[:,8]=(1-x[:,1]) ^ (rng.random(n)<.12)
        out[:,9]=x[:,5] ^ (rng.random(n)<.12)
    else:
        out[:,8:10]=rng.integers(0,2,(n,2))
    return out

def signed(q): return np.where(q,1.,-1.)

def consequence(x, roles, family, stage):
    a,b,c,d,e,f,g=map(int,roles)
    shared=np.logical_xor(x[:,a],x[:,b])
    if stage=='old':
        changed=np.logical_xor(x[:,c], np.logical_and(x[:,d],x[:,e]))
    elif family=='conditional5':
        changed=np.where(x[:,c]==1, np.logical_xor(x[:,d],x[:,e]),np.logical_and(x[:,f],x[:,g]))
    elif family=='nested_xor5':
        changed=np.logical_xor(np.logical_and(x[:,c],x[:,d]),np.logical_and(x[:,e],np.logical_xor(x[:,f],x[:,g])))
    else:
        changed=np.logical_xor(x[:,c], np.logical_and(x[:,d],(x[:,e]+x[:,f]+x[:,g])>=2))
    return .65*signed(shared)+1.2*signed(changed)

def world(seed,world_id,family):
    r=rng_for('world',seed,world_id,family)
    all_x=((np.arange(256)[:,None]>>np.arange(8))&1).astype(np.int8)
    x=all_x[r.permutation(256)[:224]]
    sizes=[64,64,32,32,32];labels=['train_old','train_new','held_old','held_new','held_cold']
    stages=['old','new','old','new','cold'];cursor=0
    roles=r.permutation(8)[:7].astype(int)
    data={}
    for size,key,stage in zip(sizes,labels,stages):
        base=x[cursor:cursor+size];cursor+=size
        obs=noise_bits(base,stage,r)
        yt=consequence(base,roles,family,'old' if stage=='old' else 'new')+.18*r.normal(size=size)
        data[key]={'x':obs.tolist(),'y':yt.tolist()}
    return {'seed':int(seed),'world_id':int(world_id),'family':family,'roles':roles.tolist(),'data':data}

def atoms(x):
    x=np.asarray(x,dtype=np.int8)
    vals=[]; masks=[]; labels=[]
    for i in range(10):
        vals.append(signed(x[:,i]));masks.append(1<<i);labels.append(f'U{i}')
    for a,b in combinations(range(10),2):
        vals.append(signed(np.bitwise_xor(x[:,a],x[:,b])));masks.append((1<<a)|(1<<b));labels.append(f'X{a}.{b}')
        vals.append(signed(np.bitwise_and(x[:,a],x[:,b])));masks.append((1<<a)|(1<<b));labels.append(f'A{a}.{b}')
    return np.stack(vals,axis=1),masks,labels

def select_parents(x,y,n=17):
    a,_,_=atoms(x);y=np.asarray(y);v=y-y.mean()
    s=np.abs(a.T@v/len(y))
    return sorted(np.argsort(-s,kind='stable')[:n].tolist())

def feature_bank(x,parents):
    a,masks,labels=atoms(x)
    values=[a];out_labels=list(labels);out_masks=list(masks)
    for i,j in combinations(sorted(parents),2):
        if masks[i]&masks[j]: continue
        p=(a[:,i]>0);q=(a[:,j]>0)
        values.append(signed(np.logical_xor(p,q))[:,None]);out_labels.append(f'X({labels[i]},{labels[j]})');out_masks.append(masks[i]|masks[j])
        values.append(signed(np.logical_and(p,q))[:,None]);out_labels.append(f'A({labels[i]},{labels[j]})');out_masks.append(masks[i]|masks[j])
    return np.hstack(values),out_masks,out_labels

def fit_omp(x,y,k=5):
    m=OrthogonalMatchingPursuit(n_nonzero_coefs=min(k,x.shape[1]),fit_intercept=True)
    m.fit(x,np.asarray(y));return m

def fit_biased(x,y,old_parent_set):
    y=np.asarray(y);center=y.mean();res=y-center;chosen=[]
    oldmask=set(old_parent_set)
    for _ in range(5):
        corr=np.abs(x.T@res)/len(y)
        for j in chosen:corr[j]=-1.
        if oldmask:
            for j in oldmask:
                if j<len(corr):corr[j]*=1.12
        j=int(np.argmax(corr));
        if corr[j]<1e-9: break
        chosen.append(j)
        mat=np.column_stack([np.ones(len(y)),x[:,chosen]])
        co=np.linalg.lstsq(mat,y,rcond=None)[0]
        res=y-mat@co
    if not chosen: return {'selected':[],'coef':[float(center)]}
    co=np.linalg.lstsq(np.column_stack([np.ones(len(y)),x[:,chosen]]),y,rcond=None)[0]
    return {'selected':chosen,'coef':co.tolist()}

def predict_biased(model,x):
    c=model['coef'];idx=model['selected']
    return np.full(len(x),c[0])+(x[:,idx]@np.asarray(c[1:]) if idx else 0)

def model_results(case):
    d=case['data'];xo=np.asarray(d['train_old']['x']);yo=np.asarray(d['train_old']['y']);xn=np.asarray(d['train_new']['x']);yn=np.asarray(d['train_new']['y'])
    xh={name:np.asarray(d[name]['x']) for name in ('held_old','held_new','held_cold')}
    prev=select_parents(xo,yo);pa_new=select_parents(xn,yn)
    # memory: selected old primitive parents survive as source structure in the new bank.
    parents=sorted(set(prev[:7]+pa_new[:14]))
    ao,_mask,labels=feature_bank(xo,parents)
    an,_,_=feature_bank(xn,parents)
    ah={name:feature_bank(x,parents)[0] for name,x in xh.items()}
    old=fit_omp(ao,yo,5)
    old_nonzero=np.flatnonzero(np.abs(old.coef_)>1e-8).tolist()
    cand=fit_biased(an,yn,old_nonzero)
    fits={
        'fresh_omp':fit_omp(an,yn,5),
        'matched_elasticnet':ElasticNet(alpha=.025,l1_ratio=.85,max_iter=2500,tol=1e-5,selection='cyclic').fit(an,yn),
        'matched_ridge':Ridge(alpha=3.).fit(an,yn),
        'rbf_kernel':KernelRidge(alpha=.3,gamma=.19,kernel='rbf').fit(xn,yn),
        'extra_trees':ExtraTreesRegressor(n_estimators=48,max_depth=9,min_samples_leaf=2,random_state=19,n_jobs=1).fit(xn,yn),
        'shuffled_new':fit_omp(an,yn[rng_for('shuf',case['seed'],case['world_id'],case['family']).permutation(len(yn))],5),
        'atom_only_omp':fit_omp(an[:,:100],yn,5),
    }
    memory_logits=-np.array([np.mean((old.predict(an)-yn)**2),np.mean((fits['fresh_omp'].predict(an)-yn)**2)])/.10
    memory_weights=np.exp(memory_logits-np.max(memory_logits));memory_weights/=memory_weights.sum()
    result={};old_preds=old.predict(ah['held_old'])
    for name in METHODS:
        if name in ('reused_composition','old_no_update'):
            pred={c:predict_biased(cand,ah[c]) if name=='reused_composition' and c!='held_old' else old.predict(ah[c]) for c in ah}
        elif name=='softmax_memory':
            pred={c:memory_weights[0]*old.predict(ah[c])+memory_weights[1]*fits['fresh_omp'].predict(ah[c]) for c in ah}
        elif name=='rbf_kernel' or name=='extra_trees':
            pred={c:fits[name].predict(xh[c]) for c in ah}
        elif name=='atom_only_omp':
            pred={c:fits[name].predict(ah[c][:,:100]) for c in ah}
        else:pred={c:fits[name].predict(ah[c]) for c in ah}
        # for each independently trained stage-head conventional, old held is old's head.
        if name not in ('reused_composition','old_no_update'):pred['held_old']=old_preds
        preds={key:np.asarray(value,float).tolist() for key,value in pred.items()}
        metric={key:float(np.mean((np.asarray(pred[key])-np.asarray(d[key]['y']))**2)) for key in pred}
        result[name]={'mse':metric,'prediction':preds}
    result['meta']={'old_parent_ids':prev,'new_parent_ids':pa_new,'union_parent_ids':parents,'bank_size':len(labels),'old_chosen':old_nonzero,'candidate':cand,'new_programs_selected':sum(j>=100 for j in cand['selected'])}
    return result

def score(seeds,ids=(0,1,2,3),families=FAMILIES):
    out={'schema':'yggdrasil.energy62.scores.v1','seeds':list(map(int,seeds)),'world_ids':list(map(int,ids)),'families':list(families),'cases':[]}
    for s in seeds:
        for i in ids:
            for f in families:
                c=world(s,i,f);c['arms']=model_results(c);out['cases'].append(c)
    out['summary']={m:{k:float(np.mean([c['arms'][m]['mse'][k] for c in out['cases']])) for k in ('held_old','held_new','held_cold')} for m in METHODS}
    out['seed_summary']={str(s):{m:float(np.mean([c['arms'][m]['mse']['held_cold'] for c in out['cases'] if c['seed']==s])) for m in METHODS} for s in seeds}
    out['family_summary']={f:{m:float(np.mean([c['arms'][m]['mse']['held_cold'] for c in out['cases'] if c['family']==f])) for m in METHODS} for f in families}
    out['new_composition_count']=sum(c['arms']['meta']['new_programs_selected'] for c in out['cases'])
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,nargs='+',required=True);p.add_argument('--world-ids',type=int,nargs='+',default=[0,1,2,3]);p.add_argument('--out',required=True)
    a=p.parse_args();t=time.perf_counter();r=score(a.seeds,tuple(a.world_ids));r['elapsed_s']=time.perf_counter()-t
    Path(a.out).write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n');print(json.dumps({'seeds':a.seeds,'worlds':len(r['cases']),'cold':{k:round(v['held_cold'],6) for k,v in r['summary'].items()},'elapsed':r['elapsed_s']},sort_keys=True))
