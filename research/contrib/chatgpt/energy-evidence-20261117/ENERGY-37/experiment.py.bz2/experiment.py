#!/usr/bin/env python3
"""ENERGY-37: one-pass causal-energy witness selection vs strong selectors.

Isolated synthetic external research. No accepted Yggdrasil source or native
science runs. True causal law, held outcomes and source labels stay evaluator-side.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import time
import warnings

import numpy as np
from sklearn.linear_model import LogisticRegression, OrthogonalMatchingPursuit, Ridge
from sklearn.tree import DecisionTreeClassifier

HERE = Path(__file__).resolve().parent
SEEDS = (7703, 7723, 7753)
FAMILIES = ('parity3', 'mixed', 'extended4')
SELECTORS = ('one_pass_energy', 'energy_committee', 'omp_committee', 'energy_uncertainty', 'omp_uncertainty', 'paired_fixed', 'random')
LEARNERS = ('energy', 'omp12', 'ridge', 'logistic', 'tree')
N_TRAIN_OLD = 80
N_PROBES = 16
N_HELD_OLD = 16
N_HELD_NEW = 48
BOOTSTRAPS = 6
SCORE_EPS = 1e-12

BITS = np.array([[(i >> j) & 1 for j in range(8)] for i in range(256)], dtype=np.int8)
SPIN = 2 * BITS - 1
RULE_FEATURES = []
for degree in (1, 2, 3, 4):
    for indices in itertools.combinations(range(8), degree):
        RULE_FEATURES.append(('parity', indices))
for indices in itertools.combinations(range(8), 2):
    RULE_FEATURES.append(('and', indices))
FEATURES = []
for kind, indices in RULE_FEATURES:
    if kind == 'parity':
        FEATURES.append(np.prod(SPIN[:, indices], axis=1))
    else:
        FEATURES.append(2 * (BITS[:, indices[0]] & BITS[:, indices[1]]) - 1)
PHI = np.asarray(FEATURES, dtype=np.float64).T
assert PHI.shape == (256, 190)
FACTORS = {d: [i for i, (kind, coords) in enumerate(RULE_FEATURES) if kind == 'parity' and len(coords) == d]
           for d in (2, 3, 4)}
AND_FACTORS = [i for i, (kind, _) in enumerate(RULE_FEATURES) if kind == 'and']


def hd(*parts):
    return hashlib.sha256('/'.join(map(str, ('energy37-v1', *parts))).encode('ascii')).digest()


def idx(*parts, n):
    return int.from_bytes(hd(*parts)[:8], 'big') % n


def construct(seed, world, family):
    banks = ([FACTORS[3]] * 3 if family == 'parity3' else
             [FACTORS[3], FACTORS[2], AND_FACTORS] if family == 'mixed' else
             [FACTORS[4], FACTORS[3], AND_FACTORS])
    chosen = []
    for j, bank in enumerate(banks):
        k = idx('hidden_feature', seed, world, family, j, n=len(bank))
        while bank[k] in chosen:
            k = (k + 1) % len(bank)
        chosen.append(bank[k])
    signs = [1 if idx('hidden_sign', seed, world, family, j, n=2) else -1 for j in range(3)]
    # The learner only sees its witnessed actions and noisy consequences.
    truth = np.where(sum(s * PHI[:, f] for s, f in zip(signs, chosen)) > 0, 1, -1)
    old = sorted((i for i in range(256) if i % 2 == 0), key=lambda i: hd('old_split', seed, world, family, i))
    old_train = old[:N_TRAIN_OLD]
    held_old = old[N_TRAIN_OLD:N_TRAIN_OLD + N_HELD_OLD]
    # Each prospective x0=1 action pairs with a witnessed old x0=0 action.
    pool = [i | 1 for i in old_train]
    held_new = sorted((i for i in range(256) if i % 2 == 1 and i not in pool),
                      key=lambda i: hd('held_new_order', seed, world, family, i))[:N_HELD_NEW]
    assert len(pool) == 80 and len(held_new) == 48
    assert not set(pool).intersection(held_new)
    assert not set(old_train).intersection(held_old)

    def outcome(action):
        flip = int.from_bytes(hd('noise', seed, world, family, action)[:8], 'big') / 2 ** 64 < .10
        return int(truth[action]) * (-1 if flip else 1)

    witnessed_old = np.asarray([outcome(a) for a in old_train], dtype=np.float64)
    return dict(seed=seed, world=world, family=family, old=old_train, pool=pool,
                held_old=held_old, held_new=held_new, observed_old=witnessed_old,
                truth=truth, outcome=outcome)


def fit_energy(x, y, epochs=48):
    weights = np.zeros(x.shape[1], dtype=np.float64)
    for _ in range(epochs):
        failed = y * (x @ weights) < 1
        if not np.any(failed):
            break
        gradient = np.mean(y[failed, None] * x[failed], axis=0)
        pick = np.argsort(-np.abs(gradient), kind='stable')[:8]
        weights[pick] += .05 * gradient[pick]
        support = np.argsort(-np.abs(weights), kind='stable')[:12]
        keep = np.zeros(len(weights), dtype=bool)
        keep[support] = True
        weights[~keep] = 0
    assert np.count_nonzero(weights) <= 12
    return weights


def fit_omp(x, y):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        model = OrthogonalMatchingPursuit(n_nonzero_coefs=12, fit_intercept=True).fit(x, y)
    return model


def boot_predictions(x, y, candidates, selector, seed, world, family):
    decision = []
    for j in range(BOOTSTRAPS):
        rg = np.random.default_rng(idx('bootstrap', selector, seed, world, family, j, n=2 ** 32))
        sample = rg.integers(0, len(x), size=len(x))
        if selector == 'energy_committee':
            decision.append(np.asarray(candidates @ fit_energy(x[sample], y[sample]) > 0, dtype=float))
        else:
            model = fit_omp(x[sample], y[sample])
            decision.append(np.asarray(model.predict(candidates) > 0, dtype=float))
    return np.asarray(decision)


def select_actions(case, selector):
    old, pool, y = case['old'], case['pool'], case['observed_old']
    if selector == 'paired_fixed':
        return pool[:N_PROBES]
    if selector == 'random':
        return sorted(pool, key=lambda a: hd('random_probe', case['seed'], case['world'], case['family'], a))[:N_PROBES]

    x = PHI[old]
    candidates = PHI[pool]
    if selector == 'one_pass_energy':
        # Exactly one vectorized contrastive-energy gradient from witnessed data.
        # No optimizer iteration, bootstrap, candidate labels or hidden source use.
        gradient = np.mean(y[:, None] * x, axis=0)
        keep = np.argsort(-np.abs(gradient), kind='stable')[:12]
        weights = np.zeros(x.shape[1], dtype=np.float64)
        weights[keep] = gradient[keep]
        margin = candidates @ weights
        uncertainty = np.exp(-np.abs(margin))
    elif selector == 'energy_uncertainty':
        score = candidates @ fit_energy(x, y)
        uncertainty = np.exp(-np.abs(score))
    elif selector == 'omp_uncertainty':
        score = fit_omp(x, y).predict(candidates)
        uncertainty = np.exp(-np.abs(score))
    else:
        votes = boot_predictions(x, y, candidates, selector, case['seed'], case['world'], case['family'])
        p = votes.mean(axis=0)
        uncertainty = 4 * p * (1 - p)
    # Diversity is a secondary tie-break, not a surrogate evaluator label.
    result = []
    for _ in range(N_PROBES):
        scores = []
        for j, action in enumerate(pool):
            if action in result:
                continue
            if result:
                # 7 varying coordinates; x0 is always 1 in candidate pool.
                diversity = min(int(np.count_nonzero(BITS[action] != BITS[chosen])) for chosen in result) / 7
            else:
                diversity = 1.0
            # Frozen score, deterministic stable source-private-independent tie key.
            utility = float(uncertainty[j]) + 0.05 * diversity
            scores.append((-utility, hd('tie', selector, case['seed'], case['world'], case['family'], action), action))
        result.append(min(scores)[2])
    return result


def final_predict(x, y, test_indices, learner):
    candidate = PHI[test_indices]
    if learner == 'energy':
        weights = fit_energy(x, y)
        return np.where(candidate @ weights > 0, 1, -1)
    if learner == 'omp12':
        model = fit_omp(x, y)
        return np.where(model.predict(candidate) > 0, 1, -1)
    if learner == 'ridge':
        model = Ridge(alpha=3.0).fit(x, y)
        return np.where(model.predict(candidate) > 0, 1, -1)
    if learner == 'logistic':
        model = LogisticRegression(C=1., max_iter=500, tol=1e-8).fit(x, y)
        return np.where(model.decision_function(candidate) > 0, 1, -1)
    raise ValueError(learner)


def score_world(seed, world, family):
    case = construct(seed, world, family)
    results = {}
    for selector in SELECTORS:
        ts = time.perf_counter()
        actions = select_actions(case, selector)
        selection_seconds = time.perf_counter() - ts
        assert len(actions) == 16 and len(set(actions)) == 16 and set(actions).issubset(set(case['pool']))
        observed = np.r_[case['observed_old'], [case['outcome'](a) for a in actions]]
        training = case['old'] + actions
        fitting = PHI[training]
        predictions = {}
        timings = {}
        for learner in LEARNERS:
            ts = time.perf_counter()
            if learner == 'tree':
                mdl = DecisionTreeClassifier(max_depth=8, random_state=19).fit(BITS[training], observed)
                forecast = mdl.predict(BITS[case['held_old'] + case['held_new']])
            else:
                forecast = final_predict(fitting, observed, case['held_old'] + case['held_new'], learner)
            timings[learner] = time.perf_counter() - ts
            predictions[learner] = dict(old=int(sum(forecast[:16] == case['truth'][case['held_old']])),
                                        new=int(sum(forecast[16:] == case['truth'][case['held_new']])))
        # Separate label-shuffled negative, no privileged information.
        shuf = np.random.default_rng(idx('shuffle', selector, seed, world, family, n=2 ** 32)).permutation(observed)
        shuffled_forecast = final_predict(fitting, shuf, case['held_new'], 'energy')
        results[selector] = dict(actions=actions, selected_noisy_outcomes=[int(case['outcome'](a)) for a in actions],
                                 learned=predictions, shuffled_energy_new=int(sum(shuffled_forecast == case['truth'][case['held_new']])),
                                 acquisition_seconds=selection_seconds, final_fit_seconds=timings)
    return dict(seed=seed, world=world, family=family, policies=results)


def aggregate(cases):
    score = {s:{l:{p:sum(c['policies'][s]['learned'][l][p] for c in cases) for p in ('new','old')}
                for l in LEARNERS} for s in SELECTORS}
    neg = {s:sum(c['policies'][s]['shuffled_energy_new'] for c in cases) for s in SELECTORS}
    cost = {s:{l:sum(c['policies'][s]['acquisition_seconds'] + c['policies'][s]['final_fit_seconds'][l] for c in cases)
               for l in LEARNERS} for s in SELECTORS}
    return score,neg,cost


def run(args):
    seeds=(99107,) if args.smoke else SEEDS
    worlds=range(1) if args.smoke else range(8)
    started=time.perf_counter()
    cases=[score_world(s,w,f) for s in seeds for w in worlds for f in FAMILIES]
    score,neg,cost=aggregate(cases)
    energy_active=score['one_pass_energy']['energy']
    best_alternatives=max(score[s][l]['new'] for s in SELECTORS for l in LEARNERS
                          if (s,l) != ('one_pass_energy','energy'))
    seed_margins=[]
    for seed in seeds:
        subset=[c for c in cases if c['seed']==seed]
        z,_,_=aggregate(subset)
        seed_margins.append(z['one_pass_energy']['energy']['new']-
                            max(z[s][l]['new'] for s in SELECTORS for l in LEARNERS
                                if (s,l) != ('one_pass_energy','energy')))
    gates = {
        'accuracy_vs_strongest': (energy_active['new']-best_alternatives)/(len(cases)*48) >= .03,
        'one_pass_vs_iterative': (energy_active['new']-score['energy_uncertainty']['energy']['new'])/(len(cases)*48) >= .01,
        'one_pass_vs_omp_selector': (energy_active['new']-score['omp_uncertainty']['energy']['new'])/(len(cases)*48) >= .01,
        'old_retention': energy_active['old'] >= score['paired_fixed']['energy']['old']-.01*len(cases)*16,
        'seed_stability': sum(x>0 for x in seed_margins)>=2 if not args.smoke else False,
        'shuffled_negative': energy_active['new']>neg['one_pass_energy'] + .05*len(cases)*48,
        'whole_policy_cost': cost['one_pass_energy']['energy'] <= 1.5*cost['random']['omp12'],
    }
    out=dict(schema='yggdrasil.energy37.score.v1',mode='smoke' if args.smoke else 'primary',
             seeds=list(seeds),cases=len(cases),train_old=80,probe_budget=16,held_old=16,held_new=48,
             observed_outcomes_per_arm=96,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             score=score,shuffled_negative=neg,cost_seconds=cost,seed_margins=seed_margins,
             gates=gates,classification='DEVELOPMENT_GO' if all(gates.values()) else 'DEVELOPMENT_NO_GO',
             total_wall_seconds=time.perf_counter()-started,details=cases,
             scientific_pass=False,native_checkpoint_run=False,deployment='NONE')
    Path(args.out).write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='details'},sort_keys=True,indent=2))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--out',required=True)
    run(p.parse_args())


if __name__=='__main__':main()
