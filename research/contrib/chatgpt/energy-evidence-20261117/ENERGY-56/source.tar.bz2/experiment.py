#!/usr/bin/env python3
"""ENERGY-56 — held-out compositional causal representation (external synthetic only)."""
import argparse, hashlib, itertools, json, os, time
from functools import lru_cache
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor

FAMILIES=('parity_composed','mixed_composed','gated_composed')
ARMS=('hierarchical','no_composition','full_omp','full_elasticnet','full_ridge','rbf_kernel','extra_trees','shuffled_composition')
PRIMARY=(9911,9923,9941)
NOLD,NNEW,NHELD=128,96,96

@lru_cache(maxsize=None)
def indices(up_to):
    return tuple(tuple(c) for n in range(1,up_to+1) for c in itertools.combinations(range(12),n))

@lru_cache(maxsize=None)
def degrees(up_to):return np.array([len(c) for c in indices(up_to)],dtype=np.int16)

def basis(x,up_to):
    spin=2*np.asarray(x,dtype=np.int8)-1
    ix=indices(up_to)
    return np.column_stack([np.prod(spin[:,i],axis=1) for i in ix]).astype(np.float64)

def family_modules(x,roles,fam):
    s=2*np.asarray(x,dtype=np.int8)[:,roles]-1
    a,b,c=s[:,:3],s[:,3:6],s[:,6:9]
    par=lambda t:np.prod(t,axis=1).astype(float)
    maj=lambda t:np.where(np.sum(t,axis=1)>0,1.0,-1.0)
    gate=lambda t:np.where(t[:,0]>0,t[:,1],t[:,2]).astype(float)
    if fam=='parity_composed':return par(a),par(b),par(c)
    if fam=='mixed_composed':return par(a),maj(b),par(c)
    return gate(a),par(b),maj(c)

def ground_truth(x,roles,weights,fam,phase):
    a,b,c=family_modules(x,roles,fam)
    w=np.asarray(weights,dtype=float)
    new=float(phase!='old')
    return w[0]*a+w[1]*b+w[2]*c+w[3]*a*b+(w[4] if not new else w[5])*b*c+w[6]*(2*x[:,roles[9]]-1)

def make_world(seed,source_id,family):
    fi=FAMILIES.index(family)
    rng=np.random.default_rng(np.random.SeedSequence([5601,int(seed),int(source_id),int(fi)]))
    roles=rng.permutation(10).astype(int).tolist()
    w=(rng.choice([-1,1],7)*rng.uniform([0.8,0.8,0.8,0.6,0.8,0.8,0.2],[1.35,1.35,1.35,1.2,1.35,1.35,0.45])).tolist()
    # Each causal assignment is unique throughout all train/held phases; noise never recycled.
    assignments=rng.permutation(1024)[:NOLD+NNEW+3*NHELD]
    causal=((assignments[:,None] >> np.arange(10)) &1).astype(np.int8)
    n=len(causal);x=np.column_stack([causal,np.zeros((n,2),dtype=np.int8)])
    phases=(['old']*NOLD+['new']*NNEW+['old']*NHELD+['new']*NHELD+['cold']*NHELD)
    for i,phase in enumerate(phases):
        if phase=='old': cues=[causal[i,roles[0]],causal[i,roles[1]]]
        elif phase=='new': cues=[1-causal[i,roles[0]],causal[i,roles[1]]]
        else: cues=rng.integers(0,2,size=2)
        for k,c in enumerate(cues):x[i,10+k]=int(c) if phase=='cold' or rng.random()>=0.08 else 1-int(c)
    phase_ranges={'train_old':(0,NOLD),'train_new':(NOLD,NOLD+NNEW),'held_old':(NOLD+NNEW,NOLD+NNEW+NHELD),'held_new':(NOLD+NNEW+NHELD,NOLD+NNEW+2*NHELD),'held_cold':(NOLD+NNEW+2*NHELD,n)}
    y=np.empty(n,float)
    for ph,(s,e) in phase_ranges.items():y[s:e]=ground_truth(x[s:e],roles,w,family,'old' if 'old' in ph else 'new')+rng.normal(0,.20,size=e-s)
    return {'seed':int(seed),'source_id':int(source_id),'family':family,'roles':roles,'weights':w,'x':x.tolist(),'y':y.tolist(),'ranges':{k:list(v) for k,v in phase_ranges.items()},'causal_ids':assignments.astype(int).tolist()}

def _omp(X,y,n):
    # OMP's fixed n_nonzero supports avoid data-dependent threshold and hidden budget drift.
    m=OrthogonalMatchingPursuit(n_nonzero_coefs=n,fit_intercept=True)
    m.fit(X,y)
    return m

def _ridge(X,y,a):
    m=Ridge(alpha=a,fit_intercept=True,solver='svd').fit(X,y)
    return m

def predict_arms(w):
    x=np.asarray(w['x'],dtype=np.int8); y=np.asarray(w['y'],float);ranges=w['ranges']
    sl=lambda k:slice(*ranges[k]);o,n=sl('train_old'),sl('train_new');test=['held_old','held_new','held_cold']
    z3=basis(x,3);z6=basis(x,6)
    old=_omp(z3[o],y[o],8)
    # Train on OLD consequences only. Only OLD-selected triple factors may compose.
    old_support=np.flatnonzero(np.abs(old.coef_)>1e-10).astype(int).tolist()
    triple=[j for j in old_support if degrees(3)[j]==3]
    combo_pairs=[(a,b) for a,b in itertools.combinations(triple,2) if set(indices(3)[a]).isdisjoint(indices(3)[b])]
    composed=0.3*np.column_stack([z3[:,a]*z3[:,b] for a,b in combo_pairs]) if combo_pairs else np.zeros((len(x),0),float)
    # The same old-discovered supports are reusable across phases; new weights refit on factual NEW labels.
    primitive=z3[:,old_support]
    design=np.column_stack((primitive,composed))
    if design.shape[1]==0:raise ValueError('Empty old feature support')
    pred={}
    for name,subx in [('hierarchical',design),('no_composition',primitive)]:
        old_model=_ridge(subx[o],y[o],.06)
        new_model=_ridge(subx[n],y[n],.06)
        pred[name]=[old_model.predict(subx[sl('held_old')]).tolist(),new_model.predict(subx[sl('held_new')]).tolist(),new_model.predict(subx[sl('held_cold')]).tolist()]
    full_omp_old=_omp(z6[o],y[o],12);full_omp_new=_omp(z6[n],y[n],12)
    pred['full_omp']=[full_omp_old.predict(z6[sl('held_old')]).tolist(),full_omp_new.predict(z6[sl('held_new')]).tolist(),full_omp_new.predict(z6[sl('held_cold')]).tolist()]
    en_old=ElasticNet(alpha=.04,l1_ratio=.8,max_iter=1200,tol=.001,selection='cyclic').fit(z6[o],y[o])
    en_new=ElasticNet(alpha=.04,l1_ratio=.8,max_iter=1200,tol=.001,selection='cyclic').fit(z6[n],y[n])
    pred['full_elasticnet']=[en_old.predict(z6[sl('held_old')]).tolist(),en_new.predict(z6[sl('held_new')]).tolist(),en_new.predict(z6[sl('held_cold')]).tolist()]
    rid_old=_ridge(z6[o],y[o],12.);rid_new=_ridge(z6[n],y[n],12.)
    pred['full_ridge']=[rid_old.predict(z6[sl('held_old')]).tolist(),rid_new.predict(z6[sl('held_new')]).tolist(),rid_new.predict(z6[sl('held_cold')]).tolist()]
    rbf_old=KernelRidge(alpha=.30,gamma=.18,kernel='rbf').fit(x[o],y[o]);rbf_new=KernelRidge(alpha=.30,gamma=.18,kernel='rbf').fit(x[n],y[n])
    pred['rbf_kernel']=[rbf_old.predict(x[sl('held_old')]).tolist(),rbf_new.predict(x[sl('held_new')]).tolist(),rbf_new.predict(x[sl('held_cold')]).tolist()]
    trees_old=ExtraTreesRegressor(n_estimators=64,max_depth=14,min_samples_leaf=2,n_jobs=1,random_state=12).fit(x[o],y[o])
    trees_new=ExtraTreesRegressor(n_estimators=64,max_depth=14,min_samples_leaf=2,n_jobs=1,random_state=13).fit(x[n],y[n])
    pred['extra_trees']=[trees_old.predict(x[sl('held_old')]).tolist(),trees_new.predict(x[sl('held_new')]).tolist(),trees_new.predict(x[sl('held_cold')]).tolist()]
    rng=np.random.default_rng(np.random.SeedSequence([5605,w['seed'],w['source_id'],FAMILIES.index(w['family'])]))
    sham_new=_ridge(design[n],rng.permutation(y[n]),.06)
    sham_old=_ridge(design[o],y[o],.06)
    pred['shuffled_composition']=[sham_old.predict(design[sl('held_old')]).tolist(),sham_new.predict(design[sl('held_new')]).tolist(),sham_new.predict(design[sl('held_cold')]).tolist()]
    return pred,old_support,combo_pairs

def run(seeds,ids=(0,1,2,3),families=FAMILIES):
    cases=[];sumtime=0
    for seed in seeds:
      for family in families:
       for wid in ids:
        start=time.perf_counter();w=make_world(seed,wid,family)
        pred,support,pairs=predict_arms(w);spent=time.perf_counter()-start;sumtime+=spent
        y=np.asarray(w['y']);mse={}
        for arm,pr in pred.items():
         mse[arm]={ctx:float(np.mean((np.asarray(pr[i])-y[slice(*w['ranges']['held_'+ctx])])**2)) for i,ctx in enumerate(('old','new','cold'))}
        cases.append({'world':w,'predictions':pred,'mse':mse,'old_support':support,'composed_pair_indices':pairs,'seconds_total_case':spent})
    aggregate={arm:{ctx:float(np.mean([c['mse'][arm][ctx] for c in cases])) for ctx in ('old','new','cold')} for arm in ARMS}
    by_seed={str(s):{arm:float(np.mean([c['mse'][arm]['cold'] for c in cases if c['world']['seed']==s])) for arm in ARMS} for s in seeds}
    by_family={f:{arm:float(np.mean([c['mse'][arm]['cold'] for c in cases if c['world']['family']==f])) for arm in ARMS} for f in families}
    return {'experiment':'ENERGY-56','seeds':list(seeds),'ids':list(ids),'families':list(families),'source_id':'E56:compose-v1','data':cases,'aggregate':aggregate,'per_seed':by_seed,'per_family':by_family,'total_seconds':sumtime}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,nargs='+',required=True);p.add_argument('--ids',type=int,nargs='+',default=[0,1,2,3]);p.add_argument('--families',nargs='+',default=list(FAMILIES),choices=FAMILIES);p.add_argument('--out',required=True);a=p.parse_args()
 result=run(tuple(a.seeds),tuple(a.ids),tuple(a.families));from pathlib import Path;Path(a.out).write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n');print(json.dumps({'worlds':len(result['data']),'cold':{k:round(v['cold'],5) for k,v in result['aggregate'].items()},'seconds':round(result['total_seconds'],3)}))
