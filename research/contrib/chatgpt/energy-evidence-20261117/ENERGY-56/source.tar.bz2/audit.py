#!/usr/bin/env python3
"""Independently written E56 evidence auditor; does not import experiment.py."""
import argparse, collections, hashlib, itertools, json
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor
ARM_NAMES=('hierarchical','no_composition','full_omp','full_elasticnet','full_ridge','rbf_kernel','extra_trees','shuffled_composition')
FAMILIES=('parity_composed','mixed_composed','gated_composed')

def features(x,max_order):
  states=(np.asarray(x,dtype=int)*2-1).astype(float)
  selections=[c for k in range(1,max_order+1) for c in itertools.combinations(range(12),k)]
  return np.array([np.prod(states[:,c],axis=1) for c in selections]).T,selections

def model_omp(features,targets,n):
  m=OrthogonalMatchingPursuit(n_nonzero_coefs=n,fit_intercept=True);m.fit(features,targets);return m

def rd(X,y,alpha):return Ridge(alpha=alpha,solver='svd').fit(X,y)

def audit_one(rec):
  w=rec['world'];x=np.asarray(w['x'],int);y=np.asarray(w['y'],float);checks=0
  groups=w['ranges'];r=lambda key:slice(*groups[key]);old,new=r('train_old'),r('train_new')
  for key,ct in [('train_old',128),('train_new',96),('held_old',96),('held_new',96),('held_cold',96)]:
   assert groups[key][1]-groups[key][0]==ct;checks+=1
  assert len(x)==512 and x.shape==(512,12) and len(y)==512 and np.isfinite(y).all();checks+=1
  assert np.all((x==0)|(x==1));checks+=1
  codes=np.sum(x[:,:10]*(2**np.arange(10)),axis=1).tolist();assert codes==w['causal_ids'] and len(set(codes))==512;checks+=513
  z3,tri=features(x,3);z6,_=features(x,6)
  m0=model_omp(z3[old],y[old],8)
  keep=np.flatnonzero(np.abs(m0.coef_)>1e-10).tolist();assert keep==rec['old_support'];checks+=len(keep)+1
  triple=[i for i in keep if len(tri[i])==3]
  pairs=[(a,b) for a,b in itertools.combinations(triple,2) if not set(tri[a]).intersection(tri[b])]
  assert [list(t) for t in pairs]==rec['composed_pair_indices'];checks+=len(pairs)+1
  subset=z3[:,keep]
  paired=np.array([z3[:,a]*z3[:,b] for a,b in pairs]).T*.3 if pairs else np.zeros((len(x),0))
  extended=np.column_stack((subset,paired))
  models={}
  for name,z in (('hierarchical',extended),('no_composition',subset)):
   mo=rd(z[old],y[old],.06);mn=rd(z[new],y[new],.06)
   models[name]=[mo.predict(z[r('held_old')]),mn.predict(z[r('held_new')]),mn.predict(z[r('held_cold')])]
  o_omp=model_omp(z6[old],y[old],12);n_omp=model_omp(z6[new],y[new],12)
  models['full_omp']=[o_omp.predict(z6[r('held_old')]),n_omp.predict(z6[r('held_new')]),n_omp.predict(z6[r('held_cold')])]
  eo=ElasticNet(alpha=.04,l1_ratio=.8,max_iter=1200,tol=.001,selection='cyclic').fit(z6[old],y[old]);en=ElasticNet(alpha=.04,l1_ratio=.8,max_iter=1200,tol=.001,selection='cyclic').fit(z6[new],y[new])
  models['full_elasticnet']=[eo.predict(z6[r('held_old')]),en.predict(z6[r('held_new')]),en.predict(z6[r('held_cold')])]
  ro=rd(z6[old],y[old],12.);rn=rd(z6[new],y[new],12.)
  models['full_ridge']=[ro.predict(z6[r('held_old')]),rn.predict(z6[r('held_new')]),rn.predict(z6[r('held_cold')])]
  ko=KernelRidge(alpha=.30,gamma=.18,kernel='rbf').fit(x[old],y[old]);kn=KernelRidge(alpha=.30,gamma=.18,kernel='rbf').fit(x[new],y[new]);models['rbf_kernel']=[ko.predict(x[r('held_old')]),kn.predict(x[r('held_new')]),kn.predict(x[r('held_cold')])]
  to=ExtraTreesRegressor(n_estimators=64,max_depth=14,min_samples_leaf=2,n_jobs=1,random_state=12).fit(x[old],y[old]);tn=ExtraTreesRegressor(n_estimators=64,max_depth=14,min_samples_leaf=2,n_jobs=1,random_state=13).fit(x[new],y[new]);models['extra_trees']=[to.predict(x[r('held_old')]),tn.predict(x[r('held_new')]),tn.predict(x[r('held_cold')])]
  rng=np.random.default_rng(np.random.SeedSequence([5605,int(w['seed']),int(w['source_id']),FAMILIES.index(w['family'])]));so=rd(extended[old],y[old],.06);sn=rd(extended[new],rng.permutation(y[new]),.06);models['shuffled_composition']=[so.predict(extended[r('held_old')]),sn.predict(extended[r('held_new')]),sn.predict(extended[r('held_cold')])]
  for name in ARM_NAMES:
   for i,ctx in enumerate(('old','new','cold')):
    got=np.asarray(rec['predictions'][name][i],float);calc=models[name][i]
    assert got.shape==(96,) and np.allclose(got,calc,atol=2e-7,rtol=2e-7),(name,ctx,np.max(np.abs(got-calc)))
    checks+=len(got)
    mse=float(np.mean((calc-y[r('held_'+ctx)])**2))
    assert abs(mse-rec['mse'][name][ctx])<1e-7,(name,ctx,mse,rec['mse'][name][ctx]);checks+=1
  return checks

def verify(path):
 data=json.loads(Path(path).read_text());cases=data['data'];assert len(cases)==len(data['seeds'])*len(data['ids'])*len(data['families'])
 n=0
 for case in cases:n+=audit_one(case)
 for a in ARM_NAMES:
  for ctx in ('old','new','cold'):
   means=np.mean([v['mse'][a][ctx] for v in cases]);assert abs(means-data['aggregate'][a][ctx])<1e-9;n+=1
  for seed in data['seeds']:
   means=np.mean([v['mse'][a]['cold'] for v in cases if v['world']['seed']==seed]);assert abs(means-data['per_seed'][str(seed)][a])<1e-9;n+=1
  for fam in data['families']:
   means=np.mean([v['mse'][a]['cold'] for v in cases if v['world']['family']==fam]);assert abs(means-data['per_family'][fam][a])<1e-9;n+=1
 return {'audit':'PASS','independently_refit_predictions':n,'worlds':len(cases),'shared_backends':'NumPy and sklearn; independent implementation of model refits and test reconstruction, shared exposed original data (not independent generator truth).'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('scored');p.add_argument('--out',required=True);a=p.parse_args();r=verify(a.scored);Path(a.out).write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r))
