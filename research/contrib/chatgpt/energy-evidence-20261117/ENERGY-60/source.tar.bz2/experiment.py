#!/usr/bin/env python3
"""ENERGY-60 contributor research: learned latent-state retrieval against E59 softmax baseline.
No native Yggdrasil, protected data, APIs, controllers, or accepted state.
"""
import argparse, hashlib, itertools, json, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet
from sklearn.cluster import KMeans
from sklearn.kernel_ridge import KernelRidge

FAMILIES=('return_old','return_middle','novel_threshold')
ARMS=('state_filter','prototype_softmax','softmax_memory','best_snapshot','last_snapshot','pooled_elasticnet','recent_elasticnet','pooled_krr','random_snapshot','shuffled_probes')
TERM=tuple(c for k in (2,3) for c in itertools.combinations(range(12),k))
TRAIN=76; PROBES=12; HELD=52; W=64; STRIDE=16
DESIGN=np.random.default_rng(600111).integers(0,2,size=(40,12),dtype=np.int8)

def feat(x):
    s=2*np.asarray(x,dtype=np.int8)-1
    return np.column_stack([np.prod(s[:,c],axis=1) for c in TERM]).astype(float)

def synth(seed,wid,family):
    assert family in FAMILIES
    rng=np.random.default_rng(np.random.SeedSequence([6001,seed,wid,FAMILIES.index(family)]))
    causal=rng.permutation(9)
    b=[tuple(sorted(causal[j:j+2].tolist())) for j in (0,2,4,6)]
    t=[tuple(sorted(causal[[0,3,8]].tolist())),tuple(sorted(causal[[1,5,7]].tolist()))]
    weights=rng.choice([-1.,1.],6)*rng.uniform(.8,1.2,6)
    roles={'A':{b[0]:weights[0],b[1]:weights[1],b[2]:weights[2],b[3]:weights[3]},
           'B':{b[0]:weights[0],b[1]:weights[1],t[0]:weights[4],t[1]:weights[5]}}
    if family=='return_old':roles['C']=roles['A'].copy()
    elif family=='return_middle':roles['C']=roles['B'].copy()
    else:roles['C']={b[0]:weights[0],b[1]:-weights[1],b[3]:weights[3],t[1]:weights[5]}
    # One higher-order unfamiliar mechanism per family: type and support withheld from learners.
    order=4 if family!='novel_threshold' else 5
    extra_vars=tuple(sorted(causal[:order].tolist()))
    extra_w=float(rng.choice([-1.,1.])*rng.uniform(.9,1.4))
    lengths=rng.integers(TRAIN-8,TRAIN+9,3).tolist()
    assert sum(lengths)+3*PROBES+3*HELD<=512
    counts=lengths+[PROBES]*3+[HELD]*3
    keys=rng.permutation(512)[:sum(counts)]
    x=((keys[:,None]>>np.arange(9))&1).astype(np.int8)
    obs=np.column_stack([x,np.zeros((len(x),3),dtype=np.int8)])
    spans={};offset=0
    for phase,count in zip(('A','B','C')*3,counts):
        kind=('train' if offset<sum(lengths) else 'probe' if offset<sum(lengths)+3*PROBES else 'held')
        sl=slice(offset,offset+count);spans[kind+'_'+phase]=[offset,offset+count]
        for j in range(3):
            cue=x[sl,int(causal[j])].copy()
            if phase=='B':cue=1-cue
            obs[sl,9+j]=(rng.integers(0,2,size=count) if kind=='held' else np.where(rng.random(count)<.08,1-cue,cue))
        offset+=count
    f=feat(obs);lookup={z:i for i,z in enumerate(TERM)};y=np.empty(len(x),float)
    for part in ('train','probe','held'):
        for phase in ('A','B','C'):
            lo,hi=spans[part+'_'+phase];a=obs[lo:hi]
            mean=np.zeros(hi-lo,float)
            for z,v in roles[phase].items():mean+=v*f[lo:hi,lookup[z]]
            if phase=='C':
                if family=='novel_threshold':
                    mean+=extra_w*(2*(np.sum(a[:,extra_vars],axis=1)>=3)-1)
                else:mean+=extra_w*np.prod(2*a[:,extra_vars]-1,axis=1)
            y[lo:hi]=mean+rng.normal(0,.16,hi-lo)
    return {'seed':int(seed),'world_id':int(wid),'family':family,'x':obs.tolist(),'y':y.tolist(),
            'key':keys.tolist(),'spans':spans,'stream_n':sum(lengths),
            'truth_for_audit':{'lengths':lengths,'roles':{phase:{str(z):float(v) for z,v in role.items()} for phase,role in roles.items()},
                               'extra_vars':list(extra_vars),'extra_weight':extra_w,'extra_kind':('threshold' if family=='novel_threshold' else 'parity')}}

def model(x,y):
    m=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(feat(x),np.asarray(y,float))
    return {'coef':np.asarray(m.coef_).tolist(),'intercept':float(m.intercept_),
            'support':np.flatnonzero(np.abs(m.coef_)>1e-9).tolist()}

def infer(m,x):return feat(x)@np.asarray(m['coef'])+float(m['intercept'])

def learn(x,y):
    starts=list(range(0,len(y)-W+1,STRIDE))
    if starts[-1]!=len(y)-W:starts.append(len(y)-W)
    snap=[]
    for st in starts:
        m=model(x[st:st+W],y[st:st+W]);m['start']=st;snap.append(m)
    signature=np.stack([infer(m,DESIGN) for m in snap])
    labels=KMeans(n_clusters=3,n_init=10,random_state=173,algorithm='lloyd').fit_predict(signature)
    # Stable canonical codebook order by first observed member, not hidden regime labels.
    order=sorted(range(3),key=lambda k:int(np.flatnonzero(labels==k)[0]))
    labels=np.asarray([order.index(int(j)) for j in labels],dtype=int)
    prototypes=[]
    for k in range(3):
        group=[snap[i] for i in range(len(snap)) if labels[i]==k]
        coef=np.mean(np.asarray([v['coef'] for v in group]),axis=0)
        prototypes.append({'coef':coef.tolist(),'intercept':float(np.mean([v['intercept'] for v in group])),'count':len(group)})
    transitions=np.ones((3,3),float)
    for a,b in zip(labels[:-1],labels[1:]):transitions[a,b]+=1
    transitions/=transitions.sum(axis=1,keepdims=True)
    return {'schema':'energy60.latent.v1','snapshots':snap,'prototypes':prototypes,
            'cluster_labels':labels.tolist(),'transition':transitions.tolist(),
            'terms':[list(t) for t in TERM],'observations_seen':len(y)}

def score_loss(memory,px,py):
    snap_losses=np.asarray([np.mean((infer(m,px)-py)**2) for m in memory['snapshots']]);
    prot_losses=np.asarray([np.mean((infer(m,px)-py)**2) for m in memory['prototypes']]);
    return snap_losses,prot_losses

def posterior(loss,prior=None):
    z=np.exp(-np.clip((np.asarray(loss)-np.min(loss))/.10,0,700))
    if prior is not None:z=z*np.asarray(prior)
    return z/z.sum()

def fit_world(world):
    x=np.asarray(world['x'],np.int8);y=np.asarray(world['y'],float);n=int(world['stream_n']);t0=time.perf_counter()
    checkpoint=learn(x[:n],y[:n]);enc=json.dumps(checkpoint,sort_keys=True,separators=(',',':'))
    cksha=hashlib.sha256(enc.encode()).hexdigest();checkpoint=json.loads(enc)
    pred={name:{} for name in ARMS};choices={};previous=None
    for phase in ('A','B','C'):
        p=slice(*world['spans']['probe_'+phase]);h=slice(*world['spans']['held_'+phase]);px,py=x[p],y[p];hx=x[h]
        loss_s,loss_p=score_loss(checkpoint,px,py)
        w_raw=posterior(loss_s);w_uniform=posterior(loss_p)
        T=np.asarray(checkpoint['transition']);base=np.full(3,1/3.)
        prior=base if previous is None else .2*base+.8*(previous@T)
        w_state=posterior(loss_p,prior)
        previous=w_state.copy()
        s=np.asarray([infer(m,hx) for m in checkpoint['snapshots']])
        proto=np.asarray([infer(m,hx) for m in checkpoint['prototypes']])
        pred['state_filter'][phase]=(w_state@proto).tolist()
        pred['prototype_softmax'][phase]=(w_uniform@proto).tolist()
        pred['softmax_memory'][phase]=(w_raw@s).tolist()
        pred['best_snapshot'][phase]=s[int(np.argmin(loss_s))].tolist()
        pred['last_snapshot'][phase]=s[-1].tolist()
        pred['random_snapshot'][phase]=s[(int(world['seed'])+int(world['world_id'])+FAMILIES.index(world['family']))%len(s)].tolist()
        bad=np.asarray([np.mean((infer(m,px)-py[::-1])**2) for m in checkpoint['snapshots']]);pred['shuffled_probes'][phase]=s[int(np.argmin(bad))].tolist()
        allx=np.vstack((x[:n],px));ally=np.r_[y[:n],py]
        en=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=3500,tol=.0001).fit(feat(allx),ally)
        pred['pooled_elasticnet'][phase]=en.predict(feat(hx)).tolist()
        en2=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=3500,tol=.0001).fit(feat(np.vstack((x[n-80:n],px))),np.r_[y[n-80:n],py]);pred['recent_elasticnet'][phase]=en2.predict(feat(hx)).tolist()
        kr=KernelRidge(alpha=.20,kernel='rbf',gamma=.20).fit(allx,ally);pred['pooled_krr'][phase]=kr.predict(hx).tolist()
        choices[phase]={'snap_losses':loss_s.tolist(),'proto_losses':loss_p.tolist(),'raw_weights':w_raw.tolist(),
                        'prototype_weights':w_uniform.tolist(),'state_prior':prior.tolist(),'state_posterior':w_state.tolist()}
    metrics={arm:{p:float(np.mean((np.asarray(pred[arm][p])-y[slice(*world['spans']['held_'+p])])**2)) for p in ('A','B','C')} for arm in ARMS}
    return {'checkpoint':checkpoint,'checkpoint_sha256':cksha,'predictions':pred,'choices':choices,'metrics':metrics,
            'seconds_fit_predict':time.perf_counter()-t0}

def evaluate(seeds,ids=(0,1,2,3),families=FAMILIES):
    t=time.perf_counter();cases=[]
    for seed in seeds:
        for family in families:
            for wid in ids:
                world=synth(seed,wid,family);cases.append({'world':world,'fit':fit_world(world)})
    agg={a:{ph:float(np.mean([c['fit']['metrics'][a][ph] for c in cases])) for ph in ('A','B','C')} for a in ARMS}
    pooled={a:float(np.mean(list(agg[a].values()))) for a in ARMS}
    by_seed={str(seed):{a:float(np.mean([c['fit']['metrics'][a][p] for c in cases if c['world']['seed']==seed for p in ('A','B','C')])) for a in ARMS} for seed in seeds}
    by_family={f:{a:float(np.mean([c['fit']['metrics'][a][p] for c in cases if c['world']['family']==f for p in ('A','B','C')])) for a in ARMS} for f in families}
    return {'experiment':'ENERGY-60','generator':'E60:latent-state-outside-grammar:v1','seeds':list(seeds),'world_ids':list(ids),'families':list(families),
            'cases':cases,'aggregate':agg,'pooled':pooled,'by_seed':by_seed,'by_family':by_family,'elapsed_seconds':time.perf_counter()-t}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,nargs='+',required=True);p.add_argument('--ids',type=int,nargs='+',default=[0,1,2,3]);p.add_argument('--out',required=True)
    a=p.parse_args();r=evaluate(a.seeds,tuple(a.ids));Path(a.out).write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps({'cases':len(r['cases']),'pooled_mse':r['pooled'],'seconds':r['elapsed_seconds']},sort_keys=True))
