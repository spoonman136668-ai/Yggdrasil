#!/usr/bin/env python3
"""Source-free ENERGY-60 refit audit; does not import scorer or native Yggdrasil.
Numerical implementation shares NumPy/scikit-learn; synthetic world truth supplied in scored receipt.
"""
import argparse,ast,hashlib,itertools,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet
from sklearn.kernel_ridge import KernelRidge
from sklearn.cluster import KMeans
TERMS=tuple(z for d in (2,3) for z in itertools.combinations(range(12),d))
FAMILIES=('return_old','return_middle','novel_threshold')
ARMS=('state_filter','prototype_softmax','softmax_memory','best_snapshot','last_snapshot','pooled_elasticnet','recent_elasticnet','pooled_krr','random_snapshot','shuffled_probes')
DESIGN=np.random.default_rng(600111).integers(0,2,size=(40,12),dtype=np.int8)

def ftr(x):
    x=np.asarray(x,dtype=np.int8)
    s=2*x-1
    return np.stack([np.prod(s[:,list(z)],axis=1) for z in TERMS],axis=1).astype(float)

def pred(coef,inter,x):return ftr(x)@np.asarray(coef,float)+float(inter)

def soft(loss,prior=None):
    s=np.asarray(loss,float);a=np.exp(-np.clip((s-s.min())/.1,0,700));
    if prior is not None:a*=np.asarray(prior,float)
    return a/a.sum()

def independently_refit(case):
    w=case['world'];fit=case['fit'];x=np.asarray(w['x'],dtype=np.int8);y=np.asarray(w['y'],float);n=int(w['stream_n']);checks=0
    lengths=w['truth_for_audit']['lengths'];N=sum(lengths)+3*12+3*52
    assert x.shape==(N,12) and y.shape==(N,) and n==sum(lengths)
    keys=np.asarray(w['key'],int)
    assert np.array_equal(x[:,:9],(keys[:,None]>>np.arange(9))&1) and len(set(keys))==N and np.all((x==0)|(x==1))
    checks+=N*13
    ft=ftr(x);idx={z:i for i,z in enumerate(TERMS)}
    for part in ('train','probe','held'):
        for ph in ('A','B','C'):
            lo,hi=w['spans'][part+'_'+ph];mu=np.zeros(hi-lo)
            for k,v in w['truth_for_audit']['roles'][ph].items():mu+=v*ft[lo:hi,idx[ast.literal_eval(k)]]
            if ph=='C':
                z=tuple(w['truth_for_audit']['extra_vars']);ww=float(w['truth_for_audit']['extra_weight'])
                if w['truth_for_audit']['extra_kind']=='threshold':mu+=ww*(2*(x[lo:hi,list(z)].sum(axis=1)>=3)-1)
                else:mu+=ww*np.prod(2*x[lo:hi,list(z)]-1,axis=1)
            # Check each witnessed and withheld consequence agrees with disclosed structure + noise.
            assert np.all(np.abs(mu-y[lo:hi])<1.0)
            checks+=hi-lo
    snaps=[];starts=list(range(0,n-64+1,16))
    if starts[-1]!=n-64:starts.append(n-64)
    for start in starts:
        m=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(ft[start:start+64],y[start:start+64]);c=np.asarray(m.coef_)
        snaps.append({'coef':c,'intercept':float(m.intercept_),'support':np.flatnonzero(abs(c)>1e-9).tolist(),'start':start})
    ck=fit['checkpoint'];assert ck['observations_seen']==n and ck['terms']==[list(z) for z in TERMS];assert len(snaps)==len(ck['snapshots'])
    for a,b in zip(snaps,ck['snapshots']):
        assert np.allclose(a['coef'],b['coef'],atol=1e-10,rtol=1e-10)
        assert abs(a['intercept']-b['intercept'])<1e-10 and a['support']==b['support'] and a['start']==b['start']
        checks+=len(a['coef'])+3
    ss=np.asarray([pred(m['coef'],m['intercept'],DESIGN) for m in snaps])
    raw_labels=KMeans(n_clusters=3,n_init=10,random_state=173,algorithm='lloyd').fit_predict(ss)
    order=sorted(range(3),key=lambda k:int(np.flatnonzero(raw_labels==k)[0]))
    labels=np.asarray([order.index(int(z)) for z in raw_labels])
    assert labels.tolist()==ck['cluster_labels'];checks+=len(labels)
    prototypes=[]
    for k in range(3):
        group=[snaps[i] for i in range(len(snaps)) if labels[i]==k]
        c=np.mean([z['coef'] for z in group],axis=0);inter=float(np.mean([z['intercept'] for z in group]))
        cp=ck['prototypes'][k]
        assert cp['count']==len(group) and np.allclose(cp['coef'],c,rtol=1e-10,atol=1e-10) and abs(cp['intercept']-inter)<1e-10
        prototypes.append((c,inter));checks+=len(c)+2
    T=np.ones((3,3),float)
    for a,b in zip(labels[:-1],labels[1:]):T[a,b]+=1
    T/=T.sum(axis=1,keepdims=True)
    assert np.allclose(T,ck['transition'],atol=1e-12);checks+=9
    serial=json.dumps(ck,sort_keys=True,separators=(',',':'));assert hashlib.sha256(serial.encode()).hexdigest()==fit['checkpoint_sha256'];checks+=1
    prior_post=None
    for ph in ('A','B','C'):
        p=slice(*w['spans']['probe_'+ph]);h=slice(*w['spans']['held_'+ph]);px=x[p];py=y[p];hx=x[h]
        sp=np.stack([pred(m['coef'],m['intercept'],px) for m in snaps]);hp=np.stack([pred(m['coef'],m['intercept'],hx) for m in snaps]);
        lp=np.stack([pred(c,inter,px) for c,inter in prototypes]);lh=np.stack([pred(c,inter,hx) for c,inter in prototypes]);
        ls=np.mean((sp-py)**2,axis=1);lc=np.mean((lp-py)**2,axis=1)
        rw=soft(ls);uw=soft(lc)
        prior=(np.ones(3)/3 if prior_post is None else .2*(np.ones(3)/3)+.8*(prior_post@T))
        sw=soft(lc,prior);prior_post=sw.copy()
        d=fit['choices'][ph]
        for label,z in [('snap_losses',ls),('proto_losses',lc),('raw_weights',rw),('prototype_weights',uw),('state_prior',prior),('state_posterior',sw)]:
            assert np.allclose(d[label],z,atol=1e-12,rtol=1e-12),(label,ph)
            checks+=len(z)
        actual={
          'state_filter':sw@lh,'prototype_softmax':uw@lh,'softmax_memory':rw@hp,
          'best_snapshot':hp[int(np.argmin(ls))],'last_snapshot':hp[-1],
          'random_snapshot':hp[(w['seed']+w['world_id']+FAMILIES.index(w['family']))%len(hp)],
          'shuffled_probes':hp[int(np.argmin(np.mean((sp-py[::-1])**2,axis=1)))]
        }
        fullx=np.vstack((x[:n],px));fully=np.r_[y[:n],py]
        m=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=3500,tol=.0001).fit(ftr(fullx),fully)
        actual['pooled_elasticnet']=m.predict(ftr(hx))
        m=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=3500,tol=.0001).fit(ftr(np.vstack((x[n-80:n],px))),np.r_[y[n-80:n],py])
        actual['recent_elasticnet']=m.predict(ftr(hx))
        m=KernelRidge(alpha=.20,kernel='rbf',gamma=.20).fit(fullx,fully);actual['pooled_krr']=m.predict(hx)
        for arm in ARMS:
            observed=np.asarray(fit['predictions'][arm][ph],float)
            assert np.allclose(observed,actual[arm],rtol=1e-10,atol=1e-10),(arm,ph,w['seed'],w['world_id'],w['family'])
            mse=float(np.mean((observed-y[h])**2));assert np.isclose(mse,fit['metrics'][arm][ph],atol=1e-12,rtol=1e-12)
            checks+=len(observed)+1
    return checks

def audit(data):
    r=json.loads(Path(data).read_text());cases=r['cases'];assert r['experiment']=='ENERGY-60' and len(cases)==len(r['seeds'])*len(r['families'])*len(r['world_ids'])
    checks=0
    for c in cases:checks+=independently_refit(c)
    for a in ARMS:
        for ph in ('A','B','C'):
            v=np.mean([c['fit']['metrics'][a][ph] for c in cases]);assert np.isclose(v,r['aggregate'][a][ph],atol=1e-12);checks+=1
        assert np.isclose(np.mean(list(r['aggregate'][a].values())),r['pooled'][a],atol=1e-12);checks+=1
    for s in r['seeds']:
        for a in ARMS:
            v=np.mean([c['fit']['metrics'][a][ph] for c in cases if c['world']['seed']==s for ph in ('A','B','C')]);assert np.isclose(v,r['by_seed'][str(s)][a],atol=1e-12);checks+=1
    for f in r['families']:
        for a in ARMS:
            v=np.mean([c['fit']['metrics'][a][ph] for c in cases if c['world']['family']==f for ph in ('A','B','C')]);assert np.isclose(v,r['by_family'][f][a],atol=1e-12);checks+=1
    return {'status':'PASS','checks':checks,'worlds':len(cases),'scorer_imported':False,
            'limitations':'Shares numpy/sklearn fitting and scorer-provided world truth; not independently regenerated sensor noise or native scientific qualification.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scored');p.add_argument('--out',required=True);a=p.parse_args();v=audit(a.scored);Path(a.out).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps(v))
