#!/usr/bin/env python3
"""Independent read-only ENERGY-42 source reconstruction, estimator refits, solver audit.
No imports from experiment.py; SciPy/sklearn/NumPy remain common libraries.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from sklearn.linear_model import LogisticRegression

VERSION='energy42-v1'; FAMS=('erdos','modular','lattice'); ARMS=('structured_energy','bayes','logistic','uniform','shuffled_energy','oracle')
NOISE=(0.06,0.16,0.44)
COUNTS=8,24,40

def h(*keys):
    return hashlib.sha256('/'.join(map(str,(VERSION,*keys))).encode('ascii')).digest()

def integer(*keys):return int.from_bytes(h(*keys)[:8],'big')

def rng(*keys):return np.random.default_rng(integer(*keys))

def grp(a,b,n):
    span=min(b-a,n-(b-a))
    if span==1:return 0
    return 1 if span in (2,3,4) else 2

def synth(seed,mode,family,n,wid):
    pairs={tuple(sorted((k,(k+1)%n))) for k in range(n)}
    candidate=[]
    for a in range(n):
        for b in range(a+1,n):
            if (a,b) in pairs:continue
            if family=='erdos':typ=0
            elif family=='modular':typ=int(a//8!=b//8)
            elif family=='lattice':typ=int(min(b-a,n-b+a)>4)
            else:raise AssertionError('unknown family')
            candidate.append((typ,h('rank',seed,mode,family,n,wid,a,b),a,b))
    candidate.sort()
    pairs.update((a,b) for _,_,a,b in candidate[:2*n])
    x=rng('truth',seed,mode,family,n,wid).integers(0,2,size=n,dtype=np.int8).tolist()
    x[0]=0
    observed=[]
    for a,b in sorted(pairs):
        g=grp(a,b,n)
        corrupt=integer('noise',seed,mode,family,n,wid,a,b)%1000000<int(NOISE[g]*1000000)
        observed.append([a,b,x[a]^x[b]^int(corrupt),g])
    assert len(observed)==3*n
    return observed,x

def means(case_list,shuffle=False):
    good=np.zeros(3);bad=np.zeros(3)
    for c in case_list:
        labels=[edge[3] for edge in c['edges']]
        if shuffle:
            rng('group-shuffle',c['seed'],c['family'],c['n'],c['world']).shuffle(labels)
        x=c['truth']
        for edge,g in zip(c['edges'],labels):
            a,b,y,_=edge
            if (x[a]^x[b])==y:good[g]+=1
            else:bad[g]+=1
    return good,bad

def clamp(w):
    v=np.clip(np.array(w,dtype=float),0.05,8.0)
    return np.round(3*v/v.sum(),10)

def learn(cases,arm):
    if arm=='oracle':return clamp(np.log((1-np.array(NOISE))/np.array(NOISE)))
    if arm=='uniform':return clamp([1.,1.,1.])
    if arm=='bayes':
        g,b=means(cases)
        return clamp(np.log((g+1)/(b+1)))
    if arm=='logistic':
        g,b=means(cases)
        X=np.repeat(np.eye(3),(g+b).astype(int),axis=0)
        label=np.concatenate([np.r_[np.ones(int(a)),np.zeros(int(z))] for a,z in zip(g,b)])
        clf=LogisticRegression(fit_intercept=False,C=1,max_iter=1000,tol=1e-9,solver='lbfgs')
        clf.fit(X,label)
        return clamp(clf.coef_[0])
    assert arm in ('structured_energy','shuffled_energy')
    d=[]
    for c in cases:
        labels=[e[3] for e in c['edges']]
        if arm=='shuffled_energy':rng('group-shuffle',c['seed'],c['family'],c['n'],c['world']).shuffle(labels)
        for k in range(c['n']):
            delta=np.zeros(3)
            for edge,g in zip(c['edges'],labels):
                a,b,y,_=edge
                if a!=k and b!=k:continue
                delta[g]+=1 if (c['truth'][a]^c['truth'][b])==y else -1
            d.append(delta)
    d=np.array(d)
    w=np.ones(3)
    for epoch in range(96):
        violated=d@w<2.0
        avg=np.mean(d[violated],axis=0) if np.any(violated) else np.zeros(3)
        w=clamp(np.clip(w+0.06*(avg-0.01*(w-1)),0.05,8))
    return w

def inference(edges,n,weights,seed,family,world,mode):
    rand=rng('inference',seed,mode,family,n,world)
    state=rand.choice(np.array([-1,1],dtype=np.int8),size=(8,n)).astype(np.int32)
    jmat=np.zeros((n,n),dtype=float)
    for a,b,desired,g in edges:
        jmat[a,b]=jmat[b,a]=float(weights[g])*(1-2*desired)
    def costs():
        values=np.zeros(8)
        for a,b,desired,g in edges:
            values+=float(weights[g])*(((state[:,a]<0)^(state[:,b]<0))!=bool(desired))
        return values
    values=costs();pos=int(values.argmin());best=float(values[pos]);record=(state[pos]<0).astype(np.int8).tobytes().hex()
    for sweep in range(24):
        for bit in rand.permutation(n):
            gradient=state[:,bit]*(state@jmat[:,bit])
            selection=gradient<-1e-10
            state[selection,bit]*=-1
            values[selection]+=gradient[selection]
            best_i=int(values.argmin())
            if float(values[best_i])<best-1e-8:
                best=float(values[best_i]);record=(state[best_i]<0).astype(np.int8).tobytes().hex()
        if (sweep+1)%8==0 and sweep<23:
            for k in range(8):
                chosen=rand.choice(n,size=max(1,n//10),replace=False)
                state[k,chosen]*=-1
            values=costs()
    return record,best

def audit(data):
    errors=[];checks=0;seeds=data['seeds'];smoke=data['mode']=='smoke'
    assert seeds==([99773] if smoke else [8501,8521,8537])
    assert len(data['cohorts'])==len(seeds)
    for co in data['cohorts']:
        seed=co['seed'];assert seed in seeds
        cases=co['train'];test=co['test'];assert len(cases)==16 and len(test)==16
        train_ids={(x['family'],x['n'],x['world']) for x in cases}
        assert len(train_ids)==16
        for train in cases:
            a,x=synth(seed,'train',train['family'],train['n'],train['world'])
            assert train['family'] in ('erdos','modular') and train['n']==20
            assert a==train['edges'] and x==train['truth'];checks+=len(a)+train['n']
            # First-principles signed-contrastive invariant: V(flipped)-V(true).
            for toggled in range(train['n']):
                for group in range(3):
                    source_delta=0;direct_delta=0
                    for edge in a:
                        i,j,obs,g=edge
                        if g!=group or toggled not in (i,j):continue
                        before=int((x[i]^x[j])!=obs)
                        flipped=x.copy();flipped[toggled]^=1
                        after=int((flipped[i]^flipped[j])!=obs)
                        direct_delta+=after-before
                        source_delta+=(1 if (x[i]^x[j])==obs else -1)
                    assert source_delta==direct_delta,('signed-gradient invariant',seed,train['family'],train['world'],toggled,group)
                    checks+=1
        weights={arm:learn(cases,arm) for arm in ARMS}
        for arm in ARMS:
            assert np.allclose(weights[arm],co['weights'][arm],atol=1e-9,rtol=0)
            checks+=3
        seen=set()
        for test_case in test:
            key=(test_case['mode'],test_case['family'],test_case['n'],test_case['world'])
            assert key not in seen;seen.add(key)
            mode,family,n,wid=key
            assert (mode=='old' and n==20 and family in ('erdos','modular')) or (mode=='novel' and n in (36,52) and family in FAMS)
            edges,latent=synth(seed,mode,family,n,wid)
            assert edges==test_case['edges'] and bytes(latent).hex()==test_case['truth_hex'];checks+=len(edges)+n
            already={(a,b) for a,b,_,_ in edges}
            pool=sorted((h('probe',seed,mode,family,n,wid,a,b),a,b) for a in range(n) for b in range(a+1,n) if (a,b) not in already)
            probes=[[a,b] for _,a,b in pool[:40]]
            assert probes==test_case['probe_pairs'] and len(set(map(tuple,probes)))==40
            checks+=len(probes)
            for arm in ARMS:
                output=test_case['arms'][arm]
                bits=bytes.fromhex(output['bits_hex']);assert len(bits)==n
                value=sum(float(weights[arm][g]) for a,b,y,g in edges if (bits[a]^bits[b])!=y)
                assert abs(value-output['weighted_energy'])<1e-6
                hits=sum((bits[a]^bits[b])==(latent[a]^latent[b]) for a,b in probes)
                assert hits==output['correct'];checks+=len(probes)+len(edges)
                rebuilt,ref_value=inference(edges,n,weights[arm],seed,family,wid,mode)
                assert rebuilt==output['bits_hex'],('prediction mismatch',seed,mode,family,n,wid,arm)
                assert abs(ref_value-output['weighted_energy'])<1e-6
                checks+=n
        assert len(seen)==16
    if not smoke:
        scores={arm:{'old_correct':0,'novel_correct':0,'lattice_correct':0,'n52_correct':0} for arm in ARMS}
        per_seed=[]
        for co in data['cohorts']:
            per={arm:0 for arm in ARMS}
            for case in co['test']:
                for arm in ARMS:
                    k='old_correct' if case['mode']=='old' else 'novel_correct'
                    hits=case['arms'][arm]['correct'];scores[arm][k]+=hits
                    if case['mode']=='novel':
                        per[arm]+=hits
                        if case['family']=='lattice':scores[arm]['lattice_correct']+=hits
                        if case['n']==52:scores[arm]['n52_correct']+=hits
                    checks+=1
            per_seed.append({'seed':co['seed'],'novel_correct':per})
        for arm in ARMS:
            for k,v in scores[arm].items():assert v==data['summary']['scores'][arm][k];checks+=1
        assert per_seed==data['summary']['per_seed']
        c=data['summary']['scores']['structured_energy'];baseline=data['summary']['scores'];den=data['summary']['denominators'];g=data['summary']['gates']
        matched=('bayes','logistic','uniform','shuffled_energy')
        best_n=max(baseline[a]['novel_correct'] for a in matched);best_o=max(baseline[a]['old_correct'] for a in matched)
        margins=[per['novel_correct']['structured_energy']-max(per['novel_correct'][a] for a in matched) for per in per_seed]
        calc={
          'novel_vs_best_information_matched_2pp':(c['novel_correct']-best_n)/den['novel']>=.02,
          'novel_vs_uniform_3pp':(c['novel_correct']-baseline['uniform']['novel_correct'])/den['novel']>=.03,
          'old_retention_at_most_1pp_loss':(best_o-c['old_correct'])/den['old']<=.01,
          'group_shuffled_negative_5pp':(c['novel_correct']-baseline['shuffled_energy']['novel_correct'])/den['novel']>=.05,
          'unseen_family_vs_bayes_1pp':(c['lattice_correct']-baseline['bayes']['lattice_correct'])/den['lattice']>=.01,
          'n52_vs_bayes_1pp':(c['n52_correct']-baseline['bayes']['n52_correct'])/den['n52']>=.01,
          'seed_stability_two_of_three':sum(x>0 for x in margins)>=2,
          'end_to_end_value_per_second_1point2x_bayes':c['novel_correct']/data['summary']['policy_generation_fit_inference_s']['structured_energy']>=1.2*baseline['bayes']['novel_correct']/data['summary']['policy_generation_fit_inference_s']['bayes']
        }
        assert calc==g and margins==data['summary']['seed_novel_margins_vs_strongest']
        assert data['summary']['classification']==('DEVELOPMENT_GO' if all(calc.values()) else 'DEVELOPMENT_NO_GO')
        checks+=len(calc)+len(margins)
    assert data['scientific_pass'] is False and data['native_model_changed'] is False and data['deployment']=='NONE'
    return {'schema':'yggdrasil.energy42.audit.v1','status':'PASS','checks':checks,
            'worlds_rebuilt':len(seeds)*32,'training_graphs_rebuilt':len(seeds)*16,
            'evaluation_graphs_rebuilt':len(seeds)*16,'all_arms_independently_refit':True,
            'all_arms_inference_replayed':True,'held_relations_independently_checked':True,
            'sklearn_third_party_solver_shared':True,'native_qualification':'NOT RUN'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--out',required=True)
    a=p.parse_args();data=json.loads(Path(a.input).read_text());r=audit(data)
    Path(a.out).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps(r,indent=2,sort_keys=True))
