# ENERGY-04–ENERGY-18 Original Evidence Bundle

This ZIP contains 15 unchanged original ENERGY experiment evidence packages, under `original-zips/`. Each embedded ZIP has its own per-file code, scoring, test and audit records as originally saved. `MANIFEST.json` provides their exact SHA-256 and byte lengths.

ENERGY-01 remains in Yggdrasil draft PR #1201; original ENERGY-02/03 packages were not recovered. Do not misrepresent this bundle as complete ENERGY-01–18 evidence. The results are isolated research and do NOT qualify native Yggdrasil science or code.

To verify: extract the bundle; check each `original-zips/*.zip` SHA-256 against `MANIFEST.json`; run `zipfile.ZipFile(path).testzip()` on each.
