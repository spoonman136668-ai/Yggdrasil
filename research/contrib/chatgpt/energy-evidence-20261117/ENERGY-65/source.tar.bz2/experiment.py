"""ENERGY-65 external synthetic causal-factor experiment, source freeze v1.
No native Yggdrasil code, owner loop, training state or external inputs.
"""
import argparse, hashlib, itertools, json, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
from sklearn.model_selection import KFold

PAIR = tuple(itertools.combinations(range(8),2))
QUAD = tuple(itertools.combinations(range(8),4))
ALL = PAIR+QUAD
ARMS=("factor_residual_quad","same_support_elasticnet","full_bank_elasticnet","full_bank_omp4","full_bank_ridge","softmax_old_fresh","old_support_no_quad","old_frozen","shuffled_new","oracle_basis")
FAMILIES=("single_new_quad","double_new_quad","novel_fifth")
SPLITS=(("train_old",60),("train_new",40),("held_old",36),("held_new",36),("held_cold",36))

def features(x, supports=ALL):
    arr=np.asarray(x,dtype=np.float64)
    return np.column_stack([np.prod(arr[:,s],axis=1) for s in supports])

def cv_elastic(x,y):
    # Fixed train-only CV. Exactly the same CV algorithm for matched/full banks.
    folds=KFold(3,shuffle=True,random_state=65019)
    best=None
    for alpha in (.005,.025,.08):
        errors=[]
        for a,b in folds.split(x):
            m=ElasticNet(alpha=alpha,l1_ratio=.85,max_iter=5000,tol=1.e-6,selection="cyclic").fit(x[a],y[a])
            errors.append(float(np.mean((m.predict(x[b])-y[b])**2)))
        key=(float(np.mean(errors)),alpha)
        if best is None or key<best:best=key
    model=ElasticNet(alpha=best[1],l1_ratio=.85,max_iter=5000,tol=1.e-6,selection="cyclic").fit(x,y)
    return model,{"alpha":best[1],"cv_mse":best[0]}

def world(seed,family_id,world_id):
    rng=np.random.default_rng(np.random.SeedSequence([seed,658,family_id,world_id]))
    actionids=rng.permutation(256)[:208]
    bits=np.stack([2*((actionids >> k)&1)-1 for k in range(8)],axis=1).astype(float)
    pairorder=rng.permutation(8)[:6]
    supports=[tuple(sorted([int(pairorder[k]),int(pairorder[k+1])])) for k in (0,2,4)]
    coeff_old=np.asarray([rng.choice([-1,1])*rng.uniform(.9,1.4) for _ in range(3)],dtype=float)
    coeff_new=coeff_old+rng.normal(0,.14,size=3)
    chosen=rng.permutation(len(QUAD))
    q1,q2=QUAD[int(chosen[0])],QUAD[int(chosen[1])]
    chosen_five=tuple(sorted(int(t) for t in rng.permutation(8)[:5]))
    is_new=[]
    for split,n in SPLITS:is_new += [split not in ("train_old","held_old")]*n
    def truth(x,stage):
        base=np.zeros(len(x))
        for s,c in zip(supports,coeff_new if stage else coeff_old):base+=c*np.prod(x[:,s],axis=1)
        if stage:
            if family_id==0:base+=1.65*np.prod(x[:,q1],axis=1)
            elif family_id==1:base+=1.10*np.prod(x[:,q1],axis=1)+1.10*np.prod(x[:,q2],axis=1)
            else:base+=1.65*np.prod(x[:,chosen_five],axis=1)
        return base
    y=np.asarray([truth(bits[k:k+1],stage)[0] for k,stage in enumerate(is_new)],dtype=float)
    noise=rng.normal(0,.18,size=len(y));y+=noise
    partitions={};offset=0
    for split,n in SPLITS:
        partitions[split]={"action_ids":actionids[offset:offset+n].tolist(),"x":bits[offset:offset+n].tolist(),"y":y[offset:offset+n].tolist(),"noise":noise[offset:offset+n].tolist()}
        offset+=n
    return {"seed":seed,"family":FAMILIES[family_id],"family_id":family_id,"world_id":world_id,
        "truth":{"pair_supports":supports,"old_coefficients":coeff_old.tolist(),"new_coefficients":coeff_new.tolist(),"quad1":q1,"quad2":q2,"five":chosen_five,"novel_effect":[1.65,1.10,1.65][family_id],"generator":"synthetic ENERGY-65 v1"},"splits":partitions}

def run_case(case):
    parts=case["splits"]
    oo=np.asarray(parts["train_old"]["x"]);yo=np.asarray(parts["train_old"]["y"])
    xn=np.asarray(parts["train_new"]["x"]);yn=np.asarray(parts["train_new"]["y"])
    ho=np.asarray(parts["held_old"]["x"]);hn=np.asarray(parts["held_new"]["x"]);hc=np.asarray(parts["held_cold"]["x"])
    true={split:np.asarray(parts[split]["y"]) for split in ("held_old","held_new","held_cold")}
    old=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True).fit(features(oo,PAIR),yo)
    old_supports=[PAIR[i] for i in np.flatnonzero(abs(old.coef_)>1.e-9)]
    # old readout is copied immutable into each candidate checkpoint.
    old_pred=old.predict(features(ho,PAIR))
    ol=old.predict(features(xn,PAIR));on=old.predict(features(hn,PAIR));oc=old.predict(features(hc,PAIR))
    xbase=features(xn,old_supports);qbase=features(xn,QUAD)
    residual=yn-Ridge(alpha=.1).fit(xbase,yn).predict(xbase)
    # Residualized novel factor search: orthogonalize every candidate against old supports.
    xm=np.column_stack([np.ones(len(xbase)),xbase])
    qorth=qbase-xm@np.linalg.lstsq(xm,qbase,rcond=None)[0]
    scores=abs(qorth.T@residual)/(np.linalg.norm(qorth,axis=0)+1.e-12)
    selected=int(np.argmax(scores));new_supports=old_supports+[QUAD[selected]]
    cand=Ridge(alpha=.1).fit(features(xn,new_supports),yn)
    matched,matched_cv=cv_elastic(features(xn,new_supports[:-1]+list(QUAD)),yn)
    all_bank,all_cv=cv_elastic(features(xn),yn)
    omp=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(features(xn),yn)
    ridge=Ridge(alpha=1.).fit(features(xn),yn)
    fresh_omp=omp.predict(features(xn))
    score_old=float(np.mean((ol-yn)**2));score_new=float(np.mean((fresh_omp-yn)**2))
    # All softmax weights based on witnessed NEW labels only.
    logits=np.array([-score_old/.4,-score_new/.4]);w=np.exp(logits-logits.max());w/=w.sum()
    rng=np.random.default_rng(np.random.SeedSequence([case["seed"],658,99,case["family_id"],case["world_id"]]))
    shuffled=Ridge(alpha=.1).fit(features(xn,new_supports),rng.permutation(yn))
    oracle_features=[tuple(t) for t in case["truth"]["pair_supports"]]
    if case["family"]=="single_new_quad":oracle_features+=[case["truth"]["quad1"]]
    elif case["family"]=="double_new_quad":oracle_features+=[case["truth"]["quad1"],case["truth"]["quad2"]]
    else:oracle_features+=[case["truth"]["five"]]
    oracle=Ridge(alpha=.1).fit(features(xn,oracle_features),yn)
    def predictions(x,stage):
        if stage=="old":return {a:old_pred.tolist() for a in ARMS}
        bank=features(x)
        return {
            "factor_residual_quad":cand.predict(features(x,new_supports)).tolist(),
            "same_support_elasticnet":matched.predict(features(x,new_supports[:-1]+list(QUAD))).tolist(),
            "full_bank_elasticnet":all_bank.predict(bank).tolist(),
            "full_bank_omp4":omp.predict(bank).tolist(),
            "full_bank_ridge":ridge.predict(bank).tolist(),
            "softmax_old_fresh":(w[0]*old.predict(features(x,PAIR))+w[1]*omp.predict(bank)).tolist(),
            "old_support_no_quad":Ridge(alpha=.1).fit(xbase,yn).predict(features(x,old_supports)).tolist(),
            "old_frozen":old.predict(features(x,PAIR)).tolist(),
            "shuffled_new":shuffled.predict(features(x,new_supports)).tolist(),
            "oracle_basis":oracle.predict(features(x,oracle_features)).tolist(),
        }
    pred_old=predictions(ho,"old");pred_new=predictions(hn,"new");pred_cold=predictions(hc,"cold")
    pred={a:{"old":pred_old[a],"new":pred_new[a],"cold":pred_cold[a]} for a in ARMS}
    mse={a:{s:float(np.mean((np.asarray(pred[a][s])-true["held_"+s])**2)) for s in ("old","new","cold")} for a in ARMS}
    case.update({"models":{"old_pair_supports":old_supports,"discovered_quad":QUAD[selected],"cv_matched":matched_cv,"cv_full":all_cv,"softmax_weights":w.tolist(),"old_frozen_prediction_hash":hashlib.sha256(np.asarray(old_pred).tobytes()).hexdigest()},"predictions":pred,"mse":mse})
    return case

def summarize(cases):
    means={a:{s:float(np.mean([c["mse"][a][s] for c in cases])) for s in ("old","new","cold")} for a in ARMS}
    cand=means["factor_residual_quad"]["cold"]
    regular=("same_support_elasticnet","full_bank_elasticnet","full_bank_omp4","full_bank_ridge","softmax_old_fresh")
    best=min(means[a]["cold"] for a in regular)
    by_seed={str(seed):{a:float(np.mean([c["mse"][a]["cold"] for c in cases if c["seed"]==seed])) for a in ARMS} for seed in sorted(set(c["seed"] for c in cases))}
    by_family={fam:{a:float(np.mean([c["mse"][a]["cold"] for c in cases if c["family"]==fam])) for a in ARMS} for fam in FAMILIES}
    gates={
        "cold_gain5_vs_best_strong_control":cand<=.95*best,
        "cold_gain5_vs_full_elasticnet":cand<=.95*means["full_bank_elasticnet"]["cold"],
        "cold_gain5_vs_matched_elasticnet":cand<=.95*means["same_support_elasticnet"]["cold"],
        "each_seed_better_than_best_other":all(by_seed[k]["factor_residual_quad"]<min(by_seed[k][a] for a in regular) for k in by_seed),
        "each_family_nondegradation10pct":all(by_family[k]["factor_residual_quad"]<=1.1*min(by_family[k][a] for a in regular) for k in by_family),
        "old_retention_exact":all(np.array_equal(np.asarray(c["predictions"][a]["old"]),np.asarray(c["predictions"]["old_frozen"]["old"])) for c in cases for a in ARMS),
        "novel_quad_recovered_60pct":sum(tuple(c["models"]["discovered_quad"])==tuple(c["truth"]["quad1"]) for c in cases if c["family"]=="single_new_quad")>=.6*sum(c["family"]=="single_new_quad" for c in cases),
        "shuffled_negative20pct":cand<=.8*means["shuffled_new"]["cold"],
        "over_old_frozen20pct":cand<=.8*means["old_frozen"]["cold"],
    }
    required=("cold_gain5_vs_best_strong_control","cold_gain5_vs_full_elasticnet","cold_gain5_vs_matched_elasticnet","each_seed_better_than_best_other")
    classification="SCREEN_PROMISING" if all(gates[k] for k in required) and sum(gates.values())>=8 else "SCREEN_NO_GO"
    return {"means":means,"by_seed":by_seed,"by_family":by_family,"gates":gates,"passed":sum(gates.values()),"total_gates":len(gates),"classification":classification,"best_strong_control_mse":best}

def main():
    p=argparse.ArgumentParser();p.add_argument("--seeds",type=int,nargs="+",required=True);p.add_argument("--ids",type=int,nargs="+",default=[0,1,2,3]);p.add_argument("--out",required=True);args=p.parse_args()
    start=time.perf_counter();cases=[run_case(world(seed,fam,wid)) for seed in args.seeds for fam in range(3) for wid in args.ids]
    obj={"experiment":"ENERGY-65","source":"frozen-v1","seeds":args.seeds,"world_ids":args.ids,"cases":cases,"aggregate":summarize(cases),"elapsed_seconds":time.perf_counter()-start}
    Path(args.out).write_text(json.dumps(obj,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps({"file":args.out,"worlds":len(cases),"classification":obj["aggregate"]["classification"],"gates":obj["aggregate"]["gates"],"cold":{k:v["cold"] for k,v in obj["aggregate"]["means"].items()},"elapsed_seconds":obj["elapsed_seconds"]},indent=2))
if __name__=="__main__":main()
