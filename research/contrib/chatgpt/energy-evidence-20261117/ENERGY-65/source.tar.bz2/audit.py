"""Separate original-source ENERGY-65 audit; no importing experiment.py.
Independent reconstruction of original labels/feature supports and all fitted arms.
Shares NumPy and sklearn solvers, therefore not independent scientific replication.
"""
import argparse, json, itertools, hashlib
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
from sklearn.model_selection import KFold

PAIRS=tuple(itertools.combinations(range(8),2));QUADS=tuple(itertools.combinations(range(8),4));BANK=PAIRS+QUADS
ARMS=("factor_residual_quad","same_support_elasticnet","full_bank_elasticnet","full_bank_omp4","full_bank_ridge","softmax_old_fresh","old_support_no_quad","old_frozen","shuffled_new","oracle_basis")

def design(x,terms):
    x=np.asarray(x,dtype=float)
    return np.asarray([[float(np.prod(row[list(t)])) for t in terms] for row in x])

def train_en(X,y):
    cv=KFold(n_splits=3,shuffle=True,random_state=65019)
    opt=(float('inf'),float('inf'))
    for alpha in (.005,.025,.08):
        losses=[]
        for a,b in cv.split(X):
            mod=ElasticNet(alpha=alpha,l1_ratio=.85,max_iter=5000,tol=1.e-6,selection="cyclic").fit(X[a],y[a]);losses.append(float(np.mean((mod.predict(X[b])-y[b])**2)))
        opt=min(opt,(float(np.mean(losses)),alpha))
    return ElasticNet(alpha=opt[1],l1_ratio=.85,max_iter=5000,tol=1.e-6,selection="cyclic").fit(X,y),{"alpha":opt[1],"cv_mse":opt[0]}

def audit_case(r):
    checks=0; tol=1e-8; sp=r['splits'];truth=r['truth'];fam=r['family'];models=r['models'];pr=r['predictions']
    ids=[i for name in ('train_old','train_new','held_old','held_new','held_cold') for i in sp[name]['action_ids']]
    assert len(ids)==len(set(ids))==208;checks+=209
    oldterms=[tuple(t) for t in truth['pair_supports']]
    assert len(oldterms)==3; checks+=1
    for name,stage in [('train_old',False),('held_old',False),('train_new',True),('held_new',True),('held_cold',True)]:
        block=sp[name];X=np.asarray(block['x']);Y=np.asarray(block['y']);N=np.asarray(block['noise'])
        assert len(X)==len(Y)==len(N)==len(block['action_ids']);checks+=1
        for row,id_ in zip(X,block['action_ids']):
            assert np.array_equal(row,np.asarray([2*((id_>>k)&1)-1 for k in range(8)]));checks+=1
        fit=np.zeros(len(X))
        for term,coef in zip(oldterms,truth['new_coefficients'] if stage else truth['old_coefficients']):fit+=float(coef)*design(X,[term])[:,0]
        if stage:
            if fam=='single_new_quad':fit+=1.65*design(X,[truth['quad1']])[:,0]
            elif fam=='double_new_quad':fit+=1.1*design(X,[truth['quad1']])[:,0]+1.1*design(X,[truth['quad2']])[:,0]
            else:fit+=1.65*design(X,[truth['five']])[:,0]
        assert np.allclose(fit+N,Y,rtol=0,atol=3e-14);checks+=len(Y)
    Xo=np.asarray(sp['train_old']['x']);Yo=np.asarray(sp['train_old']['y']);Xn=np.asarray(sp['train_new']['x']);Yn=np.asarray(sp['train_new']['y'])
    old=OrthogonalMatchingPursuit(n_nonzero_coefs=3,fit_intercept=True).fit(design(Xo,PAIRS),Yo)
    found=[PAIRS[k] for k in np.flatnonzero(np.abs(old.coef_)>1.e-9)]
    assert found==[tuple(t) for t in models['old_pair_supports']];checks+=3
    Xm=design(Xn,found);Q=design(Xn,QUADS)
    residual=Yn-Ridge(alpha=.1).fit(Xm,Yn).predict(Xm)
    M=np.column_stack((np.ones(len(Xm)),Xm));projection=M@np.linalg.lstsq(M,Q,rcond=None)[0]
    residual_q=Q-projection
    ranking=np.abs(residual_q.T@residual)/(np.linalg.norm(residual_q,axis=0)+1e-12)
    selected=QUADS[int(np.argmax(ranking))]; assert selected==tuple(models['discovered_quad']);checks+=1
    final_terms=found+[selected]
    fit=Ridge(alpha=.1).fit(design(Xn,final_terms),Yn)
    matched,cv1=train_en(design(Xn,found+list(QUADS)),Yn)
    full,cv2=train_en(design(Xn,BANK),Yn)
    assert np.allclose([models['cv_matched']['alpha'],models['cv_matched']['cv_mse']],[cv1['alpha'],cv1['cv_mse']],atol=tol,rtol=0);checks+=2
    assert np.allclose([models['cv_full']['alpha'],models['cv_full']['cv_mse']],[cv2['alpha'],cv2['cv_mse']],atol=tol,rtol=0);checks+=2
    omp=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(design(Xn,BANK),Yn)
    ridge=Ridge(alpha=1).fit(design(Xn,BANK),Yn)
    old_noquad=Ridge(alpha=.1).fit(design(Xn,found),Yn)
    old_new=old.predict(design(Xn,PAIRS));new_new=omp.predict(design(Xn,BANK));ss=np.array([-np.mean((old_new-Yn)**2)/.4,-np.mean((new_new-Yn)**2)/.4]);ss=np.exp(ss-ss.max());ss/=sum(ss)
    assert np.allclose(models['softmax_weights'],ss,atol=tol,rtol=0);checks+=2
    rg=np.random.default_rng(np.random.SeedSequence([r['seed'],658,99,r['family_id'],r['world_id']]))
    shuffled=Ridge(alpha=.1).fit(design(Xn,final_terms),rg.permutation(Yn))
    oracle_terms=oldterms+[tuple(truth['quad1'])] if fam=='single_new_quad' else oldterms+[tuple(truth['quad1']),tuple(truth['quad2'])] if fam=='double_new_quad' else oldterms+[tuple(truth['five'])]
    oracle=Ridge(alpha=.1).fit(design(Xn,oracle_terms),Yn)
    for name in ('held_old','held_new','held_cold'):
        stage=name.split('_')[1];XX=np.asarray(sp[name]['x']);YY=np.asarray(sp[name]['y'])
        reference=old.predict(design(XX,PAIRS))
        actual={
            'factor_residual_quad':fit.predict(design(XX,final_terms)),
            'same_support_elasticnet':matched.predict(design(XX,found+list(QUADS))),
            'full_bank_elasticnet':full.predict(design(XX,BANK)),
            'full_bank_omp4':omp.predict(design(XX,BANK)),
            'full_bank_ridge':ridge.predict(design(XX,BANK)),
            'softmax_old_fresh':ss[0]*reference+ss[1]*omp.predict(design(XX,BANK)),
            'old_support_no_quad':old_noquad.predict(design(XX,found)),
            'old_frozen':reference,
            'shuffled_new':shuffled.predict(design(XX,final_terms)),
            'oracle_basis':oracle.predict(design(XX,oracle_terms)),
        }
        for arm in ARMS:
            predictions=reference if stage=='old' else actual[arm]
            original=np.asarray(pr[arm][stage])
            assert np.allclose(predictions,original,rtol=0,atol=tol), (r['seed'],r['family'],r['world_id'],arm,stage,np.max(abs(predictions-original)))
            mse=np.mean((original-YY)**2)
            assert abs(mse-r['mse'][arm][stage])<tol
            checks+=len(original)+1
    assert hashlib.sha256(np.asarray(old.predict(design(np.asarray(sp['held_old']['x']),PAIRS))).tobytes()).hexdigest()==models['old_frozen_prediction_hash']; checks+=1
    return checks

def main():
    a=argparse.ArgumentParser();a.add_argument('source');a.add_argument('--out',required=True);args=a.parse_args();z=json.loads(Path(args.source).read_text())
    checks=0
    for c in z['cases']:checks+=audit_case(c)
    # Independently recompute aggregate MSE, without importing scorer.
    for arm in ARMS:
        for stage in ('old','new','cold'):
            got=np.mean([c['mse'][arm][stage] for c in z['cases']]);expect=z['aggregate']['means'][arm][stage]
            assert abs(got-expect)<1e-10;checks+=1
    audit={'experiment':'ENERGY-65','status':'PASS','cases':len(z['cases']),'checks':checks,'shared_dependencies':['numpy','scikit-learn'],'scorer_imported':False}
    Path(args.out).write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n')
    print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
