#!/usr/bin/env python3
"""Independent ENERGY-59 audit. Does not import experiment.py.
Reimplements model fitting/inference and validates held metrics and evidence directly.
Shares NumPy/sklearn numerical packages and experiment's disclosed world data.
"""
import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit,ElasticNet
from sklearn.kernel_ridge import KernelRidge

TERMS=tuple(c for k in (2,3) for c in itertools.combinations(range(12),k))
ARMS=('energy_consensus','best_snapshot','softmax_memory','last_snapshot','pooled_elasticnet','recent_elasticnet','pooled_krr','random_snapshot','shuffled_probes')
FAM=('return_old','return_middle','novel_composition')
def features(x):
    s=np.asarray(x,dtype=float)*2-1
    return np.stack([np.prod(s[:,list(term)],axis=1) for term in TERMS],axis=1)

def auditor(case):
    w=case['world'];fit=case['fit'];x=np.asarray(w['x'],dtype=int);y=np.asarray(w['y'],dtype=float);spans=w['spans'];n=w['stream_n'];checks=0
    assert x.shape==(sum(w['truth_only_for_evaluator']['lengths'])+3*12+3*64,12)
    keys=np.asarray(w['causal_key'],dtype=int);assert len(keys)==len(set(keys))==len(x);checks+=len(keys)
    assert np.array_equal(x[:,:9],(keys[:,None]>>np.arange(9))&1);checks+=len(keys)*9
    role=w['truth_only_for_evaluator']['roles'];
    import ast
    term_idx={z:i for i,z in enumerate(TERMS)}
    ft=features(x)
    for part in ('train','probe','held'):
      for phase in ('A','B','C'):
        lo,hi=spans[part+'_'+phase];vals=np.zeros(hi-lo)
        for pair,val in role[phase].items():
            valterm=tuple(ast.literal_eval(pair));vals+=float(val)*ft[lo:hi,term_idx[valterm]]
        # independently check all labels within 5 sigma of disclosed causal mechanism
        assert np.all(np.abs(vals-y[lo:hi])<1.0)
        checks+=hi-lo
    assert sum(w['truth_only_for_evaluator']['lengths'])==n
    # Source-free refit of every historical sparse snapshot on an unlabeled stream.
    snapshots=[]
    starts=list(range(0,n-64+1,16))
    if starts[-1]!=n-64:starts.append(n-64)
    for i in starts:
        xx=ft[i:i+64];m=OrthogonalMatchingPursuit(n_nonzero_coefs=4,fit_intercept=True).fit(xx,y[i:i+64])
        v=np.asarray(m.coef_);snapshots.append((v,float(m.intercept_),np.flatnonzero(abs(v)>1e-9).tolist()))
    ck=fit['checkpoint'];assert ck['observations_seen']==n and len(ck['snapshots'])==len(snapshots)
    assert ck['terms']==[list(t) for t in TERMS]
    for st,(coef,inter,support) in zip(ck['snapshots'],snapshots):
        assert np.allclose(st['coef'],coef,atol=1e-10,rtol=1e-10)
        assert abs(st['intercept']-inter)<1e-10
        assert st['support']==support
        checks+=len(coef)+2
    serial=json.dumps(ck,sort_keys=True,separators=(',',':'))
    assert hashlib.sha256(serial.encode()).hexdigest()==fit['checkpoint_sha256'];checks+=1
    for phase in ('A','B','C'):
        p=slice(*spans['probe_'+phase]);h=slice(*spans['held_'+phase]);pf=ft[p];hf=ft[h];py=y[p]
        probes=np.asarray([pf@v+inter for v,inter,_ in snapshots])
        query=np.asarray([hf@v+inter for v,inter,_ in snapshots])
        losses=np.mean((probes-py)**2,axis=1)
        order=np.argsort(losses,kind='stable');best,second=map(int,order[:2]);
        weights=np.exp(-np.clip((losses-losses.min())/.10,0,700));weights/=sum(weights)
        share=len(set(snapshots[best][2])&set(snapshots[second][2]))
        consensus=bool(share>=3 and losses[second]-losses[best]<.04)
        d=fit['decision'][phase]
        assert np.allclose(d['losses'],losses,atol=1e-12)
        assert d['best']==best and d['second']==second and d['shared_support_count']==share
        assert d['consensus_accepted']==consensus and np.allclose(d['softmax_weights'],weights)
        checks+=len(losses)*2+4
        expected={
          'best_snapshot':query[best],
          'last_snapshot':query[-1],
          'random_snapshot':query[(int(w['seed'])+int(w['world_id'])+FAM.index(w['family']))%len(query)],
          'softmax_memory':np.average(query,axis=0,weights=weights),
          'energy_consensus':(query[best]+query[second])/2 if consensus else query[best],
          'shuffled_probes':query[int(np.argsort(np.mean((probes-py[::-1])**2,axis=1),kind='stable')[0])]
        }
        ax=np.vstack([x[:n],x[p]]);ay=np.r_[y[:n],py]
        recent=np.vstack([x[n-80:n],x[p]]);recent_y=np.r_[y[n-80:n],py]
        for name,tx,ty in [('pooled_elasticnet',ax,ay),('recent_elasticnet',recent,recent_y)]:
            m=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=3500,tol=.0001).fit(features(tx),ty)
            expected[name]=m.predict(hf)
        kr=KernelRidge(alpha=.20,kernel='rbf',gamma=.20).fit(ax,ay)
        expected['pooled_krr']=kr.predict(x[h])
        for name in ARMS:
            actual=np.asarray(fit['predictions'][name][phase],dtype=float)
            assert np.allclose(actual,expected[name],rtol=1e-10,atol=1e-10),('bad model',name,w['seed'],phase)
            err=float(np.mean((actual-y[h])**2))
            assert np.isclose(err,fit['metrics'][name][phase],atol=1e-12,rtol=1e-12)
            checks+=len(actual)+1
    return checks

def main(scored):
    result=json.loads(Path(scored).read_text());cs=result['cases'];allchecks=0
    assert result['experiment']=='ENERGY-59' and len(cs)==len(result['seeds'])*len(result['families'])*len(result['world_ids'])
    for c in cs:allchecks+=auditor(c)
    # Independent aggregation, including seed/family strata.
    for name in ARMS:
      for ph in ('A','B','C'):
        v=np.mean([c['fit']['metrics'][name][ph] for c in cs]);assert np.isclose(v,result['aggregate'][name][ph],rtol=1e-12);allchecks+=1
      v=np.mean([result['aggregate'][name][ph] for ph in ('A','B','C')]);assert np.isclose(v,result['pooled'][name],rtol=1e-12);allchecks+=1
    for seed in result['seeds']:
      for name in ARMS:
        v=np.mean([c['fit']['metrics'][name][ph] for c in cs if c['world']['seed']==seed for ph in ('A','B','C')]);assert np.isclose(v,result['by_seed'][str(seed)][name],rtol=1e-12);allchecks+=1
    for fam in result['families']:
      for name in ARMS:
        v=np.mean([c['fit']['metrics'][name][ph] for c in cs if c['world']['family']==fam for ph in ('A','B','C')]);assert np.isclose(v,result['by_family'][fam][name],rtol=1e-12);allchecks+=1
    return {'status':'PASS','experiment':'ENERGY-59','independent_refit_checks':int(allchecks),'worlds':len(cs),'uses_experiment_import':False,'external_synthetic_only':True,'shared_dependencies':'NumPy and sklearn; generator validation from scored disclosed truth (not full independent regeneration)'}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('scored');a.add_argument('--out',required=True);args=a.parse_args();r=main(args.scored);Path(args.out).write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r))
