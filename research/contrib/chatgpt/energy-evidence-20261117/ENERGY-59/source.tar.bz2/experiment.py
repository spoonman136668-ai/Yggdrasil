#!/usr/bin/env python3
"""ENERGY-59 external synthetic unlabeled-context causal memory screen/primary.
No native Yggdrasil access. Interventions and consequences supplied, never episode IDs.
"""
import argparse, hashlib, itertools, json, time
from pathlib import Path
import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, ElasticNet, Ridge
from sklearn.kernel_ridge import KernelRidge

FAMILIES=('return_old','return_middle','novel_composition')
ARMS=('energy_consensus','best_snapshot','softmax_memory','last_snapshot','pooled_elasticnet','recent_elasticnet','pooled_krr','random_snapshot','shuffled_probes')
TERM=tuple(c for k in (2,3) for c in itertools.combinations(range(12),k))
TRAIN=76; PROBES=12; HELD=64

def feat(x):
    v=2*np.asarray(x,dtype=np.int8)-1
    return np.column_stack([np.prod(v[:,c],axis=1) for c in TERM]).astype(float)

def synth(seed,world_id,family):
    assert family in FAMILIES
    rng=np.random.default_rng(np.random.SeedSequence([5901,seed,world_id,FAMILIES.index(family)]))
    vars=rng.permutation(9)
    # Four authored but hidden causal relations; two remain invariant, two change.
    base=[tuple(sorted(vars[q:q+2].tolist())) for q in (0,2,4,6)]
    extra=[tuple(sorted(vars[[0,3,8]].tolist())),tuple(sorted(vars[[1,5,7]].tolist()))]
    assert len(set(base+extra))==6
    strengths=rng.choice([-1.,1.],6)*rng.uniform(.85,1.25,6)
    roles={
      'A':{base[0]:strengths[0],base[1]:strengths[1],base[2]:strengths[2],base[3]:strengths[3]},
      'B':{base[0]:strengths[0],base[1]:strengths[1],extra[0]:strengths[4],extra[1]:strengths[5]},
    }
    if family=='return_old': roles['C']=roles['A'].copy()
    elif family=='return_middle': roles['C']=roles['B'].copy()
    else: roles['C']={base[0]:strengths[0],base[1]:-strengths[1],base[3]:strengths[3],extra[1]:strengths[5]}
    # Randomized changepoints not supplied to learner. A/B/C lengths vary.
    lengths=rng.integers(TRAIN-12,TRAIN+13,3).tolist()
    spans={};start=0
    for tag,count in zip(('A','B','C'),lengths):spans[tag]=[start,start+count];start+=count
    # 3 probe sessions and 3 held sessions, all held intervention causal IDs disjoint.
    counts=lengths+[PROBES]*3+[HELD]*3
    n=sum(counts); keys=rng.permutation(512)[:n]
    x=((keys[:,None]>>np.arange(9))&1).astype(np.int8)
    observed=np.column_stack([x,np.zeros((n,3),dtype=np.int8)])
    origins=['A','B','C','A','B','C','A','B','C']
    slices={};start=0
    for phase,count in zip(origins,counts):
        end=start+count;label=('train_' if start<sum(lengths) else ('probe_' if start<sum(lengths)+3*PROBES else 'held_'))+phase
        slices[label]=[start,end]
        for i in range(start,end):
            for j in range(3):
                truebit=int(x[i,int(vars[j])]);
                cue=truebit if phase=='A' else (1-truebit if phase=='B' else truebit)
                observed[i,9+j]=int(rng.integers(0,2)) if label.startswith('held_') else (cue if rng.random()>.08 else 1-cue)
        start=end
    f=feat(observed);term_idx={z:i for i,z in enumerate(TERM)}
    y=np.zeros(n)
    for part in ('train','probe','held'):
        for phase in ('A','B','C'):
            s=slice(*slices[f'{part}_{phase}']); y[s]=sum(v*f[s,term_idx[z]] for z,v in roles[phase].items())+rng.normal(0,.16,len(y[s]))
    # Learner gets stream only: x, y, chronological order (without explicit phase labels).
    stream_n=sum(lengths)
    return {'seed':seed,'world_id':world_id,'family':family,'x':observed.tolist(),'y':y.tolist(),
            'causal_key':keys.tolist(),'spans':slices,'stream_n':stream_n,
            'truth_only_for_evaluator':{'strengths':strengths.tolist(),'roles':{k:{str(t):v for t,v in value.items()} for k,value in roles.items()},'lengths':lengths}}

def model(x,y,n_nonzero=4):
    # OMP provides conventional sparse snapshot fits, no episode labels.
    f=feat(x);m=OrthogonalMatchingPursuit(n_nonzero_coefs=n_nonzero,fit_intercept=True).fit(f,np.asarray(y))
    return {'coef':np.asarray(m.coef_).tolist(),'intercept':float(m.intercept_), 'support':np.flatnonzero(np.abs(m.coef_)>1e-9).tolist()}

def infer(m,x):return feat(x)@np.asarray(m['coef'])+m['intercept']

def learn_stream(x,y):
    # One stateful learner: a single dictionary of causal hypothesis snapshots.
    # Sliding windows are independent of the generated episode boundaries.
    W=64;stride=16
    starts=list(range(0,len(y)-W+1,stride))
    if starts[-1]!=len(y)-W:starts.append(len(y)-W)
    snapshots=[]
    for st in starts:
        m=model(x[st:st+W],y[st:st+W]);m['start_index']=st;snapshots.append(m)
    return {'schema':'energy59.memory.v1','terms':[list(t) for t in TERM],'snapshots':snapshots,'observations_seen':len(y)}

def select(memory,probe_x,probe_y):
    snapshots=memory['snapshots']
    losses=np.array([np.mean((infer(m,probe_x)-probe_y)**2) for m in snapshots])
    order=np.argsort(losses,kind='stable');best=int(order[0]);second=int(order[1]);
    soft=np.exp(-np.clip((losses-min(losses))/.10,0,700));soft=soft/sum(soft)
    # Candidate: evidence-gated same-structure consensus. Blend only if the two
    # best historical snapshots support the same causal factors and are nearly tied.
    overlap=len(set(snapshots[best]['support'])&set(snapshots[second]['support']))
    accept=overlap>=3 and losses[second]-losses[best]<.04
    return {'losses':losses.tolist(),'best':best,'second':second,'softmax_weights':soft.tolist(),
            'consensus_accepted':bool(accept),'shared_support_count':overlap}

def fit_predict(world):
    allx=np.asarray(world['x'],np.int8);ally=np.asarray(world['y'],float);n=world['stream_n']
    stream_x,stream_y=allx[:n],ally[:n]
    checkpoint=learn_stream(stream_x,stream_y)
    md=json.dumps(checkpoint,sort_keys=True,separators=(',',':'))
    ckpt_hash=hashlib.sha256(md.encode()).hexdigest()
    checkpoint=json.loads(md) # exact serialization and restore; all predictions from restored memory
    pred={a:{} for a in ARMS};decisions={};t0=time.perf_counter()
    for phase in ('A','B','C'):
        p=slice(*world['spans']['probe_'+phase]);h=slice(*world['spans']['held_'+phase]);px,py=allx[p],ally[p];hx=allx[h]
        select_info=select(checkpoint,px,py)
        ss=checkpoint['snapshots'];best=select_info['best'];second=select_info['second']
        z=[infer(m,hx) for m in ss]
        pred['best_snapshot'][phase]=z[best].tolist()
        pred['last_snapshot'][phase]=z[-1].tolist()
        pred['random_snapshot'][phase]=z[(world['seed']+world['world_id']+FAMILIES.index(world['family']))%len(z)].tolist()
        pred['softmax_memory'][phase]=np.average(z,axis=0,weights=select_info['softmax_weights']).tolist()
        pred['energy_consensus'][phase]=(0.5*(z[best]+z[second]) if select_info['consensus_accepted'] else z[best]).tolist()
        neg=py[::-1].copy();bad=select(checkpoint,px,neg)
        pred['shuffled_probes'][phase]=z[bad['best']].tolist()
        # Conventional same-information fully fitted separate query controls.
        xx=np.concatenate((stream_x,px),axis=0);yy=np.concatenate((stream_y,py),axis=0)
        en=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=3500,tol=.0001).fit(feat(xx),yy)
        pred['pooled_elasticnet'][phase]=en.predict(feat(hx)).tolist()
        rx=np.concatenate((stream_x[-80:],px));ry=np.concatenate((stream_y[-80:],py))
        en2=ElasticNet(alpha=.035,l1_ratio=.85,max_iter=3500,tol=.0001).fit(feat(rx),ry)
        pred['recent_elasticnet'][phase]=en2.predict(feat(hx)).tolist()
        krr=KernelRidge(alpha=.20,kernel='rbf',gamma=.20).fit(xx,yy)
        pred['pooled_krr'][phase]=krr.predict(hx).tolist()
        decisions[phase]=select_info
    metrics={arm:{phase:float(np.mean((np.asarray(pred[arm][phase])-ally[slice(*world['spans']['held_'+phase])])**2)) for phase in ('A','B','C')} for arm in ARMS}
    # Context-retrieval checks: no phase IDs appear in the learner interface.
    return {'predictions':pred,'metrics':metrics,'decision':decisions,'checkpoint':checkpoint,
            'checkpoint_sha256':ckpt_hash,'elapsed_fit_predict_seconds':time.perf_counter()-t0}

def evaluate(seeds,ids=(0,1,2,3),families=FAMILIES):
    cases=[];t=time.perf_counter()
    for seed in seeds:
        for family in families:
            for idx in ids:
                world=synth(seed,idx,family);computed=fit_predict(world)
                cases.append({'world':world,'fit':computed})
    agg={a:{phase:float(np.mean([c['fit']['metrics'][a][phase] for c in cases])) for phase in ('A','B','C')} for a in ARMS}
    pooled={a:float(np.mean([agg[a][phase] for phase in ('A','B','C')])) for a in ARMS}
    by_seed={str(s):{a:float(np.mean([c['fit']['metrics'][a][p] for c in cases if c['world']['seed']==s for p in ('A','B','C')])) for a in ARMS} for s in seeds}
    by_family={f:{a:float(np.mean([c['fit']['metrics'][a][p] for c in cases if c['world']['family']==f for p in ('A','B','C')])) for a in ARMS} for f in families}
    return {'experiment':'ENERGY-59','generator':'E59:unlabeled-regime-memory-v1','seeds':list(seeds),'world_ids':list(ids),'families':list(families),'cases':cases,'aggregate':agg,'pooled':pooled,'by_seed':by_seed,'by_family':by_family,'elapsed_seconds':time.perf_counter()-t}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seeds',type=int,nargs='+',required=True);parser.add_argument('--ids',type=int,nargs='+',default=[0,1,2,3]);parser.add_argument('--out',required=True)
    args=parser.parse_args();r=evaluate(args.seeds,tuple(args.ids))
    Path(args.out).write_text(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps({'cases':len(r['cases']),'pooled_mse':r['pooled'],'seconds':r['elapsed_seconds']},sort_keys=True))
