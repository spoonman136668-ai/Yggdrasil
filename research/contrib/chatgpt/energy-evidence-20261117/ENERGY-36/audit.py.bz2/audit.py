#!/usr/bin/env python3
"""Independent ENERGY-36 source-world and all-arm refit audit.

Reimplements 190-feature grammar, source outcomes, observed noise, bootstrap
selectors, trained baselines, and 25 selection/learner pairs from scratch.
Does not import or call the scorer and never changes its original results.
"""
import argparse
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import time
import warnings

import numpy as np
from sklearn.linear_model import OrthogonalMatchingPursuit, Ridge, LogisticRegression
from sklearn.tree import DecisionTreeClassifier

SOURCESHA='320ffbe34409b1f9eb49219f22e0f136a933e4604480e153f3a1afaf863d7b7e'
SEEDS=(7607,7621,7643)
FAMILIES=('parity3','mixed','extended4')
POLICIES=('energy_committee','omp_committee','energy_uncertainty','paired_fixed','random')
LEARNERS=('energy','omp12','ridge','logistic','tree')
N_BOOT=6
BIT_PATTERNS=[[int(bool(k&(1<<b))) for b in range(8)] for k in range(256)]
COLUMNS=[]
for degree in (1,2,3,4): COLUMNS += [('parity',bits) for bits in combinations(range(8),degree)]
COLUMNS += [('and',bits) for bits in combinations(range(8),2)]
assert len(COLUMNS)==190

def feature(row):
    result=[]
    for kind,coords in COLUMNS:
        if kind=='parity':
            v=1
            for col in coords: v *= 2*row[col]-1
        else: v=2*(row[coords[0]]&row[coords[1]])-1
        result.append(v)
    return result

DESIGN=np.asarray([feature(row) for row in BIT_PATTERNS],dtype=float)
BITS=np.asarray(BIT_PATTERNS,dtype=int)


def sha(*a): return sha256('/'.join(str(x) for x in ('energy36-v1',*a)).encode('ascii')).digest()
def choose(*a,n):return int.from_bytes(sha(*a)[:8],'big')%n

def world(seed,w,fam):
    bydeg={d:[i for i,(kind,c) in enumerate(COLUMNS) if kind=='parity' and len(c)==d] for d in (2,3,4)}
    pairs=[i for i,(kind,c) in enumerate(COLUMNS) if kind=='and']
    pools=([bydeg[3]]*3 if fam=='parity3' else [bydeg[3],bydeg[2],pairs] if fam=='mixed' else [bydeg[4],bydeg[3],pairs])
    law=[]
    for t,bank in enumerate(pools):
        k=choose('hidden_feature',seed,w,fam,t,n=len(bank))
        while bank[k] in law:k=(k+1)%len(bank)
        law.append(bank[k])
    sign=[1 if choose('hidden_sign',seed,w,fam,t,n=2) else -1 for t in range(3)]
    oracle=np.where(sum(s*DESIGN[:,i] for s,i in zip(sign,law))>0,1,-1)
    sortedzero=sorted((x for x in range(256) if x%2==0),key=lambda x:sha('old_split',seed,w,fam,x))
    old=sortedzero[:80]
    held_old=sortedzero[80:96]
    candidates=[i+1 for i in old]
    held_new=sorted((i for i in range(256) if i%2==1 and i not in candidates),key=lambda i:sha('held_new_order',seed,w,fam,i))[:48]
    def observed(x):
        error=int.from_bytes(sha('noise',seed,w,fam,x)[:8],'big')/2**64<.1
        return int(oracle[x])*(-1 if error else 1)
    return dict(seed=seed,w=w,family=fam,old=old,candidates=candidates,held_old=held_old,held_new=held_new,
                obs=np.asarray([observed(x) for x in old],dtype=float),observed=observed,oracle=oracle)


def sparse(x,y):
    w=np.zeros(x.shape[1],dtype=float)
    for _ in range(48):
        margin=y*np.dot(x,w)
        wrong=np.flatnonzero(margin<1.0)
        if not len(wrong):break
        grad=(y[wrong,None]*x[wrong]).mean(axis=0)
        picks=np.argsort(-np.abs(grad),kind='stable')[:8]
        w[picks]+=.05*grad[picks]
        top=np.argsort(-np.abs(w),kind='stable')[:12]
        mask=np.zeros(len(w),dtype=bool);mask[top]=True
        w[~mask]=0.
    return w


def omp(x,y):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        return OrthogonalMatchingPursuit(n_nonzero_coefs=12,fit_intercept=True).fit(x,y)


def candidates_for(c,policy):
    pool=c['candidates']
    if policy=='paired_fixed':return pool[:16]
    if policy=='random':return sorted(pool,key=lambda a:sha('random_probe',c['seed'],c['w'],c['family'],a))[:16]
    design=DESIGN[c['old']];y=c['obs'];candidate_features=DESIGN[pool]
    if policy=='energy_uncertainty':
        values=np.exp(-np.abs(candidate_features@sparse(design,y)))
    else:
        binary_votes=[]
        for boot in range(N_BOOT):
            rng=np.random.default_rng(choose('bootstrap',policy,c['seed'],c['w'],c['family'],boot,n=2**32))
            draws=rng.integers(0,len(design),size=len(design))
            if policy=='energy_committee':pred=candidate_features@sparse(design[draws],y[draws])
            else:pred=omp(design[draws],y[draws]).predict(candidate_features)
            binary_votes.append((pred>0).astype(float))
        p=np.asarray(binary_votes).mean(axis=0)
        values=4*p*(1-p)
    chosen=[]
    for _ in range(16):
        scored=[]
        for pos,item in enumerate(pool):
            if item in chosen:continue
            variety=(min(sum(BIT_PATTERNS[item][bit]!=BIT_PATTERNS[old][bit] for bit in range(8)) for old in chosen)/7 if chosen else 1.)
            value=float(values[pos])+.05*variety
            scored.append((-value,sha('tie',policy,c['seed'],c['w'],c['family'],item),item))
        chosen.append(min(scored)[2])
    return chosen


def class_predictions(kind,indices,label,held):
    X=DESIGN[indices];h=DESIGN[held]
    if kind=='energy':v=h@sparse(X,label)
    elif kind=='omp12':v=omp(X,label).predict(h)
    elif kind=='ridge':v=Ridge(alpha=3.).fit(X,label).predict(h)
    elif kind=='logistic':v=LogisticRegression(C=1.,max_iter=500,tol=1e-8).fit(X,label).decision_function(h)
    elif kind=='tree':v=DecisionTreeClassifier(max_depth=8,random_state=19).fit(BITS[indices],label).predict(BITS[held])
    else:raise AssertionError('unknown predictor '+kind)
    return np.where(v>0,1,-1)


def audit(original):
    b=Path(original).read_bytes();scored=json.loads(b)
    checks=0
    def ok(p,why):
        nonlocal checks
        checks+=1
        if not p:raise AssertionError(why)
    ok(scored['mode']=='primary' and scored['schema']=='yggdrasil.energy36.score.v1','schema/mode')
    ok(scored['seeds']==list(SEEDS) and scored['cases']==72,'population')
    ok(scored['source_sha256']==SOURCESHA,'pinned source SHA')
    ok(len(scored['details'])==72,'cases present')
    observed_worlds=set();total={s:{l:{'old':0,'new':0} for l in LEARNERS} for s in POLICIES}
    negatives={s:0 for s in POLICIES}
    cost={s:{l:0. for l in LEARNERS} for s in POLICIES}
    for case in scored['details']:
        seed,ident,fam=case['seed'],case['world'],case['family']
        key=(seed,ident,fam)
        ok(seed in SEEDS and ident in range(8) and fam in FAMILIES and key not in observed_worlds,'case identity')
        observed_worlds.add(key)
        c=world(seed,ident,fam)
        ok(len(set(c['old']))==80 and len(set(c['candidates']))==80,'distinct source')
        ok(len(set(c['held_old']))==16 and len(set(c['held_new']))==48,'held counts')
        ok(not set(c['old'])&set(c['held_old']) and not set(c['candidates'])&set(c['held_new']),'no held leakage')
        held=c['held_old']+c['held_new']
        for policy in POLICIES:
            receipt=case['policies'][policy]
            probes=candidates_for(c,policy)
            ok(probes==receipt['actions'],'selected actions')
            ok(len(set(probes))==16 and set(probes).issubset(c['candidates']),'budget')
            witnessed=[c['observed'](action) for action in probes]
            ok(witnessed==receipt['selected_noisy_outcomes'],'received action consequences')
            indices=c['old']+probes
            observed=np.r_[c['obs'],witnessed]
            ok(len(indices)==96 and not set(indices)&set(held),'train-held disjoint')
            for learner in LEARNERS:
                guess=class_predictions(learner,indices,observed,held)
                oldcorrect=int(sum(guess[:16]==c['oracle'][c['held_old']]))
                newcorrect=int(sum(guess[16:]==c['oracle'][c['held_new']]))
                ok(receipt['learned'][learner]=={'old':oldcorrect,'new':newcorrect},'independent refit '+str(key)+'/'+policy+'/'+learner)
                ok(receipt['final_fit_seconds'][learner]>=0,'time nonnegative')
                total[policy][learner]['old']+=oldcorrect
                total[policy][learner]['new']+=newcorrect
                cost[policy][learner]+=receipt['acquisition_seconds']+receipt['final_fit_seconds'][learner]
            negativesample=np.random.default_rng(choose('shuffle',policy,seed,ident,fam,n=2**32)).permutation(observed)
            sham=class_predictions('energy',indices,negativesample,c['held_new'])
            negative=int(sum(sham==c['oracle'][c['held_new']]))
            ok(negative==receipt['shuffled_energy_new'],'negative control')
            negatives[policy]+=negative
    ok(observed_worlds=={(s,w,f) for s in SEEDS for w in range(8) for f in FAMILIES},'world population complete')
    ok(total==scored['score'],'full score reaggregation')
    ok(negatives==scored['shuffled_negative'],'shuffled control aggregates')
    ok(all(abs(cost[s][l]-scored['cost_seconds'][s][l])<1e-8 for s in POLICIES for l in LEARNERS),'cost sum')
    committee=total['energy_committee']['energy']
    best_other=max(total[s][l]['new'] for s in POLICIES for l in LEARNERS if (s,l)!=('energy_committee','energy'))
    margins=[]
    for seed in SEEDS:
        subset=[c for c in scored['details'] if c['seed']==seed]
        score_by_arm={(s,l):sum(c['policies'][s]['learned'][l]['new'] for c in subset) for s in POLICIES for l in LEARNERS}
        margins.append(score_by_arm['energy_committee','energy'] - max(v for k,v in score_by_arm.items() if k!=('energy_committee','energy')))
    ok(margins==scored['seed_margins'],'seed margins')
    frozen={
        'active_accuracy_vs_strongest':(committee['new']-best_other)/3456>=.03,
        'committee_vs_uncertainty':(committee['new']-total['energy_uncertainty']['energy']['new'])/3456>=.02,
        'committee_vs_conventional_selector':(committee['new']-total['omp_committee']['energy']['new'])/3456>=.01,
        'old_retention':committee['old']>=total['paired_fixed']['energy']['old']-.01*1152,
        'seed_stability':sum(m>0 for m in margins)>=2,
        'shuffled_negative':committee['new']>negatives['energy_committee']+.05*3456,
        'whole_policy_cost':cost['energy_committee']['energy']<=1.5*cost['random']['omp12'],
    }
    ok(frozen==scored['gates'],'gates unchanged')
    ok(scored['classification']==('DEVELOPMENT_GO' if all(frozen.values()) else 'DEVELOPMENT_NO_GO'),'classification')
    ok(not scored['scientific_pass'] and not scored['native_checkpoint_run'] and scored['deployment']=='NONE','authority')
    return {'schema':'yggdrasil.energy36.audit.v1','status':'PASS','checks':checks,'worlds':72,
            'primary_json_sha256':sha256(b).hexdigest(),'source_sha256':SOURCESHA,
            'scores':total,'shuffled_controls':negatives,'gates':frozen,'seed_margins':margins,
            'audit_scope':'Independently reimplemented source generator, acquisition and all 25 trained learner combinations using shared sklearn conventional estimator library; no native model or cross-OS acceptance.'}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('file')
    p.add_argument('--out',required=True)
    args=p.parse_args()
    t=time.perf_counter()
    result=audit(args.file)
    result['audit_wall_seconds']=time.perf_counter()-t
    Path(args.out).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='scores'},indent=2))


if __name__=='__main__':main()
