"""NCI-NOVEL-05: isolated source-free causal interaction birth (not a native Yggdrasil learner)."""
from __future__ import annotations
import argparse, hashlib, itertools, json, math, pickle, time
from collections import defaultdict
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier

NOISE = 0.06
FAMILIES = ('fourfold','conj_pair','action_switch','parity_mix','unchanged','unidentifiable','degree_five')
NOVEL = FAMILIES[:4]
NEGATIVE = FAMILIES[4:]
SEEDS = (809011,809033,809057,809089)
PILOT = 809001
COUNTS = {'old_train':128,'new_train':256,'valid':64,'held_shared':64,'held_policy':64,'old_return':64}
KINDS = ('CAND','BASE','FULL','TREE','BETA','PRIOR')
STRONG = ('FULL','TREE','BETA')

def key(seed, family, phase, index, tag, action=0):
    raw = f'nci-novel05/{seed}/{family}/{phase}/{index}/{tag}/{action}'.encode('ascii')
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], 'big')

def x_for(seed, family, phase, i):
    x = tuple(key(seed,family,phase,i,f'x{j}') & 1 for j in range(4))
    if family=='unidentifiable' and phase=='new_train':
        x = (*x[:3],0)
    return x

def source_law(family, phase, x, a):
    x0,x1,x2,x3=x
    if phase in ('old_train','old_return') or family=='unchanged':
        return x0^a
    if family=='fourfold':return (x0&x1&x3&a)^x2
    if family=='conj_pair':return (x0&x3&a)^(x1&x2)
    if family=='action_switch':return (x1&x2&x3&a)^(x0&a)
    if family=='parity_mix':return (x0&x2&x3&a)^x1
    if family=='unidentifiable':return (x0&x3&a)^x2
    if family=='degree_five':return (x0&x1&x2&x3&a)^x1
    raise ValueError('unknown world')

def consequence(seed, family, phase, i, x, a):
    truth = source_law(family,phase,x,a)
    return truth ^ int(key(seed,family,phase,i,'noise',a)%10000 < 600)

def sample(seed, family, phase, i, policy=None):
    x=x_for(seed,family,phase,i)
    a=(key(seed,family,phase,i,'balanced')&1) if policy is None else int(policy(x))
    return (*x,a),consequence(seed,family,phase,i,x,a)

def episode_tape(seed, family, phase):
    return [sample(seed,family,phase,i) for i in range(COUNTS[phase])]

def signatures(degree):
    terms=[]
    for d in range(1,degree+1):
        for c in itertools.combinations(range(5),d):
            mask=sum(1<<j for j in c)
            sig=sum(int((v&mask)==mask)<<v for v in range(32))
            terms.append((sig,d,tuple(c)))
    uni=(1<<32)-1
    out={0:(0,(),0)}
    def add(sig,cost,monomials,flip):
        value=(cost,monomials,flip)
        if sig not in out or value<out[sig]:out[sig]=value
    for sig,d,c in terms:add(sig,d,(c,),0)
    for (s0,d0,c0),(s1,d1,c1) in itertools.combinations(terms,2):
        add(s0^s1,d0+d1+1,(c0,c1),0)
    for sig,(cost,ts,_) in list(out.items()):add(sig^uni,cost+1,ts,1)
    return tuple((s,c,ts,flip,any(3 in t for t in ts))
                 for s,(c,ts,flip) in sorted(out.items()))

TEMPLATES={2:signatures(2),4:signatures(4)}

class ANFBayes:
    def __init__(self,degree=4):
        self.degree=degree
        self.templates=TEMPLATES[degree]
        self.sigs=np.asarray([v[0] for v in self.templates],dtype=np.uint64)
        self.prior=np.asarray([-0.6*v[1] for v in self.templates],dtype=float)
        self.weights=None
    def fit(self,tape):
        idx=np.asarray([sum(int(b)<<j for j,b in enumerate(x)) for x,_ in tape],dtype=np.uint64)
        outcome=np.asarray([y for _,y in tape],dtype=np.uint8)
        predicted=((self.sigs[:,None]>>idx[None,:])&1).astype(np.uint8)
        scores=self.prior+np.where(predicted==outcome[None,:],math.log(1-NOISE),math.log(NOISE)).sum(axis=1)
        scores-=scores.max()
        w=np.exp(scores)
        self.weights=w/w.sum()
        return self
    def predict(self,x):
        idx=sum(int(b)<<j for j,b in enumerate(x))
        signals=((self.sigs>>idx)&1).astype(float)
        return float(NOISE+(1-2*NOISE)*np.dot(self.weights,signals))
    def identified(self):
        i=int(np.argmax(self.weights))
        return bool(self.weights[i]>=0.95 and self.templates[i][4])

class Candidate:
    def fit(self,tape):
        early=ANFBayes(2).fit(tape[:-64])
        tail=sum((early.predict(x)-y)**2 for x,y in tape[-64:])/64
        seen={tuple(x) for x,_ in tape}
        paired=sum(tuple((*v[:3],1,*v[4:])) in seen for v in seen if v[3]==0)
        self.tail_brier=tail
        self.paired=paired
        self.expanded=bool(tail>0.12 and paired>=6)
        self.model=ANFBayes(4 if self.expanded else 2).fit(tape)
        return self
    def predict(self,x):return self.model.predict(x)
    def identified(self):return self.expanded and self.model.identified()

class Tree:
    def fit(self,tape,seed):
        x=np.asarray([v for v,_ in tape],dtype=np.uint8)
        y=np.asarray([v for _,v in tape],dtype=np.uint8)
        self.model=ExtraTreesClassifier(n_estimators=128,min_samples_leaf=2,random_state=seed,n_jobs=1)
        self.model.fit(x,y)
        return self
    def predict(self,x):
        proba=self.model.predict_proba(np.asarray([x],dtype=np.uint8))[0]
        classes=self.model.classes_
        return float(proba[np.where(classes==1)[0][0]]) if 1 in classes else 0.0

class Beta:
    def fit(self,tape):
        self.counts={}
        for x,y in tape:self.counts.setdefault(tuple(x),[0,0])[y]+=1
        return self
    def predict(self,x):
        zeros,ones=self.counts.get(tuple(x),(0,0))
        return (ones+0.5)/(ones+zeros+1)

class Prior:
    def fit(self,tape):return self
    def predict(self,x):return .5

def fit(kind,tape,seed):
    if kind=='CAND':return Candidate().fit(tape)
    if kind=='BASE':return ANFBayes(2).fit(tape)
    if kind=='FULL':return ANFBayes(4).fit(tape)
    if kind=='TREE':return Tree().fit(tape,seed)
    if kind=='BETA':return Beta().fit(tape)
    if kind=='PRIOR':return Prior().fit(tape)
    raise ValueError('unknown arm')

def brier(model,tape):
    return sum((model.predict(x)-y)**2 for x,y in tape)/len(tape)

def policy(model,seed,family):
    vals=[]
    for i in range(COUNTS['held_policy']):
        x=x_for(seed,family,'held_policy',i)
        a=int(model.predict((*x,1))>model.predict((*x,0)))
        vals.append(consequence(seed,family,'held_policy',i,x,a))
    return sum(vals)/len(vals)

def single(seed,family):
    before=time.process_time()
    old=episode_tape(seed,family,'old_train')
    new=episode_tape(seed,family,'new_train')
    valid=episode_tape(seed,family,'valid')
    held=episode_tape(seed,family,'held_shared')
    ret=episode_tape(seed,family,'old_return')
    old_models={k:fit(k,old,seed) for k in KINDS}
    old_before={k:brier(v,ret) for k,v in old_models.items()}
    old_snapshot={k:hashlib.sha256(pickle.dumps(v,protocol=4)).hexdigest() for k,v in old_models.items()}
    models={k:fit(k,new,seed) for k in KINDS}
    validates={k:brier(v,valid) for k,v in models.items()}
    best=min(STRONG,key=lambda k:(validates[k],STRONG.index(k)))
    helds={k:brier(v,held) for k,v in models.items()}
    rewards={k:policy(models[k],seed,family) for k in ('CAND',best,'FULL','TREE','BETA')}
    old_after={k:brier(v,ret) for k,v in old_models.items()}
    old_stable=all(old_before[k]==old_after[k] and
        old_snapshot[k]==hashlib.sha256(pickle.dumps(v,protocol=4)).hexdigest()
        for k,v in old_models.items())
    # Same encoded old checkpoint can be cold restored for deterministic readouts.
    restore=all([brier(pickle.loads(pickle.dumps(v,protocol=4)),ret)==old_before[k]
                 for k,v in old_models.items()])
    return {'seed':seed,'family':family,'valid':validates,'selected_control':best,'held':helds,
            'policy':rewards,'old_brier_before':old_before['CAND'],
            'old_brier_after':old_after['CAND'],'old_stable':old_stable,'old_cold_readout':restore,
            'expanded':models['CAND'].expanded,'identified':models['CAND'].identified(),
            'paired_contrasts':models['CAND'].paired,'trigger_brier':models['CAND'].tail_brier,
            'cpu_seconds':time.process_time()-before}

def report(worlds,mode):
    fams=[]
    for f in FAMILIES:
        rows=[r for r in worlds if r['family']==f]
        m=lambda v:sum(v(r) for r in rows)/len(rows)
        fams.append({'family':f,'cand_brier':m(lambda r:r['held']['CAND']),
                     'control_brier':m(lambda r:r['held'][r['selected_control']]),
                     'base_brier':m(lambda r:r['held']['BASE']),
                     'cand_reward':m(lambda r:r['policy']['CAND']),
                     'control_reward':m(lambda r:r['policy'][r['selected_control']]),
                     'expanded':sum(r['expanded'] for r in rows),
                     'identified':sum(r['identified'] for r in rows),
                     'old_stable':all(r['old_stable'] and r['old_cold_readout'] for r in rows)})
    qualifying=[z for z in fams if z['family'] in NOVEL and
                z['cand_brier']<=0.95*z['control_brier'] and
                z['cand_reward']-z['control_reward']>=0.01]
    base_adv=[z for z in fams if z['family'] in NOVEL and z['cand_brier']<z['base_brier']]
    negatives=all(not r['identified'] for r in worlds if r['family'] in NEGATIVE)
    old_ok=all(r['old_stable'] and r['old_cold_readout'] and
               r['old_brier_after']<=r['old_brier_before']+0.02 for r in worlds)
    passed=(len(qualifying)>=3 and len(base_adv)>=3 and negatives and old_ok)
    return {'schema':'nci-novel05.source-free-evidence.v1','mode':mode,
            'seeds':sorted(set(r['seed'] for r in worlds)), 'families':fams,
            'qualified_novel_families':len(qualifying),'base_advantage_families':len(base_adv),
            'negative_family_no_false_positives':negatives,'old_retention_ok':old_ok,
            'science_development_go':passed,'worlds':worlds,
            'native_owner_admitted':False,'original_source_first_use':False}

def main():
    p=argparse.ArgumentParser()
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--pilot',action='store_true');g.add_argument('--primary',action='store_true')
    p.add_argument('--output',required=True)
    a=p.parse_args()
    seeds=(PILOT,) if a.pilot else SEEDS
    start=time.perf_counter()
    worlds=[single(s,f) for s in seeds for f in FAMILIES]
    result=report(worlds,'PILOT' if a.pilot else 'PRIMARY_ONCE')
    result['wall_seconds']=time.perf_counter()-start
    with open(a.output,'w',encoding='utf8') as out:
        json.dump(result,out,sort_keys=True,indent=2,allow_nan=False);out.write('\n')
    print(json.dumps({'mode':result['mode'],'worlds':len(worlds),'go':result['science_development_go'],
         'novel_gates':result['qualified_novel_families'],'negative_pass':result['negative_family_no_false_positives'],
         'old_ok':result['old_retention_ok'],'wall':result['wall_seconds']},sort_keys=True))
if __name__=='__main__':main()
