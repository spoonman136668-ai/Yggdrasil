"""Focused non-primary source-only preflight. Do not use frozen primary seeds."""
import unittest
import experiment as e

class Contracts(unittest.TestCase):
    def test_grammar_growth(self):
        self.assertGreater(len(e.TEMPLATES[4]),len(e.TEMPLATES[2]))
    def test_degree_five_outside_grammar(self):
        truth=sum(int(v==31)<<v for v in range(32))
        self.assertTrue(all(t[0]!=truth for t in e.TEMPLATES[4]))
    def test_immutable_old_source_semantics(self):
        for f in e.FAMILIES:
            self.assertEqual(e.source_law(f,'old_return',(1,0,1,1),0),1)
    def test_action_consequences_deterministic(self):
        for a in (0,1):
            self.assertEqual(e.sample(e.PILOT,'fourfold','valid',7,lambda x:a),
                             e.sample(e.PILOT,'fourfold','valid',7,lambda x:a))
    def test_source_identity_separation(self):
        self.assertNotIn(e.PILOT,e.SEEDS)
        self.assertEqual(len(set(e.SEEDS)),4)
    def test_same_public_tape_all_arms(self):
        tape=e.episode_tape(e.PILOT,'fourfold','new_train')
        self.assertEqual(len(tape),256)
        self.assertTrue(all(len(x)==5 and y in (0,1) for x,y in tape))
    def test_normalized_bayesian_posterior(self):
        model=e.ANFBayes(2).fit(e.episode_tape(e.PILOT,'fourfold','old_train'))
        self.assertAlmostEqual(float(model.weights.sum()),1.0,places=10)
    def test_train_only_candidate_trigger(self):
        model=e.Candidate().fit(e.episode_tape(e.PILOT,'fourfold','new_train'))
        self.assertTrue(isinstance(model.expanded,bool))
        self.assertTrue(0<=model.predict((0,1,0,1,0))<=1)
    def test_negative_source_zero_x3_on_train(self):
        self.assertTrue(all(x[3]==0 for x,_ in e.episode_tape(e.PILOT,'unidentifiable','new_train')))
    def test_source_budget(self):
        self.assertEqual(sum(e.COUNTS.values()),640)
    def test_trial_pilot_does_not_use_primary_seeds(self):
        self.assertNotIn(e.PILOT,e.SEEDS)

if __name__=='__main__':unittest.main()
