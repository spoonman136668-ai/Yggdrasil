"""Gate 07: output-only intervention-based causal pair identification.

Original synthetic development experiment. No Yggdrasil native first use, no
external sources, no hidden mediator observations, no learned grammar.
Run from the directory containing the frozen protocol.json.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import struct
import time
import resource
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROTO = ROOT / 'protocol.json'
RESULT = ROOT / 'result.json'
CANDIDATES = tuple((a, b, k) for a in range(4) for b in range(a + 1, 4)
                   for k in range(4) if k not in (a, b))
assert len(CANDIDATES) == 12
NOISE = 0.05


def truth(bits: int, law: tuple[int, int, int]) -> int:
    a, b, k = law
    return (((bits >> a) & 1) & ((bits >> b) & 1)) ^ ((bits >> k) & 1)


def action_cycle(rng: random.Random, repeats: int) -> list[int]:
    out = []
    for _ in range(repeats):
        cycle = list(range(16))
        rng.shuffle(cycle)
        out.extend(cycle)
    return out


def source_episode(rng: random.Random, law, negative=None):
    xs = action_cycle(rng, 4) + action_cycle(rng, 2)
    ys = []
    for bits in xs:
        if negative == 'random':
            ys.append(rng.randrange(2))
        else:
            if negative == 'xor_xor':
                a, b, k = law
                label = ((bits >> a) & 1) ^ ((bits >> b) & 1) ^ ((bits >> k) & 1)
            else:
                label = truth(bits, law)
            ys.append(label ^ int(rng.random() < NOISE))
    return list(zip(xs[:64], ys[:64])), list(zip(xs[64:], ys[64:]))


class LocalGraph:
    """Two context-local routing slots; no hidden fields or external memory.

    Byte layout: version, then for each context a context id, seen, route, 12
    uint8 cumulative mismatch scores. 31 bytes exactly. The 'mode' is fixed
    implementation code, not an undocumented learned parameter.
    """
    def __init__(self, mode: str):
        assert mode in ('adaptive', 'first16', 'fitted')
        self.mode = mode
        self.seen = [0, 0]
        self.route = [255, 255]
        self.score = [[0] * 12 for _ in range(2)]
        self.fit_comparisons = 0
        self.rewirings = 0

    def observe(self, context: int, bits: int, y: int):
        assert context in (0, 1) and 0 <= bits < 16 and y in (0, 1)
        if self.seen[context] >= 64:
            raise ValueError('held data cannot update a frozen context')
        if self.mode != 'first16' or self.seen[context] < 16:
            for i, law in enumerate(CANDIDATES):
                self.score[context][i] += truth(bits, law) != y
                self.fit_comparisons += 1
        self.seen[context] += 1
        n = self.seen[context]
        should_select = (self.mode == 'adaptive' and n % 16 == 0) or (self.mode == 'first16' and n == 16) or (self.mode == 'fitted' and n == 64)
        if should_select:
            best = min(range(12), key=lambda i: (self.score[context][i], i))
            if self.route[context] != 255 and self.route[context] != best:
                self.rewirings += 1
            self.route[context] = best

    def forecast(self, context: int, bits: int) -> float:
        selected = self.route[context]
        if selected == 255 or self.score[context][selected] > (self.seen[context] // 5):
            return 0.5
        return 0.95 if truth(bits, CANDIDATES[selected]) else 0.05

    def accepted(self, context: int) -> bool:
        q = self.route[context]
        return q != 255 and self.score[context][q] <= self.seen[context] // 5

    def packed(self) -> bytes:
        buf = bytearray([1])
        for c in (0, 1):
            buf.extend([c, self.seen[c], self.route[c], *self.score[c]])
        assert len(buf) == 31
        return bytes(buf)

    @classmethod
    def restore(cls, raw: bytes, mode: str):
        if len(raw) != 31 or raw[0] != 1:
            raise ValueError('invalid packed header/length')
        obj = cls(mode)
        for c in (0, 1):
            p = 1 + c * 15
            if raw[p] != c or raw[p + 1] > 64 or raw[p + 2] not in (*range(12), 255):
                raise ValueError('invalid context slot')
            obj.seen[c] = raw[p + 1]
            obj.route[c] = raw[p + 2]
            obj.score[c] = list(raw[p + 3:p + 15])
            if any(k > obj.seen[c] for k in obj.score[c]):
                raise ValueError('invalid score invariant')
        if obj.packed() != raw:
            raise ValueError('cold byte drift')
        return obj


class ExactBayes:
    def __init__(self):
        self.loglike = [[0.] * 12 for _ in range(2)]
        self.fit_comparisons = 0
        self.predict_comparisons = 0

    def observe(self, c: int, bits: int, y: int):
        for i, law in enumerate(CANDIDATES):
            self.loglike[c][i] += math.log(.95 if truth(bits, law) == y else .05)
            self.fit_comparisons += 1

    def forecast(self, c: int, bits: int) -> float:
        logw = self.loglike[c]
        m = max(logw)
        z = [math.exp(t - m) for t in logw]
        probs = [t / sum(z) for t in z]
        self.predict_comparisons += 12
        return sum(p * (.95 if truth(bits, law) else .05) for p, law in zip(probs, CANDIDATES))


def brier(p, y):
    return (p - y) ** 2


def run_seed(seed: int):
    rng = random.Random(seed)
    true_laws = rng.sample(list(CANDIDATES), 2)
    records = [source_episode(rng, law) for law in true_laws]
    graphs = {name: LocalGraph(name) for name in ('adaptive', 'first16', 'fitted')}
    bayes = ExactBayes()
    for c in (0, 1):
        for bits, outcome in records[c][0]:
            for learner in graphs.values():
                learner.observe(c, bits, outcome)
            bayes.observe(c, bits, outcome)
    metrics = {}
    for name, learner in graphs.items():
        checkpoint = learner.packed()
        cold = LocalGraph.restore(checkpoint, name)
        metrics[name] = {
            'checkpoint_bytes': len(checkpoint),
            'checkpoint_sha256': hashlib.sha256(checkpoint).hexdigest(),
            'exact_routes': sum(CANDIDATES[learner.route[c]] == true_laws[c] for c in (0, 1) if learner.accepted(c)),
            'accepted_routes': sum(learner.accepted(c) for c in (0, 1)),
            'rewirings': learner.rewirings,
            'candidate_fit_evaluations': learner.fit_comparisons,
            'cold_restore_exact': checkpoint == cold.packed(),
            'cold_predictions_exact': all(learner.forecast(c, bits) == cold.forecast(c, bits)
                                          for c in (0, 1) for bits in range(16)),
        }
    metrics['bayes'] = {'nominal_float64_bytes': 192, 'candidate_fit_evaluations': bayes.fit_comparisons}
    for c in (0, 1):
        held = records[c][1]
        for name, learner in [*graphs.items(), ('bayes', bayes)]:
            preds = [learner.forecast(c, bits) for bits, _ in held]
            losses = [brier(p, y) for p, (_, y) in zip(preds, held)]
            metrics[name][f'held_context_{c}_brier_sum'] = sum(losses)
            metrics[name][f'held_context_{c}_correct'] = sum((p >= .5) == bool(y) for p, (_, y) in zip(preds, held))
    return metrics


def negative_seed(seed: int, negative: str):
    rng = random.Random(seed)
    law = rng.choice(CANDIDATES)
    fit, held = source_episode(rng, law, negative=negative)
    learner = LocalGraph('adaptive')
    for bits, y in fit:
        learner.observe(0, bits, y)
    cold = LocalGraph.restore(learner.packed(), 'adaptive')
    return {'rejected': not learner.accepted(0),
            'held_brier': sum(brier(learner.forecast(0, bits), y) for bits, y in held) / len(held),
            'cold': learner.packed() == cold.packed(),
            'selected': learner.route[0]}


def summarize(rows):
    names = ('adaptive', 'first16', 'fitted', 'bayes')
    result = {}
    n = len(rows)
    for name in names:
        per = [r[name] for r in rows]
        result[name] = {
            'held_brier_mean': sum(x['held_context_0_brier_sum'] + x['held_context_1_brier_sum'] for x in per) / (64 * n),
            'return_A_brier_mean': sum(x['held_context_0_brier_sum'] for x in per) / (32 * n),
            'return_B_brier_mean': sum(x['held_context_1_brier_sum'] for x in per) / (32 * n),
            'held_accuracy': sum(x['held_context_0_correct'] + x['held_context_1_correct'] for x in per) / (64 * n),
            'candidate_fit_evaluations_total': sum(x['candidate_fit_evaluations'] for x in per),
        }
        if name != 'bayes':
            result[name].update({
                'route_recovery_fraction': sum(x['exact_routes'] for x in per) / (2 * n),
                'accepted_fraction': sum(x['accepted_routes'] for x in per) / (2 * n),
                'cold_restore_seeds_pass': sum(x['cold_restore_exact'] and x['cold_predictions_exact'] for x in per),
                'total_rewirings': sum(x['rewirings'] for x in per),
                'checkpoint_bytes': 31,
            })
        else:
            result[name]['nominal_float64_bytes'] = 192
    return result


def main():
    protocol_bytes = PROTO.read_bytes()
    protocol = json.loads(protocol_bytes)
    assert protocol['schema'] == 'yggdrasil.self-assembling.gate07.blind-mediator.dev.v1'
    assert hashlib.sha256(protocol_bytes).hexdigest() == '609d5f110801ed0eb774210aae2835c19bc0449c6835d38ab52ce20041de3034'
    start = time.perf_counter()
    seeds = list(range(2000, 2064))
    rows = [run_seed(s) for s in seeds]
    negatives = {}
    for name in ('xor_xor', 'random'):
        outcomes = [negative_seed(s, name) for s in range(3000, 3032)]
        negatives[name] = {
            'rejection_fraction': sum(r['rejected'] for r in outcomes) / len(outcomes),
            'held_brier_mean': sum(r['held_brier'] for r in outcomes) / len(outcomes),
            'cold_restore_pass': sum(r['cold'] for r in outcomes),
        }
    summary = summarize(rows)
    adaptive, first, fixed, bayes = (summary[n] for n in ('adaptive', 'first16', 'fitted', 'bayes'))
    gate = {
        'route_recovery_at_least_90pct': adaptive['route_recovery_fraction'] >= .90,
        'improvement_over_first16_at_least_0p03': first['held_brier_mean'] - adaptive['held_brier_mean'] >= .03,
        'negative_family_rejection_at_least_90pct': all(x['rejection_fraction'] >= .90 for x in negatives.values()),
        'checkpoint_at_most_64_bytes': adaptive['checkpoint_bytes'] <= 64,
        'cold_restore_64_of_64': adaptive['cold_restore_seeds_pass'] == 64,
        'scientific_superiority_over_fully_fitted_fixed': adaptive['held_brier_mean'] < fixed['held_brier_mean'],
        'scientific_superiority_over_bayesian': adaptive['held_brier_mean'] + 1e-9 < bayes['held_brier_mean'],
    }
    out = {
        'schema':'yggdrasil.self-assembling.gate07.blind-mediator.result.v1',
        'source':'synthetic contributor development only; no native Yggdrasil first use',
        'protocol_sha256':hashlib.sha256(protocol_bytes).hexdigest(),
        'seed_count':64,
        'fit_interventions':64 * 2 * 64,
        'held_interventions':64 * 2 * 32,
        'negative_fit_interventions':32 * 2 * 64,
        'negative_held_interventions':32 * 2 * 32,
        'summary':summary,
        'negative':negatives,
        'gates':gate,
        'development_go':all(gate[k] for k in ('route_recovery_at_least_90pct','improvement_over_first16_at_least_0p03','negative_family_rejection_at_least_90pct','checkpoint_at_most_64_bytes','cold_restore_64_of_64')),
        'scientific_pass':False,
        'unmatched_bayesian_resource':True,
        'elapsed_wall_seconds_diagnostic':round(time.perf_counter()-start,6),
        'peak_process_rss_ru_maxrss_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    }
    RESULT.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'development_go':out['development_go'],'gates':gate,'summary':summary,'negative':negatives,'result_file':str(RESULT)},sort_keys=True,indent=2))

if __name__ == '__main__':
    main()
