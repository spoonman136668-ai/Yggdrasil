"""Independent output-only source/control auditor for frozen Gate07 data.

Uses no experiment imports. Reconstructs seed streams, exact truth tables,
matched likelihood-score controls, cold property and submitted aggregates.
"""
from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parent
protocol_bytes = (ROOT / 'protocol.json').read_bytes()
result = json.loads((ROOT / 'result.json').read_bytes())
assert hashlib.sha256(protocol_bytes).hexdigest() == '609d5f110801ed0eb774210aae2835c19bc0449c6835d38ab52ce20041de3034'
assert result['protocol_sha256'] == hashlib.sha256(protocol_bytes).hexdigest()

# An independent declarative truth-table implementation.
models = [(i, j, k) for i in range(4) for j in range(i + 1, 4) for k in range(4) if k != i and k != j]
assert len(models) == 12

def value(bits, law):
    u, v, w = law
    return int(bool(bits & (1 << u)) and bool(bits & (1 << v))) ^ int(bool(bits & (1 << w)))

assert len(set(tuple(value(b, t) for b in range(16)) for t in models)) == 12
# The hidden grouping of (XOR XOR) is mathematically unidentifiable even with
# unlimited nonadaptive AND adaptive interventions on x when only y is seen.
for bits in range(16):
    a,b,c = (((bits >> j) & 1) for j in (0,1,2))
    assert (a ^ b) ^ c == (a ^ c) ^ b == (b ^ c) ^ a


def schedule(rng, count):
    actions = []
    for _ in range(count):
        order = list(range(16))
        rng.shuffle(order)
        actions.extend(order)
    return actions


def rebuild(seed):
    rng = random.Random(seed)
    laws = rng.sample(models,2)
    scores = {'adaptive':0.,'first16':0.,'fitted':0.}
    correct = {k:0 for k in scores}
    route_count = {k:0 for k in scores}
    accepted = {k:0 for k in scores}
    return_A = {k:0. for k in scores}
    for context, law in enumerate(laws):
        xs=schedule(rng,4) + schedule(rng,2)
        observations=[value(bits,law)^int(rng.random()<.05) for bits in xs]
        fit=list(zip(xs[:64],observations[:64]))
        hold=list(zip(xs[64:],observations[64:]))
        for mode, count in (('adaptive',64),('first16',16),('fitted',64)):
            loss=[sum(value(x,cand)!=y for x,y in fit[:count]) for cand in models]
            select=min(range(12),key=lambda i:(loss[i],i))
            isaccepted=loss[select]<=count//5
            accepted[mode]+=isaccepted
            route_count[mode]+=isaccepted and models[select]==law
            for x,y in hold:
                p=(.95 if value(x,models[select]) else .05) if isaccepted else .5
                score=(p-y)**2
                scores[mode]+=score
                correct[mode]+=(p>=.5)==bool(y)
                if context==0:
                    return_A[mode]+=score
    return scores,correct,route_count,accepted,return_A

sums={n:0. for n in ('adaptive','first16','fitted')}
corr={n:0 for n in sums}
recovery={n:0 for n in sums}
accept={n:0 for n in sums}
return_a={n:0. for n in sums}
for seed in range(2000,2064):
    metrics= rebuild(seed)
    for idx, target in enumerate((sums,corr,recovery,accept,return_a)):
        for name in sums:
            target[name]+=metrics[idx][name]
for name in sums:
    row=result['summary'][name]
    assert abs(row['held_brier_mean'] - sums[name]/(64*64)) < 1e-12, (name,'held')
    assert abs(row['return_A_brier_mean'] - return_a[name]/(32*64)) < 1e-12, (name,'return')
    assert abs(row['held_accuracy'] - corr[name]/(64*64)) < 1e-12, (name,'accuracy')
    assert row['route_recovery_fraction'] == recovery[name]/128, (name,'route')
    assert row['accepted_fraction'] == accept[name]/128, (name,'accept')
    assert row['checkpoint_bytes'] == 31
    assert row['cold_restore_seeds_pass']==64
# Reference-compute does not use private law values in candidate scoring;
# only the held-out audit does, after predictions are frozen.
assert result['gates']['scientific_superiority_over_fully_fitted_fixed'] is False
assert result['gates']['scientific_superiority_over_bayesian'] is False
assert result['gates']['improvement_over_first16_at_least_0p03'] is False
assert result['development_go'] is False
assert result['scientific_pass'] is False
assert result['negative']['random']['rejection_fraction'] == 1.
assert result['negative']['xor_xor']['rejection_fraction'] == 1.
report={'schema':'yggdrasil.self-assembling.gate07.independent-audit.v1',
        'status':'AUDIT_PASS_SCIENTIFIC_NO_GO',
        'independent_seed_recomputations':64,
        'truth_table_distinct_templates':12,
        'truth_table_input_checks':16*12,
        'xor_grouping_identity_checks':16,
        'checked_models':['adaptive','first16','fitted'],
        'protocol_sha256':hashlib.sha256(protocol_bytes).hexdigest(),
        'result_sha256':hashlib.sha256((ROOT/'result.json').read_bytes()).hexdigest(),
        'source_private_label_leakage_proven_absent':False,
        'note':'Independent numeric recomputation and algebraic negative proof; source-code provenance review separately required.'}
(ROOT/'audit.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,sort_keys=True,indent=2))
