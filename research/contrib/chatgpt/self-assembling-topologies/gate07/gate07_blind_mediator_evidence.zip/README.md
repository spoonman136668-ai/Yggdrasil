# Gate 07 — Output-only blind-mediator causal topology (development NO-GO)

**Research contributor / isolated simulation. Not native Yggdrasil training, not an independent scientific first-use, and not a qualified improvement to Amalgam.** The central Unified Causal Intelligence Amalgam Work chat remains the only cumulative native integration coordinator.

## Frozen record and execution

- Protocol frozen in separate repository commit `bd48fde11d5b2c6ff0f7c8417f13a8091e4d6857` **before new Gate 07 outcomes**. Its SHA-256 is `609d5f110801ed0eb774210aae2835c19bc0449c6835d38ab52ce20041de3034`.
- Script: `experiment.py`, SHA-256 `aae2a2bf371daa4cd5edbc2eb3845fc654536d6c89454576dd475faee58fda6a`.
- Independent numeric/algebraic auditor: `independent_audit.py`, SHA-256 `4b3aa542cebcf558ab584dca677088d6b28f598c049489e62c569a63918a21c3`.
- Frozen original result: `result.json`, SHA-256 `75f4e736d70482b14071bb8198e2e087cf7674862a6cf11d1e2fad13338b9713`.
- Original audit receipt: `audit.json`, SHA-256 `eab56f7b960fb32358c3fc56fbabe70469d7f09cef81e5df3fa55411f8923c33`.

## Causal task and controls

Four intervention bits are public. A hidden mediator computes `h = AND(x_i, x_j)` for unknown parents, and the public binary outcome is `y = h XOR x_k` with 5% independent noise. The mediator, parents and output-law tuple are **never delivered to the learner**. The intervention set is balanced, with 64 observed fit actions and 32 held outcomes per A/B context for 64 development seeds (8,192 fit interventions, 4,096 held interventions). Context cue A/B is public to every competitor. Changing tasks requires neither model reset nor training-data replay.

The *entire candidate grammar*, however, is provided: 12 AND–XOR templates. No unknown operator or arbitrary graph is invented. The 31-byte adaptive routing state has two fixed context-local slots of 12 mismatch counters, chosen route and count, plus version; it rewires deterministically every 16 observed actions. The equally compact 16-observation frozen bank and 64-observation fully fitted fixed bank use the same candidate family. A fitted exact Bayesian filter consumes the same observations but 192 nominal float64 bytes, so it is not a capacity-matched comparator.

## Results

| Method | Held Brier (lower better) | Exact route recovery | Packed state |
|---|---:|---:|---:|
| Adaptive local rewiring | **0.043369140625** | 128/128 | 31 B |
| Frozen after first 16 observations | 0.046884765625 | 126/128 | 31 B |
| Fully fitted fixed bank, 64 observations | **0.043369140625** | 128/128 | 31 B |
| Exact Bayesian full posterior | 0.043369140629 | Not applicable | 192 nominal B |

The Bayes difference is approximately `3.7e-12` Brier from numerical arithmetic: **a tie**, not superiority. The adaptive graph only improves the early frozen control by `0.003516` Brier and **fails** the frozen >=0.03 development threshold. It exactly ties the equally compact fully fitted fixed model, preventing any self-assembly superiority claim. The adaptive model did change its route twice over 64 seeded experiments; its final function is equivalent to a learned fixed route.

The unknown XOR–XOR grouping negative control is structurally non-identifiable because all bracketings of `x_i XOR x_j XOR x_k` have identical output truth tables without intermediate observations. This is an information-theoretic obstruction, not something that more rewiring can solve. The candidate model rejected unsupported structural confidence on all 32 XOR–XOR and all 32 random-label negative seeds. The independent audit recomputed all 64 A/B seed results without importing the experimental implementation, checked all 12 distinct AND–XOR truth tables and the XOR associativity identity. Audit: `AUDIT_PASS_SCIENTIFIC_NO_GO`.

### Resource accounting limitations

The 31 B figure is **packed persistent learner state**, not resident Python RAM, generator code, or total process cost. Each full-fitting learner scored 98,304 candidate/action combinations across the 64-seed study. The first-window control scored 24,576. Entire-program wall time and process `ru_maxrss` are diagnostic only and are not energy or cross-platform performance results. GitHub Actions, mandatory full repo regression and native first-use remain UNVERIFIED.

## Reproduction

Unpack `gate07_blind_mediator_evidence.zip` and, from that extracted directory:

```bash
python -B independent_audit.py
python -B experiment.py
python -B independent_audit.py
```

The first command checks the sealed original result; the experiment command regenerates with deterministic seeds but may change wall-clock and resource fields. The second audit checks the regenerated result. Preserve the original ZIP and SHA-256 rather than overwriting it.

## Disposition and next falsifiable step

**ENGINEERING (isolated): PASS. SCIENCE: DEVELOPMENT NO-GO for advantage over equally informed fixed factorization; no native qualification. DEPLOYMENT: NONE.** Do not merge into accepted main, change native weights or append evidence to the canonical checkpoint. Useful lesson: identifiability and strong matched controls must precede structural budget claims. The next non-duplicative research mechanism would need *genuinely new compositional operators without enumerated true-function grammar* and must distinguish unseen causal relations with active interventions rather than label-only reuse. Preserve this negative result.
