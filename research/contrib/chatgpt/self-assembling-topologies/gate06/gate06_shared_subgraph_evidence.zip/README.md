# Gate 06 — Shared causal subgraph transfer (exploratory)

Status: **development signal only / no native Yggdrasil scientific qualification / no promotion**.

This is an isolated synthetic simulation with 6 manipulable binary inputs, two publicly observed noisy XOR intermediate consequences, and 6 composition tasks of 32 interventions each. The trained learner sees only public interventions and consequences; the held source has private pair/operator identity. Both proposed dynamic-edge and fixed factorized models receive identical evidence and serialize to 64 bytes. Competing 64-byte flat table and memory-unmatched full Bayesian model are included.

## Reproduce

```
python experiment.py
python independent_audit.py
```

The measured runtime field in `result.json` varies with machine; all model scores and state identities are deterministic for this source. `independent_audit.py` is pinned to the frozen source and protocol hashes, and checks the recorded result SHA; run it on the unchanged bundle before rerunning `experiment.py`.

## Frozen custody

- protocol SHA-256 `27cefcf209863661f89d36d4392ca51333130d796263de773170663bd2cadd89`
- scored source SHA-256 `1dbe7452b564f3fb0c9b869204a12852765bf95e6b52e9acfd14131e9d3df7d8`
- first scored result SHA-256 `4bfda6272feb160c7e51bfdfa94c33e24c48c7a5453547610d09a19350b338c8`

## Results

- Prequential first-eight Brier, 64 development seeds: structural **0.12799442**, flat 0.24394396, factorized **0.12799442**, full Bayesian **0.12799442**.
- Paired structural minus flat: **-0.11594953**, normal-approx 95% CI [-0.12214668, -0.10975239].
- Structural minus equal-budget factorized: **0.0**, exactly tied on predictions and persistent states.
- Random-table OOD full-segment Brier, 32 negative seeds: structural **0.25733590**, versus constant 0.5 reference **0.25**. Passes preregistered 0.26 ceiling, but is worse than the trivial reference.
- Public intermediate-label shuffle makes structural first-eight Brier worse by **0.13957120**; this is evidence of dependence on acquired data, not proof of unprovided operator discovery.
- Cold checks: 24 model-level checks, exact model/score identity. Independent enumeration: 23,040 truth comparisons and 20 direct posterior steps. Independent recomputation verified the 64 development and 32 OOD aggregates.
- All 64 development seeds correctly inferred both parent pairs from 36 noisy intermediate-label training examples; the ease of the source is an important limitation.

## Interpretation

The 64-byte paired-edge representation improves dramatically over a flat lookup under this **provided compositional grammar**. It does not prove that dynamically rewiring nodes or self-assembling topology adds anything beyond a compact fixed factorized architecture; the latter matches it exactly. Full Bayes also matches, with substantially more state and candidate evaluations. No native Yggdrasil training, first-use, checkpoint modification, merge, model promotion, runner dispatch or external CI was performed.

## Next falsifiable boundary

Blind the intermediate channels; require local two-stage interventions to discover both causal parents and operator structure without a supplied known-operator catalog, and test against a fully fitted finite-hypothesis Bayesian reference and same-byte static factorization. Success would require benefit from actual structure creation/retention, not edge-index bookkeeping.
