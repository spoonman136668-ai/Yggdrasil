"""Bounded shared causal-subgraph transfer: isolated synthetic exploratory study.

The first stage supplies genuine interventions x and two *observed* intermediate
consequences. The second supplies x and a composed final consequence only.
No oracle parent ids or operator labels are passed to the learners.
This code does not access or modify a native Yggdrasil learner or repository.
"""
from __future__ import annotations
import hashlib
import json
import math
import random
import statistics
import time
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROTOCOL_BYTES = (HERE / 'protocol.json').read_bytes()
PROTO = json.loads(PROTOCOL_BYTES)
NOISE = 0.05
PAIRS = list(combinations(range(6),2))
SCHEDULE = tuple(PROTO['source']['gate_schedule'])
ALL_GATES = ('AND','OR','XOR','XNOR')
SERIAL_BYTES = 64


def bit(x, k): return (x >> k) & 1

def pair_out(x, ij): return bit(x,ij[0]) ^ bit(x,ij[1])

def gate_out(z0,z1,g):
    if g == 'AND': return z0 & z1
    if g == 'OR': return z0 | z1
    if g == 'XOR': return z0 ^ z1
    if g == 'XNOR': return 1 ^ z0 ^ z1
    raise ValueError('bad gate')

def pair_guess(x,pair_index):return pair_out(x,PAIRS[pair_index])

def compose(x, pair0, pair1, gate):
    return gate_out(pair_guess(x,pair0),pair_guess(x,pair1),gate)

def brier(p,y): return (p-y)**2

def safe_mean(a): return statistics.fmean(a) if a else float('nan')

def scenario(seed, ood=False):
    """Only source generator receives private parent/wiring and gate labels."""
    rng=random.Random(seed)
    p0=rng.randrange(len(PAIRS))
    eligible=[i for i,p in enumerate(PAIRS) if not set(p)&set(PAIRS[p0])]
    p1=rng.choice(eligible)
    train=[]
    for _ in range(36):
        x=rng.randrange(64)
        truth=(pair_guess(x,p0),pair_guess(x,p1))
        train.append((x,*(v ^ (rng.random()<NOISE) for v in truth)))
    segments=[]
    for gate in SCHEDULE:
        table=[rng.randrange(2) for _ in range(64)] if ood else None
        rows=[]
        for _ in range(32):
            x=rng.randrange(64)
            truth=table[x] if table is not None else compose(x,p0,p1,gate)
            y=int(truth ^ (rng.random()<NOISE))
            rows.append((x,y))
        segments.append(rows)
    return train,segments,(p0,p1)


class PairRule:
    """Two independently inferred input edges and a bounded composition gate.

    The explicit edges implementation and the algebraic factorized control use
    exactly the same learned sufficient statistics, predictions, and storage.
    """
    def __init__(self, structural=True):
        self.structural=structural
        self.losses=[[0]*15 for _ in range(2)]
        self.parents=[0,0]
        self.fit_n=0
        self.n=0
        self.gate_errors=[0]*4
        self.rewires=0
        self.eval_ops=0

    def fit(self,x,z0,z1):
        if self.fit_n>=36:raise ValueError('fit budget exceeded')
        for receiver,z in enumerate((z0,z1)):
            for i in range(15):
                self.losses[receiver][i]+=(pair_guess(x,i)!=z)
                self.eval_ops+=1
            chosen=min(range(15),key=lambda i:(self.losses[receiver][i],i))
            if self.structural and self.fit_n>=5 and chosen!=self.parents[receiver]:
                self.rewires+=1
            self.parents[receiver]=chosen
        self.fit_n+=1

    def start_task(self):
        if self.fit_n!=36:raise ValueError('must complete fit first')
        self.n=0
        self.gate_errors=[0]*4

    def predictions(self,x):
        p0,p1=self.parents
        z0=pair_guess(x,p0);z1=pair_guess(x,p1)
        return [gate_out(z0,z1,g) for g in ALL_GATES]

    def forecast(self,x):
        if self.n>=32:raise ValueError('task budget exceeded')
        raw=self.predictions(x)
        # Mixture: 50% unknown hypothesis (constant 0.5), 4 model gates
        # with equal prior 12.5%. No outcome or source-private label leaks.
        weights=[0.5*(0.5**self.n)]
        for e in self.gate_errors:
            weights.append(0.125*(NOISE**e)*((1-NOISE)**(self.n-e)))
        norm=sum(weights)
        q=sum(w*v for w,v in zip(weights[1:],raw))/norm
        p=(weights[0]*0.5 + norm*0 + (1-2*NOISE)*sum(w*v for w,v in zip(weights[1:],raw)) + NOISE*sum(weights[1:]))/norm
        self.eval_ops+=4
        return p

    def observe(self,x,y):
        for i,v in enumerate(self.predictions(x)):
            self.gate_errors[i]+=(v!=y)
        self.n+=1

    def snapshot(self):
        # Byte layout: [fit_n, task_n, parents[2], losses[30], gate_errors[4],
        #              zero padding[26]]. Rewire count is telemetry only.
        b=bytearray(SERIAL_BYTES)
        b[0]=self.fit_n;b[1]=self.n
        b[2:4]=bytes(self.parents)
        b[4:34]=bytes(a for row in self.losses for a in row)
        b[34:38]=bytes(self.gate_errors)
        return bytes(b)

    @classmethod
    def restore(cls,b,structural=True):
        if len(b)!=SERIAL_BYTES or any(b[38:]):raise ValueError('bad snapshot')
        m=cls(structural)
        m.fit_n=b[0];m.n=b[1];m.parents=list(b[2:4])
        m.losses=[list(b[4:19]),list(b[19:34])]
        m.gate_errors=list(b[34:38])
        if m.fit_n>36 or m.n>32 or max(m.parents)>14 or max([*m.gate_errors,*m.losses[0],*m.losses[1]])>36:
            raise ValueError('invalid snapshot fields')
        if m.snapshot()!=b:raise ValueError('roundtrip failed')
        return m


class FlatLookup:
    """One whole-outcome posterior per input using 64 packed byte counters."""
    def __init__(self):
        self.count=[0]*64
        self.ops=0
    def fit(self,x,z0,z1):
        # Receives identical training data but has no factorized mechanism.
        pass
    def start_task(self):self.count=[0]*64
    def forecast(self,x):
        v=self.count[x];n=v>>4;ones=v&15
        self.ops+=1
        return (1+ones)/(2+n)
    def observe(self,x,y):
        v=self.count[x];n=v>>4;ones=v&15
        if n>=15:raise ValueError('flat count saturation')
        self.count[x]=((n+1)<<4)|(ones+y)
    def snapshot(self):return bytes(self.count)
    @classmethod
    def restore(cls,b):
        if len(b)!=64 or any((v&15)>(v>>4) for v in b):raise ValueError('bad table')
        m=cls();m.count=list(b)
        return m


class ExactJointBayes:
    """Correct full posterior, with provided candidate family but no private truth."""
    def __init__(self):
        self.configs=[(i,j) for i,a in enumerate(PAIRS) for j,b in enumerate(PAIRS) if not set(a)&set(b)]
        assert len(self.configs)==90
        self.weights=[1/90]*90
        self.joint=[];self.unknown=0
        self.ops=0
    def fit(self,x,z0,z1):
        w=[]
        for (i,j),v in zip(self.configs,self.weights):
            v*= (1-NOISE if pair_guess(x,i)==z0 else NOISE)
            v*= (1-NOISE if pair_guess(x,j)==z1 else NOISE)
            w.append(v)
        total=sum(w);self.weights=[v/total for v in w]
        self.ops+=len(self.configs)*2
    def start_task(self):
        self.joint=[v*.125 for v in self.weights for _ in ALL_GATES]
        self.unknown=.5
    def forecast(self,x):
        active=0.
        for (i,j),gvals in zip(self.configs,range(0,len(self.joint),4)):
            z0,z1=pair_guess(x,i),pair_guess(x,j)
            for t,g in enumerate(ALL_GATES):
                active+=self.joint[gvals+t]*gate_out(z0,z1,g)
        self.ops+=len(self.joint)
        return self.unknown*.5 + (sum(self.joint)-active)*NOISE + active*(1-NOISE)
    def observe(self,x,y):
        k=0
        for i,j in self.configs:
            z0,z1=pair_guess(x,i),pair_guess(x,j)
            for gate in ALL_GATES:
                self.joint[k] *= (1-NOISE if gate_out(z0,z1,gate)==y else NOISE)
                k+=1
        self.unknown*=.5
        t=sum(self.joint)+self.unknown
        self.joint=[v/t for v in self.joint];self.unknown/=t


def models():
    return {'structural_64':PairRule(True),'factorized_64':PairRule(False),
            'flat_64':FlatLookup(),'bayes_unmatched':ExactJointBayes()}


def one_seed(seed,ood=False,shuffled=False,cold=False):
    train,segments,truth=scenario(seed,ood)
    if shuffled:
        rng=random.Random(seed^0x5A5A77)
        zs0=[a for x,a,b in train];zs1=[b for x,a,b in train]
        rng.shuffle(zs0);rng.shuffle(zs1)
        train=[(x,a,b) for (x,_,_),a,b in zip(train,zs0,zs1)]
    ms=models()
    for x,a,b in train:
        for m in ms.values():m.fit(x,a,b)
    initial_match=[int(ms['structural_64'].parents[k]==truth[k]) for k in range(2)]
    records={k:{'early':[],'all':[],'return':[]} for k in [*ms,'chance']}
    cold_pairs=0
    for seg_index,segment in enumerate(segments):
        for m in ms.values():m.start_task()
        for t,(x,y) in enumerate(segment):
            if cold and seg_index==2 and t==13:
                for key in ('structural_64','factorized_64','flat_64'):
                    old=ms[key]; raw=old.snapshot()
                    restored=type(old).restore(raw, structural=old.structural) if isinstance(old,PairRule) else type(old).restore(raw)
                    assert restored.snapshot()==raw
                    ms[key]=restored
                    cold_pairs+=1
            for key,m in ms.items():
                p=m.forecast(x)
                err=brier(p,y)
                records[key]['all'].append(err)
                if t<8:records[key]['early'].append(err)
                if seg_index>=4 and t<8:records[key]['return'].append(err)
                m.observe(x,y)
            ref=brier(.5,y)
            records['chance']['all'].append(ref)
            if t<8:records['chance']['early'].append(ref)
            if seg_index>=4 and t<8:records['chance']['return'].append(ref)
    summaries={name:{kind:safe_mean(vals) for kind,vals in v.items()} for name,v in records.items()}
    summaries['structural_64'].update(correct_parent_edges=sum(initial_match),serialized_bytes=len(ms['structural_64'].snapshot()),
            graph_rewires=ms['structural_64'].rewires,primitive_eval_ops=ms['structural_64'].eval_ops,
            final_snapshot_sha256=hashlib.sha256(ms['structural_64'].snapshot()).hexdigest())
    summaries['factorized_64'].update(serialized_bytes=len(ms['factorized_64'].snapshot()),primitive_eval_ops=ms['factorized_64'].eval_ops,
            final_snapshot_sha256=hashlib.sha256(ms['factorized_64'].snapshot()).hexdigest())
    summaries['flat_64'].update(serialized_bytes=len(ms['flat_64'].snapshot()),primitive_eval_ops=ms['flat_64'].ops)
    summaries['bayes_unmatched'].update(candidate_likelihood_evals=ms['bayes_unmatched'].ops,
            num_joint_weights=len(ms['bayes_unmatched'].joint))
    assert all(summaries[name]['serialized_bytes']==64 for name in ('structural_64','factorized_64','flat_64'))
    assert summaries['structural_64']['final_snapshot_sha256']==summaries['factorized_64']['final_snapshot_sha256']
    assert all(summaries['structural_64'][key] == summaries['factorized_64'][key] for key in ('all','early','return'))
    return summaries,cold_pairs


def mean_ci(vals):
    x=safe_mean(vals);n=len(vals)
    std=statistics.stdev(vals) if n>1 else 0
    return {'mean':x,'ci95':[x-1.96*std/math.sqrt(n),x+1.96*std/math.sqrt(n)]}


def run():
    start=time.perf_counter()
    seeds=range(PROTO['seeds']['development_first'],PROTO['seeds']['development_first']+PROTO['seeds']['development_count'])
    trials=[]
    for s in seeds:trials.append(one_seed(s)[0])
    negative=[one_seed(s,ood=True)[0] for s in range(PROTO['seeds']['negative_first'],PROTO['seeds']['negative_first']+PROTO['seeds']['negative_count'])]
    shuffled=[one_seed(s,shuffled=True)[0] for s in seeds]
    cold=[one_seed(s,cold=True) for s in range(PROTO['seeds']['cold_first'],PROTO['seeds']['cold_first']+PROTO['seeds']['cold_count'])]
    # Compare after forced restore to the uninterrupted run (including serial state).
    cold_equal=0
    for i,(restored,c) in enumerate(cold):
        original,_=one_seed(PROTO['seeds']['cold_first']+i)
        for key in ('structural_64','factorized_64','flat_64'):
            for metric in ('early','all','return'):
                assert original[key][metric]==restored[key][metric]
            if key!='flat_64':assert original[key]['final_snapshot_sha256']==restored[key]['final_snapshot_sha256']
            cold_equal+=1
    kinds=('early','all','return')
    report={'schema':PROTO['schema'],'protocol_sha256':hashlib.sha256(PROTOCOL_BYTES).hexdigest(),
            'development_seeds':len(trials),'development_outcomes':len(trials)*6*32,
            'negative_seeds':len(negative),'cold_seeds':len(cold),'cold_model_exact_checks':cold_equal,
            'models':{},'paired':{},'negative':{},'shuffled':{},'elapsed_wall_seconds':None}
    for name in ('structural_64','factorized_64','flat_64','bayes_unmatched','chance'):
        report['models'][name]={k:mean_ci([v[name][k] for v in trials]) for k in kinds}
        report['negative'][name]={k:mean_ci([v[name][k] for v in negative]) for k in ('early','all')}
    report['models']['structural_64']['mean_correct_parent_edges']=safe_mean([v['structural_64']['correct_parent_edges'] for v in trials])
    report['models']['structural_64']['mean_graph_rewires']=safe_mean([v['structural_64']['graph_rewires'] for v in trials])
    for name in ('flat_64','factorized_64','bayes_unmatched'):
        report['paired'][f'structural_minus_{name}']=mean_ci([r['structural_64']['early']-r[name]['early'] for r in trials])
    report['shuffled']['structural_early']=mean_ci([r['structural_64']['early'] for r in shuffled])
    report['shuffled']['structural_early_minus_unshuffled']=mean_ci([s['structural_64']['early']-r['structural_64']['early'] for s,r in zip(shuffled,trials)])
    for name in ('structural_64','factorized_64','flat_64'):
        report['models'][name]['serialized_state_bytes']=64
    report['models']['structural_64']['mean_candidate_evals']=safe_mean([v['structural_64']['primitive_eval_ops'] for v in trials])
    report['models']['bayes_unmatched']['mean_candidate_evals']=safe_mean([v['bayes_unmatched']['candidate_likelihood_evals'] for v in trials])
    report['models']['bayes_unmatched']['joint_posterior_components']=360
    diff=report['paired']['structural_minus_flat_64']['mean']
    ood=report['negative']['structural_64']['all']['mean']
    report['thresholds']={'delta_primary_vs_flat':-0.03,'max_ood_brier':0.26,'max_bytes':64}
    report['gate_conditions']={'beats_flat_by_0p03':diff<=-.03,
                                'ood_le_0p26':ood<=.26,'cold_exact':cold_equal==24,
                                'serialized_64':True,
                                'beats_equivalent_factorized':report['paired']['structural_minus_factorized_64']['mean']<0}
    report['development_disposition']='DEVELOPMENT_SIGNAL_ONLY' if all(report['gate_conditions'][k] for k in ('beats_flat_by_0p03','ood_le_0p26','cold_exact','serialized_64')) else 'DEVELOPMENT_NO_GO'
    report['scientific_pass']=False
    report['limitations']=['No source-native Yggdrasil execution','Supplied XOR/gate grammar','Factorized control yields same behavior as dynamic graph','Bayes memory unmatched','Logical serialized state excludes Python process and code']
    report['elapsed_wall_seconds']=time.perf_counter()-start
    (HERE/'result.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True,indent=2))

if __name__=='__main__':run()
