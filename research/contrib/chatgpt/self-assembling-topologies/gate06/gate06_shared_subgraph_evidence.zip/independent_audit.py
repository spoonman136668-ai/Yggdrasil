"""Independent frozen-result audit and direct finite-case reference checks.

No train, promotion, native Yggdrasil, remote execution or hidden labels.
"""
import importlib.util
import hashlib
import json
import math
import statistics
from itertools import product
from pathlib import Path

P=Path(__file__).resolve().parent
EXPECTED_PROTOCOL='27cefcf209863661f89d36d4392ca51333130d796263de773170663bd2cadd89'
EXPECTED_SOURCE='1dbe7452b564f3fb0c9b869204a12852765bf95e6b52e9acfd14131e9d3df7d8'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'protocol.json')==EXPECTED_PROTOCOL,'protocol changed'
assert sha(P/'experiment.py')==EXPECTED_SOURCE,'scored source changed'
result=json.loads((P/'result.json').read_text())
assert result['protocol_sha256']==EXPECTED_PROTOCOL
spec=importlib.util.spec_from_file_location('mechanism',P/'experiment.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

# Independently enumerate all input/two-edge compositions through direct bits.
checks=0
for x in range(64):
    for p0,a in enumerate(m.PAIRS):
        for p1,b in enumerate(m.PAIRS):
            if set(a)&set(b):continue
            z0=((x>>a[0])&1)^((x>>a[1])&1)
            z1=((x>>b[0])&1)^((x>>b[1])&1)
            reference={'AND':z0&z1,'OR':z0|z1,'XOR':z0^z1,'XNOR':1^z0^z1}
            for g in reference:
                assert m.compose(x,p0,p1,g)==reference[g]
                checks+=1
assert checks==64*90*4

# Direct product-of-likelihoods reference, avoiding the learner's update math.
s=50007
training,segments,truth=m.scenario(s)
a=m.PairRule(True)
for x,z0,z1 in training:a.fit(x,z0,z1)
a.start_task()
trace=[]
posterior_checks=0
for t,(x,y) in enumerate(segments[0][:20]):
    z0=((x>>m.PAIRS[a.parents[0]][0])&1)^((x>>m.PAIRS[a.parents[0]][1])&1)
    z1=((x>>m.PAIRS[a.parents[1]][0])&1)^((x>>m.PAIRS[a.parents[1]][1])&1)
    def op(z0,z1,g):
        return {'AND':z0&z1,'OR':z0|z1,'XOR':z0^z1,'XNOR':1^z0^z1}[g]
    raw=[]
    for gate in m.ALL_GATES:
        probability=.125
        for xx,yy in trace:
            aa,bb=m.PAIRS[a.parents[0]],m.PAIRS[a.parents[1]]
            za=((xx>>aa[0])&1)^((xx>>aa[1])&1)
            zb=((xx>>bb[0])&1)^((xx>>bb[1])&1)
            probability *= (.95 if op(za,zb,gate)==yy else .05)
        raw.append(probability)
    unknown=.5*(.5**t)
    expected=(unknown*.5 + sum(w*(.95 if op(z0,z1,gate) else .05)
                               for w,gate in zip(raw,m.ALL_GATES)))/(unknown+sum(raw))
    assert abs(a.forecast(x)-expected)<1e-12,(t,a.forecast(x),expected)
    posterior_checks+=1
    trace.append((x,y));a.observe(x,y)

# New independent replay of development and OOD seed batches, same locked source.
seeds=range(41000,41064)
raw=[m.one_seed(s)[0] for s in seeds]
neg=[m.one_seed(s,ood=True)[0] for s in range(42000,42032)]
for label,arr in [('structural_64',raw),('flat_64',raw),('factorized_64',raw),('bayes_unmatched',raw)]:
    actual=statistics.fmean(v[label]['early'] for v in arr)
    expected=result['models'][label]['early']['mean']
    assert actual==expected,(label,actual,expected)
for label in ('structural_64','factorized_64','flat_64','bayes_unmatched'):
    actual=statistics.fmean(v[label]['all'] for v in neg)
    expected=result['negative'][label]['all']['mean']
    assert actual==expected,(label,actual,expected)
assert all(x['structural_64']['early']==x['factorized_64']['early'] for x in raw)
assert all(x['structural_64']['final_snapshot_sha256']==x['factorized_64']['final_snapshot_sha256'] for x in raw)

# Force invalid input snapshots to be rejected rather than silently repaired.
payload=a.snapshot()
for bad in (payload[:63],payload[:38]+b'\x01'+payload[39:],bytes([255])+payload[1:]):
    try:m.PairRule.restore(bad)
    except ValueError:pass
    else:raise AssertionError('malformed snapshot accepted')

# This limitation MUST be published: the graph is only edge-index replacement;
# factorized arithmetic exactly emulates it with no structural mechanism.
report={
  'schema':'bounded-shared-subgraph-transfer.audit.v1',
  'protocol_sha256':EXPECTED_PROTOCOL,'scored_source_sha256':EXPECTED_SOURCE,
  'scored_result_sha256':sha(P/'result.json'),
  'finite_reference_truth_evaluations':checks,
  'independent_posterior_step_checks':posterior_checks,
  'independent_recomputed_development_seeds':len(raw),
  'independent_recomputed_negative_seeds':len(neg),
  'all_reported_seed_aggregates_exact':True,
  'equivalent_factorized_readout_exact':True,
  'snapshot_malformed_negatives_rejected':3,
  'causal_identifiability_limit':'Intermediate links directly observed in training, known XOR hypothesis family and task-boundary signals',
  'structural_uniqueness_limit':'Graph edge rewiring is only a representation of parent indices, no gain beyond fixed factorized model',
  'actual_process_memory_measured':False,
  'native_Yggdrasil_qualification':False,
  'status':'AUDIT_PASS_WITH_SCIENTIFIC_NONPROMOTION'
}
(P/'audit.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,sort_keys=True,indent=2))
